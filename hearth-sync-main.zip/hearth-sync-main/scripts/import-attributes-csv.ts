/**
 * import-attributes-csv.ts
 *
 * Reads temp/missing-attributes.csv and upserts each row as a ProductAttribute.
 * Matches on slug (unique key) — safe to run multiple times.
 *
 * Run: npx tsx scripts/import-attributes-csv.ts
 *      DRY_RUN=true npx tsx scripts/import-attributes-csv.ts
 */

import prisma from '../src/lib/db';
import fs from 'fs';
import path from 'path';

const DRY_RUN = process.env.DRY_RUN === 'true';
const CSV_PATH = path.resolve('temp/missing-attributes.csv');

function parseCSV(content: string): Record<string, string>[] {
    const lines = content.split('\n').filter(l => l.trim());
    const headers = parseCSVLine(lines[0]);
    return lines.slice(1).map(line => {
        const vals = parseCSVLine(line);
        return Object.fromEntries(headers.map((h, i) => [h.trim(), (vals[i] ?? '').trim()]));
    });
}

function parseCSVLine(line: string): string[] {
    const result: string[] = [];
    let current = '';
    let inQuotes = false;
    for (let i = 0; i < line.length; i++) {
        const ch = line[i];
        if (ch === '"') {
            inQuotes = !inQuotes;
        } else if (ch === ',' && !inQuotes) {
            result.push(current);
            current = '';
        } else {
            current += ch;
        }
    }
    result.push(current);
    return result;
}

async function main() {
    console.log(`\n🔍  Mode: ${DRY_RUN ? 'DRY RUN (no writes)' : 'LIVE'}\n`);

    const content = fs.readFileSync(CSV_PATH, 'utf-8');
    const rows = parseCSV(content);

    console.log(`Found ${rows.length} attribute(s) in CSV.\n`);

    let created = 0;
    let updated = 0;
    let skipped = 0;

    for (const row of rows) {
        const slug = row.slug;
        if (!slug) { console.warn('  ⚠ Row has no slug, skipping:', row); continue; }

        const existing = await prisma.productAttribute.findUnique({ where: { slug } });

        const data = {
            name:      row.name,
            slug,
            dataType:  row.dataType as any,
            unit:      row.unit || null,
            options:   row.options || null,
            description: row.description || null,
            sortOrder: parseInt(row.sortOrder || '0', 10),
            isSystem:  row.isSystem === 'true',
        };

        if (existing) {
            console.log(`  ~ EXISTS: "${slug}" — skipping (already in DB)`);
            skipped++;
            continue;
        }

        console.log(`  + ${DRY_RUN ? '[dry] ' : ''}Creating: "${data.name}" (${data.dataType})`);
        if (!DRY_RUN) {
            await prisma.productAttribute.create({ data });
        }
        created++;
    }

    console.log(`\n✅  Done.`);
    console.log(`   Created : ${DRY_RUN ? '(dry run) ' : ''}${created}`);
    console.log(`   Skipped : ${skipped}`);
    console.log(`   Updated : ${updated}`);
}

main()
    .catch(err => { console.error(err); process.exit(1); })
    .finally(() => prisma.$disconnect());
