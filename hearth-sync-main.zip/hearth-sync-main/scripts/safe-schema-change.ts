/**
 * scripts/safe-schema-change.ts
 * ─────────────────────────────────────────────────────────────────────────────
 * The ONLY safe way to apply Prisma schema changes in this project.
 *
 * Usage:
 *   npm run db:safe-migrate -- --name <migration-name>
 *   npx tsx scripts/safe-schema-change.ts --name add-ftp-table
 *
 * What it does (in order):
 *   1. Computes the schema diff   (shows what SQL will run — no changes yet)
 *   2. Detects destructive ops    (DROP TABLE, DROP COLUMN, TRUNCATE, etc.)
 *   3. Auto-backup                (prisma/backups/ — always, not just on destructive)
 *   4. Generate seed snapshot     (prisma/seeds/snapshots/ — captures full live state)
 *   5. Confirms with user         (if destructive, asks for explicit confirmation)
 *   6. Applies migration          (prisma migrate dev --name <label>)
 *   7. Regenerates Prisma client  (prisma generate)
 *   8. Re-seeds reference data    (prisma db seed — idempotent upserts)
 *
 * DO NOT USE db:migrate or db:push directly. They skip the backup/snapshot steps.
 * ─────────────────────────────────────────────────────────────────────────────
 */

import { execSync } from 'child_process';
import * as readline from 'readline';

const DESTRUCTIVE_PATTERNS = [
    /DROP TABLE/i,
    /DROP COLUMN/i,
    /DROP INDEX/i,
    /ALTER COLUMN.*NOT NULL/i,
    /TRUNCATE/i,
];

function run(cmd: string, opts: { capture?: boolean } = {}): string {
    console.log(`\n$ ${cmd}`);
    if (opts.capture) {
        return execSync(cmd, { encoding: 'utf8' });
    }
    execSync(cmd, { stdio: 'inherit' });
    return '';
}

async function confirm(question: string): Promise<boolean> {
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
    return new Promise(resolve => {
        rl.question(`\n⚠️  ${question} (yes/no): `, answer => {
            rl.close();
            resolve(answer.toLowerCase() === 'yes');
        });
    });
}

async function main() {
    // Parse --name argument
    const nameIdx = process.argv.indexOf('--name');
    const migrationName = nameIdx !== -1 ? process.argv[nameIdx + 1] : null;

    if (!migrationName) {
        console.error('\n❌ Missing --name argument.');
        console.error('   Usage: npm run db:safe-migrate -- --name <descriptive-migration-name>');
        console.error('   Example: npm run db:safe-migrate -- --name add-ftp-inbound-table\n');
        process.exit(1);
    }

    const safeLabel = migrationName.replace(/\s+/g, '-').replace(/[^a-z0-9-]/gi, '').toLowerCase();

    console.log('\n🔒 HearthSync Safe Migration\n' + '='.repeat(50));
    console.log(`   Migration: ${safeLabel}\n`);

    // ── Step 1: Compute diff ──────────────────────────────────────────────────
    console.log('[1/7] Computing schema diff (no changes applied yet)...');
    let diff = '';
    try {
        diff = run(
            'npx prisma migrate diff --from-schema-datasource prisma/schema.prisma --to-schema-datamodel prisma/schema.prisma --script',
            { capture: true },
        );
    } catch {
        try {
            diff = execSync(
                'npx prisma migrate diff --from-schema-datasource prisma/schema.prisma --to-schema-datamodel prisma/schema.prisma --script 2>&1',
                { encoding: 'utf8' },
            );
        } catch (e: any) {
            diff = e.stdout || '';
        }
    }

    if (!diff.trim() || diff.includes('No difference detected')) {
        console.log('\n✅ Schema is already in sync with the database. Nothing to do.');
        process.exit(0);
    }

    console.log('\n--- SQL that will be applied ---');
    console.log(diff);
    console.log('--------------------------------');

    // ── Step 2: Detect destructive operations ─────────────────────────────────
    const destructiveLines = DESTRUCTIVE_PATTERNS
        .flatMap(pattern => diff.split('\n').filter(line => pattern.test(line)));

    if (destructiveLines.length > 0) {
        console.log('\n🚨 DESTRUCTIVE OPERATIONS DETECTED:');
        destructiveLines.forEach(l => console.log('   ❌', l.trim()));
        console.log('\n   These operations can cause DATA LOSS.');
    } else {
        console.log('\n✅ No destructive operations detected (additive changes only).');
    }

    // ── Step 3: Auto-backup (always runs) ─────────────────────────────────────
    console.log(`\n[2/7] Creating full database backup...`);
    run(`npx tsx prisma/backup.ts --label "${safeLabel}"`);

    // ── Step 4: Generate seed snapshot (always runs) ──────────────────────────
    console.log(`\n[3/7] Generating seed snapshot of live state...`);
    run(`npx tsx prisma/seeds/generate-seed.ts --label "${safeLabel}"`);

    // ── Step 5: Confirm if destructive ────────────────────────────────────────
    if (destructiveLines.length > 0) {
        console.log('\n   Backup and snapshot created. You can restore with:');
        console.log(`   npm run db:restore`);
        console.log(`   npm run db:seed:restore\n`);

        const proceed = await confirm(
            `Destructive operations detected. Backup and snapshot are saved. Proceed with migration "${safeLabel}"?`
        );
        if (!proceed) {
            console.log('\n✋ Migration aborted. No schema changes made.');
            console.log('   Backup:   prisma/backups/ (latest folder)');
            console.log('   Snapshot: prisma/seeds/snapshots/ (latest folder)\n');
            process.exit(0);
        }
    }

    // ── Step 6: Apply migration ───────────────────────────────────────────────
    console.log(`\n[4/7] Applying migration via prisma migrate dev...`);
    run(`npx prisma migrate dev --name ${safeLabel}`);

    // ── Step 7: Regenerate Prisma client ──────────────────────────────────────
    console.log('\n[5/7] Regenerating Prisma client...');
    run('npx prisma generate');

    // ── Step 8: Re-seed reference data ───────────────────────────────────────
    console.log('\n[6/7] Re-seeding reference data (categories, manufacturers, brands)...');
    run('npx prisma db seed');

    console.log('\n[7/7] Done!\n');
    console.log('='.repeat(50));
    console.log('✅ Migration complete!');
    console.log(`   Migration name: ${safeLabel}`);
    console.log('   Backup:         prisma/backups/ (latest)');
    console.log('   Snapshot:       prisma/seeds/snapshots/ (latest)');
    console.log('\n   ⚠️  Restart the dev server to pick up the regenerated Prisma client.');
    console.log('   If data is missing, run:  npm run db:restore\n');
}

main().catch(e => {
    console.error('\n❌ Migration failed:', e.message);
    console.error('   The backup and snapshot created in steps 2-3 are still available.');
    console.error('   Run: npm run db:restore   to recover data.');
    process.exit(1);
});
