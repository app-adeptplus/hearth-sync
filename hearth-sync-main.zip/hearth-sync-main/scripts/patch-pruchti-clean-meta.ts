/**
 * Patches pruchti@adeptplus.com:
 * - Ensures app_metadata.portal_role = 'admin' is set (canonical, tamper-proof)
 * - Removes portal_role from user_metadata (user-editable, should not hold security roles)
 */
import { createClient } from '@supabase/supabase-js';
import * as dotenv from 'dotenv';
import * as fs from 'fs';

dotenv.config({ path: '.env' });

const supabase = createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!,
    { auth: { autoRefreshToken: false, persistSession: false } }
);

async function main() {
    const targetEmail = 'pruchti@adeptplus.com';

    const { data } = await supabase.auth.admin.listUsers({ perPage: 100 });
    const user = data?.users.find(u => u.email?.toLowerCase() === targetEmail);

    if (!user) {
        console.error(`No user found for ${targetEmail}`);
        return;
    }

    console.log(`Found user: ${user.id}`);
    console.log(`  Current app_metadata:  ${JSON.stringify(user.app_metadata)}`);
    console.log(`  Current user_metadata: ${JSON.stringify(user.user_metadata)}`);

    // Step 1: Ensure app_metadata has portal_role: admin (it already does, but re-stamp to be safe)
    const { error: appError } = await supabase.auth.admin.updateUserById(user.id, {
        app_metadata: { portal_role: 'admin' },
    });
    if (appError) throw new Error(`Failed to set app_metadata: ${appError.message}`);
    console.log(`✓ app_metadata.portal_role = 'admin' confirmed`);

    // Step 2: Remove portal_role from user_metadata, keep all other fields
    const { portal_role: _removed, ...cleanUserMeta } = user.user_metadata ?? {};
    const { error: userError } = await supabase.auth.admin.updateUserById(user.id, {
        user_metadata: cleanUserMeta,
    });
    if (userError) throw new Error(`Failed to clean user_metadata: ${userError.message}`);
    console.log(`✓ portal_role removed from user_metadata (kept: ${JSON.stringify(cleanUserMeta)})`);

    // Verify
    const { data: verifyData } = await supabase.auth.admin.getUserById(user.id);
    const verifiedUser = verifyData?.user;
    console.log(`\nFinal state for ${targetEmail}:`);
    console.log(`  app_metadata:  ${JSON.stringify(verifiedUser?.app_metadata)}`);
    console.log(`  user_metadata: ${JSON.stringify(verifiedUser?.user_metadata)}`);
}

main().catch(console.error);
