/**
 * seed-remaining-mappings.ts
 *
 * Comprehensive pass that adds category mappings for:
 *   1. All 26 attributes with zero category mappings after the initial seed
 *   2. Attributes that already had SOME mappings but are under-mapped relative
 *      to what the research suggests (identified from low map counts in the DB)
 *
 * SAFE: Uses findFirst before create — idempotent, no duplicates created.
 *
 * Run:  npx tsx scripts/seed-remaining-mappings.ts
 *       DRY_RUN=true npx tsx scripts/seed-remaining-mappings.ts
 */

import prisma from '../src/lib/db';

// ─────────────────────────────────────────────────────────────────────────────
// MAPPING: attribute slug → additional categories to map it to
// ─────────────────────────────────────────────────────────────────────────────

const ATTR_TO_CATEGORIES: Record<string, string[]> = {

    // ═══════════════════════════════════════════════════════════════════════
    // GROUP 1 — Previously UNMAPPED (0 mappings): newly created attributes
    //           + pre-existing attributes that slipped through
    // ═══════════════════════════════════════════════════════════════════════

    // ── Hearth ────────────────────────────────────────────────────────────

    // Child of Fuel Type = Wood
    'wood-sub-type': ['fireplace', 'insert', 'stove'],

    // Child of Fuel Type = Gas — convertible NG/LP units
    'convertible-ng-lp': ['fireplace', 'insert', 'stove', 'vented-log-sets', 'vent-free-log-sets', 'burner'],

    // Grandchild — only relevant when convertible = Yes
    'conversion-kit-included': ['fireplace', 'insert', 'stove', 'vented-log-sets', 'vent-free-log-sets'],

    // Insert-specific venting spec
    'co-linear-capable': ['insert'],

    // EPA wood-burning emissions — child of Certifications
    'emissions-g-hr': ['fireplace', 'insert', 'stove'],

    // ── Grills ────────────────────────────────────────────────────────────

    'stainless-steel-grade': ['built-in', 'portable-cart', 'portable', 'smoker', 'griddle'],
    'lid-material':          ['built-in', 'portable-cart', 'portable', 'griddle'],
    'pellet-sub-type':       ['smoker', 'portable-cart', 'built-in'],

    // ── Outdoor Kitchen & Living ──────────────────────────────────────────

    'island-configuration':  ['outdoor-kitchen-island'],
    'frame-material':        ['outdoor-kitchen-island'],
    'counter-material':      ['outdoor-kitchen-island'],
    'sink-included':         ['outdoor-kitchen-island'],
    'refrigerator-included': ['outdoor-kitchen-island'],
    'refrigerator-volume':   ['outdoor-kitchen-island'],
    'table-top-material':    ['fire-table', 'table'],
    'burner-included':       ['fire-pit', 'fire-table'],
    'fuel-supply':           ['heater'],

    // ── Pre-existing, never mapped ────────────────────────────────────────

    'fuel-tank-location':   ['portable-cart', 'portable', 'heater'],
    'number-of-grates':     ['built-in', 'portable-cart', 'portable', 'kamado'],
    'chimney-included':     ['smoker', 'pizza-oven', 'stove'],
    'app-compatible':       ['smoker', 'fireplace', 'insert', 'heater'],

    // ── Warranties ────────────────────────────────────────────────────────

    // Firebox warranty — products with a combustion chamber
    'firebox-warranty': ['fireplace', 'insert', 'stove', 'firebox'],

    // Burner warranty — covers all gas-burning products
    'burner-warranty': [
        'fireplace', 'insert', 'stove',
        'vented-log-sets', 'vent-free-log-sets',
        'fire-pit', 'fire-table', 'burner',
        'heater',
        'built-in', 'portable-cart', 'portable',
    ],

    // Heat exchanger warranty — gas/pellet hearth products
    'heat-exchanger-warranty': ['fireplace', 'insert', 'stove'],

    // Paint/finish warranty — metal-bodied products with painted surfaces
    'paint-finish-warranty': [
        'fireplace', 'insert', 'stove', 'firebox',
        'built-in', 'portable-cart', 'portable',
        'kamado', 'smoker', 'pizza-oven', 'griddle',
    ],

    // Outdoor finish warranty — products exposed to weather
    'finish-warranty-outdoor': [
        'fire-pit', 'fire-table', 'heater',
        'outdoor-kitchen-island', 'patio-furniture',
        'seating', 'table', 'spa', 'water-feature',
        'outdoor-lighting',
    ],

    // ═══════════════════════════════════════════════════════════════════════
    // GROUP 2 — Under-mapped: HAD some mappings but research shows wider scope
    // ═══════════════════════════════════════════════════════════════════════

    // Vent Termination Type — maps: 1. Direct/B-vent applies to all vented hearth products
    'vent-termination-type': ['fireplace', 'insert', 'stove', 'vent-free-log-sets'],

    // Flame Color — maps: 1. Applies anywhere fire media is present
    'flame-color': ['fireplace', 'insert', 'fire-pit', 'fire-table', 'vented-log-sets', 'vent-free-log-sets'],

    // Log Set Size — maps: 2. Should exist on log sets AND fireplaces/inserts that fit log sets
    'log-set-size': ['fireplace', 'insert', 'vented-log-sets', 'vent-free-log-sets'],

    // BTU Input Min — maps: 1. Modulating valve available on inserts and stoves too
    'btu-input-min': ['fireplace', 'insert', 'stove'],

    // Efficiency Type — maps: 1. Clarifies rating method for all high-efficiency products
    'efficiency-type': ['fireplace', 'insert', 'stove'],

    // Viewing Area — maps: 1. Inserts also have a viewing glass dimension
    'viewing-area': ['fireplace', 'insert'],

    // Parts Warranty — maps: 1 (pre-existing). Should span all major product types
    'parts-warranty': [
        'fireplace', 'insert', 'stove', 'firebox',
        'vented-log-sets', 'vent-free-log-sets',
        'built-in', 'portable-cart', 'portable', 'kamado',
        'smoker', 'pizza-oven', 'griddle',
        'heater', 'fire-pit', 'fire-table',
    ],

    // Battery Backup Included — maps: 3. Also relevant to smart outdoor heaters
    'battery-backup-included': ['heater', 'fire-pit'],

    // Blower CFM — maps: 2. Stoves also have blowers
    'blower-cfm': ['stove'],

    // Blower Included — maps: 4. Stoves with blowers
    'blower-included': ['stove'],

    // Firebox Depth — maps: 4. Should also include stove (for wood length specification)
    'firebox-depth': ['stove'],

    // Cooking Surface Size — maps: 1 (pizza-oven). Griddle also has a relevant cooking surface
    'cooking-surface-size': ['griddle'],

    // Secondary/Warming Area — maps: 4. Also relevant for kamado with raised racks
    'secondary-warming-area': ['kamado'],

    // Smart/WiFi — maps: 8. Fireplaces increasingly have smart control
    'wifi-enabled': ['fireplace', 'insert'],

    // Bluetooth — maps: 9. Same as WiFi — relevant for smart hearth
    'bluetooth-enabled': ['fireplace', 'insert'],

    // Remote included — maps 5 (hearth). Some heaters also come with remote
    'remote-included': ['heater'],

    // Safety Shutoff — maps: 7. Also relevant for heaters and outdoor kitchen appliances
    'safety-shutoff': ['outdoor-kitchen-island', 'outdoor-kitchen-accessories'],

    // Installation Type — maps: 5 (hearth). Also applies to outdoor kitchens (built-in vs freestanding)
    'installation-type': ['outdoor-kitchen-island'],

    // Framing Opening — maps: 3. Firebox also has an opening specification
    'framing-opening': ['firebox', 'stove'],

    // Frame/Surround Finish — maps: 4. Also relevant for fire tables (frame finish)
    'frame-surround-finish': ['fire-table', 'fire-pit'],

    // Glass Type — maps: 4. Fire feature table tops sometimes use tempered glass
    'glass-type': ['fire-table'],

    // Body Material — maps: 9. Also relevant for fire pit bodies
    'body-material': ['fire-pit', 'fire-table'],

    // Grate Style — maps for grills. Also relevant for hearth wood grates
    'grate-style': ['stove'],

    // Ignition Type (hearth) — maps: 9. Torch is gas-ignited
    'ignition-type': ['torch'],

    // Indoor/Outdoor Use — maps: 18. Spa and water features often need this
    'indoor-outdoor-use': ['spa', 'water-feature'],

    // Cover Included — maps: 5. Spa, outdoor kitchen
    'cover-included': ['spa', 'outdoor-kitchen-island'],

    // Assembly Required — maps: 7. Fire pit and fire table often require assembly
    'assembly-required': ['fire-pit', 'fire-table', 'built-in'],

    // Portable — maps: 7. Also fire tables and heaters can be portable
    'portable': ['fire-table', 'heater'],
};

// ─────────────────────────────────────────────────────────────────────────────

const DRY_RUN = process.env.DRY_RUN === 'true';

async function main() {
    console.log(`\n🔍  Mode: ${DRY_RUN ? 'DRY RUN (no writes)' : 'LIVE'}\n`);

    const categories = await prisma.productCategory.findMany({
        where: { parentId: { not: null } },
        select: { id: true, name: true, slug: true },
    });

    const attributes = await prisma.productAttribute.findMany({
        select: { id: true, name: true, slug: true },
    });

    const catBySlug  = new Map(categories.map(c => [c.slug, c]));
    const attrBySlug = new Map(attributes.map(a => [a.slug, a]));

    let created  = 0;
    let skipped  = 0;
    let attrMiss = 0;
    let catMiss  = 0;

    for (const [attrSlug, catSlugs] of Object.entries(ATTR_TO_CATEGORIES)) {
        const attribute = attrBySlug.get(attrSlug);
        if (!attribute) {
            console.warn(`⚠  Attribute not found: "${attrSlug}"`);
            attrMiss++;
            continue;
        }

        for (const catSlug of catSlugs) {
            const category = catBySlug.get(catSlug);
            if (!category) {
                console.warn(`   ↳ Category not found: "${catSlug}" (attr: ${attrSlug})`);
                catMiss++;
                continue;
            }

            const existing = await prisma.categoryAttributeMap.findFirst({
                where: { categoryId: category.id, attributeId: attribute.id },
            });
            if (existing) { skipped++; continue; }

            console.log(`  + ${attribute.name}  →  ${category.name}`);

            if (!DRY_RUN) {
                await prisma.categoryAttributeMap.create({
                    data: {
                        categoryId:   category.id,
                        attributeId:  attribute.id,
                        isRequired:   false,
                        isFilterable: false,
                        sortOrder:    0,
                    },
                });
            }
            created++;
        }
    }

    console.log(`\n✅  Done.`);
    console.log(`   Mappings created   : ${DRY_RUN ? '(dry run) ' : ''}${created}`);
    console.log(`   Already existed    : ${skipped}`);
    console.log(`   Missing attributes : ${attrMiss}`);
    console.log(`   Missing categories : ${catMiss}`);
}

main()
    .catch(err => { console.error(err); process.exit(1); })
    .finally(() => prisma.$disconnect());
