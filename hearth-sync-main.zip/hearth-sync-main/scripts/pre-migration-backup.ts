/**
 * pre-migration-backup.ts
 *
 * Run this BEFORE any schema change. Dumps all data to a dated SQL file.
 *
 * Usage:
 *   npx tsx scripts/pre-migration-backup.ts
 *
 * Requires pg_dump to be installed (comes with PostgreSQL client tools).
 * On Windows: install from https://www.postgresql.org/download/windows/
 *   or via: choco install postgresql-client
 */

import { execSync } from 'child_process';
import * as fs from 'fs';
import * as path from 'path';
import * as dotenv from 'dotenv';

dotenv.config();

const DATABASE_URL = process.env.DATABASE_URL;
if (!DATABASE_URL) {
    console.error('❌ DATABASE_URL not set in .env');
    process.exit(1);
}

const backupDir = path.join(process.cwd(), 'backups');
fs.mkdirSync(backupDir, { recursive: true });

const timestamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
const backupFile = path.join(backupDir, `backup-${timestamp}.sql`);

console.log(`📦 Starting backup → ${backupFile}`);
console.log('   This may take a minute for large databases...\n');

(async () => {
    try {
        execSync(`pg_dump "${DATABASE_URL}" -f "${backupFile}" --no-password`, {
            stdio: 'inherit',
        });
        const size = fs.statSync(backupFile).size;
        console.log(`\n✅ Backup complete: ${backupFile} (${(size / 1024).toFixed(1)} KB)`);
    } catch (err: any) {
        // If pg_dump isn't available, fall back to a Prisma-based JSON export
        console.warn('\n⚠️  pg_dump not found. Falling back to JSON data export...\n');
        await jsonFallbackExport(backupFile.replace('.sql', '.json'));
    }
})();

async function jsonFallbackExport(outputFile: string) {
    const { PrismaClient } = await import('@prisma/client');
    const prisma = new PrismaClient();

    try {
        console.log('Exporting data via Prisma...');

        // Get all table names
        const tables = await prisma.$queryRaw<{ table_name: string }[]>`
            SELECT table_name 
            FROM information_schema.tables 
            WHERE table_schema = 'public' AND table_type = 'BASE TABLE'
            ORDER BY table_name
        `;

        const backup: Record<string, any[]> = {};
        for (const { table_name } of tables) {
            try {
                const rows = await prisma.$queryRawUnsafe<any[]>(`SELECT * FROM "${table_name}"`);
                backup[table_name] = rows;
                console.log(`  ✓ ${table_name}: ${rows.length} rows`);
            } catch {
                console.log(`  ⚠ ${table_name}: skipped`);
            }
        }

        fs.writeFileSync(outputFile, JSON.stringify(backup, null, 2));
        const size = fs.statSync(outputFile).size;
        console.log(`\n✅ JSON backup complete: ${outputFile} (${(size / 1024).toFixed(1)} KB)`);
    } finally {
        await prisma.$disconnect();
    }
}
