const fs = require('fs');
let code = fs.readFileSync('src/app/admin/products/import/page.tsx', 'utf8');

const styleBlock = `
<style>{\`
.excel-modal-backdrop { position: fixed; top: 0; left: 0; right: 0; bottom: 0; z-index: 9999; background: rgba(0,0,0,0.5); backdrop-filter: blur(4px); display: flex; align-items: center; justify-content: center; padding: 1.5rem; }
.excel-modal-window { position: relative; width: 100%; max-width: 98vw; height: 95vh; background: #fff; border-radius: 12px; box-shadow: 0 25px 50px -12px rgba(0,0,0,0.25); display: flex; flex-direction: column; overflow: hidden; border: 1px solid rgba(0,0,0,0.05); color: #111827; }
.excel-header { flex: none; padding: 1rem 1.5rem; border-bottom: 1px solid #e5e7eb; background: #f9fafb; display: flex; align-items: center; justify-content: space-between; z-index: 10; }
.excel-header h2 { font-size: 1.25rem; font-weight: 700; color: #111827; margin: 0; }
.excel-header p { font-size: 0.75rem; font-weight: 500; color: #6b7280; margin: 0.25rem 0 0 0; }
.excel-actions { display: flex; gap: 0.5rem; align-items: center; }
.btn-excel-sec { padding: 0.5rem 1rem; border: 1px solid #d1d5db; border-radius: 4px; font-size: 0.875rem; color: #374151; background: #fff; cursor: pointer; transition: all 150ms; }
.btn-excel-sec:hover { background: #f3f4f6; }
.btn-excel-pri { padding: 0.5rem 1.5rem; background: #059669; color: #fff; border-radius: 4px; font-size: 0.875rem; font-weight: 700; border: none; cursor: pointer; transition: all 150ms; box-shadow: 0 1px 2px rgba(0,0,0,0.05); }
.btn-excel-pri:hover { background: #047857; }
.btn-excel-danger { padding: 0.5rem 1rem; background: #ffe4e6; color: #be123c; border: 1px solid #fda4af; font-weight: 700; font-size: 0.875rem; border-radius: 4px; cursor: pointer; transition: all 150ms; }
.btn-excel-danger:hover { background: #fecdd3; }
.excel-bar-wrap { width: 100%; background: #e5e7eb; height: 0.375rem; flex: none; position: relative; overflow: hidden; }
.excel-bar-fill { background: #10b981; height: 100%; transition: width 300ms; }
.excel-body { flex: 1; overflow: auto; background: #f3f4f6; position: relative; display: flex; flex-direction: column; }
.excel-table-wrap { flex: 1; overflow: auto; background: #fff; }
.excel-table { width: 100%; text-align: left; font-size: 0.875rem; font-family: ui-sans-serif, system-ui, sans-serif; table-layout: fixed; border-spacing: 0; border-collapse: collapse; }
.excel-table thead { background: #f3f4f6; position: sticky; top: 0; z-index: 20; box-shadow: 0 1px 2px rgba(0,0,0,0.1); }
.excel-table th { padding: 0.5rem 1rem; border: 1px solid #d1d5db; background: #f3f4f6; vertical-align: bottom; user-select: none; }
.excel-table th.col-num { width: 4rem; text-align: center; font-weight: 600; color: #4b5563; }
.excel-th-title { display: block; color: #111827; font-weight: 700; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; font-size: 13px; }
.excel-th-sub { display: block; color: #6b7280; font-family: ui-monospace, SFMono-Regular, Consolas, monospace; font-size: 10px; text-transform: uppercase; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; margin-top: 0.25rem; background: transparent !important; }
.excel-table tbody tr { background: #fff; }
.excel-table tbody tr:hover { opacity: 0.95; box-shadow: inset 0 0 0 999px rgba(0,0,0,0.03); }
.excel-table td { border: 1px solid #d1d5db; padding: 0.375rem 1rem; color: #1f2937; }
.excel-table td.col-num { font-family: ui-monospace, SFMono-Regular, Consolas, monospace; font-size: 0.75rem; color: #6b7280; text-align: center; background: #f9fafb; padding: 0.375rem 0.75rem; }
.excel-cell-scroll { max-height: 6rem; overflow: auto; padding-right: 0.25rem; font-size: 0.8125rem; line-height: 1.25rem; }
.excel-footer { flex: none; padding: 0.5rem 1rem; border-top: 1px solid #d1d5db; background: #f9fafb; display: flex; align-items: center; justify-content: space-between; font-size: 0.875rem; z-index: 30; box-shadow: 0 -1px 3px rgba(0,0,0,0.02); }
.excel-paginator { display: flex; align-items: center; gap: 0.25rem; }
.excel-page-btn { width: 2rem; height: 2rem; display: flex; align-items: center; justify-content: center; border: 1px solid #d1d5db; background: #fff; border-radius: 4px; cursor: pointer; color: #374151; font-weight: 700; transition: all 150ms; }
.excel-page-btn:disabled { opacity: 0.5; cursor: not-allowed; }
.excel-page-btn:hover:not(:disabled) { background: #f3f4f6; }
.badge-success { background: #d1fae5; color: #047857; }
.badge-error { background: #ffe4e6; color: #be123c; }
.badge-warn { background: #fef3c7; color: #b45309; }
.excel-badge { display: inline-flex; align-items: center; padding: 0.125rem 0.5rem; border-radius: 4px; font-size: 10px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.05em; }
\`}</style>
`;

// Replacements
code = code.replace(
    /className="fixed inset-0 z-\[100\] bg-black\/50 backdrop-blur-sm flex items-center justify-center p-4 sm:p-6 animate-fade-in"/g,
    'className="excel-modal-backdrop"'
);
code = code.replace(
    /className="relative w-full max-w-\[98vw\] h-\[95vh\] bg-white rounded-xl shadow-2xl flex flex-col overflow-hidden ring-1 ring-black\/5"/g,
    'className="excel-modal-window"'
);
code = code.replace(
    /className="flex-none px-6 py-4 border-b border-gray-200 bg-gray-50 flex items-center justify-between z-10"/g,
    'className="excel-header"'
);
code = code.replace(/<h2 className="text-xl font-bold tracking-tight text-gray-900">/g, '<h2>');
code = code.replace(/<p className="text-xs font-medium text-gray-500 mt-1">/g, '<p>');
code = code.replace(/<div className="flex gap-2 items-center">/g, '<div className="excel-actions">');

code = code.replace(/className="px-4 py-2 border border-gray-300 rounded text-sm text-gray-700 bg-white hover:bg-gray-50 shadow-sm transition-colors"/g, 'className="btn-excel-sec"');
code = code.replace(/className="px-6 py-2 bg-emerald-600 text-white rounded text-sm font-bold shadow-sm hover:bg-emerald-700 transition-colors"/g, 'className="btn-excel-pri"');
code = code.replace(/className="px-4 py-2 bg-rose-100 text-rose-700 rounded border border-rose-300 font-bold text-sm shadow-sm hover:bg-rose-200 transition-colors"/g, 'className="btn-excel-danger"');

code = code.replace(/className="w-full bg-gray-200 h-1\.5 flex-none relative overflow-hidden"/g, 'className="excel-bar-wrap"');
code = code.replace(/className="bg-emerald-500 h-full transition-all duration-300 relative"/g, 'className="excel-bar-fill"');

code = code.replace(/className="flex-1 overflow-auto bg-gray-100 min-h-0 relative"/g, 'className="excel-body"');
code = code.replace(/className="flex flex-col h-full bg-white"/g, 'className="excel-body"');
code = code.replace(/className="flex-1 overflow-auto bg-white custom-scrollbar-excel"/g, 'className="excel-table-wrap"');

code = code.replace(/className="w-full text-left text-sm whitespace-nowrap border-collapse font-sans table-fixed"/g, 'className="excel-table"');
code = code.replace(/className="bg-\[#f3f4f6\] sticky top-0 z-20 shadow-\[0_1px_2px_rgba\(0,0,0,0\.1\)\]"/g, '');
code = code.replace(/className="px-3 py-2 border border-gray-300 font-semibold text-gray-600 w-16 text-center select-none bg-\[#f3f4f6\]"/g, 'className="col-num"');

code = code.replace(/className={`px - 4 py - 2 border border - gray - 300 select - none bg -\[#f3f4f6\] align - bottom \${ isWide \?'w-96': 'w-48' }`}/g, 'style={{ width: isWide ? "24rem" : "12rem" }}');
code = code.replace(/<div className="flex flex-col gap-1">/g, '<div>');
code = code.replace(/<span className="text-gray-900 font-bold truncate"/g, '<span className="excel-th-title"');
code = code.replace(/<span className="text-gray-500 font-mono text-\[10px\] tracking-wide uppercase truncate"/g, '<span className="excel-th-sub"');

code = code.replace(/className="bg-white"/g, '');
code = code.replace(/className="hover:bg-blue-50\/50 group"/g, '');
code = code.replace(/className="hover:bg-gray-50 group"/g, '');

code = code.replace(/className="px-3 py-1\.5 border border-gray-300 text-gray-500 font-mono text-xs text-center bg-gray-50\/50 group-hover:bg-blue-100\/50 select-none"/g, 'className="col-num"');
code = code.replace(/className="px-3 py-1\.5 border border-gray-300 text-gray-500 font-mono text-xs text-center bg-gray-50\/50 group-hover:bg-gray-100\/50 select-none"/g, 'className="col-num"');

code = code.replace(/className={`px - 4 py - 1\.5 border border - gray - 300 text - gray - 800 \${ isWide \?'whitespace-normal break-words': 'truncate' }`}/g, 'className={isWide ? "wide" : "narrow"}');
code = code.replace(/className="max-h-24 overflow-auto custom-scrollbar-excel pr-1"/g, 'className="excel-cell-scroll"');
code = code.replace(/<span className="text-gray-300 italic">null<\/span>/g, '<span style={{ color: "#d1d5db", fontStyle: "italic" }}>null</span>');

code = code.replace(/className="flex-none px-4 py-2 border-t border-gray-300 bg-gray-50 flex items-center justify-between text-sm select-none shadow-\[0_-1px_3px_rgba\(0,0,0,0\.02\)\]"/g, 'className="excel-footer"');
code = code.replace(/<div className="text-gray-600 font-medium tracking-tight">/g, '<div>');
code = code.replace(/<span className="text-gray-900 font-bold">/g, '<span style={{ fontWeight: 700, color: "#111827" }}>');
code = code.replace(/<span className="text-emerald-600 font-bold">/g, '<span style={{ fontWeight: 700, color: "#059669" }}>');

code = code.replace(/<div className="flex items-center gap-1">/g, '<div className="excel-paginator">');
code = code.replace(/className="w-8 h-8 flex items-center justify-center border border-transparent rounded hover:bg-gray-200 disabled:opacity-30 disabled:hover:bg-transparent transition-colors text-gray-600"/g, 'className="excel-page-btn"');
code = code.replace(/className="w-8 h-8 flex items-center justify-center border border-gray-300 bg-white rounded shadow-sm hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors font-bold text-gray-700"/g, 'className="excel-page-btn"');
code = code.replace(/<span className="px-3 text-gray-500 font-medium">/g, '<span style={{ padding: "0 0.75rem", color: "#6b7280", fontWeight: 500 }}>');

code = code.replace(/className="border border-gray-300 rounded overflow-hidden flex flex-col shadow-sm h-full bg-white m-6"/g, 'className="excel-body" style={{ margin: "1.5rem", borderRadius: "8px", border: "1px solid #d1d5db", overflow: "hidden" }}');

code = code.replace(/className="px-3 py-2 border border-gray-300 font-semibold text-gray-600 w-20 text-center select-none bg-\[#f3f4f6\]"/g, 'className="col-num" style={{ width: "5rem" }}');
code = code.replace(/className="px-4 py-2 border border-gray-300 font-semibold text-gray-600 w-64 select-none bg-\[#f3f4f6\]"/g, 'style={{ width: "16rem" }}');
code = code.replace(/className="px-4 py-2 border border-gray-300 font-semibold text-gray-600 w-32 select-none bg-\[#f3f4f6\] text-center"/g, 'style={{ width: "8rem", textAlign: "center" }}');
code = code.replace(/className="px-4 py-2 border border-gray-300 font-semibold text-gray-600 bg-\[#f3f4f6\]"/g, '');

code = code.replace(/className="px-4 py-1\.5 border border-gray-300 font-semibold text-gray-800 truncate"/g, 'className="narrow" style={{ fontWeight: 600 }}');
code = code.replace(/className="px-4 py-1\.5 border border-gray-300 text-center"/g, 'style={{ textAlign: "center" }}');

code = code.replace(/className={`inline - flex items - center px - 2 py - 0\.5 rounded text -\[10px\] font - bold tracking - wider uppercase\n.*?\${ r.status === 'success' \?'bg-emerald-100 text-emerald-700': \n.*? r.status === 'error' \?'bg-rose-100 text-rose-700': \n.*? 'bg-amber-100 text-amber-700'}`}/gs, 'className={`excel - badge ${ r.status === "success" ? "badge-success" : r.status === "error" ? "badge-error" : "badge-warn" }`}');

code = code.replace(/className={`px - 4 py - 1\.5 border border - gray - 300 whitespace - normal text - sm \${ r.status === 'error' \?'text-rose-600 font-medium': 'text-gray-600' }`}/g, 'className="wide" style={{ color: r.status === "error" ? "#be123c" : "#4b5563", fontWeight: r.status === "error" ? 500 : 400 }}');

// Add styleBlock to Portal output
code = code.replace(
    /{mounted && showPreviewModal && step >= 3 && createPortal\(/g,
    '{mounted && showPreviewModal && step >= 3 && createPortal(\n<>{styleBlock}'
);
code = code.replace(
    /                <\/div>,\n                document.body\n            \)}/g,
    '                </div>\n                </>,\n                document.body\n            )}'
);


fs.writeFileSync('src/app/admin/products/import/page.tsx', code, 'utf8');
console.log('Patch complete.');
