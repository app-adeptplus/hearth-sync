/**
 * Fixes doug@futurenowmarketing.com:
 * - Changes app_metadata.portal_role from 'dealer' to 'admin'
 * - Removes him from the DealerUser table (not a portal member)
 */
import { PrismaClient } from '@prisma/client';
import { createClient } from '@supabase/supabase-js';
import * as dotenv from 'dotenv';

dotenv.config({ path: '.env' });

const prisma = new PrismaClient();
const supabase = createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!,
    { auth: { autoRefreshToken: false, persistSession: false } }
);

async function main() {
    const targetEmail = 'doug@futurenowmarketing.com';

    // 1. Find the Supabase user and re-tag as admin
    const { data } = await supabase.auth.admin.listUsers({ perPage: 100 });
    const user = data?.users.find(u => u.email?.toLowerCase() === targetEmail);

    if (!user) {
        console.error(`No Supabase user found for ${targetEmail}`);
        await prisma.$disconnect();
        return;
    }

    const { error } = await supabase.auth.admin.updateUserById(user.id, {
        app_metadata: { portal_role: 'admin' },
    });
    if (error) throw new Error(`Failed to re-tag: ${error.message}`);
    console.log(`✓ ${targetEmail} re-tagged as admin in app_metadata`);

    // 2. Remove from DealerUser table — this person is an admin, not a portal member
    const deleted = await prisma.dealerUser.deleteMany({ where: { email: targetEmail } });
    console.log(`✓ Removed ${deleted.count} DealerUser row(s) for ${targetEmail}`);

    await prisma.$disconnect();
    console.log('Done.');
}

main().catch(console.error);
