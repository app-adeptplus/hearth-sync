/**
 * seed-enrichment-agent.ts
 *
 * Idempotent seed script that creates:
 *   1. A PromptTemplate for product data enrichment (Handlebars-based)
 *   2. A PromptAssignment linking it to the default LLM config
 *   3. AssignmentObjectScope records for PRODUCT, CATEGORY, ATTRIBUTE, BRAND, DATA_PACKAGE
 *
 * Run: npx tsx scripts/seed-enrichment-agent.ts
 */

import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

const ASSIGNMENT_LABEL = 'Product Enrichment Agent';

const SYSTEM_PROMPT = `You are a product data enrichment agent for HearthSync, a hearth and outdoor products catalog.

Brand: {{brand_name}} (SKU prefix: {{brand_sku}})

You are analyzing a product and must propose corrections and taxonomy assignments.

PRODUCT TO ENRICH:
- Name: {{product_name}}
- Model Number: {{product_model_number}}
- Current SKU: {{product_sku}}
- Description: {{product_description}}
{{#if raw_text}}- Additional scraped content:
{{raw_text}}{{/if}}

EXISTING CATEGORIES (use ONLY exact names from this list):
{{category_context}}

EXISTING ATTRIBUTES (use ONLY exact names from this list):
{{attribute_context}}

EXISTING OPTION GROUPS (use ONLY exact names from this list):
{{option_group_context}}

Return a JSON object with EXACTLY these fields:
{
  "normalized_name": "Product name without brand prefix, properly formatted",
  "model_number": "The brand's specific SKU/model number if visible, else null",
  "proposed_categories": ["Exact Category Name from the list above"],
  "proposed_attributes": { "Exact Attribute Name": "extracted value" },
  "proposed_option_groups": ["Exact Option Group Name"],
  "suggested_new_categories": [{ "name": "...", "parent_category_name": "...", "reason": "..." }],
  "suggested_new_attributes": [{ "name": "...", "unit": "...", "data_type": "text|number|boolean|select", "reason": "..." }],
  "suggested_new_option_groups": [{ "name": "...", "options": ["..."], "reason": "..." }],
  "description_summary": "A clean 1-2 sentence product description"
}

RULES:
- proposed_categories: ONLY use exact names from the EXISTING CATEGORIES list
- proposed_attributes: ONLY use exact names from the EXISTING ATTRIBUTES list
- proposed_option_groups: ONLY use exact names. These should be specific to the brand and product type
- suggested_new_*: ONLY suggest truly new items NOT in the existing lists. Be conservative
- model_number: This is the brand's specific identifier, NOT a generic product code
- Return ONLY the JSON object, no markdown fences, no explanation`;

const TEMPLATE_VARIABLES = [
    { name: 'brand_name', description: 'Brand name' },
    { name: 'brand_sku', description: 'Brand SKU prefix' },
    { name: 'product_name', description: 'Product name being enriched' },
    { name: 'product_model_number', description: 'Current model number or UNKNOWN' },
    { name: 'product_sku', description: 'Current SKU or empty' },
    { name: 'product_description', description: 'Product description' },
    { name: 'raw_text', description: 'Additional scraped page content' },
    { name: 'category_context', description: 'Formatted list of existing categories' },
    { name: 'attribute_context', description: 'Formatted list of existing attributes' },
    { name: 'option_group_context', description: 'Formatted list of existing option groups' },
];

const OBJECT_SCOPES: { entity: string; canRead: boolean; canWrite: boolean }[] = [
    { entity: 'PRODUCT', canRead: true, canWrite: true },
    { entity: 'CATEGORY', canRead: true, canWrite: false },
    { entity: 'ATTRIBUTE', canRead: true, canWrite: false },
    { entity: 'BRAND', canRead: true, canWrite: false },
    { entity: 'DATA_PACKAGE', canRead: true, canWrite: true },
];

async function main() {
    console.log('🔧 Seeding Product Enrichment Agent...\n');

    // 1. Check if assignment already exists
    const existing = await prisma.promptAssignment.findFirst({
        where: {
            serviceType: 'ENRICHMENT',
            serviceId: null,
            label: ASSIGNMENT_LABEL,
        },
        include: { promptTemplate: true, llmConfig: true, objectScopes: true },
    });

    if (existing) {
        console.log(`✅ Assignment "${ASSIGNMENT_LABEL}" already exists (id: ${existing.id})`);
        console.log(`   Template: ${existing.promptTemplate?.name || 'none'}`);
        console.log(`   LLM Config: ${existing.llmConfig?.displayName || existing.llmConfig?.model || 'none'}`);
        console.log(`   Object Scopes: ${existing.objectScopes.length}`);
        console.log('\n   Skipping — already seeded. Delete the existing records to re-seed.');
        return;
    }

    // 2. Create PromptTemplate
    console.log('📝 Creating PromptTemplate...');
    const template = await prisma.promptTemplate.create({
        data: {
            name: 'Product Data Enrichment',
            category: 'ENRICHMENT',
            systemPrompt: SYSTEM_PROMPT,
            variables: TEMPLATE_VARIABLES,
            tags: ['enrichment', 'product', 'taxonomy'],
            isActive: true,
        },
    });
    console.log(`   Created template: ${template.id}`);

    // 3. Find default active LLM config
    console.log('🔍 Finding default LLM config...');
    const llmConfig = await prisma.llmApiConfig.findFirst({
        where: { isDefault: true, isActive: true },
    });

    if (!llmConfig) {
        console.error('❌ No default active LlmApiConfig found!');
        console.error('   Go to System Services → API Connections and set one as default.');
        // Clean up the template we just created
        await prisma.promptTemplate.delete({ where: { id: template.id } });
        process.exit(1);
    }
    console.log(`   Using: ${llmConfig.displayName || llmConfig.model} (${llmConfig.provider})`);

    // 4. Create PromptAssignment
    console.log('🤖 Creating PromptAssignment...');
    const assignment = await prisma.promptAssignment.create({
        data: {
            label: ASSIGNMENT_LABEL,
            serviceType: 'ENRICHMENT',
            serviceId: null,
            promptTemplateId: template.id,
            llmConfigId: llmConfig.id,
            isActive: true,
            notes: 'Default enrichment agent for DataPackage and Product enrichment.',
        },
    });
    console.log(`   Created assignment: ${assignment.id}`);

    // 5. Create AssignmentObjectScope records
    console.log('🔐 Creating object scopes...');
    for (const scope of OBJECT_SCOPES) {
        await prisma.assignmentObjectScope.create({
            data: {
                assignmentId: assignment.id,
                entity: scope.entity as any,
                canRead: scope.canRead,
                canWrite: scope.canWrite,
            },
        });
        console.log(`   ${scope.entity}: read=${scope.canRead}, write=${scope.canWrite}`);
    }

    console.log('\n✅ Product Enrichment Agent seeded successfully!');
    console.log(`   Template ID:    ${template.id}`);
    console.log(`   Assignment ID:  ${assignment.id}`);
    console.log(`   LLM Config:     ${llmConfig.displayName || llmConfig.model}`);
}

main()
    .catch((err) => {
        console.error('Fatal error:', err);
        process.exit(1);
    })
    .finally(() => prisma.$disconnect());
