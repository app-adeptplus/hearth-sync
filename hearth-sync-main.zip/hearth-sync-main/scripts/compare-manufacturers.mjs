/**
 * compare-manufacturers.mjs
 * Compares target CSV against live DB dump and writes a markdown plan to prompts/
 * Usage: node scripts/compare-manufacturers.mjs
 */
import fs from 'fs';
import path from 'path';

const ROOT = path.resolve('.');
const DB_FILE  = path.join(ROOT, 'temp/current-mfr-brands.json');
const CSV_FILE = path.join(ROOT, 'temp/Manufacturers_Brands_Final.csv');

const normalize = s => s.toLowerCase().replace(/[^a-z0-9]/g, '');

function parseCSVLine(line) {
    const result = [];
    let current = '', inQuotes = false;
    for (const ch of line) {
        if (ch === '"') { inQuotes = !inQuotes; }
        else if (ch === ',' && !inQuotes) { result.push(current); current = ''; }
        else { current += ch; }
    }
    result.push(current);
    return result;
}

const db = JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
const csvLines = fs.readFileSync(CSV_FILE, 'utf8').trim().split(/\r?\n/).slice(1);

// DB index
const dbMfrs = new Map();
for (const mfr of db) {
    dbMfrs.set(normalize(mfr.name), {
        displayName: mfr.name,
        brands: new Map(mfr.brands.map(b => [normalize(b.name), b.name]))
    });
}

// CSV index
const csvMfrs = new Map();
for (const line of csvLines) {
    const c = parseCSVLine(line);
    const mfrName = c[0]?.trim(); if (!mfrName) continue;
    const key = normalize(mfrName);
    if (!csvMfrs.has(key)) csvMfrs.set(key, {
        displayName: mfrName, prefix: c[1]?.trim(),
        mfrWeb: c[9]?.trim(), status: c[7]?.trim(), brands: []
    });
    const brandName = c[2]?.trim();
    if (brandName) csvMfrs.get(key).brands.push({
        brandName, brandSku: c[3]?.trim(), brandWeb: c[4]?.trim(),
        logoUrl: c[5]?.trim(), status: c[7]?.trim(), notes: c[11]?.trim()
    });
}

// 1. Missing manufacturers
const missingMfrs = [];
for (const [key, csv] of csvMfrs) {
    if (!dbMfrs.has(key)) missingMfrs.push({ ...csv, key });
}
missingMfrs.sort((a, b) => a.displayName.localeCompare(b.displayName));

// 2. Missing brands inside existing manufacturers
const missingBrands = [];
for (const [key, csv] of csvMfrs) {
    if (!dbMfrs.has(key)) continue;
    const db_ = dbMfrs.get(key);
    for (const brand of csv.brands) {
        if (!db_.brands.has(normalize(brand.brandName))) {
            missingBrands.push({ mfrCsvName: csv.displayName, mfrDbName: db_.displayName, ...brand });
        }
    }
}
missingBrands.sort((a, b) => a.mfrCsvName.localeCompare(b.mfrCsvName));

// 3. DB-only
const dbOnly = [];
for (const [key, db_] of dbMfrs) {
    if (!csvMfrs.has(key)) dbOnly.push(db_.displayName);
}

// Build markdown
const L = [];
L.push(`# Manufacturer & Brand Import Plan`);
L.push(`*Generated: ${new Date().toISOString().slice(0,10)} | DB: ${db.length} mfrs | CSV target: ${csvMfrs.size} mfrs*`);
L.push(``);
L.push(`## Summary`);
L.push(``);
L.push(`| | Count |`);
L.push(`|---|---|`);
L.push(`| Missing manufacturers (full adds) | ${missingMfrs.length} |`);
L.push(`| Missing brands inside existing manufacturers | ${missingBrands.length} |`);
L.push(`| DB-only (investigate) | ${dbOnly.length} |`);
L.push(``);
L.push(`---`);
L.push(``);
L.push(`## Part 1 — Manufacturers to Add (${missingMfrs.length})`);
L.push(``);

const byStatus = {};
for (const m of missingMfrs) {
    const s = m.status || 'UNKNOWN';
    (byStatus[s] = byStatus[s] || []).push(m);
}

for (const s of ['ACTIVE','IN_PROGRESS','WISHLIST','REVIEW','UNKNOWN']) {
    if (!byStatus[s]?.length) continue;
    L.push(`### ${s} (${byStatus[s].length})`);
    L.push(``);
    L.push(`| Manufacturer | Prefix | Website | Brand(s) | Brand SKU(s) |`);
    L.push(`|---|---|---|---|---|`);
    for (const m of byStatus[s]) {
        const brands = m.brands.map(b => b.brandName).join(', ');
        const skus   = m.brands.map(b => b.brandSku || '–').join(', ');
        L.push(`| ${m.displayName} | ${m.prefix || '–'} | ${m.mfrWeb || '–'} | ${brands} | ${skus} |`);
    }
    L.push(``);
}

L.push(`---`);
L.push(``);
L.push(`## Part 2 — Brands to Add to Existing Manufacturers (${missingBrands.length})`);
L.push(``);
L.push(`| Manufacturer | Brand | SKU | Website |`);
L.push(`|---|---|---|---|`);
for (const b of missingBrands) {
    const mfrLabel = b.mfrDbName !== b.mfrCsvName ? `${b.mfrDbName} *(CSV: "${b.mfrCsvName}")*` : b.mfrDbName;
    L.push(`| ${mfrLabel} | ${b.brandName} | ${b.brandSku || '–'} | ${b.brandWeb || '–'} |`);
}
L.push(``);
L.push(`---`);
L.push(``);
L.push(`## Part 3 — In DB but Not in CSV (${dbOnly.length})`);
L.push(``);
L.push(`*These exist in the DB but have no match in the CSV — verify if they should be renamed, merged, or removed.*`);
L.push(``);
for (const name of dbOnly.sort()) L.push(`- ${name}`);
L.push(``);

const out = L.join('\n');
const outPath = path.join(ROOT, 'prompts/manufacturer-import-plan.md');
fs.mkdirSync(path.dirname(outPath), { recursive: true });
fs.writeFileSync(outPath, out, 'utf8');
console.log(`Plan written → ${outPath}`);
console.log(`${missingMfrs.length} missing mfrs | ${missingBrands.length} missing brands | ${dbOnly.length} DB-only`);
