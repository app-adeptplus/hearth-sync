/**
 * seed-unmapped-attributes.ts
 *
 * Adds category mappings for the 26 attributes that had zero CategoryAttributeMap rows
 * after the initial seeding run. Covers:
 *   - Newly created attributes (wood-sub-type, convertible-ng-lp, stainless-steel-grade, etc.)
 *   - Pre-existing attributes that were never mapped (warranties, app-compatible, etc.)
 *
 * Run:  npx tsx scripts/seed-unmapped-attributes.ts
 *       DRY_RUN=true npx tsx scripts/seed-unmapped-attributes.ts
 */

import prisma from '../src/lib/db';

// ─────────────────────────────────────────────────────────────────────────────
// MAPPING TABLE — attribute slug → categories it applies to
// ─────────────────────────────────────────────────────────────────────────────

const ATTR_TO_CATEGORIES: Record<string, string[]> = {

    // ── Newly created: Hearth sub-attributes ──────────────────────────────────

    // Child of Fuel Type = Wood — applies to wood-burning products
    'wood-sub-type': ['fireplace', 'insert', 'stove', 'firebox'],

    // Child of Fuel Type = Gas — whether NG↔LP conversion is available
    'convertible-ng-lp': ['fireplace', 'insert', 'stove', 'vented-log-sets', 'vent-free-log-sets', 'burner'],

    // Grandchild — only relevant when convertible-ng-lp = Yes
    'conversion-kit-included': ['fireplace', 'insert', 'stove', 'vented-log-sets', 'vent-free-log-sets'],

    // Child of Venting Type — inserts fitting masonry chimneys with co-linear liner
    'co-linear-capable': ['insert'],

    // EPA emissions — applies to wood-burning hearth products (child of Certifications)
    'emissions-g-hr': ['fireplace', 'insert', 'stove'],

    // ── Newly created: Grill attributes ──────────────────────────────────────

    // SS grade applies to all metal-bodied grills
    'stainless-steel-grade': ['built-in', 'portable-cart', 'portable', 'kamado', 'smoker', 'griddle'],

    // Lid material — cart and built-in only (not kamado, which uses ceramic)
    'lid-material': ['built-in', 'portable-cart', 'portable', 'griddle'],

    // Pellet sub-type — pellet grills and smokers
    'pellet-sub-type': ['smoker', 'portable-cart', 'built-in'],

    // ── Newly created: Outdoor Kitchen attributes ─────────────────────────────

    'island-configuration': ['outdoor-kitchen-island'],
    'frame-material':       ['outdoor-kitchen-island'],
    'counter-material':     ['outdoor-kitchen-island'],

    'sink-included':        ['outdoor-kitchen-island'],
    'refrigerator-included':['outdoor-kitchen-island'],
    'refrigerator-volume':  ['outdoor-kitchen-island'],

    // Table top material — fire tables and patio tables
    'table-top-material':   ['fire-table', 'table'],

    // Burner included — fire pits and fire tables (may be sold without burner)
    'burner-included':      ['fire-pit', 'fire-table'],

    // Fuel supply — how the heater is powered/fuelled
    'fuel-supply':          ['heater'],

    // ── Pre-existing: never mapped ────────────────────────────────────────────

    // Fuel tank location — propane cart grills
    'fuel-tank-location':   ['portable-cart', 'portable', 'heater'],

    // Number of grates — BBQ-style grills
    'number-of-grates':     ['built-in', 'portable-cart', 'portable', 'kamado'],

    // Chimney included — pellet smokers and pizza ovens typically include chimney stack
    'chimney-included':     ['smoker', 'pizza-oven', 'stove'],

    // App compatible — smart grills and smart hearth products
    'app-compatible':       ['smoker', 'fireplace', 'insert', 'heater'],

    // ── Warranties — mapped to all applicable product types ───────────────────
    // Firebox warranty = hearth products with a firebox
    'firebox-warranty':         ['fireplace', 'insert', 'firebox'],

    // Burner warranty = gas-burning products
    'burner-warranty':          ['fireplace', 'insert', 'stove', 'vented-log-sets', 'vent-free-log-sets', 'fire-pit', 'fire-table', 'burner', 'heater', 'built-in', 'portable-cart', 'portable'],

    // Heat exchanger warranty = gas and pellet hearth products with heat exchange systems
    'heat-exchanger-warranty':  ['fireplace', 'insert', 'stove'],

    // Paint/finish warranty = grills and hearth products with painted/powder-coated surfaces
    'paint-finish-warranty':    ['fireplace', 'insert', 'stove', 'firebox', 'built-in', 'portable-cart', 'portable', 'kamado', 'smoker', 'pizza-oven', 'griddle'],

    // Outdoor finish warranty = outdoor living products exposed to elements
    'finish-warranty-outdoor':  ['fire-pit', 'fire-table', 'heater', 'outdoor-kitchen-island', 'patio-furniture', 'seating', 'table', 'spa', 'water-feature'],
};

// ─────────────────────────────────────────────────────────────────────────────

const DRY_RUN = process.env.DRY_RUN === 'true';

async function main() {
    console.log(`\n🔍  Mode: ${DRY_RUN ? 'DRY RUN (no writes)' : 'LIVE'}\n`);

    const categories = await prisma.productCategory.findMany({
        where: { parentId: { not: null } },
        select: { id: true, name: true, slug: true },
    });

    const attributes = await prisma.productAttribute.findMany({
        select: { id: true, name: true, slug: true },
    });

    const catBySlug  = new Map(categories.map(c => [c.slug, c]));
    const attrBySlug = new Map(attributes.map(a => [a.slug, a]));

    let created  = 0;
    let skipped  = 0;
    let attrMiss = 0;
    let catMiss  = 0;

    for (const [attrSlug, catSlugs] of Object.entries(ATTR_TO_CATEGORIES)) {
        const attribute = attrBySlug.get(attrSlug);
        if (!attribute) {
            console.warn(`⚠  Attribute not found: "${attrSlug}"`);
            attrMiss++;
            continue;
        }

        for (const catSlug of catSlugs) {
            const category = catBySlug.get(catSlug);
            if (!category) {
                console.warn(`   ↳ Category not found: "${catSlug}" (attr: ${attrSlug})`);
                catMiss++;
                continue;
            }

            const existing = await prisma.categoryAttributeMap.findFirst({
                where: { categoryId: category.id, attributeId: attribute.id },
            });
            if (existing) { skipped++; continue; }

            console.log(`  + ${attribute.name}  →  ${category.name}`);

            if (!DRY_RUN) {
                await prisma.categoryAttributeMap.create({
                    data: {
                        categoryId:   category.id,
                        attributeId:  attribute.id,
                        isRequired:   false,
                        isFilterable: false,
                        sortOrder:    0,
                    },
                });
            }
            created++;
        }
    }

    console.log(`\n✅  Done.`);
    console.log(`   Mappings created   : ${DRY_RUN ? '(dry run) ' : ''}${created}`);
    console.log(`   Already existed    : ${skipped}`);
    console.log(`   Missing attributes : ${attrMiss}`);
    console.log(`   Missing categories : ${catMiss}`);
}

main()
    .catch(err => { console.error(err); process.exit(1); })
    .finally(() => prisma.$disconnect());
