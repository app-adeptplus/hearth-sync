import prisma from '../src/lib/db';
async function main() {
    const attrs = await prisma.productAttribute.findMany({
        select: { name: true, slug: true, dataType: true },
        orderBy: { name: 'asc' }
    });
    attrs.forEach(a => console.log(`${a.slug} | ${a.name} | ${a.dataType}`));
}
main().finally(() => prisma.$disconnect());
