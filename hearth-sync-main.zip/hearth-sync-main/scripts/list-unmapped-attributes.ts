import prisma from '../src/lib/db';

async function main() {
    const totalMaps = await prisma.categoryAttributeMap.count();
    const totalDeps = await prisma.attributeDependency.count();

    const attrs = await prisma.productAttribute.findMany({
        select: {
            slug: true, name: true, dataType: true,
            _count: { select: { categoryMappings: true } },
        },
        orderBy: { name: 'asc' },
    });

    const unmapped = attrs.filter(a => a._count.categoryMappings === 0);

    console.log(`\nTotal CategoryAttributeMaps : ${totalMaps}`);
    console.log(`Total AttributeDependencies : ${totalDeps}`);
    console.log(`Total Attributes            : ${attrs.length}`);
    console.log(`Still unmapped              : ${unmapped.length}`);

    if (unmapped.length > 0) {
        console.log('\nUnmapped:');
        unmapped.forEach(a => console.log(`  ${a.slug} | ${a.name} | ${a.dataType}`));
    } else {
        console.log('\n✅ All attributes have at least one category mapping.');
    }
}

main().finally(() => prisma.$disconnect());
