import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function main() {
    // Get ALL table names and their row counts via raw SQL
    const tables = await prisma.$queryRaw<{ table_name: string }[]>`
        SELECT table_name 
        FROM information_schema.tables 
        WHERE table_schema = 'public' 
          AND table_type = 'BASE TABLE'
        ORDER BY table_name
    `;

    console.log(`\n=== All ${tables.length} tables ===`);
    for (const t of tables) {
        try {
            const result = await prisma.$queryRawUnsafe<{ count: string }[]>(
                `SELECT COUNT(*) as count FROM "${t.table_name}"`
            );
            console.log(`  ${t.table_name}: ${result[0].count} rows`);
        } catch (e: any) {
            console.log(`  ${t.table_name}: ERROR - ${e.message.split('\n')[0]}`);
        }
    }
}

main().catch(console.error).finally(() => prisma.$disconnect());
