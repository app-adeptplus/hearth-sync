/**
 * seed-category-attributes.ts
 *
 * Maps existing sub-categories to existing ProductAttributes based on the
 * Hearth_Grill_Outdoor_Attributes-Research.xlsx research file.
 *
 * SAFE: Only creates CategoryAttributeMap rows. Never creates/deletes Categories or Attributes.
 * Idempotent: safe to run more than once.
 *
 * Run: npx tsx scripts/seed-category-attributes.ts
 *      DRY_RUN=true npx tsx scripts/seed-category-attributes.ts
 *
 * NOTE: Fuel Type is an attribute — not a category. "Heater" covers both indoor
 * and patio heaters; the fuel type attribute distinguishes them.
 */

import prisma from '../src/lib/db';

// ─────────────────────────────────────────────────────────────────────────────
// MAPPING TABLE
// Key   = sub-category slug (from live DB as of 2026-03-20)
// Value = attribute slugs that apply to this sub-category
//
// Slugs have been verified against live DB output of list-attributes.ts
// ─────────────────────────────────────────────────────────────────────────────

const CATEGORY_ATTRIBUTE_MAP: Record<string, string[]> = {

    // ═══════════════════════════════════════════════════════════════════════
    // HEARTH
    // ═══════════════════════════════════════════════════════════════════════

    'fireplace': [
        'fuel-type',
        'venting-type',
        'installation-type',
        'btu-input',
        'btu-output',
        'heating-area',
        'efficiency-rating',
        'ignition-type',
        'remote-included',
        'wifi-enabled',
        'firebox-width',
        'firebox-height',
        'firebox-depth',
        'width',
        'height',
        'depth',
        'weight',
        'framing-opening',
        'viewing-area',
        'frame-surround-finish',
        'glass-type',
        'body-material',
        'fire-media',
        'blower-included',
        'mantel-compatible',
        'indoor-outdoor-use',
        'certifications',
        'safety-shutoff',
        'battery-backup-included',
    ],

    'insert': [
        'fuel-type',
        'venting-type',
        'installation-type',
        'btu-input',
        'btu-output',
        'heating-area',
        'efficiency-rating',
        'ignition-type',
        'remote-included',
        'wifi-enabled',
        'firebox-width',
        'firebox-height',
        'firebox-depth',
        'width',
        'height',
        'depth',
        'weight',
        'framing-opening',
        'body-material',
        'glass-type',
        'fire-media',
        'blower-included',
        'mantel-compatible',
        'indoor-outdoor-use',
        'certifications',
        'safety-shutoff',
        'battery-backup-included',
    ],

    'stove': [
        'fuel-type',
        'venting-type',
        'installation-type',
        'btu-input',
        'btu-output',
        'heating-area',
        'efficiency-rating',
        'ignition-type',
        'remote-included',
        'body-material',
        'width',
        'height',
        'depth',
        'weight',
        'blower-included',
        'indoor-outdoor-use',
        'certifications',
        'safety-shutoff',
        'hopper-capacity',
    ],

    'vented-log-sets': [
        'fuel-type',
        'gas-sub-type',
        'btu-input',
        'btu-output',
        'ignition-type',
        'remote-included',
        'fire-media',
        'fire-media-type',
        'log-set-size',
        'certifications',
        'indoor-outdoor-use',
    ],

    'vent-free-log-sets': [
        'fuel-type',
        'gas-sub-type',
        'btu-input',
        'btu-output',
        'heating-area',
        'venting-type',
        'ignition-type',
        'remote-included',
        'fire-media',
        'fire-media-type',
        'log-set-size',
        'certifications',
        'safety-shutoff',
        'indoor-outdoor-use',
    ],

    'firebox': [
        'installation-type',
        'firebox-width',
        'firebox-height',
        'firebox-depth',
        'width',
        'height',
        'depth',
        'weight',
        'framing-opening',
        'body-material',
        'indoor-outdoor-use',
        'certifications',
    ],

    'fire-pit': [
        'fuel-type',
        'btu-input',
        'btu-output-outdoor',
        'fire-media',
        'fire-feature-style',
        'burner-shape',
        'width',
        'height',
        'depth',
        'weight',
        'ignition-type',
        'indoor-outdoor-use',
        'certifications',
        'safety-shutoff',
        'cover-included',
        'portable',
    ],

    'fire-table': [
        'fuel-type',
        'btu-input',
        'btu-output-outdoor',
        'fire-media',
        'fire-feature-style',
        'burner-shape',
        'width',
        'height',
        'depth',
        'weight',
        'ignition-type',
        'indoor-outdoor-use',
        'certifications',
        'safety-shutoff',
        'cover-included',
    ],

    'torch': [
        'fuel-type',
        'height',
        'weight',
        'indoor-outdoor-use',
    ],

    // Heater covers all types (patio, indoor, wall-mount, tabletop)
    // fuel-type and heater-style attributes distinguish them
    'heater': [
        'fuel-type',
        'heater-style',
        'btu-input',
        'btu-output-outdoor',
        'heating-coverage',
        'heat-settings',
        'emitter-type',
        'radiant-convective',
        'width',
        'height',
        'weight',
        'indoor-outdoor-use',
        'weather-resistance-rating',
        'certifications',
        'safety-shutoff',
        'portable',
        'cover-included',
        'ip-rating',
    ],

    'burner': [
        'fuel-type',
        'gas-sub-type',
        'btu-input',
        'fire-media',
        'ignition-type',
        'burner-diameter',
        'burner-shape',
        'width',
        'depth',
    ],

    'cooking-stove': [
        'fuel-type',
        'btu-input',
        'total-btu',
        'number-of-main-burners',
        'width',
        'height',
        'depth',
        'weight',
        'ignition-type',
        'certifications',
    ],

    // ═══════════════════════════════════════════════════════════════════════
    // GRILLS
    // ═══════════════════════════════════════════════════════════════════════

    'built-in': [
        'fuel-type',
        'gas-sub-type',
        'total-btu',
        'btu-per-main-burner',
        'number-of-main-burners',
        'primary-cooking-area',
        'total-cooking-area',
        'secondary-warming-area',
        'grate-material',
        'grate-style',
        'cooking-surface-material',
        'grill-ignition-type',
        'side-burner-btu',
        'infrared-burner-btu',
        'sear-burner-btu',
        'rotisserie-burner-btu',
        'smoker-box-included',
        'built-in-thermometer',
        'warming-rack-included',
        'grease-management-system',
        'width',
        'height',
        'depth',
        'weight',
        'certifications',
    ],

    'portable-cart': [
        'fuel-type',
        'gas-sub-type',
        'total-btu',
        'btu-per-main-burner',
        'number-of-main-burners',
        'primary-cooking-area',
        'total-cooking-area',
        'secondary-warming-area',
        'grate-material',
        'grate-style',
        'cooking-surface-material',
        'grill-ignition-type',
        'side-burner-btu',
        'side-shelves',
        'storage-cabinet',
        'built-in-thermometer',
        'warming-rack-included',
        'smoker-box-included',
        'grease-management-system',
        'width',
        'height',
        'depth',
        'weight',
        'certifications',
        'assembly-required',
    ],

    'portable': [
        'fuel-type',
        'gas-sub-type',
        'total-btu',
        'number-of-main-burners',
        'primary-cooking-area',
        'grate-material',
        'cooking-surface-material',
        'grill-ignition-type',
        'width',
        'height',
        'depth',
        'weight',
        'certifications',
        'portable',
    ],

    'kamado': [
        'fuel-type',
        'max-temperature',
        'primary-cooking-area',
        'total-cooking-area',
        'grate-material',
        'cooking-surface-material',
        'width',
        'height',
        'depth',
        'weight',
        'certifications',
        'portable',
        'temperature-range',
    ],

    'smoker': [
        'fuel-type',
        'hopper-capacity',
        'primary-cooking-area',
        'total-cooking-area',
        'grate-material',
        'cooking-surface-material',
        'grill-ignition-type',
        'temperature-range',
        'probe-ports',
        'pid-controller',
        'wifi-enabled',
        'bluetooth-enabled',
        'width',
        'height',
        'depth',
        'weight',
        'certifications',
    ],

    'pizza-oven': [
        'fuel-type',
        'max-temperature',
        'preheat-time',
        'cooking-surface-size',
        'width',
        'height',
        'depth',
        'weight',
        'certifications',
        'indoor-outdoor-use',
        'portable',
    ],

    'griddle': [
        'fuel-type',
        'total-btu',
        'number-of-main-burners',
        'primary-cooking-area',
        'cooking-surface-material',
        'grease-management-system',
        'grill-ignition-type',
        'side-shelves',
        'width',
        'height',
        'depth',
        'weight',
        'certifications',
        'portable',
    ],

    'outdoor-kitchen-island': [
        'width',
        'height',
        'depth',
        'weight',
        'indoor-outdoor-use',
        'certifications',
        'assembly-required',
        'weather-resistance-rating',
    ],

    // ═══════════════════════════════════════════════════════════════════════
    // ACCESSORIES
    // ═══════════════════════════════════════════════════════════════════════

    'mantels-surrounds': [
        'body-material',
        'frame-surround-finish',
        'width',
        'height',
        'depth',
        'weight',
        'firebox-width',
        'firebox-height',
    ],

    'doors-screens': [
        'firebox-width',
        'firebox-height',
        'width',
        'height',
        'frame-surround-finish',
        'glass-type',
    ],

    'fireplace-screen': [
        'firebox-width',
        'firebox-height',
        'width',
        'height',
        'body-material',
        'finish-color',
    ],

    'tools-sets': [
        'height',
        'weight',
        'finish-color',
    ],

    'blowers-fans': [
        'blower-cfm',
        'width',
        'height',
        'weight',
    ],

    'grill-cover': [
        'width',
        'height',
        'depth',
        'weather-resistance-rating',
        'weather-cover-included',
    ],

    'fire-pit-accessory': [
        'fuel-type',
        'width',
        'height',
    ],

    'weather-cover': [
        'width',
        'height',
        'depth',
        'weather-resistance-rating',
        'indoor-outdoor-use',
    ],

    'wood-grate': [
        'width',
        'depth',
        'grate-material',
        'grate-style',
        'weight',
    ],

    'wood-cover': [
        'width',
        'depth',
        'weight',
        'weather-resistance-rating',
    ],

    'ash-vacuum': [
        'weight',
        'certifications',
    ],

    'chimney-cap': [
        'body-material',
        'vent-pipe-diameter',
        'weather-resistance-rating',
        'finish-color',
    ],

    'outdoor-kitchen-accessories': [
        'width',
        'height',
        'depth',
        'weight',
        'body-material',
        'weather-resistance-rating',
    ],

    // ═══════════════════════════════════════════════════════════════════════
    // OUTDOOR LIVING
    // ═══════════════════════════════════════════════════════════════════════

    'spa': [
        'width',
        'height',
        'depth',
        'weight',
        'indoor-outdoor-use',
        'weather-resistance-rating',
        'wifi-enabled',
        'certifications',
        'assembly-required',
    ],

    'seating': [
        'width',
        'height',
        'depth',
        'weight',
        'weather-resistance-rating',
        'assembly-required',
        'cover-included',
    ],

    'table': [
        'width',
        'height',
        'depth',
        'weight',
        'weather-resistance-rating',
        'assembly-required',
    ],

    'outdoor-lighting': [
        'indoor-outdoor-use',
        'weather-resistance-rating',
        'ip-rating',
        'wifi-enabled',
        'bluetooth-enabled',
        'dimmer-control',
        'certifications',
        'width',
        'height',
        'weight',
    ],

    'patio-furniture': [
        'width',
        'height',
        'depth',
        'weight',
        'weather-resistance-rating',
        'assembly-required',
        'cover-included',
        'indoor-outdoor-use',
    ],

    'water-feature': [
        'width',
        'height',
        'depth',
        'weight',
        'indoor-outdoor-use',
        'weather-resistance-rating',
        'certifications',
        'assembly-required',
    ],
};

// ─────────────────────────────────────────────────────────────────────────────

const DRY_RUN = process.env.DRY_RUN === 'true';

async function main() {
    console.log(`\n🔍  Mode: ${DRY_RUN ? 'DRY RUN (no writes)' : 'LIVE'}\n`);

    const categories = await prisma.productCategory.findMany({
        where: { parentId: { not: null } },
        select: { id: true, name: true, slug: true },
    });
    const attributes = await prisma.productAttribute.findMany({
        select: { id: true, name: true, slug: true },
    });

    const catBySlug  = new Map(categories.map(c => [c.slug, c]));
    const attrBySlug = new Map(attributes.map(a => [a.slug, a]));

    let created  = 0;
    let skipped  = 0;
    let catMiss  = 0;
    let attrMiss = 0;

    for (const [catSlug, attrSlugs] of Object.entries(CATEGORY_ATTRIBUTE_MAP)) {
        const category = catBySlug.get(catSlug);
        if (!category) {
            console.warn(`⚠  Category not found: "${catSlug}" — skipping entire block`);
            catMiss++;
            continue;
        }

        for (const attrSlug of attrSlugs) {
            const attribute = attrBySlug.get(attrSlug);
            if (!attribute) {
                console.warn(`   ↳ Attribute not found: "${attrSlug}" (${catSlug}) — skipping`);
                attrMiss++;
                continue;
            }

            const existing = await prisma.categoryAttributeMap.findFirst({
                where: { categoryId: category.id, attributeId: attribute.id },
            });
            if (existing) { skipped++; continue; }

            console.log(`  + ${category.name}  →  ${attribute.name}`);

            if (!DRY_RUN) {
                await prisma.categoryAttributeMap.create({
                    data: {
                        categoryId:   category.id,
                        attributeId:  attribute.id,
                        isRequired:   false,
                        isFilterable: true,
                        sortOrder:    0,
                    },
                });
            }
            created++;
        }
    }

    console.log(`\n✅  Done.`);
    console.log(`   Mappings created    : ${DRY_RUN ? '(dry run) ' : ''}${created}`);
    console.log(`   Already existed     : ${skipped}`);
    console.log(`   Missing categories  : ${catMiss}`);
    console.log(`   Missing attributes  : ${attrMiss}`);
}

main()
    .catch(err => { console.error(err); process.exit(1); })
    .finally(() => prisma.$disconnect());
