/**
 * migrate-brand-logos.ts
 *
 * Finds all brands whose logoUrl points to the old WordPress CDN
 * (hearth.gofnm.com), downloads each image, re-uploads to Supabase storage,
 * and updates the brand record with the new hosted URL.
 * Also propagates the logo up to the parent manufacturer if it has none.
 *
 * Usage: npx ts-node --project tsconfig.json scripts/migrate-brand-logos.ts
 */

import { PrismaClient } from '@prisma/client';
import { createClient } from '@supabase/supabase-js';
import * as dotenv from 'dotenv';
import * as path from 'path';

dotenv.config({ path: '.env' });

const prisma = new PrismaClient();

const SUPABASE_URL = process.env.NEXT_PUBLIC_SUPABASE_URL!;
const SUPABASE_SERVICE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY!;
const BUCKET = 'products';

const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_KEY, {
    auth: { autoRefreshToken: false, persistSession: false },
});

/** Download a URL and return its buffer + detected content-type */
async function fetchImage(url: string): Promise<{ buffer: Buffer; contentType: string } | null> {
    try {
        const res = await fetch(url, {
            headers: { 'User-Agent': 'Mozilla/5.0 (HearthSync logo-migrator)' },
            signal: AbortSignal.timeout(15000),
        });
        if (!res.ok) {
            console.warn(`    ⚠ HTTP ${res.status} for ${url}`);
            return null;
        }
        const arrayBuffer = await res.arrayBuffer();
        const contentType = res.headers.get('content-type') || 'image/png';
        return { buffer: Buffer.from(arrayBuffer), contentType };
    } catch (err: any) {
        console.warn(`    ⚠ Fetch failed: ${url} — ${err.message}`);
        return null;
    }
}

/** Upload a buffer to Supabase and return the public URL */
async function uploadToSupabase(
    buffer: Buffer,
    contentType: string,
    filename: string
): Promise<string | null> {
    const ext = contentType.includes('webp') ? '.webp'
        : contentType.includes('jpeg') ? '.jpg'
        : contentType.includes('png') ? '.png'
        : path.extname(filename) || '.png';

    const safeName = filename.replace(/[^a-z0-9._-]/gi, '_').replace(/\.[^.]+$/, '') + ext;
    const storagePath = `logos/${Date.now()}_${safeName}`;

    const { error } = await supabase.storage.from(BUCKET).upload(storagePath, buffer, {
        contentType,
        upsert: false,
    });

    if (error) {
        console.error(`    ✗ Upload failed: ${error.message}`);
        return null;
    }

    const { data } = supabase.storage.from(BUCKET).getPublicUrl(storagePath);
    return data.publicUrl;
}

const OLD_CDN = 'hearth.gofnm.com';

async function main() {
    // Find all brands with old CDN logo URLs
    const brands = await prisma.brand.findMany({
        where: { logoUrl: { contains: OLD_CDN } },
        include: { manufacturer: { select: { id: true, name: true, logoUrl: true } } },
    });

    console.log(`Found ${brands.length} brand(s) with old CDN logos to migrate.\n`);

    let migrated = 0;
    let failed = 0;
    let mfrUpdated = 0;

    for (const brand of brands) {
        const oldUrl = brand.logoUrl!;
        const filename = path.basename(oldUrl.split('?')[0]);
        process.stdout.write(`  [${brand.name}] Fetching ${filename}… `);

        const img = await fetchImage(oldUrl);
        if (!img) {
            console.log('SKIP (fetch failed)');
            failed++;
            continue;
        }

        const newUrl = await uploadToSupabase(img.buffer, img.contentType, filename);
        if (!newUrl) {
            failed++;
            continue;
        }

        // Update brand
        await prisma.brand.update({
            where: { id: brand.id },
            data: { logoUrl: newUrl },
        });
        console.log(`✅ → ${newUrl.slice(-60)}`);
        migrated++;

        // Propagate to parent manufacturer if it has no logo yet
        if (brand.manufacturer && !brand.manufacturer.logoUrl) {
            await prisma.manufacturer.update({
                where: { id: brand.manufacturer.id },
                data: { logoUrl: newUrl },
            });
            console.log(`    ↑ Also set on manufacturer: ${brand.manufacturer.name}`);
            mfrUpdated++;
        }

        // Small delay to avoid hammering the old CDN
        await new Promise(r => setTimeout(r, 200));
    }

    console.log('\n' + '='.repeat(55));
    console.log(`Done.`);
    console.log(`  Brand logos migrated:       ${migrated}`);
    console.log(`  Manufacturer logos set:     ${mfrUpdated}`);
    console.log(`  Failed / skipped:           ${failed}`);
}

main()
    .catch(err => { console.error(err); process.exit(1); })
    .finally(() => prisma.$disconnect());
