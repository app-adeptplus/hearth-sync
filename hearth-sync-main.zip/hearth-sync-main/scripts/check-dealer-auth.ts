import { PrismaClient } from '@prisma/client';
import { createClient } from '@supabase/supabase-js';
import * as dotenv from 'dotenv';
import * as fs from 'fs';

dotenv.config({ path: '.env' });

const prisma = new PrismaClient();
const supabase = createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!,
    { auth: { autoRefreshToken: false, persistSession: false } }
);

async function main() {
    const lines: string[] = [];
    const log = (s: string) => { lines.push(s); process.stdout.write(s + '\n'); };

    log('=== DealerAccount rows ===');
    const dealers = await prisma.dealerAccount.findMany({
        select: { id: true, companyName: true, userId: true, email: true },
        orderBy: { createdAt: 'asc' },
    });
    dealers.forEach((d) => {
        const ok = !d.userId.startsWith('manual-');
        log(`  ${ok ? 'OK' : 'BROKEN'} | "${d.companyName}" | userId: ${d.userId}`);
    });

    log('\n=== DealerUser rows ===');
    const users = await prisma.dealerUser.findMany({
        select: { id: true, dealerId: true, email: true, userId: true, role: true },
    });
    users.forEach((u) => {
        log(`  ${u.userId ? 'OK' : 'NO_SUPABASE_ID'} | ${u.email} | role: ${u.role} | userId: ${u.userId ?? 'null'}`);
    });

    log('\n=== Supabase Auth users ===');
    const { data, error } = await supabase.auth.admin.listUsers({ perPage: 100 });
    if (error) {
        log(`  ERROR: ${error.message}`);
    } else {
        data.users.forEach((u) => {
            const appRole = (u.app_metadata?.portal_role as string) ?? 'none';
            const userRole = (u.user_metadata?.portal_role as string) ?? 'none';
            log(`  ${u.email} | app_meta: ${appRole} | user_meta: ${userRole}`);
        });
    }

    fs.writeFileSync('logs/auth-check.log', lines.join('\n'));
    log('\nResults also written to logs/auth-check.log');
    await prisma.$disconnect();
}

main().catch(console.error);
