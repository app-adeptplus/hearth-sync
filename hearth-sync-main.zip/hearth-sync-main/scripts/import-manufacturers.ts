/**
 * import-manufacturers.ts
 *
 * Seeds the 63 approved REVIEW manufacturers from Manufacturers_Brands_Final.csv
 * plus adds the Hampton brand to the existing Miles Industries manufacturer.
 *
 * Idempotent: skips any manufacturer/brand that already exists (matched by name).
 *
 * Usage: npx ts-node --project tsconfig.json scripts/import-manufacturers.ts
 */

import { PrismaClient } from '@prisma/client';
import * as fs from 'fs';
import * as path from 'path';

const prisma = new PrismaClient();

// --- Slugify (matches app logic) ---
function slugify(text: string): string {
    return text.toString().toLowerCase()
        .replace(/\s+/g, '-')
        .replace(/[^\w\-]+/g, '')
        .replace(/\-\-+/g, '-')
        .replace(/^-+/, '')
        .replace(/-+$/, '');
}

// --- CSV parser ---
function parseCSVLine(line: string): string[] {
    const result: string[] = [];
    let current = '', inQuotes = false;
    for (const ch of line) {
        if (ch === '"') { inQuotes = !inQuotes; }
        else if (ch === ',' && !inQuotes) { result.push(current); current = ''; }
        else { current += ch; }
    }
    result.push(current);
    return result;
}

// --- Approved: skip these specifically from REVIEW ---
const SKIP_MANUFACTURERS = new Set([
    'alfresco', 'astria', 'harman', 'plaza',           // ACTIVE — already in DB
    'athena', 'enerzone', 'osburn', 'valcourt', 'ventis', // WISHLIST — deferred
    'fireplacex', 'xoappliances',                       // REVIEW exceptions
]);

const normalize = (s: string) => s.toLowerCase().replace(/[^a-z0-9]/g, '');

// --- Load CSV ---
const csvPath = path.join(process.cwd(), 'temp/Manufacturers_Brands_Final.csv');
const csvLines = fs.readFileSync(csvPath, 'utf8').trim().split(/\r?\n/).slice(1);

// Build map: normalized mfr name -> { displayName, prefix, mfrWeb, brands[] }
const csvMfrs = new Map<string, {
    displayName: string;
    prefix: string;
    mfrWeb: string;
    status: string;
    brands: { brandName: string; brandSku: string; brandWeb: string; logoUrl: string }[];
}>();

for (const line of csvLines) {
    const c = parseCSVLine(line);
    const mfrName = c[0]?.trim(); if (!mfrName) continue;
    const key = normalize(mfrName);
    if (!csvMfrs.has(key)) csvMfrs.set(key, {
        displayName: mfrName,
        prefix: c[1]?.trim() || '',
        mfrWeb: c[9]?.trim() || '',
        status: c[7]?.trim() || '',
        brands: [],
    });
    const brandName = c[2]?.trim();
    if (brandName) {
        csvMfrs.get(key)!.brands.push({
            brandName,
            brandSku: c[3]?.trim() || '',
            brandWeb: c[4]?.trim() || '',
            logoUrl:  c[5]?.trim() || '',
        });
    }
}

async function main() {
    // Fetch current DB state
    const existingMfrs = await prisma.manufacturer.findMany({
        include: { brands: { select: { name: true, brandSku: true } } }
    });
    const dbMfrMap = new Map(existingMfrs.map(m => [normalize(m.name), m]));

    let mfrsAdded = 0;
    let mfrsSkipped = 0;
    let brandsAdded = 0;

    // --- Part 1: Add the 63 approved REVIEW manufacturers ---
    for (const [key, csv] of Array.from(csvMfrs)) {
        if (SKIP_MANUFACTURERS.has(key)) continue;
        if (csv.status !== 'REVIEW') continue;

        if (dbMfrMap.has(key)) {
            console.log(`  ⏭  SKIP (exists): ${csv.displayName}`);
            mfrsSkipped++;
            continue;
        }

        const mfrSlug = slugify(csv.displayName);

        try {
            const created = await prisma.manufacturer.create({
                data: {
                    name: csv.displayName,
                    slug: mfrSlug,
                    prefix: csv.prefix || null,
                    website: csv.mfrWeb || null,
                    country: 'US',
                    brands: {
                        create: csv.brands.map((b: { brandName: string; brandSku: string; brandWeb: string; logoUrl: string }) => ({
                            name: b.brandName,
                            slug: slugify(b.brandName),
                            brandSku: b.brandSku || null,
                            website: b.brandWeb || null,
                            logoUrl: b.logoUrl || null,
                            isActive: true,
                        })),
                    },
                },
            });
            console.log(`  ✅ ADDED: ${csv.displayName} (${csv.brands.length} brand${csv.brands.length !== 1 ? 's' : ''})`);
            mfrsAdded++;
            brandsAdded += csv.brands.length;
        } catch (err: any) {
            console.error(`  ❌ ERROR: ${csv.displayName} — ${err.message}`);
        }
    }

    // --- Part 2: Add Hampton brand to Miles Industries ---
    const milesKey = normalize('Miles Industries');
    const milesMfr = dbMfrMap.get(milesKey);

    if (!milesMfr) {
        console.error('\n❌ Miles Industries not found in DB — cannot add Hampton brand.');
    } else {
        const hamptonExists = milesMfr.brands.some(
            b => normalize(b.name) === normalize('Hampton') || b.brandSku === 'HAMP'
        );
        if (hamptonExists) {
            console.log('\n  ⏭  SKIP: Hampton brand already exists under Miles Industries');
        } else {
            await prisma.brand.create({
                data: {
                    name: 'Hampton',
                    slug: slugify('Hampton'),
                    brandSku: 'HAMP',
                    website: 'https://www.regency-fire.com',
                    isActive: true,
                    manufacturerId: milesMfr.id,
                },
            });
            console.log('\n  ✅ ADDED: Hampton brand → Miles Industries');
            brandsAdded++;
        }
    }

    console.log('\n' + '='.repeat(50));
    console.log(`Done.`);
    console.log(`  Manufacturers added:  ${mfrsAdded}`);
    console.log(`  Manufacturers skipped: ${mfrsSkipped}`);
    console.log(`  Brands added:         ${brandsAdded}`);
}

main()
    .catch(err => { console.error(err); process.exit(1); })
    .finally(() => prisma.$disconnect());
