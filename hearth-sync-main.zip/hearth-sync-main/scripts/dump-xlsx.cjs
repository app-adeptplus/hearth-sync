const XLSX = require('xlsx');
const fs   = require('fs');

const wb     = XLSX.readFile('temp/Hearth_Grill_Outdoor_Attributes-Research.xlsx');
const output = {};

wb.SheetNames.forEach(name => {
    const ws   = wb.Sheets[name];
    const rows = XLSX.utils.sheet_to_json(ws, { defval: '' });
    output[name] = rows;
    console.log('Sheet "' + name + '": ' + rows.length + ' data rows');
});

fs.writeFileSync('temp/xlsx-dump.json', JSON.stringify(output, null, 2));
console.log('\nWritten to temp/xlsx-dump.json');
