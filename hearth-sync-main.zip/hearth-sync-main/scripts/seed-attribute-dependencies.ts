/**
 * seed-attribute-dependencies.ts
 *
 * Creates AttributeDependency rows linking parent attributes to child attributes
 * that are conditionally shown based on the parent's selected value.
 *
 * Based on the Hearth_Grill_Outdoor_Attributes-Research.xlsx (Hierarchy = Child column).
 *
 * SAFE: Only creates AttributeDependency rows. Never modifies attributes or categories.
 * Idempotent: safe to run more than once.
 *
 * Run: npx tsx scripts/seed-attribute-dependencies.ts
 *      DRY_RUN=true npx tsx scripts/seed-attribute-dependencies.ts
 *
 * NOTE: triggerValue "any" means the child should always appear when the parent
 *       attribute exists on a product, regardless of parent's value. The product
 *       edit page treats "any" as an unconditional "always show" rule.
 */

import prisma from '../src/lib/db';
import { randomUUID } from 'crypto';

// Slugs verified against live DB as of 2026-03-20

const DEPENDENCY_RULES: { parent: string; triggerValue: string; child: string }[] = [

    // ── Fuel Type → Gas Sub-Type ─────────────────────────────────────────────
    { parent: 'fuel-type', triggerValue: 'Gas',    child: 'gas-sub-type' },

    // ── Fuel Type → Pellet → hopper capacity ─────────────────────────────────
    { parent: 'fuel-type', triggerValue: 'Pellet', child: 'hopper-capacity' },

    // ── Venting Type → Vent Termination Type ────────────────────────────────
    { parent: 'venting-type', triggerValue: 'Direct Vent',           child: 'vent-termination-type' },
    { parent: 'venting-type', triggerValue: 'B-Vent (Natural Vent)', child: 'vent-termination-type' },

    // ── Venting Type → Vent Pipe Diameter ───────────────────────────────────
    { parent: 'venting-type', triggerValue: 'Direct Vent',           child: 'vent-pipe-diameter' },
    { parent: 'venting-type', triggerValue: 'B-Vent (Natural Vent)', child: 'vent-pipe-diameter' },

    // ── BTU Input (Max) → BTU Input (Min) ───────────────────────────────────
    { parent: 'btu-input', triggerValue: 'any', child: 'btu-input-min' },

    // ── Efficiency Rating → Efficiency Type ──────────────────────────────────
    { parent: 'efficiency-rating', triggerValue: 'any', child: 'efficiency-type' },

    // ── Ignition Type → Battery Backup ──────────────────────────────────────
    { parent: 'ignition-type', triggerValue: 'Electronic (IPI)',       child: 'battery-backup-included' },
    { parent: 'ignition-type', triggerValue: 'Electronic (Millivolt)', child: 'battery-backup-included' },
    { parent: 'grill-ignition-type', triggerValue: 'Electronic',       child: 'battery-backup-included' },

    // ── Firebox Width → Log Set Size ─────────────────────────────────────────
    { parent: 'firebox-width', triggerValue: 'any', child: 'log-set-size' },

    // ── Fire Media → Flame Color ─────────────────────────────────────────────
    { parent: 'fire-media',      triggerValue: 'any', child: 'flame-color' },
    { parent: 'fire-media-type', triggerValue: 'any', child: 'flame-color' },

    // ── Blower Included → Blower CFM ─────────────────────────────────────────
    { parent: 'blower-included', triggerValue: 'Yes',                child: 'blower-cfm' },
    { parent: 'blower-included', triggerValue: 'Optional Add-On',    child: 'blower-cfm' },

    // ── Certifications → Emissions ────────────────────────────────────────────
    { parent: 'certifications', triggerValue: 'EPA Phase 2', child: 'emissions-g-hr' },

    // ── Heater Style → Emitter Type ──────────────────────────────────────────
    { parent: 'heater-style', triggerValue: 'Infrared Panel', child: 'emitter-type' },

    // ── Heater Style → Heat Settings ─────────────────────────────────────────
    { parent: 'heater-style', triggerValue: 'any', child: 'heat-settings' },

    // ── Weather Resistance Rating → IP Rating ─────────────────────────────────
    { parent: 'weather-resistance-rating', triggerValue: 'All-Weather',             child: 'ip-rating' },
    { parent: 'weather-resistance-rating', triggerValue: 'Covered Use Recommended', child: 'ip-rating' },

    // ── Fire Feature Style → Burner Shape ────────────────────────────────────
    { parent: 'fire-feature-style', triggerValue: 'any', child: 'burner-shape' },

    // ── Storage Cabinet → Side Shelves ───────────────────────────────────────
    { parent: 'storage-cabinet', triggerValue: 'any', child: 'side-shelves' },

    // ── Smoker: PID Controller → WiFi ────────────────────────────────────────
    { parent: 'pid-controller', triggerValue: 'Yes', child: 'wifi-enabled' },
    { parent: 'pid-controller', triggerValue: 'Yes', child: 'bluetooth-enabled' },

    // ── Total BTU → BTU per Main Burner ──────────────────────────────────────
    { parent: 'total-btu', triggerValue: 'any', child: 'btu-per-main-burner' },

    // ── Total BTU → Side Burner BTU ──────────────────────────────────────────
    { parent: 'total-btu', triggerValue: 'any', child: 'side-burner-btu' },

    // ── Total BTU → Infrared Burner BTU ──────────────────────────────────────
    { parent: 'total-btu', triggerValue: 'any', child: 'infrared-burner-btu' },

    // ── Total BTU → Sear Burner BTU ──────────────────────────────────────────
    { parent: 'total-btu', triggerValue: 'any', child: 'sear-burner-btu' },

    // ── Total BTU → Rotisserie Burner BTU ────────────────────────────────────
    { parent: 'total-btu', triggerValue: 'any', child: 'rotisserie-burner-btu' },
];

// ─────────────────────────────────────────────────────────────────────────────

const DRY_RUN = process.env.DRY_RUN === 'true';

async function main() {
    console.log(`\n🔍  Mode: ${DRY_RUN ? 'DRY RUN (no writes)' : 'LIVE'}\n`);

    const attributes  = await prisma.productAttribute.findMany({
        select: { id: true, name: true, slug: true },
    });
    const attrBySlug = new Map(attributes.map(a => [a.slug, a]));

    let created  = 0;
    let skipped  = 0;
    let missingP = 0;
    let missingC = 0;

    for (const rule of DEPENDENCY_RULES) {
        const parent = attrBySlug.get(rule.parent);
        const child  = attrBySlug.get(rule.child);

        if (!parent) {
            console.warn(`⚠  Parent not found: "${rule.parent}"`);
            missingP++;
            continue;
        }
        if (!child) {
            console.warn(`⚠  Child not found: "${rule.child}" (parent: ${rule.parent})`);
            missingC++;
            continue;
        }
        if (parent.id === child.id) continue;

        const existing = await prisma.attributeDependency.findFirst({
            where: {
                parentAttributeId: parent.id,
                triggerValue:      rule.triggerValue,
                childAttributeId:  child.id,
            },
        });
        if (existing) { skipped++; continue; }

        console.log(`  + "${parent.name}" [${rule.triggerValue}] → "${child.name}"`);

        if (!DRY_RUN) {
            await prisma.attributeDependency.create({
                data: {
                    id:                randomUUID(),
                    parentAttributeId: parent.id,
                    triggerValue:      rule.triggerValue,
                    childAttributeId:  child.id,
                    sortOrder:         0,
                },
            });
        }
        created++;
    }

    console.log(`\n✅  Done.`);
    console.log(`   Dependencies created : ${DRY_RUN ? '(dry run) ' : ''}${created}`);
    console.log(`   Already existed      : ${skipped}`);
    console.log(`   Missing parent attrs : ${missingP}`);
    console.log(`   Missing child attrs  : ${missingC}`);
}

main()
    .catch(err => { console.error(err); process.exit(1); })
    .finally(() => prisma.$disconnect());
