/**
 * Seed script: creates the default Hearth Scraper and Grill Scraper prompt templates
 * Run with: npx tsx scripts/seed-prompt-templates.ts
 */
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

const TEMPLATES = [
    {
        name: 'Hearth Product Scraper',
        category: 'SITE_SCRAPER' as const,
        tags: ['hearth', 'fireplace', 'site-scraper'],
        systemPrompt: `You are a product data extraction assistant for a hearth product catalog.
You are extracting products from {{brand_name}}'s website ({{brand_website}}).

{{#if product_type}}
Focus specifically on {{product_type}} products.
{{/if}}

For each product found on the page, extract:
1. Product Name — Full product name/title as displayed
2. SKU / Model Number — Manufacturer SKU, model number, or part number
3. Images — All product image URLs (full resolution when available)
4. Product Description — Full marketing description and product overview

{{#if extraction_fields}}
Additionally extract these specific fields: {{extraction_fields}}
{{/if}}

{{#if custom_instructions}}
Additional instructions: {{custom_instructions}}
{{/if}}

Return structured JSON for each product. If a field is not available on the page, set it to null.`,
        variables: [
            { name: 'brand_name', description: 'Brand name from AutomationConfig', defaultValue: '' },
            { name: 'brand_website', description: 'Brand website URL', defaultValue: '' },
            { name: 'product_type', description: 'Category context (e.g. Gas Fireplaces)', defaultValue: '' },
            { name: 'extraction_fields', description: 'Additional fields to extract', defaultValue: '' },
            { name: 'custom_instructions', description: 'Per-config override instructions', defaultValue: '' },
        ],
    },
    {
        name: 'Grill Data Extractor',
        category: 'SITE_SCRAPER' as const,
        tags: ['grill', 'outdoor', 'cooking', 'site-scraper'],
        systemPrompt: `You are a product data extraction specialist for outdoor grills and cooking equipment.
You are extracting products from {{brand_name}}'s website ({{brand_website}}).

{{#if product_type}}
Product category focus: {{product_type}}
{{/if}}

For each grill or cooking product found, extract:
1. Product Name — Full name including series/model identifier
2. SKU / Model Number — Manufacturer part number
3. Images — All product image URLs
4. Product Description — Full marketing description
5. Grill-Specific Specifications:
   - Cooking area (square inches)
   - BTU rating (total)
   - Number of burners
   - Fuel type (propane / natural gas / charcoal / pellet / electric)
   - Grate material
   - Ignition type
6. Dimensions — Overall dimensions and shipping weight

{{#if custom_instructions}}
Additional instructions: {{custom_instructions}}
{{/if}}

Return structured JSON for each product. Set unavailable fields to null.`,
        variables: [
            { name: 'brand_name', description: 'Brand name', defaultValue: '' },
            { name: 'brand_website', description: 'Brand website URL', defaultValue: '' },
            { name: 'product_type', description: 'Grill category (e.g. Built-in Grills)', defaultValue: '' },
            { name: 'custom_instructions', description: 'Per-config override instructions', defaultValue: '' },
        ],
    },
    {
        name: 'Product Enrichment',
        category: 'ENRICHMENT' as const,
        tags: ['enrichment', 'data-quality'],
        systemPrompt: `You are a product data enrichment specialist for a hearth and outdoor product catalog.

Given the following raw product data, enrich and validate it:

Product: {{brand_name}} — {{product_type}}

{{#if category_context}}
Category context: {{category_context}}
{{/if}}

Tasks:
1. Normalize product name (remove redundant brand prefixes if duplicated)
2. Validate and standardize SKU format
3. Improve product description clarity and completeness
4. Identify and fill any clearly missing specification fields
5. Suggest appropriate product categories based on the description

{{#if custom_instructions}}
Additional instructions: {{custom_instructions}}
{{/if}}

Return a JSON object with enriched fields and a confidence score (0.0-1.0).`,
        variables: [
            { name: 'brand_name', description: 'Product brand', defaultValue: '' },
            { name: 'product_type', description: 'Product type/category', defaultValue: '' },
            { name: 'category_context', description: 'Category research notes', defaultValue: '' },
            { name: 'custom_instructions', description: 'Override instructions', defaultValue: '' },
        ],
    },
];

async function main() {
    console.log('Seeding default prompt templates...');

    for (const template of TEMPLATES) {
        const existing = await prisma.promptTemplate.findFirst({
            where: { name: template.name },
        });

        if (existing) {
            console.log(`  → "${template.name}" already exists (skipping)`);
            continue;
        }

        await prisma.promptTemplate.create({
            data: {
                name: template.name,
                category: template.category,
                systemPrompt: template.systemPrompt,
                variables: template.variables,
                tags: template.tags,
                version: 1,
                isActive: true,
            },
        });
        console.log(`  ✓ Created "${template.name}"`);
    }

    console.log('\nDone! Default prompt templates seeded.');
}

main()
    .catch(e => { console.error(e); process.exit(1); })
    .finally(() => prisma.$disconnect());
