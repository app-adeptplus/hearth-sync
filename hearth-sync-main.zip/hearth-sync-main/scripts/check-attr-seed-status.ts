/**
 * scripts/check-attr-seed-status.ts
 * Pre-flight check before running prisma/temporary_seeds/05-product-attributes.ts
 * Run: npx tsx scripts/check-attr-seed-status.ts
 */

import { PrismaClient } from '@prisma/client';
import * as dotenv from 'dotenv';
dotenv.config();

const p = new PrismaClient();

async function main() {
    const [attrs, maps, cats, products] = await Promise.all([
        p.productAttribute.count(),
        p.categoryAttributeMap.count(),
        p.productCategory.count(),
        p.product.count(),
    ]);

    const migrations = await p.$queryRaw<{ migration_name: string; finished_at: string | null }[]>`
        SELECT migration_name, finished_at
        FROM _prisma_migrations
        ORDER BY finished_at DESC
        LIMIT 5
    `;

    console.log('\n=== HearthSync DB Status ===');
    console.log(`product_attributes:       ${attrs}   ${attrs === 0 ? '✅ ready to seed' : '⚠️  already has data'}`);
    console.log(`category_attribute_maps:  ${maps}   ${maps === 0 ? '✅ ready to seed' : '⚠️  already has data'}`);
    console.log(`product_categories:       ${cats}   ${cats > 0 ? '✅ categories exist (mappings will resolve)' : '⚠️  no categories — mappings will be skipped'}`);
    console.log(`products:                 ${products}`);

    console.log('\n=== Last 5 Prisma Migrations (newest first) ===');
    for (const m of migrations as any[]) {
        const ts = m.finished_at ? new Date(m.finished_at).toISOString().slice(0, 19) : 'PENDING ⚠️ ';
        console.log(`  ${ts} | ${m.migration_name}`);
    }

    // Verify Product scalar fields are still present in DB (i.e. schema not drifted)
    try {
        const sample = await p.product.findFirst({
            select: { id: true, btuInput: true, ventingType: true, width: true, weight: true }
        });
        console.log('\n=== Product Scalar Fields (spot check) ===');
        console.log('  btuInput / ventingType / width / weight accessible ✅');
        if (sample) console.log('  Sample:', JSON.stringify(sample));
        else console.log('  (no products yet — fields exist but are empty)');
    } catch (e: any) {
        console.error('\n  ❌ Product scalar field check FAILED:', e.message);
        console.error('  Schema may be out of sync with DB — run: npx prisma db pull');
    }

    console.log('\n=== Verdict ===');
    if (attrs === 0 && maps === 0 && cats > 0) {
        console.log('  ✅ Safe to run: npx tsx prisma/temporary_seeds/05-product-attributes.ts');
    } else if (cats === 0) {
        console.log('  ⚠️  No product_categories found — seed will create all attrs but skip all category mappings.');
        console.log('     Seed the categories first, then re-run the attribute seed.');
    } else {
        console.log('  ⚠️  Attributes already exist. The seed is idempotent (upsert), so re-running is safe.');
        console.log('     It will update existing records and fill in any missing ones.');
    }
}

main()
    .catch(e => { console.error('Error:', e.message); process.exit(1); })
    .finally(() => p.$disconnect());
