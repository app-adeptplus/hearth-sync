/**
 * migrate-dealer-auth.ts
 *
 * One-time migration to fix the broken dealer auth state:
 *
 * 1. Find all DealerAccount rows with a placeholder userId ("manual-...").
 *    These dealers exist in Prisma but have no Supabase Auth user — they cannot log in.
 *    For each: find the owner DealerUser email, create a real Supabase Auth user,
 *    patch DealerAccount.userId and DealerUser.userId with the real UUID.
 *
 * 2. Find any Supabase Auth users that have portal_role in user_metadata but NOT in
 *    app_metadata (legacy from before the app_metadata migration). Re-tag them into
 *    app_metadata so the new middleware and filters work correctly.
 *
 * Run with:
 *   npx ts-node --project tsconfig.json scripts/migrate-dealer-auth.ts
 *
 * It is safe to run multiple times — it skips dealers that already have a real UUID.
 */

import { PrismaClient } from '@prisma/client';
import { createClient } from '@supabase/supabase-js';
import * as dotenv from 'dotenv';

dotenv.config({ path: '.env' });

const prisma = new PrismaClient();

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!;
const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY!;

if (!supabaseUrl || !serviceKey) {
    console.error('❌ Missing NEXT_PUBLIC_SUPABASE_URL or SUPABASE_SERVICE_ROLE_KEY in .env');
    process.exit(1);
}

const supabase = createClient(supabaseUrl, serviceKey, {
    auth: { autoRefreshToken: false, persistSession: false },
});

function generateTempPassword(): string {
    const digits = Math.floor(100000 + Math.random() * 900000).toString();
    return `Hearth#${digits}`;
}

async function migrateDealers() {
    console.log('\n=== STEP 1: Fix DealerAccounts with placeholder userIds ===\n');

    // Find all dealers with a fake placeholder userId
    const brokenDealers = await prisma.dealerAccount.findMany({
        where: { userId: { startsWith: 'manual-' } },
        include: { users: { where: { role: 'owner' } } },
    });

    if (brokenDealers.length === 0) {
        console.log('✓ No broken dealer accounts found. All dealers have real Supabase user IDs.\n');
    } else {
        console.log(`Found ${brokenDealers.length} dealer(s) with placeholder userIds:\n`);

        for (const dealer of brokenDealers) {
            const ownerUser = dealer.users[0];
            const ownerEmail = ownerUser?.email ?? dealer.email;

            console.log(`  Dealer: "${dealer.companyName}" (id: ${dealer.id})`);
            console.log(`  Placeholder userId: ${dealer.userId}`);
            console.log(`  Owner email: ${ownerEmail}`);

            try {
                // Create a real Supabase Auth user
                const tempPassword = generateTempPassword();
                const { data: createData, error: createError } = await supabase.auth.admin.createUser({
                    email: ownerEmail,
                    password: tempPassword,
                    email_confirm: true,
                    user_metadata: { full_name: dealer.contactName },
                });

                if (createError) {
                    // If user already exists, try to find them
                    if (createError.message?.includes('already')) {
                        console.log(`  ⚠️  User already exists in Supabase for ${ownerEmail} — fetching their UUID...`);
                        const { data: listData } = await supabase.auth.admin.listUsers();
                        const existing = listData?.users.find(u => u.email?.toLowerCase() === ownerEmail.toLowerCase());
                        if (existing) {
                            // Patch app_metadata on existing user
                            await supabase.auth.admin.updateUserById(existing.id, {
                                app_metadata: { portal_role: 'dealer' },
                            });
                            // Patch Prisma rows
                            await prisma.dealerAccount.update({ where: { id: dealer.id }, data: { userId: existing.id } });
                            if (ownerUser) {
                                await prisma.dealerUser.update({ where: { id: ownerUser.id }, data: { userId: existing.id } });
                            }
                            console.log(`  ✓ Linked to existing Supabase user ${existing.id} (no new password — user may already have one)\n`);
                        } else {
                            console.log(`  ❌ Could not find existing user for ${ownerEmail}. Manual intervention needed.\n`);
                        }
                        continue;
                    }
                    throw createError;
                }

                const realUserId = createData.user!.id;

                // Tag with portal_role in app_metadata
                await supabase.auth.admin.updateUserById(realUserId, {
                    app_metadata: { portal_role: 'dealer' },
                });

                // Patch Prisma
                await prisma.dealerAccount.update({ where: { id: dealer.id }, data: { userId: realUserId } });
                if (ownerUser) {
                    await prisma.dealerUser.update({ where: { id: ownerUser.id }, data: { userId: realUserId } });
                }

                console.log(`  ✓ Created Supabase user: ${realUserId}`);
                console.log(`  ✓ Temp password: ${tempPassword}  ← share this with the dealer\n`);

            } catch (err: any) {
                console.error(`  ❌ Failed to migrate dealer "${dealer.companyName}": ${err.message}\n`);
            }
        }
    }
}

async function migrateRolesToAppMetadata() {
    console.log('=== STEP 2: Move portal_role to app_metadata for legacy users ===\n');

    const { data, error } = await supabase.auth.admin.listUsers({ perPage: 1000 });
    if (error) {
        console.error('❌ Failed to list users:', error.message);
        return;
    }

    const needsMigration = data.users.filter((u) => {
        const hasRoleInUserMeta = u.user_metadata?.portal_role;
        const hasRoleInAppMeta = u.app_metadata?.portal_role;
        return hasRoleInUserMeta && !hasRoleInAppMeta;
    });

    if (needsMigration.length === 0) {
        console.log('✓ All users already have portal_role in app_metadata.\n');
        return;
    }

    console.log(`Found ${needsMigration.length} user(s) that need app_metadata migration:\n`);

    for (const user of needsMigration) {
        const role = user.user_metadata?.portal_role as string;
        console.log(`  User: ${user.email} — role: ${role}`);

        const { error: updateError } = await supabase.auth.admin.updateUserById(user.id, {
            app_metadata: { portal_role: role },
        });

        if (updateError) {
            console.error(`  ❌ Failed: ${updateError.message}`);
        } else {
            console.log(`  ✓ Tagged with app_metadata.portal_role = '${role}'`);
        }
    }

    console.log();
}

async function main() {
    console.log('HearthSync Auth Migration Script');
    console.log('================================');

    try {
        await migrateDealers();
        await migrateRolesToAppMetadata();
        console.log('=== Migration complete ===\n');
    } finally {
        await prisma.$disconnect();
    }
}

main().catch((err) => {
    console.error('Fatal error:', err);
    process.exit(1);
});
