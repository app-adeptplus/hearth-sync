import prisma from '../src/lib/db';
async function main() {
    const cats = await prisma.productCategory.findMany({
        where: { parentId: { not: null } },
        select: { slug: true, name: true, parent: { select: { name: true } } },
        orderBy: [{ parent: { name: 'asc' } }, { name: 'asc' }],
    });
    cats.forEach(c => console.log(`${c.parent?.name} | ${c.name} | ${c.slug}`));
}
main().finally(() => prisma.$disconnect());
