/**
 * scripts/check-migration-status.js
 * Verifies which migrations are tracked in _prisma_migrations and
 * whether the physical tables they create actually exist in the DB.
 * Run from project root: node scripts/check-migration-status.js
 */

const { PrismaClient } = require('@prisma/client');
const p = new PrismaClient();

async function check() {
    // 1. What Prisma's migration tracking table says
    const applied = await p.$queryRawUnsafe(
        'SELECT migration_name, finished_at FROM _prisma_migrations ORDER BY started_at'
    );
    console.log('=== Applied Migrations (per _prisma_migrations) ===');
    applied.forEach(m =>
        console.log(' ', m.finished_at ? '✅' : '⏳ PENDING', m.migration_name)
    );

    // 2. Whether the prompt assignment tables physically exist
    const tables = await p.$queryRawUnsafe(`
        SELECT table_name
        FROM information_schema.tables
        WHERE table_schema = 'public'
          AND table_name IN (
            'prompt_assignments',
            'assignment_object_scopes',
            'assignment_mcp_links'
          )
        ORDER BY table_name
    `);
    console.log('\n=== Physical Tables (prompt assignment set) ===');
    if (tables.length === 0) {
        console.log('  ⚠️  NONE of the 3 tables exist yet in the database');
    } else {
        tables.forEach(t => console.log(' ', '✅', t.table_name, 'EXISTS'));
        if (tables.length < 3) {
            console.log('  ⚠️  Some tables are missing — partial state');
        }
    }
}

check()
    .then(() => p.$disconnect())
    .catch(e => { console.error('ERROR:', e.message); p.$disconnect(); });
