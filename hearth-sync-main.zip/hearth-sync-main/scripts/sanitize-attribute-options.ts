/**
 * sanitize-attribute-options.ts
 *
 * One-time script that sanitizes the `options` field on select / enum / multi_select
 * ProductAttribute records:
 *
 *   - Replaces pipe characters "|" with ", "
 *   - Collapses multiple consecutive separators into one
 *   - Trims whitespace around each individual option value
 *   - Removes any empty entries that result from the cleanup
 *
 * Run with:
 *   npx ts-node --project tsconfig.json -e "require('./scripts/sanitize-attribute-options.ts')"
 * or:
 *   npx tsx scripts/sanitize-attribute-options.ts
 */

import prisma from '../src/lib/db';

const OPTION_DATA_TYPES = ['select', 'enum', 'multi_select'];

function sanitizeOptions(raw: string): string {
    return raw
        // Replace all pipe characters with a comma
        .replace(/\|/g, ',')
        // Collapse runs of commas / whitespace into a single comma
        .replace(/,+/g, ',')
        // Split on comma, trim each entry, drop blanks, rejoin
        .split(',')
        .map(o => o.trim())
        .filter(Boolean)
        .join(', ');
}

async function main() {
    // Fetch only select/enum/multi_select attributes that have options defined
    const attrs = await prisma.productAttribute.findMany({
        where: {
            dataType: { in: OPTION_DATA_TYPES },
            options:  { not: null },
        },
        select: { id: true, name: true, dataType: true, options: true },
    });

    console.log(`Found ${attrs.length} attribute(s) with options to inspect.\n`);

    let updated = 0;
    let skipped = 0;

    for (const attr of attrs) {
        const original = attr.options!;
        const sanitized = sanitizeOptions(original);

        if (original === sanitized) {
            skipped++;
            continue;
        }

        console.log(`[${attr.dataType}] ${attr.name}`);
        console.log(`  Before: ${original}`);
        console.log(`  After:  ${sanitized}`);

        await prisma.productAttribute.update({
            where: { id: attr.id },
            data:  { options: sanitized },
        });

        updated++;
    }

    console.log(`\nDone. Updated: ${updated}  |  Unchanged: ${skipped}`);
}

main()
    .catch(err => {
        console.error('Script failed:', err);
        process.exit(1);
    })
    .finally(() => prisma.$disconnect());
