/**
 * Patches doug@futurenowmarketing.com:
 * - Sets app_metadata.portal_role = 'dealer' in Supabase Auth
 * - Links his Supabase UUID to the DealerUser row
 */
import { PrismaClient } from '@prisma/client';
import { createClient } from '@supabase/supabase-js';
import * as dotenv from 'dotenv';

dotenv.config({ path: '.env' });

const prisma = new PrismaClient();
const supabase = createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!,
    { auth: { autoRefreshToken: false, persistSession: false } }
);

async function main() {
    const targetEmail = 'doug@futurenowmarketing.com';

    // Find user in Supabase
    const { data } = await supabase.auth.admin.listUsers({ perPage: 100 });
    const supabaseUser = data?.users.find(u => u.email?.toLowerCase() === targetEmail);

    if (!supabaseUser) {
        console.log(`No Supabase user found for ${targetEmail}. Nothing to do.`);
        await prisma.$disconnect();
        return;
    }

    console.log(`Found Supabase user: ${supabaseUser.id}`);

    // Tag with dealer role in app_metadata
    const { error: tagError } = await supabase.auth.admin.updateUserById(supabaseUser.id, {
        app_metadata: { portal_role: 'dealer' },
    });
    if (tagError) throw new Error(`Failed to tag: ${tagError.message}`);
    console.log(`✓ Tagged with app_metadata.portal_role = 'dealer'`);

    // Link DealerUser row to the Supabase UUID
    const dealerUser = await prisma.dealerUser.findFirst({ where: { email: targetEmail } });
    if (dealerUser) {
        await prisma.dealerUser.update({
            where: { id: dealerUser.id },
            data: { userId: supabaseUser.id },
        });
        console.log(`✓ Linked DealerUser row to userId: ${supabaseUser.id}`);
    } else {
        console.log(`No DealerUser row found for ${targetEmail}.`);
    }

    await prisma.$disconnect();
    console.log('Done.');
}

main().catch(console.error);
