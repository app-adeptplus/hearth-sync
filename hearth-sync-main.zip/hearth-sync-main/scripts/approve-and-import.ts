/**
 * scripts/approve-and-import.ts
 * 
 * Approves all pending DataPackageItems in a package, then calls the import route
 * to create Product records from the approved items.
 * 
 * Usage: npx tsx scripts/approve-and-import.ts <packageId>
 */

const PACKAGE_ID = process.argv[2] || 'cmmzbj61i00255jqb0a1qjdjc';
const BASE_URL = 'http://localhost:5000';

async function main() {
    console.log(`\n📦 Approving and importing package: ${PACKAGE_ID}\n`);

    // Step 1: Get the package and its items
    const pkgRes = await fetch(`${BASE_URL}/api/automation/data-packages/${PACKAGE_ID}`);
    if (!pkgRes.ok) {
        console.error(`❌ Failed to load package: ${pkgRes.status} ${await pkgRes.text()}`);
        process.exit(1);
    }
    const pkg = await pkgRes.json();
    console.log(`Package: "${pkg.name}" | Status: ${pkg.status} | Items: ${pkg.items?.length || 0}`);

    if (!pkg.items || pkg.items.length === 0) {
        console.error('❌ No items found in package');
        process.exit(1);
    }

    // Show items before approval
    console.log(`\n--- Items to approve ---`);
    for (const item of pkg.items) {
        console.log(`  [${item.status}] ${item.parsedName || 'Unnamed'} (confidence: ${Math.round((item.confidence || 0) * 100)}%)`);
    }

    // Step 2: Approve all pending items by calling the PATCH endpoint for each
    // Since we don't have a bulk-approve API, we'll update via direct DB call
    console.log(`\n✅ Approving ${pkg.items.filter((i: any) => i.status === 'pending').length} pending items...`);

    // Use a direct Prisma update via a temporary endpoint call
    const approveRes = await fetch(`${BASE_URL}/api/automation/data-packages/${PACKAGE_ID}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
            action: 'approve-all'
        }),
    });

    if (approveRes.ok) {
        const result = await approveRes.json();
        console.log(`   Approved: ${JSON.stringify(result)}`);
    } else {
        // If PATCH doesn't support approve-all, we'll need to do it item by item
        console.log(`   ⚠️ Bulk approve not available via API (${approveRes.status}), approving via individual updates...`);
        
        for (const item of pkg.items) {
            if (item.status !== 'approved') {
                try {
                    const res = await fetch(`${BASE_URL}/api/automation/data-packages/${PACKAGE_ID}/items/${item.id}`, {
                        method: 'PATCH',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ status: 'approved' }),
                    });
                    if (res.ok) {
                        console.log(`   ✅ Approved: ${item.parsedName || item.id}`);
                    } else {
                        console.log(`   ⚠️ Failed to approve ${item.id}: ${res.status}`);
                    }
                } catch (err) {
                    console.log(`   ⚠️ Error approving ${item.id}: ${err}`);
                }
            }
        }
    }

    // Step 3: Call the import route
    console.log(`\n📥 Importing approved items into Products table...`);
    const importRes = await fetch(`${BASE_URL}/api/automation/data-packages/${PACKAGE_ID}/import`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
    });

    if (!importRes.ok) {
        const errText = await importRes.text();
        console.error(`❌ Import failed: ${importRes.status} — ${errText}`);
        process.exit(1);
    }

    const importResult = await importRes.json();
    console.log(`\n🎉 Import complete!`);
    console.log(`   Created: ${importResult.created}`);
    console.log(`   Updated: ${importResult.updated}`);
    if (importResult.errors?.length) {
        console.log(`   Errors: ${importResult.errors.length}`);
        for (const err of importResult.errors) {
            console.log(`     - ${err}`);
        }
    }

    // Step 4: Verify — check the products table
    console.log(`\n📋 Verifying products in the database...`);
    const productsRes = await fetch(`${BASE_URL}/api/products?brandId=${pkg.brandId}`);
    if (productsRes.ok) {
        const products = await productsRes.json();
        const productList = Array.isArray(products) ? products : products.products || [];
        console.log(`   Total products for this brand: ${productList.length}`);
        for (const p of productList.slice(0, 15)) {
            console.log(`   🔹 ${p.name} (SKU: ${p.sku || 'none'}, Status: ${p.status})`);
        }
    } else {
        console.log(`   ⚠️ Could not verify products: ${productsRes.status}`);
    }
}

main().catch(err => {
    console.error('Fatal error:', err);
    process.exit(1);
});
