const { PrismaClient } = require('@prisma/client');

async function migrate() {
    const prisma = new PrismaClient();

    try {
        // 1. Get all CATEGORY scraper configs with brand info
        const categoryConfigs = await prisma.scraperConfig.findMany({
            where: { type: 'CATEGORY' },
            include: {
                brand: { select: { id: true, name: true } },
            },
            orderBy: { name: 'asc' },
        });

        console.log(`Found ${categoryConfigs.length} CATEGORY scraper configs to migrate.\n`);

        let created = 0;
        let skipped = 0;

        for (const config of categoryConfigs) {
            const name = config.name;
            const siteUrl = config.baseUrl;
            const brandId = config.brandId;

            // Check if already migrated
            const existing = await prisma.automationConfig.findFirst({
                where: {
                    OR: [
                        { name: name },
                        ...(siteUrl ? [{ siteUrl: siteUrl }] : []),
                    ],
                },
            });

            if (existing) {
                console.log(`SKIP "${name}" (already exists: ${existing.id})`);
                skipped++;
                continue;
            }

            const newConfig = await prisma.automationConfig.create({
                data: {
                    name: name,
                    brandId: brandId || null,
                    sourceType: 'SITE_SCRAPER',
                    status: 'DRAFT',
                    occurrence: 'MANUAL',
                    siteUrl: siteUrl || null,
                    notes: `Migrated from ScraperConfig #${config.id} (CATEGORY). Original sync frequency: ${config.syncFrequency}.`,
                },
            });

            console.log(`OK   "${name}" -> brand: ${config.brand?.name || 'none'} | url: ${siteUrl || 'none'}`);
            created++;
        }

        console.log(`\n--- DONE: ${created} created, ${skipped} skipped ---`);
    } catch (error) {
        console.error('Migration failed:', error);
    } finally {
        await prisma['$disconnect']();
    }
}

migrate();
