import { createClient } from '@supabase/supabase-js';
import * as dotenv from 'dotenv';
import * as fs from 'fs';

dotenv.config({ path: '.env' });

const supabase = createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!,
    { auth: { autoRefreshToken: false, persistSession: false } }
);

async function main() {
    const { data, error } = await supabase.auth.admin.listUsers({ perPage: 100 });
    if (error) { console.error(error); return; }

    const lines: string[] = [];
    data.users.forEach(u => {
        lines.push(`--- ${u.email} ---`);
        lines.push(`  app_metadata keys: ${JSON.stringify(Object.keys(u.app_metadata ?? {}))}`);
        lines.push(`  app_metadata value: ${JSON.stringify(u.app_metadata)}`);
        lines.push(`  user_metadata value: ${JSON.stringify(u.user_metadata)}`);
        // Check all possible field names
        const raw = u as any;
        lines.push(`  raw.app_metadata: ${JSON.stringify(raw.app_metadata)}`);
        lines.push(`  raw.raw_app_meta_data: ${JSON.stringify(raw.raw_app_meta_data)}`);
        lines.push(`  raw.raw_user_meta_data: ${JSON.stringify(raw.raw_user_meta_data)}`);
    });

    const output = lines.join('\n');
    console.log(output);
    fs.writeFileSync('logs/auth-field-debug.log', output);
    console.log('\nWritten to logs/auth-field-debug.log');
}

main().catch(console.error);
