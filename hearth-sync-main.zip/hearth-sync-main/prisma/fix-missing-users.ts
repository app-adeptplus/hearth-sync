import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function main() {
    console.log('Fetching all dealer accounts...');

    // Using raw query in case the Prisma client isn't fully updated 
    // to type-safe include the 'users' relation yet in this script's context.
    // However, if db:push was successful, the table exists.

    const dealers = await prisma.dealerAccount.findMany();
    console.log(`Found ${dealers.length} dealers.`);

    let createdCount = 0;

    for (const dealer of dealers) {
        // Check if a user already exists for this dealer
        // We'll use a raw query just to be extremely safe if the client is out of date
        const existingUsers: any[] = await prisma.$queryRaw`SELECT id FROM dealer_users WHERE "dealerId" = ${dealer.id}`;

        if (existingUsers.length === 0) {
            console.log(`Dealer ${dealer.companyName} has no users. Creating owner user for ${dealer.email}...`);
            await prisma.$executeRaw`
                INSERT INTO dealer_users (id, "dealerId", email, role, "updatedAt") 
                VALUES (gen_random_uuid()::text, ${dealer.id}, ${dealer.email}, 'owner', NOW())
            `;
            createdCount++;
        } else {
            console.log(`Dealer ${dealer.companyName} already has ${existingUsers.length} user(s). Skipping.`);
        }
    }

    console.log(`\nDone! Created ${createdCount} missing dealer users.`);
}

main()
    .catch((e) => {
        console.error(e);
        process.exit(1);
    })
    .finally(async () => {
        await prisma.$disconnect();
    });
