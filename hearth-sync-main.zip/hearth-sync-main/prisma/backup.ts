/**
 * prisma/backup.ts
 * ─────────────────────────────────────────────────────────────────────────────
 * Snapshots ALL database tables to JSON before a schema migration.
 *
 * Tables are discovered dynamically via information_schema — you never need to
 * manually update this file when a new model is added to schema.prisma.
 * FK-safe restore order is imported from prisma/seeds/generate-seed.ts.
 *
 * Usage:
 *   npm run db:backup
 *   npm run db:backup -- --label "before-ftp-migration"
 *
 * Output: prisma/backups/<timestamp>[-label]/<table>.json + _manifest.json
 * ─────────────────────────────────────────────────────────────────────────────
 */

import { PrismaClient } from '@prisma/client';
import * as fs from 'fs';
import * as path from 'path';
import { FK_SAFE_TABLE_ORDER, TABLE_CLASSIFICATION } from './seeds/generate-seed';

const prisma = new PrismaClient();

async function backup() {
    // Optional human-readable label: --label <text>
    const labelIdx = process.argv.indexOf('--label');
    const label = labelIdx !== -1 ? `-${process.argv[labelIdx + 1].replace(/\s+/g, '-')}` : '';

    const timestamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
    const dirName = `${timestamp}${label}`;
    const backupDir = path.join(__dirname, 'backups', dirName);
    fs.mkdirSync(backupDir, { recursive: true });

    console.log(`\n📦 Starting backup → prisma/backups/${dirName}\n`);

    // ── Discover all tables dynamically ───────────────────────────────────────
    const discovered = await prisma.$queryRaw<{ table_name: string }[]>`
        SELECT table_name
        FROM information_schema.tables
        WHERE table_schema = 'public' AND table_type = 'BASE TABLE'
        ORDER BY table_name
    `;
    const allDbTables = discovered.map(r => r.table_name);

    // Build ordered list: known FK-safe first, then any unknown new tables
    const orderedTables = [
        ...FK_SAFE_TABLE_ORDER.filter(t => allDbTables.includes(t)),
        ...allDbTables.filter(t => !FK_SAFE_TABLE_ORDER.includes(t)),
    ];

    const unknownTables = allDbTables.filter(t => !FK_SAFE_TABLE_ORDER.includes(t));
    if (unknownTables.length > 0) {
        console.log(`   ⚠️  New tables not in FK order (will be appended): ${unknownTables.join(', ')}`);
        console.log(`      → Add them to FK_SAFE_TABLE_ORDER in prisma/seeds/generate-seed.ts\n`);
    }

    console.log(`   Backing up ${orderedTables.length} tables...\n`);

    const counts: Record<string, number> = {};
    const classification: Record<string, string> = {};

    for (const table of orderedTables) {
        try {
            const rows = await prisma.$queryRawUnsafe<any[]>(`SELECT * FROM "${table}"`);
            const filePath = path.join(backupDir, `${table}.json`);
            fs.writeFileSync(filePath, JSON.stringify(rows, null, 2), 'utf-8');
            counts[table] = rows.length;
            classification[table] = TABLE_CLASSIFICATION[table] ?? 'transactional';
            const rowLabel = rows.length.toLocaleString().padStart(6);
            console.log(`  ✅ ${table.padEnd(36)} ${rowLabel} rows`);
        } catch (err: any) {
            console.warn(`  ⚠️  ${table.padEnd(36)} SKIPPED — ${err.message}`);
            counts[table] = -1;
        }
    }

    const totalRows = Object.values(counts).filter(n => n >= 0).reduce((a, b) => a + b, 0);

    const manifest = {
        timestamp,
        label: label.slice(1) || null,
        schemaFingerprint: readSchemaFingerprint(),
        tablesFound: allDbTables.length,
        unknownTables,
        classification,
        tables: counts,
        totalRows,
    };

    fs.writeFileSync(
        path.join(backupDir, '_manifest.json'),
        JSON.stringify(manifest, null, 2)
    );

    console.log(`\n✅ Backup complete. ${totalRows.toLocaleString()} rows → prisma/backups/${dirName}\n`);
    await prisma.$disconnect();
}

/**
 * Returns a quick fingerprint of the schema for change detection.
 * Just reads the first 2000 chars of schema.prisma and hashes them.
 */
function readSchemaFingerprint(): string {
    try {
        const schemaPath = path.join(__dirname, 'schema.prisma');
        const content = fs.readFileSync(schemaPath, 'utf-8');
        let hash = 0;
        for (let i = 0; i < content.length; i++) {
            hash = (hash << 5) - hash + content.charCodeAt(i);
            hash |= 0;
        }
        return Math.abs(hash).toString(16);
    } catch {
        return 'unknown';
    }
}

backup().catch(async (err) => {
    console.error('\n❌ Backup failed:', err.message);
    await prisma.$disconnect();
    process.exit(1);
});
