/**
 * One-time migration script:
 * 1. Upserts the 4 new parent categories
 * 2. Migrates existing FuelType rows → sub-categories under "Fuel Type"
 * 3. Migrates existing ProductType rows → sub-categories under "Hearth Product Type"
 *
 * Run BEFORE the prisma migrate dev that drops fuel_types / product_types.
 * Safe to re-run (all upserts).
 *
 * Usage:  npx ts-node --compiler-options "{\"module\":\"CommonJS\"}" prisma/migrate-categories.ts
 */

import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

function slugify(text: string): string {
    return text.toString().toLowerCase()
        .replace(/\s+/g, '-')
        .replace(/[^\w\-]+/g, '')
        .replace(/\-\-+/g, '-')
        .replace(/^-+/, '')
        .replace(/-+$/, '');
}

async function main() {
    console.log('=== Category Migration ===\n');

    // ─── 1. Upsert parent categories ─────────────────────────────────────────
    const parents = [
        { name: 'Fuel Type', slug: 'fuel-type' },
        { name: 'Hearth Product Type', slug: 'hearth-product-type' },
        { name: 'Outdoor Kitchen Product Type', slug: 'outdoor-kitchen-product-type' },
        { name: 'Outdoor Living Product Type', slug: 'outdoor-living-product-type' },
    ];

    const parentMap: Record<string, string> = {};

    for (const p of parents) {
        const cat = await prisma.productCategory.upsert({
            where: { slug: p.slug },
            update: {},
            create: { name: p.name, slug: p.slug, sortOrder: 0 },
        });
        parentMap[p.slug] = cat.id;
        console.log(`✔ Parent category: ${p.name} (${cat.id})`);
    }

    // ─── 2. Migrate FuelType rows ─────────────────────────────────────────────
    console.log('\nMigrating FuelType rows...');
    const fuelTypes = await (prisma as any).fuelType.findMany();

    for (const ft of fuelTypes) {
        const child = await prisma.productCategory.upsert({
            where: { slug: ft.slug },
            update: { parentId: parentMap['fuel-type'] },
            create: {
                name: ft.name,
                slug: ft.slug,
                parentId: parentMap['fuel-type'],
                sortOrder: 0,
            },
        });
        console.log(`  ↳ Fuel sub-category: ${ft.name} (${child.id})`);
    }

    // ─── 3. Migrate ProductType rows ──────────────────────────────────────────
    console.log('\nMigrating ProductType rows...');
    const productTypes = await (prisma as any).productType.findMany();

    for (const pt of productTypes) {
        const child = await prisma.productCategory.upsert({
            where: { slug: pt.slug },
            update: { parentId: parentMap['hearth-product-type'] },
            create: {
                name: pt.name,
                slug: pt.slug,
                parentId: parentMap['hearth-product-type'],
                sortOrder: 0,
            },
        });
        console.log(`  ↳ Product type sub-category: ${pt.name} (${child.id})`);
    }

    console.log('\n=== Migration complete ===');
}

main()
    .catch((e) => { console.error(e); process.exit(1); })
    .finally(() => prisma.$disconnect());
