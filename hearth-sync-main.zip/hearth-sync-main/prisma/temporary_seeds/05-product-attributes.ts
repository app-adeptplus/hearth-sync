/**
 * prisma/seeds/05-product-attributes.ts
 * ─────────────────────────────────────────────────────────────────────────────
 * Seeds ProductAttribute records and CategoryAttributeMap bridge rows using
 * industry-standard attribute definitions from the Hearth/Grill/Outdoor research.
 *
 * Design:
 *  - Excludes Product model first-class fields: name, modelNumber, sku, brand,
 *    categories relation, shortDescription, description, priceMap, priceMsrp
 *  - Previously-scalar fields (btuInput, btuOutput, efficiencyRating,
 *    ventingType, width, height, depth, weight) are now attributes here.
 *  - Fully idempotent — upserts on slug/[categoryId,attributeId] unique keys.
 *  - Missing category slugs are skipped with a warning, never fail.
 *
 * Run standalone: npx tsx prisma/seeds/05-product-attributes.ts
 */

import { PrismaClient } from '@prisma/client';
import * as dotenv from 'dotenv';
import { ATTRS, CATEGORY_PROFILES, FILTERABLE_SLUGS, REQUIRED_SLUGS } from './05-attribute-data';

dotenv.config();

// ─── Main export ───────────────────────────────────────────────────────────────

export async function seedProductAttributes(prisma: PrismaClient): Promise<void> {
    console.log('\n\uD83C\uDFF7\uFE0F  [05] Seeding product attributes...');

    // ── Step 1: Upsert all attribute definitions ───────────────────────────────
    let attrCreated = 0;
    let attrUpdated = 0;

    for (const attr of ATTRS) {
        const existing = await prisma.productAttribute.findUnique({ where: { slug: attr.slug } });
        if (existing) {
            await prisma.productAttribute.update({
                where: { slug: attr.slug },
                data: {
                    name:        attr.name,
                    description: attr.description ?? null,
                    dataType:    attr.dataType,
                    unit:        attr.unit ?? null,
                    options:     attr.options ?? null,
                    industry:    attr.industry ?? null,
                    isSystem:    attr.isSystem ?? false,
                    sortOrder:   attr.sortOrder,
                },
            });
            attrUpdated++;
        } else {
            await prisma.productAttribute.create({
                data: {
                    name:        attr.name,
                    slug:        attr.slug,
                    description: attr.description ?? null,
                    dataType:    attr.dataType,
                    unit:        attr.unit ?? null,
                    options:     attr.options ?? null,
                    industry:    attr.industry ?? null,
                    isSystem:    attr.isSystem ?? false,
                    sortOrder:   attr.sortOrder,
                },
            });
            attrCreated++;
        }
    }

    console.log(`   \u2705 Attributes: ${attrCreated} created, ${attrUpdated} updated (${ATTRS.length} total)`);

    // ── Step 2: Build slug → id lookup ────────────────────────────────────────
    const allAttrs = await prisma.productAttribute.findMany({ select: { id: true, slug: true } });
    const attrBySlug = new Map(allAttrs.map(a => [a.slug, a.id]));

    // ── Step 3: Load categories by slug ───────────────────────────────────────
    const allCats = await prisma.productCategory.findMany({ select: { id: true, slug: true } });
    const catBySlug = new Map(allCats.map(c => [c.slug, c.id]));

    // ── Step 4: Upsert CategoryAttributeMap entries ───────────────────────────
    let mapCreated = 0;
    let mapUpdated = 0;
    const missingCats: string[] = [];
    const missingAttrs: string[] = [];

    for (const [catSlug, attrSlugs] of Object.entries(CATEGORY_PROFILES)) {
        const categoryId = catBySlug.get(catSlug);
        if (!categoryId) {
            missingCats.push(catSlug);
            continue;
        }

        // Deduplicate attr slugs within this category profile
        const seen = new Set<string>();
        let mapSortOrder = 0;

        for (const attrSlug of attrSlugs) {
            if (seen.has(attrSlug)) continue;
            seen.add(attrSlug);

            const attributeId = attrBySlug.get(attrSlug);
            if (!attributeId) {
                if (!missingAttrs.includes(attrSlug)) missingAttrs.push(attrSlug);
                continue;
            }

            const isRequired   = REQUIRED_SLUGS.has(attrSlug);
            const isFilterable = FILTERABLE_SLUGS.has(attrSlug);

            const existing = await prisma.categoryAttributeMap.findUnique({
                where: { categoryId_attributeId: { categoryId, attributeId } },
            });

            if (existing) {
                await prisma.categoryAttributeMap.update({
                    where: { categoryId_attributeId: { categoryId, attributeId } },
                    data: { isRequired, isFilterable, sortOrder: mapSortOrder },
                });
                mapUpdated++;
            } else {
                await prisma.categoryAttributeMap.create({
                    data: { categoryId, attributeId, isRequired, isFilterable, sortOrder: mapSortOrder },
                });
                mapCreated++;
            }

            mapSortOrder++;
        }
    }

    console.log(`   \u2705 Category maps: ${mapCreated} created, ${mapUpdated} updated`);

    if (missingCats.length > 0) {
        console.warn(`   \u26a0\uFE0F  ${missingCats.length} category slug(s) not found in DB — mappings skipped:`);
        missingCats.forEach(s => console.warn(`       \u2022 ${s}`));
    }
    if (missingAttrs.length > 0) {
        console.warn(`   \u26a0\uFE0F  ${missingAttrs.length} attribute slug(s) not resolved (check data file):`);
        missingAttrs.forEach(s => console.warn(`       \u2022 ${s}`));
    }

    console.log(`   \u2705 [05] Product attributes complete.`);
}

// ─── Standalone runner ─────────────────────────────────────────────────────────

if (require.main === module) {
    const prisma = new PrismaClient();
    dotenv.config();
    seedProductAttributes(prisma)
        .catch(e => { console.error('Seed error:', e); process.exit(1); })
        .finally(() => prisma.$disconnect());
}
