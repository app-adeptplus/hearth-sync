/**
 * prisma/seeds/05-attribute-data.ts
 * Pure data: ATTRS array + category profile maps.
 * Imported by 05-product-attributes.ts.
 */

export interface AttrDef {
    name: string; slug: string; description?: string;
    dataType: string; unit?: string; options?: string;
    industry?: string; isSystem?: boolean; sortOrder: number;
}

export const ATTRS: AttrDef[] = [
    // ── Cross-vertical ────────────────────────────────────────────────────────
    { name:'Fuel Type', slug:'fuel-type', dataType:'select', options:'Natural Gas|Liquid Propane|Wood|Charcoal|Pellet|Electric|Gel/Ethanol|Multi-Fuel|Solar', industry:'all', isSystem:true, sortOrder:10 },
    { name:'Gas Sub-Type', slug:'gas-sub-type', dataType:'select', options:'Natural Gas (NG)|Liquid Propane (LP)', industry:'all', isSystem:true, sortOrder:11 },
    { name:'Convertible (NG\u21c4LP)', slug:'convertible-ng-lp', dataType:'boolean', industry:'all', isSystem:true, sortOrder:12 },
    { name:'Conversion Kit Included', slug:'conversion-kit-included', dataType:'boolean', industry:'all', sortOrder:13 },
    { name:'Indoor/Outdoor Use', slug:'indoor-outdoor-use', dataType:'select', options:'Indoor Only|Outdoor Only|Indoor/Outdoor', industry:'all', isSystem:true, sortOrder:20 },
    { name:'Assembly Required', slug:'assembly-required', dataType:'boolean', industry:'all', sortOrder:21 },
    { name:'Portable', slug:'portable', dataType:'boolean', industry:'all', isSystem:true, sortOrder:22 },
    { name:'WiFi Enabled', slug:'wifi-enabled', dataType:'boolean', industry:'all', isSystem:true, sortOrder:23 },
    { name:'Bluetooth Enabled', slug:'bluetooth-enabled', dataType:'boolean', industry:'all', sortOrder:24 },
    { name:'App Compatible', slug:'app-compatible', dataType:'boolean', industry:'all', sortOrder:25 },
    { name:'Cover Included', slug:'cover-included', dataType:'boolean', industry:'all', sortOrder:26 },
    { name:'Safety Shutoff', slug:'safety-shutoff', dataType:'boolean', industry:'all', sortOrder:27 },
    { name:'Certifications', slug:'certifications', dataType:'multi_select', options:'CSA|UL|ETL|AGA|ANSI|NSF|EPA Phase 2', industry:'all', isSystem:true, sortOrder:28 },
    { name:'Finish/Color', slug:'finish-color', dataType:'text', industry:'all', sortOrder:29 },
    // Shared dimensions (migrated from Product model scalars)
    { name:'Width', slug:'width', dataType:'number', unit:'in', industry:'all', isSystem:true, sortOrder:80 },
    { name:'Height', slug:'height', dataType:'number', unit:'in', industry:'all', isSystem:true, sortOrder:81 },
    { name:'Depth', slug:'depth', dataType:'number', unit:'in', industry:'all', isSystem:true, sortOrder:82 },
    { name:'Weight', slug:'weight', dataType:'number', unit:'lbs', industry:'all', isSystem:true, sortOrder:83 },

    // ── Hearth: Fuel sub-types ────────────────────────────────────────────────
    { name:'Wood Sub-Type', slug:'wood-sub-type', dataType:'select', options:'Cord Wood|Manufactured Log|Bio-Brick', industry:'hearth', sortOrder:30 },
    { name:'Pellet Sub-Type', slug:'pellet-sub-type', dataType:'select', options:'Wood Pellet|Corn/Biomass|Multi-Fuel Pellet', industry:'hearth', sortOrder:31 },
    { name:'Hopper Capacity', slug:'hopper-capacity', dataType:'number', unit:'lbs', industry:'hearth', sortOrder:32 },

    // ── Hearth: Venting ───────────────────────────────────────────────────────
    { name:'Venting Type', slug:'venting-type', dataType:'select', options:'Direct Vent|B-Vent|Ventless/Vent-Free|Power Vent|Natural Vent', description:'Ventless restricted in CA and MA.', industry:'hearth', isSystem:true, sortOrder:40 },
    { name:'Vent Termination Type', slug:'vent-termination-type', dataType:'select', options:'Top Vent|Rear Vent|Horizontal|Vertical|Basement', industry:'hearth', sortOrder:41 },
    { name:'Vent Pipe Diameter', slug:'vent-pipe-diameter', dataType:'number', unit:'in', industry:'hearth', sortOrder:42 },

    // ── Hearth: BTU & Heating (migrated from Product model) ──────────────────
    { name:'BTU Input', slug:'btu-input', dataType:'number', unit:'BTU/hr', industry:'hearth', isSystem:true, sortOrder:50 },
    { name:'BTU Input Min', slug:'btu-input-min', dataType:'number', unit:'BTU/hr', industry:'hearth', sortOrder:51 },
    { name:'BTU Output', slug:'btu-output', dataType:'number', unit:'BTU/hr', industry:'hearth', isSystem:true, sortOrder:52 },
    { name:'Heating Area', slug:'heating-area', dataType:'number', unit:'sq ft', industry:'hearth', isSystem:true, sortOrder:53 },
    { name:'Efficiency Rating', slug:'efficiency-rating', dataType:'number', unit:'%', industry:'hearth', isSystem:true, sortOrder:54 },
    { name:'Efficiency Type', slug:'efficiency-type', dataType:'select', options:'Thermal|AFUE|Steady-State|Annual', industry:'hearth', sortOrder:55 },

    // ── Hearth: Ignition ──────────────────────────────────────────────────────
    { name:'Ignition Type', slug:'ignition-type', dataType:'select', options:'IPI (Intermittent Pilot)|Millivolt|Standing Pilot|HSI (Hot Surface)|Match Light', industry:'hearth', isSystem:true, sortOrder:60 },
    { name:'Battery Backup Included', slug:'battery-backup-included', dataType:'boolean', industry:'hearth', sortOrder:61 },
    { name:'Remote Included', slug:'remote-included', dataType:'boolean', industry:'hearth', sortOrder:62 },

    // ── Hearth: Firebox Dimensions ────────────────────────────────────────────
    { name:'Firebox Width', slug:'firebox-width', dataType:'number', unit:'in', industry:'hearth', sortOrder:70 },
    { name:'Firebox Height', slug:'firebox-height', dataType:'number', unit:'in', industry:'hearth', sortOrder:71 },
    { name:'Firebox Depth', slug:'firebox-depth', dataType:'number', unit:'in', industry:'hearth', sortOrder:72 },
    { name:'Log Set Size', slug:'log-set-size', dataType:'number', unit:'in', industry:'hearth', sortOrder:73 },
    { name:'Viewing Area', slug:'viewing-area', dataType:'number', unit:'sq in', industry:'hearth', sortOrder:74 },
    { name:'Framing Opening', slug:'framing-opening', dataType:'text', industry:'hearth', sortOrder:75 },

    // ── Hearth: Materials & Finish ────────────────────────────────────────────
    { name:'Body Material', slug:'body-material', dataType:'select', options:'Steel|Cast Iron|Refractory|Porcelain|Ceramic|Aluminum|Stainless Steel', industry:'hearth', sortOrder:90 },
    { name:'Glass Type', slug:'glass-type', dataType:'select', options:'Ceramic Glass|Tempered Glass|Panoramic|Arched|Rectangular', industry:'hearth', sortOrder:91 },
    { name:'Frame/Surround Finish', slug:'frame-surround-finish', dataType:'select', options:'Matte Black|Brushed Nickel|Polished Brass|Oil-Rubbed Bronze|Pewter|Stainless Steel|Custom', industry:'hearth', isSystem:true, sortOrder:92 },
    { name:'Fire Media Type', slug:'fire-media-type', dataType:'select', options:'Ceramic Logs|River Rocks|Glass Gems|Driftwood|Birch Logs|Crystals', industry:'hearth', sortOrder:93 },
    { name:'Flame Color', slug:'flame-color', dataType:'select', options:'Yellow/Orange|Blue|Multi-Color|White', industry:'hearth', sortOrder:94 },

    // ── Hearth: Installation ──────────────────────────────────────────────────
    { name:'Installation Type', slug:'installation-type', dataType:'select', options:'Built-In|Insert|Freestanding|Wall-Mount|Mantel', industry:'hearth', isSystem:true, sortOrder:100 },
    { name:'Blower Included', slug:'blower-included', dataType:'boolean', industry:'hearth', sortOrder:101 },
    { name:'Blower CFM', slug:'blower-cfm', dataType:'number', unit:'CFM', industry:'hearth', sortOrder:102 },
    { name:'Mantel Compatible', slug:'mantel-compatible', dataType:'boolean', industry:'hearth', sortOrder:103 },

    // ── Hearth: Certifications ────────────────────────────────────────────────
    { name:'EPA Phase 2 Certified', slug:'epa-phase-2-certified', dataType:'boolean', description:'Required for US wood-burning products sold after May 15 2020.', industry:'hearth', isSystem:true, sortOrder:110 },
    { name:'Emissions (g/hr)', slug:'emissions-g-hr', dataType:'number', unit:'g/hr', industry:'hearth', sortOrder:111 },
    { name:'CSA Certified', slug:'csa-certified', dataType:'boolean', industry:'hearth', sortOrder:112 },
    { name:'UL Listed', slug:'ul-listed', dataType:'boolean', industry:'hearth', sortOrder:113 },
    { name:'AGA Certified', slug:'aga-certified', dataType:'boolean', industry:'hearth', sortOrder:114 },
    { name:'ANSI Compliant', slug:'ansi-compliant', dataType:'boolean', industry:'hearth', sortOrder:115 },

    // ── Hearth: Warranty ──────────────────────────────────────────────────────
    { name:'Heat Exchanger Warranty', slug:'heat-exchanger-warranty', dataType:'text', industry:'hearth', sortOrder:120 },
    { name:'Parts Warranty', slug:'parts-warranty', dataType:'text', industry:'hearth', sortOrder:121 },
    { name:'Labor Warranty', slug:'labor-warranty', dataType:'text', industry:'hearth', sortOrder:122 },

    // ── Grills: Cooking Area ──────────────────────────────────────────────────
    { name:'Primary Cooking Area', slug:'primary-cooking-area', dataType:'number', unit:'sq in', industry:'grills', isSystem:true, sortOrder:130 },
    { name:'Secondary/Warming Area', slug:'secondary-warming-area', dataType:'number', unit:'sq in', industry:'grills', sortOrder:131 },
    { name:'Total Cooking Area', slug:'total-cooking-area', dataType:'number', unit:'sq in', industry:'grills', isSystem:true, sortOrder:132 },
    { name:'Number of Main Burners', slug:'number-of-main-burners', dataType:'number', industry:'grills', isSystem:true, sortOrder:133 },
    { name:'Number of Grates', slug:'number-of-grates', dataType:'number', industry:'grills', sortOrder:134 },

    // ── Grills: BTU & Heat ────────────────────────────────────────────────────
    { name:'Total BTU', slug:'total-btu', dataType:'number', unit:'BTU/hr', industry:'grills', isSystem:true, sortOrder:140 },
    { name:'BTU per Main Burner', slug:'btu-per-main-burner', dataType:'number', unit:'BTU/hr', industry:'grills', sortOrder:141 },
    { name:'Side Burner BTU', slug:'side-burner-btu', dataType:'number', unit:'BTU/hr', industry:'grills', sortOrder:142 },
    { name:'Sear Burner BTU', slug:'sear-burner-btu', dataType:'number', unit:'BTU/hr', industry:'grills', sortOrder:143 },
    { name:'Infrared Burner BTU', slug:'infrared-burner-btu', dataType:'number', unit:'BTU/hr', industry:'grills', sortOrder:144 },
    { name:'Rotisserie Burner BTU', slug:'rotisserie-burner-btu', dataType:'number', unit:'BTU/hr', industry:'grills', sortOrder:145 },
    { name:'Temperature Range', slug:'temperature-range', dataType:'text', unit:'\u00b0F', industry:'grills', sortOrder:146 },

    // ── Grills: Grate & Surface ───────────────────────────────────────────────
    { name:'Grate Material', slug:'grate-material', dataType:'select', options:'Cast Iron|Stainless Steel|Porcelain-Coated|Chrome|Aluminum', industry:'grills', isSystem:true, sortOrder:150 },
    { name:'Grate Style', slug:'grate-style', dataType:'select', options:'Rod|Diamond|Flat|Reversible', industry:'grills', sortOrder:151 },
    { name:'Warming Rack Included', slug:'warming-rack-included', dataType:'boolean', industry:'grills', sortOrder:152 },
    { name:'Smoker Box Included', slug:'smoker-box-included', dataType:'boolean', industry:'grills', sortOrder:153 },
    { name:'Grill Ignition Type', slug:'grill-ignition-type', dataType:'select', options:'Push-Button|Rotary|Matchlight|Battery|Piezo|Auto', industry:'grills', sortOrder:154 },

    // ── Grills: Smart Features ────────────────────────────────────────────────
    { name:'Built-In Thermometer', slug:'built-in-thermometer', dataType:'boolean', industry:'grills', sortOrder:160 },
    { name:'Probe Ports', slug:'probe-ports', dataType:'number', industry:'grills', sortOrder:161 },
    { name:'PID Controller', slug:'pid-controller', dataType:'boolean', industry:'grills', sortOrder:162 },

    // ── Grills: Construction ──────────────────────────────────────────────────
    { name:'Lid Material', slug:'lid-material', dataType:'select', options:'Stainless Steel|Cast Aluminum|Porcelain-Coated|Painted Steel', industry:'grills', sortOrder:170 },
    { name:'Lid Type', slug:'lid-type', dataType:'select', options:'Single-Hinge|Double-Hinge|Dual-Lid|Barrel', industry:'grills', sortOrder:171 },
    { name:'Side Shelves', slug:'side-shelves', dataType:'boolean', industry:'grills', sortOrder:172 },
    { name:'Storage Cabinet', slug:'storage-cabinet', dataType:'boolean', industry:'grills', sortOrder:173 },
    { name:'Grease Management System', slug:'grease-management-system', dataType:'select', options:'Slide-Out Tray|Channel|Cup|Center Catch|None', industry:'grills', sortOrder:174 },

    // ── Grills: Warranty ──────────────────────────────────────────────────────
    { name:'Burner Warranty', slug:'burner-warranty', dataType:'text', industry:'grills', sortOrder:180 },
    { name:'Firebox Warranty', slug:'firebox-warranty', dataType:'text', industry:'grills', sortOrder:181 },
    { name:'Paint/Finish Warranty', slug:'paint-finish-warranty', dataType:'text', industry:'grills', sortOrder:182 },
    { name:'Parts Warranty (Grill)', slug:'parts-warranty-grill', dataType:'text', industry:'grills', sortOrder:183 },

    // ── Outdoor: Heat Output ──────────────────────────────────────────────────
    { name:'BTU Output (Outdoor)', slug:'btu-output-outdoor', dataType:'number', unit:'BTU/hr', industry:'outdoor', isSystem:true, sortOrder:190 },
    { name:'Heating Coverage', slug:'heating-coverage', dataType:'number', unit:'sq ft', industry:'outdoor', isSystem:true, sortOrder:191 },
    { name:'Radiant/Convective', slug:'radiant-convective', dataType:'select', options:'Radiant|Convective|Both', industry:'outdoor', sortOrder:192 },

    // ── Outdoor: Patio Heater ─────────────────────────────────────────────────
    { name:'Heater Style', slug:'heater-style', dataType:'select', options:'Freestanding|Wall-Mount|Ceiling-Mount|Tabletop|Mushroom|Pyramid|Infrared', industry:'outdoor', sortOrder:193 },
    { name:'Fuel Tank Location', slug:'fuel-tank-location', dataType:'select', options:'Base|Side Compartment|External|Built-In', industry:'outdoor', sortOrder:194 },
    { name:'Emitter Type', slug:'emitter-type', dataType:'select', options:'Quartz|Ceramic|Stainless|Metal Screen', industry:'outdoor', sortOrder:195 },
    { name:'Dimmer Control', slug:'dimmer-control', dataType:'boolean', industry:'outdoor', sortOrder:196 },
    { name:'Heat Settings', slug:'heat-settings', dataType:'number', industry:'outdoor', sortOrder:197 },

    // ── Outdoor: Fire Pit / Fire Table ────────────────────────────────────────
    { name:'Fire Feature Style', slug:'fire-feature-style', dataType:'select', options:'Bowl|Square|Rectangle|Column|Globe|Trough|Chiminea', industry:'outdoor', sortOrder:200 },
    { name:'Burner Shape', slug:'burner-shape', dataType:'select', options:'Round|Square|Linear|H-Burner', industry:'outdoor', sortOrder:201 },
    { name:'Burner Diameter', slug:'burner-diameter', dataType:'number', unit:'in', industry:'outdoor', sortOrder:202 },
    { name:'Fire Media', slug:'fire-media', dataType:'select', options:'Lava Rock|Glass Gems|River Rocks|Fire Logs|Sand|Mixed', industry:'outdoor', sortOrder:203 },
    { name:'Weather Cover Included', slug:'weather-cover-included', dataType:'boolean', industry:'outdoor', sortOrder:204 },
    { name:'Table Top Material', slug:'table-top-material', dataType:'select', options:'Aluminum|Concrete|Tile|Granite|Faux Wood|Powder-Coated Steel', industry:'outdoor', sortOrder:205 },

    // ── Outdoor: Pizza Oven ───────────────────────────────────────────────────
    { name:'Max Temperature', slug:'max-temperature', dataType:'number', unit:'\u00b0F', description:'Top purchase driver for pizza ovens.', industry:'outdoor', isSystem:true, sortOrder:210 },
    { name:'Preheat Time', slug:'preheat-time', dataType:'number', unit:'min', industry:'outdoor', isSystem:true, sortOrder:211 },
    { name:'Cooking Surface Size', slug:'cooking-surface-size', dataType:'number', unit:'sq in', industry:'outdoor', sortOrder:212 },
    { name:'Cooking Surface Material', slug:'cooking-surface-material', dataType:'select', options:'Cordierite Stone|Steel|Cast Iron|Ceramic', industry:'outdoor', sortOrder:213 },
    { name:'Rotating Base', slug:'rotating-base', dataType:'boolean', industry:'outdoor', sortOrder:214 },
    { name:'Chimney Included', slug:'chimney-included', dataType:'boolean', industry:'outdoor', sortOrder:215 },

    // ── Outdoor: Kitchen ──────────────────────────────────────────────────────
    { name:'Module Type', slug:'module-type', dataType:'select', options:'Grill|Side Burner|Refrigerator|Sink|Storage|Bar|Pizza Oven|Cabinet', industry:'outdoor', sortOrder:220 },
    { name:'Island Configuration', slug:'island-configuration', dataType:'select', options:'Straight|L-Shape|U-Shape|Island|Peninsula', industry:'outdoor', sortOrder:221 },
    { name:'Frame Material', slug:'frame-material', dataType:'select', options:'Aluminum|Stainless Steel|Polymer|Powder-Coated Steel', industry:'outdoor', sortOrder:222 },
    { name:'Counter Material', slug:'counter-material', dataType:'select', options:'Granite|Concrete|Tile|Cultured Stone|Aluminum|Stainless Steel', industry:'outdoor', sortOrder:223 },
    { name:'Refrigerator Included', slug:'refrigerator-included', dataType:'boolean', industry:'outdoor', sortOrder:224 },
    { name:'Sink Included', slug:'sink-included', dataType:'boolean', industry:'outdoor', sortOrder:225 },

    // ── Outdoor: General ──────────────────────────────────────────────────────
    { name:'Weather Resistance Rating', slug:'weather-resistance-rating', dataType:'select', options:'Indoor Only|Partially Covered|All-Weather', industry:'outdoor', isSystem:true, sortOrder:230 },
    { name:'IP Rating', slug:'ip-rating', dataType:'select', options:'IP44|IP54|IP55|IP65|IP66|IP67', industry:'outdoor', sortOrder:231 },

    // ── Outdoor: Warranty ─────────────────────────────────────────────────────
    { name:'Parts Warranty (Outdoor)', slug:'parts-warranty-outdoor', dataType:'text', industry:'outdoor', sortOrder:240 },
    { name:'Finish Warranty (Outdoor)', slug:'finish-warranty-outdoor', dataType:'text', industry:'outdoor', sortOrder:241 },
];

// ─── Filter & Required priority sets (from research High-priority list) ────────
export const FILTERABLE_SLUGS = new Set([
    'fuel-type','gas-sub-type','convertible-ng-lp','venting-type','btu-input','btu-output',
    'heating-area','installation-type','indoor-outdoor-use','certifications',
    'frame-surround-finish','epa-phase-2-certified','portable','assembly-required',
    'primary-cooking-area','total-cooking-area','grate-material','wifi-enabled',
    'btu-output-outdoor','heating-coverage','weather-resistance-rating','max-temperature',
    'number-of-main-burners','total-btu','ignition-type','efficiency-rating',
]);

export const REQUIRED_SLUGS = new Set([
    'fuel-type','venting-type','btu-input','installation-type',
    'primary-cooking-area','total-cooking-area','total-btu','btu-output-outdoor',
]);

// ─── Attribute profiles → category slug mapping ────────────────────────────────
// Each profile is a reusable list of attr slugs. Categories combine profiles.
const hBase = [
    'fuel-type','venting-type','btu-input','btu-input-min','btu-output','heating-area',
    'efficiency-rating','efficiency-type','installation-type','indoor-outdoor-use',
    'width','height','depth','weight',
    'firebox-width','firebox-height','firebox-depth',
    'body-material','glass-type','frame-surround-finish','fire-media-type',
    'blower-included','blower-cfm','mantel-compatible','certifications','safety-shutoff',
    'parts-warranty','labor-warranty',
];
const hGas = [
    'gas-sub-type','convertible-ng-lp','conversion-kit-included',
    'ignition-type','battery-backup-included','remote-included',
    'vent-termination-type','vent-pipe-diameter',
];
const hWood = [
    'wood-sub-type','log-set-size','viewing-area','framing-opening',
    'epa-phase-2-certified','emissions-g-hr','heat-exchanger-warranty',
    'csa-certified','ul-listed',
];
const hPellet = [
    'pellet-sub-type','hopper-capacity','ignition-type',
    'epa-phase-2-certified','emissions-g-hr',
];
const hElectric = [
    'flame-color','blower-included','blower-cfm','ul-listed',
];
const gBase = [
    'fuel-type','total-btu','primary-cooking-area','secondary-warming-area','total-cooking-area',
    'number-of-main-burners','number-of-grates','grate-material','grate-style',
    'warming-rack-included','smoker-box-included','grill-ignition-type',
    'wifi-enabled','bluetooth-enabled','app-compatible',
    'built-in-thermometer','probe-ports','pid-controller',
    'lid-material','lid-type','side-shelves','storage-cabinet','grease-management-system',
    'width','height','depth','weight','portable','assembly-required','indoor-outdoor-use',
    'finish-color','cover-included','certifications','safety-shutoff',
    'burner-warranty','firebox-warranty','paint-finish-warranty','parts-warranty-grill',
];
const gGas = [
    'gas-sub-type','convertible-ng-lp','conversion-kit-included',
    'btu-per-main-burner','side-burner-btu','sear-burner-btu',
    'infrared-burner-btu','rotisserie-burner-btu','temperature-range',
];
const oBase = [
    'fuel-type','indoor-outdoor-use','portable','assembly-required',
    'weather-resistance-rating','width','height','depth','weight',
    'finish-color','cover-included','certifications','safety-shutoff',
    'wifi-enabled','parts-warranty-outdoor','finish-warranty-outdoor',
];
const oHeater = [
    'btu-output-outdoor','heating-coverage','radiant-convective',
    'heater-style','fuel-tank-location','emitter-type','dimmer-control','heat-settings',
    'gas-sub-type','convertible-ng-lp','ip-rating',
];
const oFirePit = [
    'btu-output-outdoor','fire-feature-style','fire-media',
    'burner-shape','burner-diameter','weather-cover-included',
    'gas-sub-type','convertible-ng-lp',
];
const oFireTable = [
    ...oFirePit, 'table-top-material',
];
const oPizzaOven = [
    'max-temperature','preheat-time','cooking-surface-size',
    'cooking-surface-material','rotating-base','chimney-included',
];
const oKitchen = [
    'module-type','island-configuration','frame-material','counter-material',
    'refrigerator-included','sink-included',
];

// ─── Category slug → combined profile ─────────────────────────────────────────
// Spread operator deduplicates via Set in the seeder.
export const CATEGORY_PROFILES: Record<string, string[]> = {
    'gas-fireplaces':    [...hBase, ...hGas],
    'gas-inserts':       [...hBase, ...hGas, 'viewing-area','framing-opening'],
    'gas-stoves':        [...hBase, ...hGas],
    'gas-log-sets':      [...hBase, ...hGas, 'log-set-size'],
    'vent-free-log-sets':[...hBase, ...hGas],
    'wood-fireplaces':   [...hBase, ...hWood],
    'wood-inserts':      [...hBase, ...hWood, 'viewing-area','framing-opening'],
    'wood-stoves':       [...hBase, ...hWood],
    'pellet-inserts':    [...hBase, ...hPellet],
    'pellet-stoves':     [...hBase, ...hPellet],
    'electric-fireplaces':[...hBase, ...hElectric],
    'electric-inserts':  [...hBase, ...hElectric, 'viewing-area'],
    'electric-stoves':   [...hBase, ...hElectric],
    'ethanol-fireplaces':[...hBase, 'flame-color'],
    'outdoor-fireplaces':[...hBase, ...hGas],
    'fire-pits':         [...oBase, ...oFirePit],
    'grills':            [...gBase, ...gGas],
    'outdoor-heaters':   [...oBase, ...oHeater],
    'fire-tables':       [...oBase, ...oFireTable],
    'outdoor-kitchens':  [...oBase, ...oKitchen],
    'pizza-ovens':       [...oBase, ...oPizzaOven],
};
