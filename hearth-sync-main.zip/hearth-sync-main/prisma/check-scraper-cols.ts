import { PrismaClient } from '@prisma/client';
const p = new PrismaClient();
async function run() {
    // 1. Check if findFirst with name+type works at runtime
    const r = await p.scraperConfig.findFirst({ where: { name: 'test', type: 'CATEGORY' } });
    console.log('findFirst result:', r);
    // 2. Print all column names from a raw query
    const cols = await p.$queryRaw`SELECT column_name FROM information_schema.columns WHERE table_name = 'scraper_configs' ORDER BY ordinal_position`;
    console.log('DB columns:', cols);
}
run().catch(e => console.error('ERROR:', e.message)).finally(() => p.$disconnect());
