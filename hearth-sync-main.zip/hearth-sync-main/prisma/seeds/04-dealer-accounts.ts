/**
 * prisma/seeds/04-dealer-accounts.ts
 * ─────────────────────────────────────────────────────────────────────────────
 * Seeds known DealerAccount and DealerUser records.
 *
 * DESIGN PRINCIPLES:
 *   - ALL operations are idempotent upserts — safe to run multiple times.
 *   - DealerAccount is upserted by userId (Supabase Auth UUID).
 *   - DealerUser is upserted by email.
 *   - The Supabase auth user is looked up BY EMAIL (read-only) to get the UUID.
 *   - If the auth user doesn't exist in Supabase, the entry is SKIPPED with a warning.
 *   - If the app already created these records (via UI), the seed updates fields
 *     without creating duplicates.
 *   - This seed does NOT create Supabase auth users — that is the app/admin's job.
 *
 * TO ADD A NEW DEALER:
 *   Add an entry to the KNOWN_DEALERS array below. The slug is auto-generated
 *   from the company name if not provided. Once a DealerAccount exists in the
 *   database, future generate-seed snapshots will capture it automatically.
 * ─────────────────────────────────────────────────────────────────────────────
 */

import { PrismaClient } from '@prisma/client';
import { createClient } from '@supabase/supabase-js';
import * as dotenv from 'dotenv';

// Load env vars (needed when running outside of Next.js context, e.g. via tsx directly)
dotenv.config();

// ─── Known dealers ────────────────────────────────────────────────────────────
// Add new entries here to seed additional dealer accounts.
// slug is auto-generated from companyName if omitted.

interface KnownDealer {
    email: string;
    companyName: string;
    contactName: string;
    slug?: string;
    phone?: string;
    subscriptionTier?: 'STARTER' | 'PROFESSIONAL' | 'ENTERPRISE';
    subscriptionStatus?: string;
    country?: string;
}

const KNOWN_DEALERS: KnownDealer[] = [
    {
        email: 'douglasrich9215@gmail.com',
        companyName: 'Test Dealer',
        contactName: 'Doug',
        slug: 'test-dealer',
        subscriptionTier: 'STARTER',
        subscriptionStatus: 'active',
        country: 'US',
    },
    {
        email: 'carol@maceenergy.com',
        companyName: 'Mace Energy',
        contactName: 'Carol',
        slug: 'mace-energy',
        subscriptionTier: 'STARTER',
        subscriptionStatus: 'active',
        country: 'US',
    },
];

// ─── Helpers ──────────────────────────────────────────────────────────────────

function slugifyCompany(name: string): string {
    return name
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, '-')
        .replace(/^-+|-+$/g, '');
}

// ─── Seeder ───────────────────────────────────────────────────────────────────

export async function seedDealerAccounts(prisma: PrismaClient): Promise<void> {
    console.log('🏪  [04] Seeding dealer accounts...');

    const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
    const serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

    if (!supabaseUrl || !serviceRoleKey) {
        console.warn('   ⚠️  NEXT_PUBLIC_SUPABASE_URL or SUPABASE_SERVICE_ROLE_KEY not set — skipping dealer seed');
        return;
    }

    // Read-only admin client: used only to look up existing auth users by email
    const supabaseAdmin = createClient(supabaseUrl, serviceRoleKey, {
        auth: { autoRefreshToken: false, persistSession: false },
    });

    // Fetch all auth users once (avoids N API calls)
    const { data: usersData, error: listError } = await supabaseAdmin.auth.admin.listUsers({
        perPage: 1000,
    });

    if (listError) {
        console.warn(`   ⚠️  Could not fetch Supabase auth users: ${listError.message}`);
        console.warn('       Skipping dealer seed — check SUPABASE_SERVICE_ROLE_KEY');
        return;
    }

    const authUsersByEmail = new Map(
        usersData.users.map(u => [u.email?.toLowerCase(), u])
    );

    let seeded = 0;
    let skipped = 0;

    for (const dealer of KNOWN_DEALERS) {
        const email = dealer.email.toLowerCase();
        const authUser = authUsersByEmail.get(email);

        if (!authUser) {
            console.warn(`   ⚠️  No Supabase auth user found for ${dealer.email} — skipping`);
            console.warn(`       Create the user in Supabase Auth first, then re-run db:seed`);
            skipped++;
            continue;
        }

        const userId = authUser.id;
        const slug = dealer.slug ?? slugifyCompany(dealer.companyName);

        // ── Upsert DealerAccount ───────────────────────────────────────────────
        // Upsert by userId (unique). If the account already exists (UI created it),
        // we update fields without duplicating.
        const dealerAccount = await prisma.dealerAccount.upsert({
            where: { userId },
            update: {
                companyName: dealer.companyName,
                contactName: dealer.contactName,
                email: dealer.email,
                slug,
                subscriptionTier: dealer.subscriptionTier ?? 'STARTER',
                subscriptionStatus: dealer.subscriptionStatus ?? 'active',
                country: dealer.country ?? 'US',
            },
            create: {
                userId,
                companyName: dealer.companyName,
                contactName: dealer.contactName,
                email: dealer.email,
                slug,
                subscriptionTier: dealer.subscriptionTier ?? 'STARTER',
                subscriptionStatus: dealer.subscriptionStatus ?? 'active',
                country: dealer.country ?? 'US',
            },
        });

        // ── Upsert DealerUser ──────────────────────────────────────────────────
        // Upsert by email (unique). Role = owner for the primary account holder.
        // If the DealerUser was already created by the UI (or a previous seed run),
        // this simply updates the record — no duplicates, no overwrites of other users.
        await prisma.dealerUser.upsert({
            where: { email: dealer.email },
            update: {
                userId,
                dealerId: dealerAccount.id,
                role: 'owner',
            },
            create: {
                dealerId: dealerAccount.id,
                email: dealer.email,
                userId,
                role: 'owner',
            },
        });

        console.log(`   ✅ ${dealer.companyName.padEnd(24)} → DealerAccount + DealerUser (owner)  [userId: ${userId.slice(0, 8)}...]`);
        seeded++;
    }

    if (skipped > 0) {
        console.log(`   ⚠️  ${skipped} dealer(s) skipped — auth user not found in Supabase`);
    }
    console.log(`   ✅ ${seeded}/${KNOWN_DEALERS.length} dealer accounts seeded`);
}
