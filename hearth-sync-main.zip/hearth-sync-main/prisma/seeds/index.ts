/**
 * prisma/seeds/index.ts
 * ─────────────────────────────────────────────────────────────────────────────
 * Seed orchestrator — ALL data comes from the latest snapshot, ALL restore
 * operations use raw SQL. No Prisma model methods, no camelCase translation.
 *
 * Flow:
 *   1. Finds the latest snapshot in prisma/seeds/snapshots/
 *   2. For each table: INSERT ... ON CONFLICT (pk) DO UPDATE SET ...
 *   3. Runs overlay seeds (dealer accounts → Supabase auth lookup)
 *
 * If no snapshot exists, it skips restore and only runs overlays.
 * ─────────────────────────────────────────────────────────────────────────────
 */

import { PrismaClient } from '@prisma/client';
import * as fs from 'fs';
import * as path from 'path';
import { FK_SAFE_TABLE_ORDER, TABLE_CLASSIFICATION } from './generate-seed';
import { seedDealerAccounts } from './04-dealer-accounts';

const prisma = new PrismaClient();

// Tables to skip entirely during seed restore
const SKIP_TABLES = new Set(['_prisma_migrations']);

// ─── Find latest snapshot ─────────────────────────────────────────────────────

function getLatestSnapshotDir(): string | null {
    const snapshotsDir = path.join(__dirname, 'snapshots');
    if (!fs.existsSync(snapshotsDir)) return null;

    const dirs = fs.readdirSync(snapshotsDir)
        .filter(d => fs.statSync(path.join(snapshotsDir, d)).isDirectory())
        .sort()
        .reverse();

    return dirs.length > 0 ? path.join(snapshotsDir, dirs[0]) : null;
}

// ─── Discover primary keys from information_schema ────────────────────────────

async function getPrimaryKeys(client: PrismaClient): Promise<Record<string, string[]>> {
    const rows = await client.$queryRaw<{ table_name: string; column_name: string }[]>`
        SELECT kcu.table_name, kcu.column_name
        FROM information_schema.table_constraints tc
        JOIN information_schema.key_column_usage kcu
            ON tc.constraint_name = kcu.constraint_name
            AND tc.table_schema = kcu.table_schema
        WHERE tc.constraint_type = 'PRIMARY KEY'
            AND tc.table_schema = 'public'
        ORDER BY kcu.table_name, kcu.ordinal_position
    `;

    const pks: Record<string, string[]> = {};
    for (const row of rows) {
        if (!pks[row.table_name]) pks[row.table_name] = [];
        pks[row.table_name].push(row.column_name);
    }
    return pks;
}

// ─── Format a value for SQL ───────────────────────────────────────────────────

function sqlValue(val: any): string {
    if (val === null || val === undefined) return 'NULL';
    if (typeof val === 'boolean') return val ? 'TRUE' : 'FALSE';
    if (typeof val === 'number') return String(val);
    if (val instanceof Date) return `'${val.toISOString()}'`;
    if (Array.isArray(val)) {
        // Postgres arrays (TEXT[], INT[], etc.) — came from the DB as a JS array
        // of primitives. Need to produce ARRAY['a','b'] syntax, not jsonb.
        if (val.length === 0) return "'{}'";
        const first = val[0];
        if (typeof first === 'string') {
            const escaped = val.map((v: string) => `'${String(v).replace(/'/g, "''")}'`);
            return `ARRAY[${escaped.join(', ')}]::text[]`;
        }
        if (typeof first === 'number') {
            return `ARRAY[${val.join(', ')}]`;
        }
        // Fallback: array of objects → jsonb
        return `'${JSON.stringify(val).replace(/'/g, "''")}'::jsonb`;
    }
    if (typeof val === 'object') {
        // JSON/JSONB fields
        return `'${JSON.stringify(val).replace(/'/g, "''")}'::jsonb`;
    }
    // String — escape single quotes
    return `'${String(val).replace(/'/g, "''")}'`;
}

// ─── Upsert a single row via raw SQL ──────────────────────────────────────────

async function upsertRow(
    client: PrismaClient,
    table: string,
    row: Record<string, any>,
    pkColumns: string[],
): Promise<boolean> {
    const columns = Object.keys(row);
    const colNames = columns.map(c => `"${c}"`).join(', ');
    const values = columns.map(c => sqlValue(row[c])).join(', ');

    // ON CONFLICT columns
    const conflictCols = pkColumns.map(c => `"${c}"`).join(', ');

    // SET clause for update: update all non-PK columns
    const nonPkCols = columns.filter(c => !pkColumns.includes(c));

    if (nonPkCols.length === 0) {
        // All columns are PK — just insert, ignore conflicts
        const sql = `INSERT INTO "${table}" (${colNames}) VALUES (${values}) ON CONFLICT (${conflictCols}) DO NOTHING`;
        await client.$executeRawUnsafe(sql);
        return true;
    }

    const setClauses = nonPkCols.map(c => `"${c}" = EXCLUDED."${c}"`).join(', ');
    const sql = `INSERT INTO "${table}" (${colNames}) VALUES (${values}) ON CONFLICT (${conflictCols}) DO UPDATE SET ${setClauses}`;

    await client.$executeRawUnsafe(sql);
    return true;
}

// ─── Restore from snapshot ────────────────────────────────────────────────────

async function restoreFromSnapshot(client: PrismaClient, snapshotDir: string): Promise<void> {
    const manifestPath = path.join(snapshotDir, '_manifest.json');
    const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf-8'));

    console.log(`📸 Restoring from snapshot: ${path.basename(snapshotDir)}`);
    if (manifest.label) console.log(`   Label: ${manifest.label}`);
    console.log(`   Total: ${manifest.totalRows?.toLocaleString() ?? '?'} rows across ${manifest.tablesFound ?? '?'} tables\n`);

    // Discover all primary keys from the live schema
    const primaryKeys = await getPrimaryKeys(client);

    // Build ordered table list from snapshot files
    const snapshotFiles = fs.readdirSync(snapshotDir)
        .filter(f => f.endsWith('.json') && f !== '_manifest.json')
        .map(f => f.replace('.json', ''));

    const orderedTables = [
        ...FK_SAFE_TABLE_ORDER.filter(t => snapshotFiles.includes(t)),
        ...snapshotFiles.filter(t => !FK_SAFE_TABLE_ORDER.includes(t)),
    ];

    let totalRestored = 0;
    let totalSkipped = 0;

    for (const table of orderedTables) {
        if (SKIP_TABLES.has(table)) continue;

        const filePath = path.join(snapshotDir, `${table}.json`);
        if (!fs.existsSync(filePath)) continue;

        const rows: any[] = JSON.parse(fs.readFileSync(filePath, 'utf-8'));
        if (rows.length === 0) continue;

        const pk = primaryKeys[table];
        if (!pk || pk.length === 0) {
            // Implicit M2M join tables (e.g. _ProductCategories) have composite
            // primary keys like ("A", "B"). Try to get them, otherwise use all columns.
            const allCols = Object.keys(rows[0]);
            let inserted = 0;
            for (const row of rows) {
                try {
                    const colNames = allCols.map(c => `"${c}"`).join(', ');
                    const values = allCols.map(c => sqlValue(row[c])).join(', ');
                    await client.$executeRawUnsafe(
                        `INSERT INTO "${table}" (${colNames}) VALUES (${values}) ON CONFLICT DO NOTHING`
                    );
                    inserted++;
                } catch { }
            }
            if (inserted > 0) {
                console.log(`  ✅ ${table.padEnd(36)} ${inserted.toLocaleString().padStart(6)} rows`);
                totalRestored += inserted;
            }
            continue;
        }

        let upserted = 0;
        let skipped = 0;
        const errors: string[] = [];

        for (const row of rows) {
            try {
                await upsertRow(client, table, row, pk);
                upserted++;
            } catch (err: any) {
                skipped++;
                if (errors.length < 3) errors.push(err.message?.slice(0, 120));
            }
        }

        const cls = (TABLE_CLASSIFICATION[table] ?? 'unknown').padEnd(13);
        const skipNote = skipped > 0 ? ` [${skipped} err]` : '';
        console.log(`  ✅ ${table.padEnd(36)} ${upserted.toLocaleString().padStart(6)} rows  [${cls}]${skipNote}`);
        if (errors.length > 0) errors.forEach(e => console.warn(`     ⚠️  ${e}`));
        totalRestored += upserted;
        totalSkipped += skipped;
    }

    console.log(`\n   Total: ${totalRestored.toLocaleString()} rows restored${totalSkipped > 0 ? `, ${totalSkipped} errors` : ''}`);
}

// ─── Main orchestrator ────────────────────────────────────────────────────────

export async function runAllSeeds(client: PrismaClient = prisma): Promise<void> {
    console.log('\n🔥 HearthSync — Database Seed\n' + '─'.repeat(50));

    // Step 1: Restore all data from latest snapshot (fully dynamic, raw SQL)
    const snapshotDir = getLatestSnapshotDir();
    if (snapshotDir) {
        await restoreFromSnapshot(client, snapshotDir);
    } else {
        console.log('⚠️  No snapshot found in prisma/seeds/snapshots/');
        console.log('   Run: npm run db:seed:snapshot  to capture the current DB state first');
        console.log('   Skipping snapshot restore — running overlay seeds only...\n');
    }

    // Step 2: Overlay seeds (dealer accounts need Supabase auth lookup)
    console.log('\n── Overlay seeds ──────────────────────────────────');
    await seedDealerAccounts(client);

    console.log('\n' + '─'.repeat(50));
    console.log('✅ Database seed complete.\n');
}

// Allow running directly: npx tsx prisma/seeds/index.ts
if (require.main === module) {
    runAllSeeds()
        .catch((e) => {
            console.error('Seed error:', e);
            process.exit(1);
        })
        .finally(async () => {
            await prisma.$disconnect();
        });
}
