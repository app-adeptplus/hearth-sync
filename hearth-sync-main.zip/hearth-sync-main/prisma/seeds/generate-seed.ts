/**
 * prisma/seeds/generate-seed.ts
 * ─────────────────────────────────────────────────────────────────────────────
 * Snapshots the ENTIRE current database into a timestamped folder under
 * prisma/seeds/snapshots/. Run this BEFORE any schema migration to capture
 * the live state for rollback or re-seeding after migrate.
 *
 * Usage:
 *   npm run db:seed:snapshot
 *   npm run db:seed:snapshot -- --label "before-ftp-migration"
 *
 * Output: prisma/seeds/snapshots/<timestamp>[-label]/<table>.json + _manifest.json
 *
 * The snapshot can be restored after migration via:
 *   npm run db:seed:restore
 *   npm run db:seed:restore -- 2026-03-13T15-49
 * ─────────────────────────────────────────────────────────────────────────────
 */

import { PrismaClient } from '@prisma/client';
import * as fs from 'fs';
import * as path from 'path';

const prisma = new PrismaClient();

// ─── FK-safe restore order (all known tables, parents before children) ────────
// New tables not in this list are discovered dynamically and appended at the end.
// IMPORTANT: these are the actual DB table names (@@map values), NOT Prisma model names.

export const FK_SAFE_TABLE_ORDER = [
    // Level 0: no foreign key dependencies
    'product_categories',       // self-referential; top-level rows first
    'product_attributes',
    'manufacturers',
    'llm_api_configs',
    'external_service_configs',
    'mcp_server_configs',
    'prompt_templates',

    // Level 1: depend on Level 0
    'manufacturer_integrations', // → manufacturers
    'brands',                    // → manufacturers
    'manufacturer_ftp_accounts', // → manufacturers
    'prompt_template_versions',  // → prompt_templates
    'external_service_provider_links', // → external_service_configs, llm_api_configs
    'mcp_server_provider_links', // → mcp_server_configs, llm_api_configs
    'dealer_accounts',           // → Supabase auth (no DB FK, safe to restore early)
    'category_attribute_maps',   // → product_categories, product_attributes

    // Level 2: depend on Level 1
    'products',                  // → brands
    'scraper_configs',           // → brands
    'automation_configs',        // → brands, prompt_templates
    'widget_configs',            // → dealer_accounts
    'crm_integrations',          // → dealer_accounts
    'dealer_users',              // → dealer_accounts
    'dealer_catalog_groups',     // → dealer_accounts
    'estimates',                 // → dealer_accounts

    // Level 3: depend on Level 2
    'product_images',            // → products
    'product_documents',         // → products
    'product_specs',             // → products
    'product_reviews',           // → products
    'product_attribute_values',  // → products, product_attributes
    'scraper_jobs',              // → scraper_configs
    'scraper_workflows',         // → brands, scraper_configs
    'automation_runs',           // → automation_configs
    'automation_artifacts',      // → automation_configs
    'ftp_upload_logs',           // → manufacturer_ftp_accounts
    'mcp_server_config_links',   // → mcp_server_configs, automation_configs
    'dealer_catalog_selections', // → dealer_accounts, products
    'dealer_catalog_group_products', // → dealer_catalog_groups, products
    'estimate_items',            // → estimates, products

    // Level 4: depend on Level 3
    'data_packages',             // → automation_runs, brands
    'leads',                     // → dealer_accounts, products, estimates
    'dealer_activity_logs',      // → dealer_accounts
    'audit_logs',                // → products

    // Level 5: depend on Level 4
    'data_package_items',        // → data_packages, products

    // Prisma implicit many-to-many join tables (@@map is implicit, no FK order needed)
    '_ProductCategories',        // Product ↔ ProductCategory (many-to-many)
    '_ScraperConfigCategories',  // ScraperConfig ↔ ProductCategory (many-to-many)

    // Prisma internal
    '_prisma_migrations',
];

// ─── Table classification ─────────────────────────────────────────────────────
// reference   → seeded from modular seed files (01-categories.ts etc.)
// transactional → real business data, restored from snapshot only
// system      → app-generated logs/events; best-effort restore, acceptable to lose

export const TABLE_CLASSIFICATION: Record<string, 'reference' | 'transactional' | 'system'> = {
    product_categories:              'reference',
    product_attributes:              'reference',
    manufacturers:                   'reference',
    manufacturer_integrations:       'reference',
    manufacturer_ftp_accounts:       'reference',
    brands:                          'reference',
    scraper_configs:                 'reference',
    prompt_templates:                'reference',
    prompt_template_versions:        'reference',
    llm_api_configs:                 'reference',
    external_service_configs:        'reference',
    mcp_server_configs:              'reference',
    external_service_provider_links: 'reference',
    mcp_server_provider_links:       'reference',
    mcp_server_config_links:         'reference',
    category_attribute_maps:         'reference',

    products:                        'transactional',
    product_images:                  'transactional',
    product_documents:               'transactional',
    product_specs:                   'transactional',
    product_reviews:                 'transactional',
    product_attribute_values:        'transactional',
    dealer_accounts:                 'transactional',
    dealer_users:                    'transactional',
    dealer_catalog_groups:           'transactional',
    dealer_catalog_group_products:   'transactional',
    dealer_catalog_selections:       'transactional',
    widget_configs:                  'transactional',
    crm_integrations:                'transactional',
    estimates:                       'transactional',
    estimate_items:                  'transactional',
    leads:                           'transactional',
    data_packages:                   'transactional',
    data_package_items:              'transactional',
    automation_configs:              'transactional',

    // System tables: app writes these during operation; acceptable to lose on migration
    audit_logs:                      'system',
    scraper_jobs:                    'system',
    scraper_workflows:               'system',
    automation_runs:                 'system',
    automation_artifacts:            'system',
    ftp_upload_logs:                 'system',
    dealer_activity_logs:            'system',

    // Prisma implicit many-to-many join tables
    '_ProductCategories':            'reference',
    '_ScraperConfigCategories':      'reference',

    // Prisma internal migration tracking — never seed or restore this
    '_prisma_migrations':            'system',
};

// ─── Main ─────────────────────────────────────────────────────────────────────

async function generateSeed() {
    const labelIdx = process.argv.indexOf('--label');
    const label = labelIdx !== -1 ? `-${process.argv[labelIdx + 1].replace(/\s+/g, '-')}` : '';

    const timestamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
    const dirName = `${timestamp}${label}`;
    const snapshotDir = path.join(__dirname, 'snapshots', dirName);
    fs.mkdirSync(snapshotDir, { recursive: true });

    console.log(`\n📸 Generating seed snapshot → prisma/seeds/snapshots/${dirName}\n`);

    // Discover all tables in the database dynamically
    const discovered = await prisma.$queryRaw<{ table_name: string }[]>`
        SELECT table_name
        FROM information_schema.tables
        WHERE table_schema = 'public' AND table_type = 'BASE TABLE'
        ORDER BY table_name
    `;
    const allDbTables = discovered.map(r => r.table_name);

    // Build ordered list: known FK-safe order first, then any new/unknown tables
    const orderedTables = [
        ...FK_SAFE_TABLE_ORDER.filter(t => allDbTables.includes(t)),
        ...allDbTables.filter(t => !FK_SAFE_TABLE_ORDER.includes(t)),
    ];

    console.log(`   Found ${allDbTables.length} tables in database`);
    const unknownTables = allDbTables.filter(t => !FK_SAFE_TABLE_ORDER.includes(t));
    if (unknownTables.length > 0) {
        console.log(`   ⚠️  New tables not in FK_SAFE_TABLE_ORDER (appended at end):`);
        unknownTables.forEach(t => console.log(`      → ${t}`));
        console.log(`      Add these to FK_SAFE_TABLE_ORDER in generate-seed.ts for proper FK handling.\n`);
    }

    const counts: Record<string, number> = {};
    const classification: Record<string, string> = {};

    for (const table of orderedTables) {
        try {
            const rows = await prisma.$queryRawUnsafe<any[]>(`SELECT * FROM "${table}"`);
            const filePath = path.join(snapshotDir, `${table}.json`);
            fs.writeFileSync(filePath, JSON.stringify(rows, null, 2), 'utf-8');
            counts[table] = rows.length;
            classification[table] = TABLE_CLASSIFICATION[table] ?? 'transactional';
            const rowLabel = rows.length.toLocaleString().padStart(6);
            const cls = (classification[table] ?? 'unknown').padEnd(13);
            console.log(`  ✅ ${table.padEnd(36)} ${rowLabel} rows  [${cls}]`);
        } catch (err: any) {
            console.warn(`  ⚠️  ${table.padEnd(36)} SKIPPED — ${err.message}`);
            counts[table] = -1;
        }
    }

    const totalRows = Object.values(counts).filter(n => n >= 0).reduce((a, b) => a + b, 0);

    const manifest = {
        timestamp,
        label: label.slice(1) || null,
        schemaFingerprint: readSchemaFingerprint(),
        tablesFound: allDbTables.length,
        unknownTables,
        classification,
        tables: counts,
        totalRows,
        restoreWith: 'npm run db:seed:restore',
    };

    fs.writeFileSync(
        path.join(snapshotDir, '_manifest.json'),
        JSON.stringify(manifest, null, 2),
    );

    console.log(`\n✅ Snapshot complete. ${totalRows.toLocaleString()} rows → prisma/seeds/snapshots/${dirName}\n`);
    await prisma.$disconnect();
}

function readSchemaFingerprint(): string {
    try {
        const schemaPath = path.join(__dirname, '..', 'schema.prisma');
        const content = fs.readFileSync(schemaPath, 'utf-8');
        let hash = 0;
        for (let i = 0; i < content.length; i++) {
            hash = (hash << 5) - hash + content.charCodeAt(i);
            hash |= 0;
        }
        return Math.abs(hash).toString(16);
    } catch {
        return 'unknown';
    }
}

// Only run when invoked directly (not when imported by backup.ts or restore.ts)
if (require.main === module) {
    generateSeed().catch(async (err) => {
        console.error('\n❌ Snapshot failed:', err.message);
        await prisma.$disconnect();
        process.exit(1);
    });
}

