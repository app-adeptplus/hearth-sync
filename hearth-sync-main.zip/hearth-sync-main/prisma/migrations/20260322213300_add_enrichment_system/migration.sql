-- CreateTable enrichment_jobs
CREATE TABLE IF NOT EXISTS "public"."enrichment_jobs" (
    "id" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "status" TEXT NOT NULL DEFAULT 'PENDING',
    "sourceType" TEXT NOT NULL,
    "sourceFilter" JSONB,
    "totalProducts" INTEGER NOT NULL DEFAULT 0,
    "processedCount" INTEGER NOT NULL DEFAULT 0,
    "errorCount" INTEGER NOT NULL DEFAULT 0,
    "rawLog" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "enrichment_jobs_pkey" PRIMARY KEY ("id")
);

-- CreateTable enrichment_proposals
CREATE TABLE IF NOT EXISTS "public"."enrichment_proposals" (
    "id" TEXT NOT NULL,
    "jobId" TEXT NOT NULL,
    "productId" TEXT,
    "dataPackageItemId" TEXT,
    "status" TEXT NOT NULL DEFAULT 'PENDING',
    "proposedData" JSONB NOT NULL,
    "originalData" JSONB,
    "confidence" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "notes" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "enrichment_proposals_pkey" PRIMARY KEY ("id")
);

-- CreateTable taxonomy_suggestions
CREATE TABLE IF NOT EXISTS "public"."taxonomy_suggestions" (
    "id" TEXT NOT NULL,
    "jobId" TEXT NOT NULL,
    "type" TEXT NOT NULL,
    "action" TEXT NOT NULL DEFAULT 'CREATE',
    "status" TEXT NOT NULL DEFAULT 'PENDING',
    "suggestedName" TEXT NOT NULL,
    "suggestedData" JSONB,
    "resolvedId" TEXT,
    "usedByProposalIds" TEXT[] NOT NULL DEFAULT ARRAY[]::TEXT[],
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "taxonomy_suggestions_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX IF NOT EXISTS "enrichment_proposals_jobId_idx" ON "public"."enrichment_proposals"("jobId");
CREATE INDEX IF NOT EXISTS "enrichment_proposals_productId_idx" ON "public"."enrichment_proposals"("productId");
CREATE INDEX IF NOT EXISTS "taxonomy_suggestions_jobId_idx" ON "public"."taxonomy_suggestions"("jobId");

-- AddForeignKey enrichment_proposals -> enrichment_jobs
DO $$ BEGIN
    ALTER TABLE "public"."enrichment_proposals"
        ADD CONSTRAINT "enrichment_proposals_jobId_fkey"
        FOREIGN KEY ("jobId") REFERENCES "public"."enrichment_jobs"("id") ON DELETE CASCADE ON UPDATE CASCADE;
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;

-- AddForeignKey enrichment_proposals -> products (nullable)
DO $$ BEGIN
    ALTER TABLE "public"."enrichment_proposals"
        ADD CONSTRAINT "enrichment_proposals_productId_fkey"
        FOREIGN KEY ("productId") REFERENCES "public"."products"("id") ON DELETE SET NULL ON UPDATE CASCADE;
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;

-- AddForeignKey taxonomy_suggestions -> enrichment_jobs
DO $$ BEGIN
    ALTER TABLE "public"."taxonomy_suggestions"
        ADD CONSTRAINT "taxonomy_suggestions_jobId_fkey"
        FOREIGN KEY ("jobId") REFERENCES "public"."enrichment_jobs"("id") ON DELETE CASCADE ON UPDATE CASCADE;
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;
