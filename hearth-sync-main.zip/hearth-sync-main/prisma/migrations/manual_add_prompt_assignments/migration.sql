-- CreateEnum
CREATE TYPE "AssignmentServiceType" AS ENUM ('CHAT_BOT', 'PRODUCT_AUTOMATION', 'ENRICHMENT', 'DEALER_SERVICE');

-- CreateEnum
CREATE TYPE "AssignmentObjectEntity" AS ENUM ('PRODUCT', 'CATEGORY', 'ATTRIBUTE', 'BRAND', 'MANUFACTURER', 'DATA_PACKAGE', 'AUTOMATION_CONFIG', 'AUDIT_LOG');

-- CreateTable
CREATE TABLE "prompt_assignments" (
    "id" TEXT NOT NULL,
    "label" TEXT NOT NULL,
    "serviceType" "AssignmentServiceType" NOT NULL,
    "serviceId" TEXT,
    "promptTemplateId" TEXT,
    "llmConfigId" TEXT NOT NULL,
    "isActive" BOOLEAN NOT NULL DEFAULT true,
    "notes" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "prompt_assignments_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "assignment_object_scopes" (
    "id" TEXT NOT NULL,
    "assignmentId" TEXT NOT NULL,
    "entity" "AssignmentObjectEntity" NOT NULL,
    "canRead" BOOLEAN NOT NULL DEFAULT true,
    "canWrite" BOOLEAN NOT NULL DEFAULT false,

    CONSTRAINT "assignment_object_scopes_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "assignment_mcp_links" (
    "id" TEXT NOT NULL,
    "assignmentId" TEXT NOT NULL,
    "mcpServerId" TEXT NOT NULL,

    CONSTRAINT "assignment_mcp_links_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "prompt_assignments_serviceType_serviceId_idx" ON "prompt_assignments"("serviceType", "serviceId");

-- CreateIndex
CREATE UNIQUE INDEX "prompt_assignments_serviceType_serviceId_label_key" ON "prompt_assignments"("serviceType", "serviceId", "label");

-- CreateIndex
CREATE UNIQUE INDEX "assignment_object_scopes_assignmentId_entity_key" ON "assignment_object_scopes"("assignmentId", "entity");

-- CreateIndex
CREATE UNIQUE INDEX "assignment_mcp_links_assignmentId_mcpServerId_key" ON "assignment_mcp_links"("assignmentId", "mcpServerId");

-- AddForeignKey
ALTER TABLE "prompt_assignments" ADD CONSTRAINT "prompt_assignments_promptTemplateId_fkey" FOREIGN KEY ("promptTemplateId") REFERENCES "prompt_templates"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "prompt_assignments" ADD CONSTRAINT "prompt_assignments_llmConfigId_fkey" FOREIGN KEY ("llmConfigId") REFERENCES "llm_api_configs"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "assignment_object_scopes" ADD CONSTRAINT "assignment_object_scopes_assignmentId_fkey" FOREIGN KEY ("assignmentId") REFERENCES "prompt_assignments"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "assignment_mcp_links" ADD CONSTRAINT "assignment_mcp_links_assignmentId_fkey" FOREIGN KEY ("assignmentId") REFERENCES "prompt_assignments"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "assignment_mcp_links" ADD CONSTRAINT "assignment_mcp_links_mcpServerId_fkey" FOREIGN KEY ("mcpServerId") REFERENCES "mcp_server_configs"("id") ON DELETE CASCADE ON UPDATE CASCADE;
