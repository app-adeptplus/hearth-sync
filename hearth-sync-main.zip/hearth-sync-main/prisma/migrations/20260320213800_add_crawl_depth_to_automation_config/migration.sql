-- AddCrawlDepthToAutomationConfig
-- Risk: None — adding a new nullable column with a default value.
-- No data is modified, deleted, or restructured.
ALTER TABLE "automation_configs" ADD COLUMN IF NOT EXISTS "crawlDepth" TEXT DEFAULT 'SHALLOW';
