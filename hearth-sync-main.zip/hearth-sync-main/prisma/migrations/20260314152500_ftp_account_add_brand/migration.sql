-- Migration: add brandId (NOT NULL) to manufacturer_ftp_accounts
-- Safe: table has 0 rows so NOT NULL constraint is fine without a DEFAULT.
-- Purely additive — no existing data is modified or dropped.

-- Step 1: add the column (NOT NULL, no default — safe because table is empty)
ALTER TABLE "manufacturer_ftp_accounts"
    ADD COLUMN "brandId" TEXT NOT NULL;

-- Step 2: add the foreign key constraint to brands
ALTER TABLE "manufacturer_ftp_accounts"
    ADD CONSTRAINT "manufacturer_ftp_accounts_brandId_fkey"
    FOREIGN KEY ("brandId") REFERENCES "brands"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- Step 3: add index on brandId for efficient filtering
CREATE INDEX "manufacturer_ftp_accounts_brandId_idx"
    ON "manufacturer_ftp_accounts"("brandId");
