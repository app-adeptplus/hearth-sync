-- Migration: add-ftp-provisioning
-- Purely additive: new tables + new enum value. No destructive DDL.

-- 1. Add new enum value INBOUND_FTP to AutomationSourceType
ALTER TYPE "AutomationSourceType" ADD VALUE 'INBOUND_FTP';

-- 2. Create manufacturer_ftp_accounts table
CREATE TABLE "manufacturer_ftp_accounts" (
  "id"              TEXT NOT NULL,
  "manufacturerId"  TEXT NOT NULL,
  "label"           TEXT NOT NULL,
  "ftpHost"         TEXT NOT NULL,
  "ftpPort"         INTEGER NOT NULL DEFAULT 22,
  "ftpUser"         TEXT NOT NULL,
  "ftpPassword"     TEXT,
  "ftpPath"         TEXT NOT NULL,
  "isActive"        BOOLEAN NOT NULL DEFAULT true,
  "lastUploadAt"    TIMESTAMP(3),
  "notes"           TEXT,
  "createdAt"       TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt"       TIMESTAMP(3) NOT NULL,

  CONSTRAINT "manufacturer_ftp_accounts_pkey" PRIMARY KEY ("id")
);

-- 3. Create ftp_upload_logs table
CREATE TABLE "ftp_upload_logs" (
  "id"            TEXT NOT NULL,
  "accountId"     TEXT NOT NULL,
  "fileName"      TEXT NOT NULL,
  "fileSizeBytes" INTEGER,
  "fileType"      TEXT,
  "status"        TEXT NOT NULL DEFAULT 'detected',
  "errorMessage"  TEXT,
  "dataPackageId" TEXT,
  "detectedAt"    TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "processedAt"   TIMESTAMP(3),

  CONSTRAINT "ftp_upload_logs_pkey" PRIMARY KEY ("id")
);

-- 4. Add unique constraint on ftpUser
CREATE UNIQUE INDEX "manufacturer_ftp_accounts_ftpUser_key" ON "manufacturer_ftp_accounts"("ftpUser");

-- 5. Add indexes
CREATE INDEX "manufacturer_ftp_accounts_manufacturerId_idx" ON "manufacturer_ftp_accounts"("manufacturerId");
CREATE INDEX "ftp_upload_logs_accountId_idx" ON "ftp_upload_logs"("accountId");
CREATE INDEX "ftp_upload_logs_status_idx" ON "ftp_upload_logs"("status");

-- 6. Add foreign key constraints
ALTER TABLE "manufacturer_ftp_accounts" ADD CONSTRAINT "manufacturer_ftp_accounts_manufacturerId_fkey"
  FOREIGN KEY ("manufacturerId") REFERENCES "manufacturers"("id") ON DELETE CASCADE ON UPDATE CASCADE;

ALTER TABLE "ftp_upload_logs" ADD CONSTRAINT "ftp_upload_logs_accountId_fkey"
  FOREIGN KEY ("accountId") REFERENCES "manufacturer_ftp_accounts"("id") ON DELETE CASCADE ON UPDATE CASCADE;
