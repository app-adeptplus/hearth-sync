-- AlterTable: Add optional LLM config override FK to automation_configs
ALTER TABLE "automation_configs" ADD COLUMN "llmConfigOverrideId" TEXT;

-- AddForeignKey
ALTER TABLE "automation_configs" ADD CONSTRAINT "automation_configs_llmConfigOverrideId_fkey" FOREIGN KEY ("llmConfigOverrideId") REFERENCES "llm_api_configs"("id") ON DELETE SET NULL ON UPDATE CASCADE;
