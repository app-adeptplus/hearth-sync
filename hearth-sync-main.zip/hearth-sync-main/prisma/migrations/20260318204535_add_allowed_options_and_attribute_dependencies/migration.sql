-- Migration: add_allowed_options_and_attribute_dependencies
-- Purely additive: new nullable column + new table. No existing data is touched.

-- 1. Add allowedOptions to category_attribute_maps
--    null = all parent attribute options are allowed (fully backward-compatible)
ALTER TABLE "category_attribute_maps"
  ADD COLUMN "allowedOptions" TEXT;

-- 2. Create the attribute_dependencies table
CREATE TABLE "attribute_dependencies" (
  "id"                TEXT NOT NULL,
  "parentAttributeId" TEXT NOT NULL,
  "triggerValue"      TEXT NOT NULL,
  "childAttributeId"  TEXT NOT NULL,
  "sortOrder"         INTEGER NOT NULL DEFAULT 0,

  CONSTRAINT "attribute_dependencies_pkey" PRIMARY KEY ("id")
);

-- 3. Foreign keys (cascade on parent or child attribute deletion)
ALTER TABLE "attribute_dependencies"
  ADD CONSTRAINT "attribute_dependencies_parentAttributeId_fkey"
  FOREIGN KEY ("parentAttributeId")
  REFERENCES "product_attributes"("id")
  ON DELETE CASCADE ON UPDATE CASCADE;

ALTER TABLE "attribute_dependencies"
  ADD CONSTRAINT "attribute_dependencies_childAttributeId_fkey"
  FOREIGN KEY ("childAttributeId")
  REFERENCES "product_attributes"("id")
  ON DELETE CASCADE ON UPDATE CASCADE;

-- 4. Unique constraint and index
CREATE UNIQUE INDEX "attribute_dependencies_parentAttributeId_triggerValue_childAttributeId_key"
  ON "attribute_dependencies"("parentAttributeId", "triggerValue", "childAttributeId");

CREATE INDEX "attribute_dependencies_parentAttributeId_idx"
  ON "attribute_dependencies"("parentAttributeId");
