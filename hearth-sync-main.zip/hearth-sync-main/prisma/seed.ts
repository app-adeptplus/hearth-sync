/**
 * prisma/seed.ts
 * ─────────────────────────────────────────────────────────────────────────────
 * Entry point registered in package.json → "prisma": { "seed": "npx tsx prisma/seed.ts" }
 *
 * This is a THIN SHIM. All seed logic lives in prisma/seeds/index.ts.
 *
 * How seeding works:
 *   1. Restores ALL tables from the latest snapshot (prisma/seeds/snapshots/)
 *   2. Runs overlay seeds (dealer accounts via Supabase auth lookup)
 *
 * No hardcoded data lives here. All data comes from the database itself,
 * captured by: npm run db:seed:snapshot
 * ─────────────────────────────────────────────────────────────────────────────
 */

import { PrismaClient } from '@prisma/client';
import { runAllSeeds } from './seeds/index';

const prisma = new PrismaClient();

runAllSeeds(prisma)
    .catch((e) => {
        console.error('Seed error:', e);
        process.exit(1);
    })
    .finally(async () => {
        await prisma.$disconnect();
    });
