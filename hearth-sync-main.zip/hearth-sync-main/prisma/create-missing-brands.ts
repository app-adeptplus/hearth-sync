/**
 * create-missing-brands.ts
 * Creates missing brands (and their manufacturers) for brands-hearth.json entries.
 * Safe to re-run — uses upsert on manufacturer slug and brand slug.
 */
import { PrismaClient } from '@prisma/client';
import * as fs from 'fs';
import * as path from 'path';

const p = new PrismaClient();

function slugify(text: string): string {
    return text.toLowerCase().replace(/[&]/g, 'and').replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');
}

const MISSING_BRANDS = [
    { brandName: 'Astria', mfrName: 'Astria', brandSku: 'AST' },
    { brandName: 'Breeo', mfrName: 'Breeo', brandSku: 'BREEO' },
    { brandName: 'Comfort Bilt', mfrName: 'Comfort Bilt', brandSku: 'CFT' },
    { brandName: 'Dracme Mantel', mfrName: 'Dracme Mantel', brandSku: 'DRAC' },
    { brandName: 'Elmira', mfrName: 'Elmira Stove Works', brandSku: 'ELMIRA' },
    { brandName: 'Grand Canyon Gas Logs', mfrName: 'Grand Canyon Gas Logs', brandSku: 'GCGL' },
    { brandName: 'HPC Fire Inspired', mfrName: 'HPC Fire Inspired', brandSku: 'HPC' },
    { brandName: 'Invicta', mfrName: 'Invicta', brandSku: 'INV' },
    { brandName: 'Plaza', mfrName: 'Plaza', brandSku: 'PLZA' },
    { brandName: 'Ravelli', mfrName: 'Ravelli', brandSku: 'RAV' },
    { brandName: 'Stoll Industries', mfrName: 'Stoll Industries', brandSku: 'STOLL' },
];

async function main() {
    console.log('\n🏭 Creating missing brands...\n');
    const results: { brandName: string; id: string; slug: string }[] = [];

    for (const { brandName, mfrName, brandSku } of MISSING_BRANDS) {
        const mfrSlug = slugify(mfrName);
        const brandSlug = slugify(brandName);

        const mfr = await p.manufacturer.upsert({
            where: { slug: mfrSlug },
            update: {},
            create: { name: mfrName, slug: mfrSlug },
        });

        await p.manufacturerIntegration.upsert({
            where: { manufacturerId: mfr.id },
            update: {},
            create: { manufacturerId: mfr.id, integrationMethod: 'SCRAPE', status: 'ACTIVE' },
        });

        const existing = await p.brand.findUnique({ where: { slug: brandSlug } });
        let brand;
        if (existing) {
            brand = existing;
            console.log(`   ♻️  Already exists: ${brandName} (${brand.id})`);
        } else {
            brand = await p.brand.create({
                data: { name: brandName, slug: brandSlug, manufacturerId: mfr.id, brandSku, isActive: true },
            });
            console.log(`   ✅ Created: ${brandName} → ${brand.id}`);
        }
        results.push({ brandName, id: brand.id, slug: brand.slug });
    }

    // Write results to file so we can use the IDs
    const out = path.resolve(__dirname, 'new-brand-ids.json');
    fs.writeFileSync(out, JSON.stringify(results, null, 2), 'utf-8');
    console.log(`\n📄 IDs written to ${out}\n`);
}

main().catch(e => console.error('ERROR:', e)).finally(() => p.$disconnect());
