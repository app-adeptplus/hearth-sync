import { PrismaClient } from '@prisma/client';
import * as fs from 'fs';
import * as path from 'path';
const p = new PrismaClient();
async function run() {
    const brands = await p.brand.findMany({
        select: { id: true, name: true, slug: true, brandSku: true, manufacturer: { select: { name: true } } },
        orderBy: { name: 'asc' },
    });
    const out = path.resolve(__dirname, 'brand-list.json');
    fs.writeFileSync(out, JSON.stringify(brands, null, 2), 'utf-8');
    console.log(`Wrote ${brands.length} brands to ${out}`);
}
run().catch(e => console.error('ERROR:', e.message)).finally(() => p.$disconnect());
