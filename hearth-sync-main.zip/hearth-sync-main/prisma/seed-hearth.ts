/**
 * seed-hearth.ts
 *
 * Seeds ScraperConfig records ONLY from OldWebScraperProject/configs/brands-hearth.json.
 * Does NOT create or modify Brands, Manufacturers, or Integrations.
 *
 * Each JSON entry must have a brand_id field (stamped by stamp-brand-ids.ts).
 * Run:  npm run db:seed-hearth
 */

import { PrismaClient } from '@prisma/client';
import * as fs from 'fs';
import * as path from 'path';

const prisma = new PrismaClient();

// ─── Category key parser ──────────────────────────────────────────────────────

function parseCategorySlug(key: string): string | null {
    const k = key.toLowerCase().replace(/_/g, '-').replace(/\s+/g, '-');

    if (k.startsWith('pf-') || k.includes('-pf-')) return 'patio-furniture';
    if (k.includes('glog') || k.includes('gas-log') || k.includes('vented-log') || k.includes('gas-logs')) return 'gas-log-sets';
    if (k.includes('vent-free') || k.includes('ventfree')) return 'vent-free-log-sets';

    if (k.includes('insert')) {
        if (k.includes('gas')) return 'gas-inserts';
        if (k.includes('wood')) return 'wood-inserts';
        if (k.includes('electric')) return 'electric-inserts';
        if (k.includes('pellet')) return 'pellet-inserts';
        return 'gas-inserts';
    }
    if (k.includes('stove')) {
        if (k.includes('pellet')) return 'pellet-stoves';
        if (k.includes('electric')) return 'electric-stoves';
        if (k.includes('wood')) return 'wood-stoves';
        if (k.includes('gas')) return 'gas-stoves';
        return 'wood-stoves';
    }
    if (k.includes('fp-') || k.includes('fp_') || k.includes('fireplace') || k.startsWith('fp')) {
        if (k.includes('electric')) return 'electric-fireplaces';
        if (k.includes('wood')) return 'wood-fireplaces';
        if (k.includes('ethanol') || k.includes('bio')) return 'ethanol-fireplaces';
        if (k.includes('outdoor')) return 'outdoor-fireplaces';
        return 'gas-fireplaces';
    }

    if (k.includes('gas-fireplace')) return 'gas-fireplaces';
    if (k.includes('wood-fireplace')) return 'wood-fireplaces';
    if (k.includes('electric-fireplace')) return 'electric-fireplaces';
    if (k.includes('outdoor-fireplace')) return 'outdoor-fireplaces';
    if (k.includes('fire-pit') || k.includes('firepit')) return 'fire-pits';
    if (k.includes('fire-table')) return 'fire-tables';
    if (k.includes('grill') || k.includes('bbq')) return 'grills';
    if (k.includes('heater')) return 'outdoor-heaters';
    if (k.includes('kitchen')) return 'outdoor-kitchens';
    if (k.includes('access')) return 'accessories';
    return null;
}

// ─── Idempotent upsert ────────────────────────────────────────────────────────

async function upsertConfig(
    configName: string,
    type: 'CATEGORY' | 'PRODUCT_LIST' | 'PRODUCT_PAGE',
    brandId: string,
    configJson: Record<string, any>,
    notes: string,
    categoryIds: string[],
): Promise<'created' | 'updated'> {
    const existing = await prisma.scraperConfig.findFirst({ where: { name: configName, type } });

    if (existing) {
        await prisma.scraperConfig.update({
            where: { id: existing.id },
            data: {
                config: configJson,
                notes,
                ...(categoryIds.length > 0
                    ? { defaultCategories: { set: categoryIds.map(id => ({ id })) } }
                    : {}),
            },
        });
        return 'updated';
    }

    await prisma.scraperConfig.create({
        data: {
            name: configName,
            type,
            brandId,
            integrationMethod: 'SCRAPE',
            config: configJson,
            isActive: false,
            notes,
            ...(categoryIds.length > 0
                ? { defaultCategories: { connect: categoryIds.map(id => ({ id })) } }
                : {}),
        },
    });
    return 'created';
}

// ─── Main ─────────────────────────────────────────────────────────────────────

async function main() {
    console.log('\n🔥 HearthSync — Scraper Config Seed (brands-hearth.json)\n' + '─'.repeat(54));

    const configPath = path.resolve(__dirname, '..', 'OldWebScraperProject', 'configs', 'brands-hearth.json');
    if (!fs.existsSync(configPath)) {
        console.error(`❌ File not found: ${configPath}`);
        process.exit(1);
    }

    const rawConfigs: Record<string, any> = JSON.parse(fs.readFileSync(configPath, 'utf-8'));
    const configKeys = Object.keys(rawConfigs);
    console.log(`📄 ${configKeys.length} entries in brands-hearth.json`);

    const allCategories = await prisma.productCategory.findMany({ select: { id: true, slug: true } });
    const categoryBySlug = new Map(allCategories.map(c => [c.slug, c.id]));
    console.log(`🗂️  ${categoryBySlug.size} categories loaded\n`);

    let catCreated = 0, catUpdated = 0;
    let plCreated = 0, plUpdated = 0;
    let ppCreated = 0, ppUpdated = 0;
    const skipped: string[] = [];

    for (const configKey of configKeys) {
        const config = rawConfigs[configKey];
        const brandId: string | undefined = config.brand_id;
        const brandName: string = config.name || config.slug_name || configKey;
        const sourceLabel = `brands-hearth.json[${configKey}]`;

        if (!brandId) {
            console.warn(`   ⚠️  No brand_id on "${configKey}" — skipping`);
            skipped.push(configKey);
            continue;
        }

        // ── 1. CATEGORY (base_urls) ───────────────────────────────────────────
        const baseUrls = config.base_urls;
        if (baseUrls && typeof baseUrls === 'object' && !Array.isArray(baseUrls)) {
            const entries = Object.entries<string>(baseUrls);
            if (entries.length > 0) {
                const firstUrl = entries[0][1];
                const categoryIds: string[] = [];
                const seen = new Set<string>();
                for (const [key] of entries) {
                    const slug = parseCategorySlug(key);
                    if (slug && categoryBySlug.has(slug) && !seen.has(slug)) {
                        categoryIds.push(categoryBySlug.get(slug)!);
                        seen.add(slug);
                    }
                }
                // Store base_urls as config, plus baseUrl set to first URL
                const r = await upsertConfig(
                    `${brandName} – Categories`, 'CATEGORY',
                    brandId,
                    { urls: baseUrls, baseUrl: firstUrl },
                    `Source: ${sourceLabel}`,
                    categoryIds,
                );
                // Also patch baseUrl scalar field
                const saved = await prisma.scraperConfig.findFirst({ where: { name: `${brandName} – Categories`, type: 'CATEGORY' } });
                if (saved) await prisma.scraperConfig.update({ where: { id: saved.id }, data: { baseUrl: firstUrl } });
                r === 'created' ? catCreated++ : catUpdated++;
            }
        }

        // ── 2. PRODUCT_LIST (product_list) ────────────────────────────────────
        const productList = config.product_list;
        if (productList && typeof productList === 'object') {
            const r = await upsertConfig(
                `${brandName} – Product List`, 'PRODUCT_LIST',
                brandId,
                { ...productList, _source: sourceLabel },
                `Source: ${sourceLabel}`,
                [],
            );
            r === 'created' ? plCreated++ : plUpdated++;
        }

        // ── 3. PRODUCT_PAGE (product_page) ────────────────────────────────────
        const productPage = config.product_page;
        if (productPage && typeof productPage === 'object') {
            const r = await upsertConfig(
                `${brandName} – Product Page`, 'PRODUCT_PAGE',
                brandId,
                { ...productPage, _source: sourceLabel },
                `Source: ${sourceLabel}`,
                [],
            );
            r === 'created' ? ppCreated++ : ppUpdated++;
        }
    }

    const total = catCreated + catUpdated + plCreated + plUpdated + ppCreated + ppUpdated;
    console.log('─'.repeat(54));
    console.log('📊 Results:');
    console.log(`   CATEGORY     — ${catCreated} created, ${catUpdated} updated`);
    console.log(`   PRODUCT_LIST — ${plCreated} created,  ${plUpdated} updated`);
    console.log(`   PRODUCT_PAGE — ${ppCreated} created,  ${ppUpdated} updated`);
    console.log(`   Total: ${total}`);
    if (skipped.length > 0) {
        console.log(`\n   ⚠️  Skipped (${skipped.length}): ${skipped.join(', ')}`);
    }
    console.log('\n✅ Done!\n');
}

main()
    .catch(e => { console.error('Seed error:', e); process.exit(1); })
    .finally(() => prisma.$disconnect());
