/**
 * stamp-brand-ids.ts  (v2)
 * Queries the DB for each brand by slug, then stamps brand_id onto brands-hearth.json.
 * Uses DB as source of truth — no hardcoded IDs.
 */
import { PrismaClient } from '@prisma/client';
import * as fs from 'fs';
import * as path from 'path';

const p = new PrismaClient();

// config key → brand slug in DB
const CONFIG_TO_SLUG: Record<string, string> = {
    amantii: 'amantii',
    ambiance: 'ambiance',
    ambiance_mantels: 'ambiance',
    astria: 'astria',
    athena: 'athena',
    blaze_king: 'blaze-king',
    breeo: 'breeo',
    bromic_heaters: 'bromic-heating',
    comfortbilt: 'comfort-bilt',
    dimplex: 'dimplex',
    dracme_mantels: 'dracme-mantel',
    earthcore: 'earthcore',
    elmira_stove_works: 'elmira',
    empire_stoves: 'empire-stoves',
    enerzone: 'enerzone',
    european_home: 'european-home',
    firegear: 'firegear-outdoors',
    golden_blount: 'golden-blount',
    grand_canyon_gas_logs: 'grand-canyon-gas-logs',
    hargrove: 'hargrove',
    hargrove_2: 'hargrove',
    harmon: 'harman',
    hearthstone: 'heartstone',
    hpc: 'hpc-fire-inspired',
    ihp_superior: 'superior-fireplaces',
    invicta: 'invicta',
    kingsman: 'kingsman',
    kingsman_2: 'kingsman',
    kozy_heat: 'kozy-heat',
    kuma: 'kuma-stoves',
    majestic: 'majestic',
    majestic_accessories: 'majestic',
    majestic_gas_inserts: 'majestic',
    majestic_logs: 'majestic',
    mendota: 'mendota',
    mf_fire: 'mf-fire',
    modern_flames: 'modern-flames',
    ortal: 'ortal',
    outdoor_greatroom: 'the-outdoor-greatroom-company',
    outdoor_lifestyles: 'outdoor-lifestyles',
    piazzetta: 'piazzetta',
    plaza: 'plaza',
    ravelli: 'ravelli',
    regency: 'regency',
    regency_gas_stoves: 'regency',
    simplifire: 'simplifire',
    stoll_accessories: 'stoll-industries',
    tulikivi: 'tulikivi',
    uptown_electric_fireplaces: 'uptown-electric-fireplaces',
    urbana: 'urbana',
    valor: 'valor',
    valor_electric: 'valor',
    ventis: 'ventis',
    woodhaven: 'woodhaven',
    woodhaven_covers: 'woodhaven',
};

async function main() {
    // Build slug → DB id map from live DB
    const slugs = Array.from(new Set(Object.values(CONFIG_TO_SLUG)));
    const brands = await p.brand.findMany({ where: { slug: { in: slugs } }, select: { id: true, slug: true, name: true } });
    const idBySlug = new Map(brands.map(b => [b.slug, b.id]));
    console.log(`\n✅ Found ${brands.length} of ${slugs.length} slugs in DB`);

    const missing = slugs.filter(s => !idBySlug.has(s));
    if (missing.length > 0) {
        console.warn(`⚠️  Missing in DB: ${missing.join(', ')}`);
    }

    // Update brands-hearth.json
    const configPath = path.resolve(__dirname, '..', 'OldWebScraperProject', 'configs', 'brands-hearth.json');
    const raw: Record<string, any> = JSON.parse(fs.readFileSync(configPath, 'utf-8'));

    let stamped = 0, skipped = 0;
    for (const [configKey, entry] of Object.entries(raw)) {
        const brandSlug = CONFIG_TO_SLUG[configKey];
        const brandId = brandSlug ? idBySlug.get(brandSlug) : undefined;

        if (brandId) {
            // Remove any old brand_id before re-stamping to avoid duplication
            const { brand_id: _old, ...rest } = entry;
            raw[configKey] = { brand_id: brandId, ...rest };
            stamped++;
        } else {
            console.warn(`   ⚠️  No DB match for config key "${configKey}" (slug="${brandSlug ?? 'unmapped'}")`);
            skipped++;
        }
    }

    fs.writeFileSync(configPath, JSON.stringify(raw, null, 2), 'utf-8');
    console.log(`\n📄 Stamped ${stamped} entries. Skipped: ${skipped}\n`);
}

main().catch(e => console.error('ERROR:', e)).finally(() => p.$disconnect());
