import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function main() {
    console.log('Creating dealer_users table manually because Prisma push failed due to file locks...');

    await prisma.$executeRawUnsafe(`
        CREATE TABLE IF NOT EXISTS dealer_users (
            id TEXT PRIMARY KEY,
            "dealerId" TEXT NOT NULL REFERENCES dealer_accounts(id) ON DELETE CASCADE,
            email TEXT UNIQUE NOT NULL,
            "userId" TEXT UNIQUE,
            role TEXT NOT NULL DEFAULT 'member',
            "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
            "updatedAt" TIMESTAMP(3) NOT NULL
        );
    `);

    await prisma.$executeRawUnsafe(`
        CREATE INDEX IF NOT EXISTS dealer_users_dealerId_idx ON dealer_users("dealerId");
    `);

    console.log('Table created or already exists.\n');

    const dealers = await prisma.dealerAccount.findMany();
    let createdCount = 0;

    for (const dealer of dealers) {
        const existingUsers: any[] = await prisma.$queryRawUnsafe(`SELECT id FROM dealer_users WHERE "dealerId" = $1`, dealer.id);

        if (existingUsers.length === 0) {
            console.log(`Dealer ${dealer.companyName} has no users. Creating owner user for ${dealer.email}...`);
            await prisma.$executeRawUnsafe(`
                INSERT INTO dealer_users (id, "dealerId", email, role, "updatedAt") 
                VALUES (gen_random_uuid()::text, $1, $2, 'owner', NOW())
            `, dealer.id, dealer.email);
            createdCount++;
        }
    }

    console.log(`Done! Created ${createdCount} missing dealer users.`);
}

main()
    .catch((e) => {
        console.error(e);
        process.exit(1);
    })
    .finally(async () => {
        await prisma.$disconnect();
    });
