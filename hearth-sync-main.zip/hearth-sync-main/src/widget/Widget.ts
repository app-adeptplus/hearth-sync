/* eslint-disable @typescript-eslint/no-explicit-any */
import { WidgetApi, type Product } from './api';
import { getStyles } from './styles';

export class HearthSyncWidget {
    private container: HTMLElement;
    private shadowRoot: ShadowRoot;
    private api: WidgetApi;
    private dealerId: string;
    private products: Product[] = [];

    // DOM Elements
    private gridEl!: HTMLElement;
    private searchInput!: HTMLInputElement;

    constructor(containerId: string, dealerId: string) {
        const el = document.getElementById(containerId);
        if (!el) throw new Error(`[HearthSync] Container #${containerId} not found`);

        this.container = el;
        this.dealerId = dealerId;
        this.api = new WidgetApi(dealerId);

        // Attach Shadow DOM for style isolation
        this.shadowRoot = this.container.attachShadow({ mode: 'open' });
    }

    async init() {
        this.renderLoading();

        // Fetch custom config and products concurrently
        const [config, products] = await Promise.all([
            this.api.getConfig(),
            this.api.getProducts()
        ]);

        this.products = products;
        this.render(config);
    }

    private renderLoading() {
        this.shadowRoot.innerHTML = `
      <style>
        .hs-loader { text-align: center; padding: 40px; font-family: sans-serif; color: #666; }
      </style>
      <div class="hs-loader">Loading Catalog...</div>
    `;
    }

    private render(config: any) {
        const styleSheet = new CSSStyleSheet();
        styleSheet.replaceSync(getStyles(config));
        this.shadowRoot.adoptedStyleSheets = [styleSheet];

        this.shadowRoot.innerHTML = `
      <div class="hs-catalog-container">
        <div class="hs-header">
          <input type="search" class="hs-input hs-search" placeholder="Search catalog..." />
          <select class="hs-input hs-category-filter">
            <option value="">All Categories</option>
            <option value="fireplaces">Fireplaces</option>
            <option value="stoves">Stoves</option>
            <option value="inserts">Inserts</option>
          </select>
        </div>
        <div class="hs-grid"></div>
      </div>
    `;

        this.gridEl = this.shadowRoot.querySelector('.hs-grid') as HTMLElement;
        this.searchInput = this.shadowRoot.querySelector('.hs-search') as HTMLInputElement;

        this.bindEvents();
        this.renderProducts(this.products);
    }

    private bindEvents() {
        let timeout: any;
        this.searchInput.addEventListener('input', (e) => {
            clearTimeout(timeout);
            timeout = setTimeout(() => {
                const val = (e.target as HTMLInputElement).value;
                this.filterProducts(val);
            }, 300);
        });

        const categorySelect = this.shadowRoot.querySelector('.hs-category-filter');
        categorySelect?.addEventListener('change', async (e) => {
            const val = (e.target as HTMLSelectElement).value;
            this.renderLoading(); // Show minimal loader
            const filtered = await this.api.getProducts({ category: val, q: this.searchInput.value });

            // Re-apply styles after resetting innerHTML in renderLoading
            const config = await this.api.getConfig();
            this.render(config);
            this.products = filtered;
            this.renderProducts(this.products);
        });
    }

    private filterProducts(query: string) {
        const q = query.toLowerCase();
        const filtered = this.products.filter(p =>
            p.name.toLowerCase().includes(q) ||
            (p.modelNumber && p.modelNumber.toLowerCase().includes(q))
        );
        this.renderProducts(filtered);
    }

    private renderProducts(products: Product[]) {
        if (products.length === 0) {
            this.gridEl.innerHTML = `<div style="grid-column: 1/-1; text-align: center; padding: 40px;">No products found.</div>`;
            return;
        }

        this.gridEl.innerHTML = products.map(p => `
      <div class="hs-card">
        ${p.imageUrl
                ? `<img src="${p.imageUrl}" alt="${p.name}" class="hs-card-image" loading="lazy" />`
                : `<div class="hs-card-image-placeholder">No Image</div>`
            }
        <div class="hs-card-content">
          <div class="hs-brand">${p.brand}</div>
          <h3 class="hs-title" title="${p.name}">${p.name}</h3>
          <div class="hs-meta">
            <span>${p.modelNumber || 'N/A'}</span>
            <span>${p.fuelType || ''}</span>
          </div>
          <button class="hs-btn">View Details</button>
        </div>
      </div>
    `).join('');

        // Bind detail clicks
        const btns = this.gridEl.querySelectorAll('.hs-btn');
        btns.forEach((btn, i) => {
            btn.addEventListener('click', () => {
                // Mock detailed view behavior
                alert(`Opening details for: ${products[i].name}\n(Lead capture and detailed specs would load here in a modal)`);
            });
        });
    }
}

// Auto-initialize if script tag has data attributes
if (typeof window !== 'undefined') {
    (window as any).HearthSyncWidget = HearthSyncWidget;

    // Wait for DOM to be ready
    document.addEventListener('DOMContentLoaded', () => {
        const scriptTag = document.querySelector('script[data-dealer-id]');
        if (scriptTag) {
            const dealerId = scriptTag.getAttribute('data-dealer-id');
            const containerId = scriptTag.getAttribute('data-container-id') || 'hearthsync-catalog';

            if (dealerId) {
                // Create container if it doesn't exist but script specifies default ID
                if (!document.getElementById(containerId)) {
                    const div = document.createElement('div');
                    div.id = containerId;
                    scriptTag.parentNode?.insertBefore(div, scriptTag);
                }

                const widget = new HearthSyncWidget(containerId, dealerId);
                widget.init();
            }
        }
    });
}
