export interface WidgetConfig {
    primaryColor: string;
    fontFamily: string;
    cornerStyle: 'rounded' | 'square' | 'pill';
}

export interface Product {
    id: string;
    name: string;
    slug: string;
    brand: string;
    modelNumber: string | null;
    fuelType: string | null;
    imageUrl: string | null;
    priceMsrp: number | null;
}

export class WidgetApi {
    private baseUrl: string;
    private dealerId: string;

    constructor(dealerId: string) {
        this.dealerId = dealerId;
        this.baseUrl = typeof window !== 'undefined'
            ? `${window.location.origin}/api/widget`
            : (process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:5000') + '/api/widget';
    }

    async getConfig(): Promise<WidgetConfig> {
        try {
            const res = await fetch(`${this.baseUrl}/${this.dealerId}/config`);
            if (!res.ok) throw new Error('Failed to fetch config');
            return await res.json();
        } catch (e) {
            console.error('[HearthSync] Config error:', e);
            return { primaryColor: '#000000', fontFamily: 'inherit', cornerStyle: 'rounded' };
        }
    }

    async getProducts(params?: { q?: string; category?: string; brand?: string }): Promise<Product[]> {
        try {
            const url = new URL(`${this.baseUrl}/${this.dealerId}/products`);
            if (params?.q) url.searchParams.set('q', params.q);
            if (params?.category) url.searchParams.set('category', params.category);
            if (params?.brand) url.searchParams.set('brand', params.brand);

            const res = await fetch(url.toString());
            if (!res.ok) throw new Error('Failed to fetch products');

            const data = await res.json();
            return data.products || [];
        } catch (e) {
            console.error('[HearthSync] Products error:', e);
            return [];
        }
    }
}
