import { WidgetConfig } from './api';

export function getStyles(config: WidgetConfig): string {
    const borderRadius = config.cornerStyle === 'rounded' ? '8px' : config.cornerStyle === 'pill' ? '24px' : '0px';
    const fontFamily = config.fontFamily !== 'inherit' ? `font-family: ${config.fontFamily}, sans-serif;` : '';

    return `
    :host {
      --hs-primary: ${config.primaryColor};
      --hs-radius: ${borderRadius};
      --hs-bg: #ffffff;
      --hs-surface: #f8fafc;
      --hs-border: #e2e8f0;
      --hs-text: #0f172a;
      --hs-text-muted: #64748b;
      
      display: block;
      ${fontFamily}
      color: var(--hs-text);
      line-height: 1.5;
    }

    * {
      box-sizing: border-box;
    }

    .hs-catalog-container {
      width: 100%;
      max-width: 1200px;
      margin: 0 auto;
    }

    /* Search & Filter Bar */
    .hs-header {
      display: flex;
      flex-wrap: wrap;
      gap: 16px;
      margin-bottom: 24px;
      padding: 16px;
      background: var(--hs-surface);
      border-radius: var(--hs-radius);
      border: 1px solid var(--hs-border);
    }

    .hs-input {
      padding: 8px 12px;
      border: 1px solid var(--hs-border);
      border-radius: var(--hs-radius);
      font-size: 14px;
      outline: none;
      flex: 1;
      min-width: 200px;
    }

    .hs-input:focus {
      border-color: var(--hs-primary);
    }

    /* Grid */
    .hs-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
      gap: 24px;
    }

    /* Product Card */
    .hs-card {
      background: var(--hs-bg);
      border: 1px solid var(--hs-border);
      border-radius: var(--hs-radius);
      overflow: hidden;
      transition: box-shadow 0.2s;
      display: flex;
      flex-direction: column;
    }

    .hs-card:hover {
      box-shadow: 0 4px 12px rgba(0,0,0,0.05);
    }

    .hs-card-image {
      aspect-ratio: 1;
      width: 100%;
      object-fit: contain;
      padding: 16px;
      background: var(--hs-bg);
      border-bottom: 1px solid var(--hs-border);
    }

    .hs-card-image-placeholder {
      aspect-ratio: 1;
      width: 100%;
      display: flex;
      align-items: center;
      justify-content: center;
      background: var(--hs-surface);
      color: var(--hs-text-muted);
      font-size: 14px;
      border-bottom: 1px solid var(--hs-border);
    }

    .hs-card-content {
      padding: 16px;
      display: flex;
      flex-direction: column;
      flex: 1;
    }

    .hs-brand {
      font-size: 11px;
      text-transform: uppercase;
      letter-spacing: 0.05em;
      color: var(--hs-text-muted);
      margin-bottom: 4px;
    }

    .hs-title {
      font-size: 16px;
      font-weight: 600;
      margin: 0 0 8px 0;
      color: var(--hs-text);
      display: -webkit-box;
      -webkit-line-clamp: 2;
      -webkit-box-orient: vertical;
      overflow: hidden;
    }

    .hs-meta {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-top: auto;
      font-size: 13px;
      color: var(--hs-text-muted);
    }

    .hs-btn {
      margin-top: 16px;
      padding: 8px 16px;
      background: var(--hs-primary);
      color: #fff;
      border: none;
      border-radius: var(--hs-radius);
      font-weight: 500;
      cursor: pointer;
      text-align: center;
      transition: opacity 0.2s;
    }

    .hs-btn:hover {
      opacity: 0.9;
    }

    .hs-loader {
      text-align: center;
      padding: 40px;
      color: var(--hs-text-muted);
    }
  `;
}
