/* eslint-disable @typescript-eslint/no-explicit-any */
/**
 * Tests for /api/automation/configs API routes
 *
 * These tests mock the Prisma client to avoid requiring a live database.
 */
import { describe, it, expect, vi, beforeEach } from 'vitest';

// Must use vi.hoisted so the mock object is available inside vi.mock factory
const mockPrisma = vi.hoisted(() => ({
    automationConfig: {
        findMany: vi.fn(),
        findUnique: vi.fn(),
        create: vi.fn(),
        update: vi.fn(),
    },
}));

vi.mock('@/lib/db', () => ({
    default: mockPrisma,
}));

// Import after mocking
import { GET, POST } from '@/app/api/automation/configs/route';

function makeRequest(url: string, options?: RequestInit) {
    return new Request(url, options) as any;
}

describe('/api/automation/configs', () => {
    beforeEach(() => {
        vi.clearAllMocks();
    });

    describe('GET', () => {
        it('returns all configs when no sourceType filter', async () => {
            const mockConfigs = [
                { id: '1', name: 'Test Scraper', sourceType: 'SITE_SCRAPER', brand: { id: 'b1', name: 'TestBrand' }, _count: { runs: 0, artifacts: 0 } },
            ];
            mockPrisma.automationConfig.findMany.mockResolvedValue(mockConfigs);

            const request = makeRequest('http://localhost:3000/api/automation/configs');
            const response = await GET(request);
            const data = await response.json();

            expect(response.status).toBe(200);
            expect(data).toEqual(mockConfigs);
            expect(mockPrisma.automationConfig.findMany).toHaveBeenCalledWith(
                expect.objectContaining({
                    where: undefined,
                })
            );
        });

        it('filters by sourceType when provided', async () => {
            mockPrisma.automationConfig.findMany.mockResolvedValue([]);

            const request = makeRequest('http://localhost:3000/api/automation/configs?sourceType=API_AUTOMATION');
            const response = await GET(request);

            expect(response.status).toBe(200);
            expect(mockPrisma.automationConfig.findMany).toHaveBeenCalledWith(
                expect.objectContaining({
                    where: { sourceType: 'API_AUTOMATION' },
                })
            );
        });
    });

    describe('POST', () => {
        it('creates a new config with required fields', async () => {
            const newConfig = {
                id: 'new-1',
                name: 'New Scraper',
                sourceType: 'SITE_SCRAPER',
                status: 'DRAFT',
                brand: { id: 'b1', name: 'TestBrand' },
            };
            mockPrisma.automationConfig.create.mockResolvedValue(newConfig);

            const request = makeRequest('http://localhost:3000/api/automation/configs', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ name: 'New Scraper', sourceType: 'SITE_SCRAPER' }),
            });
            const response = await POST(request);
            const data = await response.json();

            expect(response.status).toBe(201);
            expect(data.name).toBe('New Scraper');
        });

        it('returns 400 when name is missing', async () => {
            const request = makeRequest('http://localhost:3000/api/automation/configs', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ sourceType: 'SITE_SCRAPER' }),
            });
            const response = await POST(request);

            expect(response.status).toBe(400);
        });

        it('returns 400 when sourceType is missing', async () => {
            const request = makeRequest('http://localhost:3000/api/automation/configs', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ name: 'Test' }),
            });
            const response = await POST(request);

            expect(response.status).toBe(400);
        });
    });
});
