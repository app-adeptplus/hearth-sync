/* eslint-disable @typescript-eslint/no-explicit-any */
/**
 * Tests for /api/automation/llm-settings API routes
 */
import { describe, it, expect, vi, beforeEach } from 'vitest';

const mockPrisma = vi.hoisted(() => ({
    llmApiConfig: {
        findMany: vi.fn(),
        create: vi.fn(),
        update: vi.fn(),
        updateMany: vi.fn(),
    },
}));

vi.mock('@/lib/db', () => ({
    default: mockPrisma,
}));

import { GET, POST, PATCH } from '@/app/api/automation/llm-settings/route';

function makeRequest(url: string, options?: RequestInit) {
    return new Request(url, options) as any;
}

describe('/api/automation/llm-settings', () => {
    beforeEach(() => {
        vi.clearAllMocks();
    });

    describe('GET', () => {
        it('returns configs with masked API keys', async () => {
            const mockConfigs = [
                { id: '1', provider: 'GOOGLE_GEMINI', apiKey: 'AIzaSyABCDEFGH12345', model: 'gemini-2.0-flash', isDefault: true },
            ];
            mockPrisma.llmApiConfig.findMany.mockResolvedValue(mockConfigs);

            const response = await GET();
            const data = await response.json();

            expect(response.status).toBe(200);
            expect(data[0].apiKey).toBe('****2345');
            expect(data[0].provider).toBe('GOOGLE_GEMINI');
        });
    });

    describe('POST', () => {
        it('creates a new LLM config', async () => {
            const newConfig = {
                id: 'llm-1',
                provider: 'GOOGLE_GEMINI',
                apiKey: 'AIzaSyABCDEFGH12345',
                model: 'gemini-2.0-flash',
                isDefault: false,
            };
            mockPrisma.llmApiConfig.create.mockResolvedValue(newConfig);

            const request = makeRequest('http://localhost:3000/api/automation/llm-settings', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    provider: 'GOOGLE_GEMINI',
                    apiKey: 'AIzaSyABCDEFGH12345',
                    model: 'gemini-2.0-flash',
                }),
            });
            const response = await POST(request);
            const data = await response.json();

            expect(response.status).toBe(201);
            expect(data.apiKey).toBe('****2345'); // Key should be masked
        });

        it('returns 400 when required fields are missing', async () => {
            const request = makeRequest('http://localhost:3000/api/automation/llm-settings', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ provider: 'GOOGLE_GEMINI' }),
            });
            const response = await POST(request);

            expect(response.status).toBe(400);
        });

        it('unsets existing defaults when isDefault is true', async () => {
            mockPrisma.llmApiConfig.updateMany.mockResolvedValue({ count: 1 });
            mockPrisma.llmApiConfig.create.mockResolvedValue({
                id: 'llm-2',
                provider: 'OPENAI',
                apiKey: 'sk-test12345678',
                model: 'gpt-4o-mini',
                isDefault: true,
            });

            const request = makeRequest('http://localhost:3000/api/automation/llm-settings', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    provider: 'OPENAI',
                    apiKey: 'sk-test12345678',
                    model: 'gpt-4o-mini',
                    isDefault: true,
                }),
            });
            await POST(request);

            expect(mockPrisma.llmApiConfig.updateMany).toHaveBeenCalledWith({
                where: { isDefault: true },
                data: { isDefault: false },
            });
        });
    });

    describe('PATCH', () => {
        it('returns 400 when id is missing', async () => {
            const request = makeRequest('http://localhost:3000/api/automation/llm-settings', {
                method: 'PATCH',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ model: 'gpt-4o' }),
            });
            const response = await PATCH(request);

            expect(response.status).toBe(400);
        });

        it('updates an existing config', async () => {
            const updatedConfig = {
                id: 'llm-1',
                provider: 'GOOGLE_GEMINI',
                apiKey: 'AIzaSyABCDEFGH12345',
                model: 'gemini-2.0-flash-lite',
                isDefault: true,
            };
            mockPrisma.llmApiConfig.update.mockResolvedValue(updatedConfig);

            const request = makeRequest('http://localhost:3000/api/automation/llm-settings', {
                method: 'PATCH',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ id: 'llm-1', model: 'gemini-2.0-flash-lite' }),
            });
            const response = await PATCH(request);
            const data = await response.json();

            expect(response.status).toBe(200);
            expect(data.apiKey).toBe('****2345'); // Key masked
        });
    });
});
