/* eslint-disable @typescript-eslint/no-explicit-any */
/**
 * Tests for /api/automation/data-packages API routes
 */
import { describe, it, expect, vi, beforeEach } from 'vitest';

const mockPrisma = vi.hoisted(() => ({
    dataPackage: {
        findMany: vi.fn(),
        findUnique: vi.fn(),
        create: vi.fn(),
        update: vi.fn(),
    },
}));

vi.mock('@/lib/db', () => ({
    default: mockPrisma,
}));

import { GET, POST } from '@/app/api/automation/data-packages/route';

function makeRequest(url: string, options?: RequestInit) {
    return new Request(url, options) as any;
}

describe('/api/automation/data-packages', () => {
    beforeEach(() => {
        vi.clearAllMocks();
    });

    describe('GET', () => {
        it('returns all packages with no filters', async () => {
            const mockPackages = [
                { id: 'pkg-1', name: 'Test Package', status: 'PENDING_REVIEW', brand: null, _count: { items: 5 } },
            ];
            mockPrisma.dataPackage.findMany.mockResolvedValue(mockPackages);

            const request = makeRequest('http://localhost:3000/api/automation/data-packages');
            const response = await GET(request);
            const data = await response.json();

            expect(response.status).toBe(200);
            expect(data).toEqual(mockPackages);
        });

        it('filters by status', async () => {
            mockPrisma.dataPackage.findMany.mockResolvedValue([]);

            const request = makeRequest('http://localhost:3000/api/automation/data-packages?status=APPROVED');
            const response = await GET(request);

            expect(response.status).toBe(200);
            expect(mockPrisma.dataPackage.findMany).toHaveBeenCalledWith(
                expect.objectContaining({
                    where: expect.objectContaining({ status: 'APPROVED' }),
                })
            );
        });
    });

    describe('POST', () => {
        it('creates a manual data package', async () => {
            const newPkg = {
                id: 'pkg-new',
                name: 'Manual Import',
                status: 'PENDING_REVIEW',
            };
            mockPrisma.dataPackage.create.mockResolvedValue(newPkg);

            const request = makeRequest('http://localhost:3000/api/automation/data-packages', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ name: 'Manual Import' }),
            });
            const response = await POST(request);
            const data = await response.json();

            expect(response.status).toBe(201);
            expect(data.name).toBe('Manual Import');
        });

        it('returns 400 when name is missing', async () => {
            const request = makeRequest('http://localhost:3000/api/automation/data-packages', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({}),
            });
            const response = await POST(request);

            expect(response.status).toBe(400);
        });
    });
});
