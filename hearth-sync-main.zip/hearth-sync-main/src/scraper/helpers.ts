/**
 * HearthSync Scraper Helpers
 * Generic utility functions for the scraping pipeline.
 *
 * Puppeteer-specific helpers (PUPGMO, propertyCallback, booleanCallback, getProps, etc.)
 * have been removed — browser-based scraping is handled by the external worker service.
 */

// ---- Sanitization Functions ----

export const SAN: Record<string, (value: string) => string> = {
    trim: (value) => value.trim(),
    commas: (value) => `"${value}"`,
    leadingSlashes: (value) => value.replace(/^\/+/, ''),
    trailingSlashes: (value) => value.endsWith('/') ? value.replace(/\/+$/, '') : value,
    addLeadingSlash: (value) => '/' + value,
    addTrailingSlash: (value) => value + '/',
};

export function sanitize(value: string | null | undefined, sanitizations: string[] = ['trim']): string {
    if (value === null || value === undefined || typeof value !== 'string') {
        return '';
    }

    let result = value;
    for (const s of sanitizations) {
        if (s.startsWith('remove::')) {
            const removeStr = s.split('::')[1];
            result = result.replace(removeStr, '');
        } else if (s.startsWith('prepend::')) {
            const prependStr = s.split('::')[1];
            result = prependStr + result;
        } else if (SAN[s]) {
            result = SAN[s](result);
        }
    }

    return result;
}

// ---- Utility ----

export const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));
export const sleepSeconds = (s: number) => sleep(s * 1000);

export function slugify(text: string): string {
    return text
        .toLowerCase()
        .replace(/[™®]/g, '')
        .replace(/\//g, '-')
        .replace(/,/g, '_')
        .replace(/"/g, '')
        .replace(/'/g, ' ft')
        .replace(/\s+/g, '-')
        .replace(/[^a-z0-9_-]/g, '')
        .replace(/-+/g, '-')
        .replace(/^-|-$/g, '');
}

export function capitalize(v: string): string {
    return v.charAt(0).toUpperCase() + v.slice(1);
}
