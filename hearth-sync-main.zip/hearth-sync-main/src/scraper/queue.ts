/**
 * HearthSync Scraper Queue — DB-Backed Job Dispatcher
 *
 * Uses the ScraperJob table as a job queue instead of Redis/BullMQ.
 * Jobs are created with status PENDING and picked up by:
 *   - Direct dispatch (queue.add → ScraperEngine.dispatch)
 *   - Vercel Cron via /api/cron/process-jobs endpoint
 */

import { ScraperEngine } from './ScraperEngine';

export interface QueueJob {
    id: string;
    data: {
        jobId: string;
        configId: number;
        targetUrl?: string;
        dryRun?: boolean;
    };
}

export class ScraperQueue {
    private static instance: ScraperQueue | null = null;

    static getInstance(): ScraperQueue {
        if (!ScraperQueue.instance) {
            ScraperQueue.instance = new ScraperQueue();
        }
        return ScraperQueue.instance;
    }

    /**
     * Dispatch a scrape job to the external worker.
     * The job record should already exist in the DB with status PENDING.
     */
    async add(jobId: string, configId: number, dryRun = false, targetUrl?: string): Promise<QueueJob> {
        console.log(`📋 Dispatching scrape job: ${jobId} for config ${configId}${targetUrl ? ` @ ${targetUrl}` : ''}`);

        // Dispatch to external worker (non-blocking)
        ScraperEngine.dispatch({ jobId, configId, dryRun, targetUrl }).catch(err => {
            console.error(`❌ Job dispatch ${jobId} failed:`, err);
        });

        return {
            id: jobId,
            data: { jobId, configId, dryRun, targetUrl },
        };
    }
}

export const scraperQueue = ScraperQueue.getInstance();
