/* eslint-disable @typescript-eslint/no-explicit-any */
/**
 * HearthSync Scraper Engine — Job Dispatcher & DB Sync
 *
 * This is the control-plane orchestrator. It does NOT execute browser-based scraping.
 * Instead it:
 *   1. Dispatches scrape jobs to an external worker service via HTTP
 *   2. Receives scraped product data back
 *   3. Compares results to existing DB records and syncs (upsert/discontinue)
 *   4. Creates audit log entries for all changes
 *
 * Browser-based scraping (Puppeteer) has been moved to the external worker service.
 */

import { PrismaClient, Prisma } from '@prisma/client';
import type { BrandScraperConfig, ScrapedProduct, ScrapeJobResult, ScrapeJobOptions } from './types';
import { slugify } from './helpers';

const prisma = new PrismaClient();

const WORKER_URL = process.env.SCRAPER_WORKER_URL;
const WORKER_SECRET = process.env.SCRAPER_WORKER_SECRET;

export class ScraperEngine {
    /**
     * Dispatch a scrape job to the external worker service.
     * The worker will call back to /api/scraper/[jobId]/complete with results.
     */
    static async dispatch(options: ScrapeJobOptions): Promise<void> {
        const { jobId, configId } = options;

        // Mark job as running
        await prisma.scraperJob.update({
            where: { id: jobId },
            data: { status: 'RUNNING', startedAt: new Date() },
        });

        try {
            // Load scraper config from DB
            const scraperConfig = await prisma.scraperConfig.findUniqueOrThrow({
                where: { id: configId },
                include: { brand: true },
            });

            const brandName = scraperConfig.brand?.name ?? 'Generic Template';
            console.log(`\n🔥 Dispatching scrape job for: ${brandName}`);
            console.log(`   Config ID: ${configId}`);
            console.log(`   Job ID: ${jobId}`);

            if (!WORKER_URL) {
                throw new Error(
                    'SCRAPER_WORKER_URL is not configured. Set this environment variable to the external scraper worker endpoint.'
                );
            }

            // Send job to external worker
            const response = await fetch(`${WORKER_URL}/jobs`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    ...(WORKER_SECRET && { Authorization: `Bearer ${WORKER_SECRET}` }),
                },
                body: JSON.stringify({
                    jobId,
                    configId,
                    config: scraperConfig.config,
                    type: scraperConfig.type,
                    targetUrl: options.targetUrl,
                    dryRun: options.dryRun ?? false,
                    callbackUrl: `${process.env.NEXT_PUBLIC_APP_URL}/api/scraper/${jobId}/complete`, // maps to /api/scraper/[id]/complete
                }),
            });

            if (!response.ok) {
                const body = await response.text();
                throw new Error(`Worker returned ${response.status}: ${body}`);
            }

            console.log(`   ✅ Job dispatched to worker successfully`);
        } catch (error) {
            const msg = error instanceof Error ? error.message : String(error);
            console.error(`   ❌ Dispatch failed: ${msg}`);

            await prisma.scraperJob.update({
                where: { id: jobId },
                data: {
                    status: 'FAILED',
                    completedAt: new Date(),
                    errors: [msg],
                    logs: msg,
                },
            });

            throw error;
        }
    }

    /**
     * Process results received from the external worker.
     * Called by the /api/scraper/[jobId]/complete callback endpoint.
     */
    static async processResults(
        jobId: string,
        products: ScrapedProduct[],
        errors: string[] = []
    ): Promise<ScrapeJobResult> {
        const job = await prisma.scraperJob.findUniqueOrThrow({
            where: { id: jobId },
            include: {
                scraperConfig: { include: { brand: true } },
            },
        });

        const scraperConfig = job.scraperConfig;
        const brandConfig = scraperConfig.config as unknown as BrandScraperConfig;
        const result: ScrapeJobResult = {
            brandSlug: brandConfig.slug_name ?? scraperConfig.brand?.slug ?? 'unknown',
            productsFound: products.length,
            productsAdded: 0,
            productsUpdated: 0,
            productsRemoved: 0,
            errors,
            duration: job.startedAt ? Date.now() - job.startedAt.getTime() : 0,
            products,
        };

        console.log(`\n📊 Processing results for job ${jobId} [${scraperConfig.type}]:`);
        console.log(`   Items received: ${result.productsFound}`);
        console.log(`   Errors: ${result.errors.length}`);

        // Sync to DB unless it's just a category URL extraction
        if (products.length > 0 && scraperConfig.type !== 'CATEGORY') {
            if (!scraperConfig.brandId) {
                throw new Error(`Cannot sync products for config #${scraperConfig.id}: no brandId set.`);
            }
            const syncResult = await ScraperEngine.syncProducts(
                scraperConfig.brandId,
                products
            );
            result.productsAdded = syncResult.added;
            result.productsUpdated = syncResult.updated;
            result.productsRemoved = syncResult.removed;
        }

        // --- WORKFLOW CHAINING LOGIC ---
        if (products.length > 0) {
            if (scraperConfig.type === 'CATEGORY') {
                const workflows = await prisma.scraperWorkflow.findMany({
                    where: { categoryConfigId: scraperConfig.id, isActive: true },
                });

                for (const wf of workflows) {
                    if (wf.productListConfigId) {
                        for (const item of products) {
                            if (item.productUrl) {
                                await prisma.scraperJob.create({
                                    data: {
                                        scraperConfigId: wf.productListConfigId,
                                        status: 'PENDING',
                                        targetUrl: item.productUrl,
                                    },
                                });
                            }
                        }
                    }
                }
            } else if (scraperConfig.type === 'PRODUCT_LIST') {
                const workflows = await prisma.scraperWorkflow.findMany({
                    where: { productListConfigId: scraperConfig.id, isActive: true },
                });

                for (const wf of workflows) {
                    if (wf.productPageConfigId) {
                        for (const item of products) {
                            if (item.productUrl) {
                                await prisma.scraperJob.create({
                                    data: {
                                        scraperConfigId: wf.productPageConfigId,
                                        status: 'PENDING',
                                        targetUrl: item.productUrl,
                                    },
                                });
                            }
                        }
                    }
                }
            }
        }
        // ---------------------------------

        // Update job record
        await prisma.scraperJob.update({
            where: { id: jobId },
            data: {
                status: 'COMPLETED',
                completedAt: new Date(),
                productsFound: result.productsFound,
                productsAdded: result.productsAdded,
                productsUpdated: result.productsUpdated,
                productsRemoved: result.productsRemoved,
                errors: result.errors.length > 0 ? result.errors : Prisma.JsonNull,
            },
        });

        // Update last sync timestamp
        await prisma.scraperConfig.update({
            where: { id: scraperConfig.id },
            data: { lastSyncAt: new Date() },
        });

        return result;
    }

    /**
     * Compare scraped products against existing DB records and sync
     */
    static async syncProducts(
        brandId: string,
        scrapedProducts: ScrapedProduct[]
    ): Promise<{ added: number; updated: number; removed: number }> {
        let added = 0;
        let updated = 0;
        let removed = 0;

        // Get existing products for this brand
        const existingProducts = await prisma.product.findMany({
            where: { brandId },
            include: { images: true, specs: true },
        });

        const existingBySlug = new Map<string, any>(existingProducts.map((p) => [p.slug, p]));
        const scrapedSlugs = new Set(scrapedProducts.map((p) => p.slug));

        const fuelCategoryCache = new Map<string, string>();
        const resolveFuelCategoryId = async (name: string | null): Promise<string | null> => {
            if (!name) return null;
            const slug = slugify(name);
            if (fuelCategoryCache.has(slug)) return fuelCategoryCache.get(slug)!;

            const parent = await prisma.productCategory.findUnique({ where: { slug: 'fuel-type' } });
            if (!parent) return null;

            let cat = await prisma.productCategory.findUnique({ where: { slug } });
            if (!cat) cat = await prisma.productCategory.create({ data: { name, slug, parentId: parent.id } });

            fuelCategoryCache.set(slug, cat.id);
            return cat.id;
        };

        // Add or update products
        for (const scraped of scrapedProducts) {
            const existing = existingBySlug.get(scraped.slug);

            if (!existing) {
                const ftName = ScraperEngine.parseFuelType(scraped.fuelType || scraped.categoryKey);
                const fuelCatId = await resolveFuelCategoryId(ftName);

                const product = await prisma.product.create({
                    data: {
                        brandId,
                        name: scraped.name,
                        slug: scraped.slug,
                        modelNumber: scraped.modelNumber,
                        sku: scraped.sku,
                        ...(fuelCatId && { categories: { connect: [{ id: fuelCatId }] } }),
                        shortDescription: scraped.shortDescription,
                        description: scraped.description,
                        productUrl: scraped.productUrl,
                        status: 'ACTIVE',
                        images: scraped.imageUrls?.length
                            ? {
                                create: scraped.imageUrls
                                    .filter((url) => url && url.startsWith('http'))
                                    .map((url, i) => ({
                                        url,
                                        isPrimary: i === 0,
                                        sortOrder: i,
                                    })),
                            }
                            : undefined,
                    },
                });

                await prisma.auditLog.create({
                    data: {
                        productId: product.id,
                        action: 'CREATED',
                        entityType: 'product',
                        entityId: product.id,
                        after: { name: scraped.name, slug: scraped.slug } as unknown as any,
                        changedBy: 'scraper',
                    },
                });

                added++;
            } else {
                const changes: Record<string, { from: unknown; to: unknown }> = {};

                if (scraped.name && scraped.name !== existing.name) {
                    changes.name = { from: existing.name, to: scraped.name };
                }
                if (scraped.description && scraped.description !== existing.description) {
                    changes.description = { from: existing.description?.substring(0, 100), to: scraped.description.substring(0, 100) };
                }
                if (scraped.shortDescription && scraped.shortDescription !== existing.shortDescription) {
                    changes.shortDescription = { from: existing.shortDescription?.substring(0, 100), to: scraped.shortDescription.substring(0, 100) };
                }
                if (scraped.price) {
                    const priceNum = parseFloat(scraped.price.replace(/[^0-9.]/g, ''));
                    if (!isNaN(priceNum) && Number(existing.priceMsrp) !== priceNum) {
                        changes.priceMsrp = { from: existing.priceMsrp, to: priceNum };
                    }
                }

                if (Object.keys(changes).length > 0) {
                    await prisma.product.update({
                        where: { id: existing.id },
                        data: {
                            name: (changes.name?.to as string) ?? existing.name,
                            description: (changes.description?.to as string) ?? existing.description,
                            shortDescription: (changes.shortDescription?.to as string) ?? existing.shortDescription,
                            priceMsrp: changes.priceMsrp ? new Prisma.Decimal(changes.priceMsrp.to as number) : existing.priceMsrp,
                            updatedAt: new Date(),
                        },
                    });

                    await prisma.auditLog.create({
                        data: {
                            productId: existing.id,
                            action: 'UPDATED',
                            entityType: 'product',
                            entityId: existing.id,
                            before: changes as unknown as any,
                            after: Object.fromEntries(
                                Object.entries(changes).map(([k, v]) => [k, v.to])
                            ) as unknown as any,
                            changedBy: 'scraper',
                        },
                    });

                    updated++;
                }
            }
        }

        // Mark products not found in scrape as potentially discontinued
        for (const [slug, existing] of Array.from(existingBySlug.entries())) {
            if (!scrapedSlugs.has(slug) && existing.status === 'ACTIVE') {
                await prisma.product.update({
                    where: { id: existing.id },
                    data: {
                        status: 'DISCONTINUED',
                        discontinuedAt: new Date(),
                    },
                });

                await prisma.auditLog.create({
                    data: {
                        productId: existing.id,
                        action: 'DISCONTINUED',
                        entityType: 'product',
                        entityId: existing.id,
                        before: { status: 'ACTIVE' } as unknown as any,
                        after: { status: 'DISCONTINUED' } as unknown as any,
                        changedBy: 'scraper',
                    },
                });

                removed++;
            }
        }

        console.log(`   ✅ Sync: +${added} added, ~${updated} updated, -${removed} discontinued`);
        return { added, updated, removed };
    }

    /**
     * Parse fuel type from category key or string
     */
    static parseFuelType(input?: string): string | null {
        if (!input) return null;
        const lower = input.toLowerCase();
        if (lower.includes('gas')) return 'Gas';
        if (lower.includes('wood')) return 'Wood';
        if (lower.includes('electric')) return 'Electric';
        if (lower.includes('pellet')) return 'Pellet';
        if (lower.includes('ethanol')) return 'Ethanol';
        return null;
    }
}
