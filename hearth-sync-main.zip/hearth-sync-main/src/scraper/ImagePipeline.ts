/**
 * HearthSync Image Pipeline
 *
 * Downloads product images and uploads them to Supabase Storage.
 * No local filesystem writes — fully compatible with serverless (Vercel).
 */

import axios from 'axios';
import { createServiceClient } from '@/lib/supabase';
import { sleepSeconds } from './helpers';

const VALID_EXTENSIONS = ['jpg', 'jpeg', 'png', 'webp', 'gif', 'svg'];
const STORAGE_BUCKET = 'products';

export class ImagePipeline {
    /**
     * Download all images for a product and upload to Supabase Storage.
     * Returns public URLs for each successfully uploaded image.
     */
    static async uploadProductImages(
        brandSlug: string,
        productSlug: string,
        imageUrls: string[]
    ): Promise<{ urls: string[]; errors: string[] }> {
        const urls: string[] = [];
        const errors: string[] = [];

        if (!imageUrls || imageUrls.length === 0) return { urls, errors };

        const supabase = createServiceClient();

        let index = 0;
        for (const url of imageUrls) {
            if (!url || url === '' || !url.startsWith('http')) {
                continue;
            }

            try {
                const cleanUrl = url.split(',')[0].trim();
                const ext = ImagePipeline.getExtension(cleanUrl);
                const storagePath = `${brandSlug}/${productSlug}/${productSlug}_${index}.${ext}`;

                // Download image into memory buffer
                const buffer = await ImagePipeline.downloadToBuffer(cleanUrl);

                // Upload to Supabase Storage
                const { error: uploadError } = await supabase.storage
                    .from(STORAGE_BUCKET)
                    .upload(storagePath, buffer, {
                        contentType: `image/${ext === 'jpg' ? 'jpeg' : ext}`,
                        upsert: true,
                    });

                if (uploadError) {
                    errors.push(`Upload failed for ${cleanUrl}: ${uploadError.message}`);
                    continue;
                }

                const { data: { publicUrl } } = supabase.storage
                    .from(STORAGE_BUCKET)
                    .getPublicUrl(storagePath);

                urls.push(publicUrl);
                await sleepSeconds(0.5); // Rate limit
                index++;
            } catch (error) {
                const msg = `Failed to process ${url}: ${error instanceof Error ? error.message : error}`;
                errors.push(msg);
                console.error(`   ⚠️ ${msg}`);
            }
        }

        return { urls, errors };
    }

    /**
     * Download an image URL into an in-memory Buffer
     */
    static async downloadToBuffer(url: string): Promise<Buffer> {
        const response = await axios({
            url,
            method: 'GET',
            responseType: 'arraybuffer',
            timeout: 30000,
            headers: {
                'User-Agent':
                    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            },
        });

        return Buffer.from(response.data);
    }

    /**
     * Get file extension from URL
     */
    static getExtension(url: string): string {
        const cleanUrl = url.split('?')[0];
        const originalName = cleanUrl.split('/').pop() || '';
        const ext = originalName.split('.').pop()?.toLowerCase() || '';

        if (VALID_EXTENSIONS.includes(ext)) return ext;

        if (url.includes('.png')) return 'png';
        if (url.includes('.jpeg')) return 'jpeg';
        if (url.includes('.webp')) return 'webp';

        return 'jpg'; // Default
    }

    /**
     * Sanitize a string for use as a storage path segment
     */
    static sanitizeSlug(slug: string): string {
        return slug
            .replace(/[™®]/g, '')
            .replace(/[/\\]/g, '_')
            .replace(/['"]/g, '-')
            .replace(/[()[\]]/g, '')
            .replace(/\s+/g, '')
            .substring(0, 100);
    }
}
