/**
 * HearthSync Scraper Engine — Type Definitions
 * Migrated and expanded from OldWebScraperProject config format
 */

// ---- Brand Scraper Config (matches old JSON format) ----

export interface BrandScraperConfig {
    name: string;
    slug_name: string;
    manufacturer?: string;
    brand_sku: string;
    sku_parse?: string;
    baseUrl?: string;
    baseUrls?: Record<string, string>; // category_key → URL
    productList: ProductListConfig;
    productPage?: ProductPageConfig;
    images?: ImageScraperConfig;
    singleProductUrls?: string[];
}

export interface ProductListConfig {
    wrapper: string; // CSS selector for product cards
    fields: ProductListFields;
}

export interface ProductListFields {
    name?: string; // CSS selector for product name
    thumb?: [string, string]; // [srcType, selector] e.g. ["src", "a img"]
    productUrl?: [string, string]; // [srcType, selector] e.g. ["href", "a"]
    productId?: [string, string, ...string[]]; // [srcType, selector, ...extras]
    description?: string;
    short_description?: string;
    short_tags?: string;
    sku?: string;
    in_stock?: [string, string]; // [boolType, selector]
    dont_gather?: unknown[];
    productDetailsSection?: {
        wrapper: [string, string, string];
        detail: string;
    };
}

export interface ProductPageConfig {
    wrapper: string; // CSS selector for page container
    fields: ProductPageFields;
}

export interface ProductPageFields {
    name?: string;
    secondary_name?: string;
    price?: string;
    sku?: string;
    short_description?: string;
    description?: string;
    text_short_description?: string;
    text_description?: string;
    model_id?: string;
    productId?: [string, string, ...string[]];
    weight?: string;
    weight_kg?: string;
    width_cm?: string;
    height_cm?: string;
    length_cm?: string;
    in_stock?: [string, string];
    images?: [string, string, ...string[]]; // [srcType, selector, ...sanitizations]
    more_images?: [string, string, ...string[]];
    all_description?: [string, ...unknown[]];
    files?: FileConfig;
    file_html?: string;
    gather_element?: string;
    do_not_gather_urls_with?: string;
}

export interface FileConfig {
    type?: string;
    wrapper?: string;
    css?: string;
    name?: string;
    link_attr?: [string, string];
}

export interface ImageScraperConfig {
    base?: string;
    wrapper?: string;
    selector: string;
    location?: string; // "src", "background-image", "href", "data-realsrc"
    page?: string;
    name?: string; // "title", "alt"
    max?: number;
}

// ---- Scraper Job Types ----

export interface ScrapedProduct {
    name: string;
    slug: string;
    productUrl?: string;
    imageUrls: string[];
    description?: string;
    shortDescription?: string;
    sku?: string;
    modelNumber?: string;
    price?: string;
    inStock?: boolean;
    fuelType?: string;
    ventingType?: string;
    btuInput?: number;
    btuOutput?: number;
    specs?: Record<string, string>;
    documents?: Array<{ name: string; url: string }>;
    categoryKey?: string;
    brandSku?: string;
    rawData?: Record<string, unknown>;
}

export interface ScrapeJobResult {
    brandSlug: string;
    productsFound: number;
    productsAdded: number;
    productsUpdated: number;
    productsRemoved: number;
    errors: string[];
    duration: number;
    products: ScrapedProduct[];
}

export interface ScrapeJobOptions {
    jobId: string;
    configId: number;
    targetUrl?: string;
    dryRun?: boolean;
}

// ---- Sanitization ----

export type SanitizationType =
    | 'trim'
    | 'commas'
    | 'leadingSlashes'
    | 'trailingSlashes'
    | 'addLeadingSlash'
    | 'addTrailingSlash'
    | `remove::${string}`
    | `prepend::${string}`;

export type PropertySrcType =
    | 'href'
    | 'src'
    | 'currentSrc'
    | 'innerText'
    | 'innerHtml'
    | 'attr'
    | 'self'
    | 'background-image'
    | 'data-realsrc';
