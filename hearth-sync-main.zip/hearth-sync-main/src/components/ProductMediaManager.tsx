/* eslint-disable @typescript-eslint/no-explicit-any */
"use client";

import { useState } from 'react';
import { useRouter } from 'next/navigation';

export default function ProductMediaManager({ product }: { product: any }) {
    const router = useRouter();
    const [isUploadingImg, setIsUploadingImg] = useState(false);
    const [isUploadingDoc, setIsUploadingDoc] = useState(false);
    const [uploadError, setUploadError] = useState('');

    const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>, isPrimary: boolean = false) => {
        if (!e.target.files || e.target.files.length === 0) return;
        const file = e.target.files[0];

        setIsUploadingImg(true);
        setUploadError('');

        const formData = new FormData();
        formData.append('file', file);
        formData.append('isPrimary', isPrimary.toString());

        try {
            const res = await fetch(`/api/products/${product.id}/images`, {
                method: 'POST',
                body: formData,
            });

            if (!res.ok) {
                const data = await res.json();
                throw new Error(data.error || 'Failed to upload image');
            }

            router.refresh(); // Refresh page to see new images
        } catch (err: any) {
            setUploadError(err.message);
        } finally {
            setIsUploadingImg(false);
            e.target.value = ''; // Reset input
        }
    };

    const handleDeleteImage = async (imageId: string) => {
        if (!confirm('Are you sure you want to delete this image?')) return;

        try {
            const res = await fetch(`/api/products/${product.id}/images?imageId=${imageId}`, {
                method: 'DELETE',
            });
            if (!res.ok) throw new Error('Failed to delete image');
            router.refresh();
        } catch (err: any) {
            alert(err.message);
        }
    };

    const handleDocumentUpload = async (e: React.FormEvent<HTMLFormElement>) => {
        e.preventDefault();
        const form = e.currentTarget;
        const fileInput = form.elements.namedItem('file') as HTMLInputElement;
        const typeInput = form.elements.namedItem('type') as HTMLSelectElement;
        const nameInput = form.elements.namedItem('name') as HTMLInputElement;

        if (!fileInput.files || fileInput.files.length === 0) return;

        setIsUploadingDoc(true);
        setUploadError('');

        const formData = new FormData();
        formData.append('file', fileInput.files[0]);
        formData.append('type', typeInput.value);
        if (nameInput.value) formData.append('name', nameInput.value);

        try {
            const res = await fetch(`/api/products/${product.id}/documents`, {
                method: 'POST',
                body: formData,
            });

            if (!res.ok) {
                const data = await res.json();
                throw new Error(data.error || 'Failed to upload document');
            }

            form.reset();
            router.refresh();
        } catch (err: any) {
            setUploadError(err.message);
        } finally {
            setIsUploadingDoc(false);
        }
    };

    const handleDeleteDocument = async (docId: string) => {
        if (!confirm('Are you sure you want to delete this document?')) return;

        try {
            const res = await fetch(`/api/products/${product.id}/documents?documentId=${docId}`, {
                method: 'DELETE',
            });
            if (!res.ok) throw new Error('Failed to delete document');
            router.refresh();
        } catch (err: any) {
            alert(err.message);
        }
    };

    const primaryImage = product.images?.find((img: any) => img.isPrimary) || product.images?.[0];
    const otherImages = product.images?.filter((img: any) => img.id !== primaryImage?.id) || [];

    return (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '2rem' }}>
            {uploadError && (
                <div style={{ padding: '1rem', background: 'var(--color-error)', color: 'white', borderRadius: 'var(--radius-md)' }}>
                    {uploadError}
                </div>
            )}

            {/* Images Section */}
            <div className="card p-6">
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem', paddingBottom: '0.5rem', borderBottom: '1px solid var(--color-border)' }}>
                    <h3 className="font-semibold text-lg">Product Images</h3>
                    <div style={{ display: 'flex', gap: '0.5rem' }}>
                        <label className={`btn btn-sm btn-secondary ${isUploadingImg ? 'opacity-50' : ''}`} style={{ cursor: 'pointer' }}>
                            {isUploadingImg ? 'Uploading...' : '+ Add Additional Image'}
                            <input type="file" accept="image/*" style={{ display: 'none' }} onChange={(e) => handleImageUpload(e, false)} disabled={isUploadingImg} />
                        </label>
                        <label className={`btn btn-sm btn-primary ${isUploadingImg ? 'opacity-50' : ''}`} style={{ cursor: 'pointer' }}>
                            {isUploadingImg ? 'Uploading...' : 'Upload Primary Image'}
                            <input type="file" accept="image/*" style={{ display: 'none' }} onChange={(e) => handleImageUpload(e, true)} disabled={isUploadingImg} />
                        </label>
                    </div>
                </div>

                <div style={{ display: 'grid', gridTemplateColumns: '1fr 2fr', gap: '1.5rem' }}>
                    <div>
                        <h4 className="text-sm font-semibold mb-2 text-[var(--color-text-secondary)]">Primary Image</h4>
                        {primaryImage ? (
                            <div style={{ position: 'relative', border: '1px solid var(--color-border)', borderRadius: 'var(--radius-md)', padding: '0.5rem', background: 'var(--color-bg-elevated)' }}>
                                <img src={primaryImage.url} alt="Primary" style={{ width: '100%', height: 'auto', borderRadius: 'var(--radius-sm)' }} />
                                <button
                                    onClick={() => handleDeleteImage(primaryImage.id)}
                                    className="btn btn-sm"
                                    style={{ position: 'absolute', top: '0.5rem', right: '0.5rem', background: 'var(--color-error)', color: 'white', border: 'none' }}
                                >✕</button>
                            </div>
                        ) : (
                            <div style={{ padding: '2rem', textAlign: 'center', border: '1px dashed var(--color-border)', borderRadius: 'var(--radius-md)', color: 'var(--color-text-muted)', fontSize: '13px' }}>
                                No primary image set
                            </div>
                        )}
                    </div>

                    <div>
                        <h4 className="text-sm font-semibold mb-2 text-[var(--color-text-secondary)]">Additional Images</h4>
                        {otherImages.length > 0 ? (
                            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(100px, 1fr))', gap: '1rem' }}>
                                {otherImages.map((img: any) => (
                                    <div key={img.id} style={{ position: 'relative', border: '1px solid var(--color-border)', borderRadius: 'var(--radius-md)', padding: '0.25rem', background: 'var(--color-bg-elevated)' }}>
                                        <img src={img.url} alt="Alt" style={{ width: '100%', aspectRatio: '1', objectFit: 'cover', borderRadius: 'var(--radius-sm)' }} />
                                        <button
                                            onClick={() => handleDeleteImage(img.id)}
                                            style={{ position: 'absolute', top: '4px', right: '4px', width: '20px', height: '20px', borderRadius: '50%', background: 'var(--color-error)', color: 'white', border: 'none', cursor: 'pointer', fontSize: '10px', display: 'flex', alignItems: 'center', justifyContent: 'center' }}
                                        >✕</button>
                                    </div>
                                ))}
                            </div>
                        ) : (
                            <div style={{ padding: '2rem', textAlign: 'center', border: '1px dashed var(--color-border)', borderRadius: 'var(--radius-md)', color: 'var(--color-text-muted)', fontSize: '13px' }}>
                                No additional images
                            </div>
                        )}
                    </div>
                </div>
            </div>

            {/* Documents Section */}
            <div className="card p-6">
                <h3 className="font-semibold text-lg mb-4 pb-2 border-b border-[var(--color-border)]">Product Documents</h3>

                <form onSubmit={handleDocumentUpload} style={{ display: 'flex', gap: '1rem', alignItems: 'flex-end', marginBottom: '1.5rem', background: 'var(--color-bg-elevated)', padding: '1rem', borderRadius: 'var(--radius-md)', border: '1px solid var(--color-border)' }}>
                    <div style={{ flex: 1 }}>
                        <label className="block text-xs font-semibold mb-1 text-[var(--color-text-secondary)]">File</label>
                        <input type="file" name="file" required className="form-input" style={{ padding: '0.5rem' }} />
                    </div>
                    <div>
                        <label className="block text-xs font-semibold mb-1 text-[var(--color-text-secondary)]">Document Type</label>
                        <select name="type" className="form-select" style={{ padding: '0.5rem 2rem 0.5rem 0.5rem' }}>
                            <option value="MANUAL">Manual</option>
                            <option value="SPEC_SHEET">Spec Sheet</option>
                            <option value="INSTALLATION_GUIDE">Install Guide</option>
                            <option value="WARRANTY">Warranty</option>
                            <option value="BROCHURE">Brochure</option>
                            <option value="OTHER">Other</option>
                        </select>
                    </div>
                    <div style={{ flex: 1 }}>
                        <label className="block text-xs font-semibold mb-1 text-[var(--color-text-secondary)]">Custom Name (Optional)</label>
                        <input type="text" name="name" placeholder="Leave blank to use filename" className="form-input" style={{ padding: '0.5rem' }} />
                    </div>
                    <button type="submit" className="btn btn-secondary" disabled={isUploadingDoc}>
                        {isUploadingDoc ? 'Uploading...' : 'Upload Document'}
                    </button>
                </form>

                {product.documents && product.documents.length > 0 ? (
                    <table className="data-table">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Type</th>
                                <th style={{ width: '80px', textAlign: 'right' }}>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            {product.documents.map((doc: any) => (
                                <tr key={doc.id}>
                                    <td className="font-medium">
                                        <a href={doc.url} target="_blank" rel="noopener noreferrer">{doc.name}</a>
                                    </td>
                                    <td>
                                        <span className="badge badge-inactive" style={{ fontSize: '10px' }}>{doc.type}</span>
                                    </td>
                                    <td style={{ textAlign: 'right' }}>
                                        <button
                                            onClick={() => handleDeleteDocument(doc.id)}
                                            className="btn btn-sm btn-ghost"
                                            style={{ color: 'var(--color-error)' }}
                                            title="Delete Document"
                                        >✕</button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                ) : (
                    <div style={{ padding: '2rem', textAlign: 'center', color: 'var(--color-text-muted)', fontSize: '13px' }}>
                        No documents have been uploaded for this product yet.
                    </div>
                )}
            </div>
        </div>
    );
}
