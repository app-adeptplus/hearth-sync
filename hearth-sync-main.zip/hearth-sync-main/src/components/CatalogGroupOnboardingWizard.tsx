'use client';

import { useState, useEffect, useCallback } from 'react';
import Modal from '@/components/Modal';

/* ── Types ─────────────────────────────────────────────── */
interface BrandOption {
    id: string;
    name: string;
    slug: string;
    logoUrl: string | null;
    manufacturer: { name: string } | null;
    _count: { products: number };
}

interface ProductOption {
    id: string;
    name: string;
    modelNumber: string | null;
    brand: { name: string };
    images: { url: string; isPrimary: boolean }[];
}

interface Props {
    isOpen: boolean;
    slug: string;       // dealer slug
    groupId: string;
    onComplete: () => void;
}

type Step = 'brands' | 'products';

/* ── Component ──────────────────────────────────────────── */
export default function CatalogGroupOnboardingWizard({ isOpen, slug, groupId, onComplete }: Props) {
    const [step, setStep] = useState<Step>('brands');
    const [dpTheme, setDpTheme] = useState<'light' | 'dark'>('light');

    /* Brand step */
    const [allBrands, setAllBrands] = useState<BrandOption[]>([]);
    const [brandsLoading, setBrandsLoading] = useState(false);
    const [brandSearch, setBrandSearch] = useState('');
    const [selectedBrandIds, setSelectedBrandIds] = useState<Set<string>>(new Set());

    /* Product step */
    const [products, setProducts] = useState<ProductOption[]>([]);
    const [productsLoading, setProductsLoading] = useState(false);
    const [deselectedIds, setDeselectedIds] = useState<Set<string>>(new Set());

    /* Saving */
    const [saving, setSaving] = useState(false);
    const [saveError, setSaveError] = useState('');

    /* Sync the dealer portal theme so the modal inherits the correct dp-* variable set */
    useEffect(() => {
        const stored = localStorage.getItem('dp-theme') as 'light' | 'dark' | null;
        setDpTheme(stored ?? 'light');
        // Also watch for theme changes while the modal is open
        const observer = new MutationObserver(() => {
            const root = document.getElementById('dealer-portal-root');
            const current = root?.getAttribute('data-dp-theme') as 'light' | 'dark' | null;
            if (current) setDpTheme(current);
        });
        const root = document.getElementById('dealer-portal-root');
        if (root) observer.observe(root, { attributes: true, attributeFilter: ['data-dp-theme'] });
        return () => observer.disconnect();
    }, []);

    /* ── Load brands once on open ──────────────────────── */
    useEffect(() => {
        if (!isOpen) return;
        setStep('brands');
        setSelectedBrandIds(new Set());
        setBrandSearch('');
        setDeselectedIds(new Set());
        setSaveError('');

        setBrandsLoading(true);
        fetch('/api/brands?hasProducts=true')
            .then(r => r.json())
            .then(d => setAllBrands(d.data ?? []))
            .catch(() => setAllBrands([]))
            .finally(() => setBrandsLoading(false));
    }, [isOpen]);

    /* ── Load products when entering Step 2 ───────────── */
    const loadProducts = useCallback(async (brandIds: string[]) => {
        if (brandIds.length === 0) return;
        setProductsLoading(true);
        setProducts([]);
        setDeselectedIds(new Set());
        try {
            const params = new URLSearchParams({ status: 'ACTIVE', limit: '500' });
            brandIds.forEach(id => params.append('brand', id));
            const res = await fetch(`/api/products?${params}`);
            const data = await res.json();
            setProducts(data.data ?? []);
        } catch {
            setProducts([]);
        }
        setProductsLoading(false);
    }, []);

    /* ── Handlers ─────────────────────────────────────── */
    const toggleBrand = (id: string) => {
        setSelectedBrandIds(prev => {
            const next = new Set(prev);
            next.has(id) ? next.delete(id) : next.add(id);
            return next;
        });
    };

    const toggleProduct = (id: string) => {
        setDeselectedIds(prev => {
            const next = new Set(prev);
            next.has(id) ? next.delete(id) : next.add(id);
            return next;
        });
    };

    const goToProducts = () => {
        setStep('products');
        loadProducts(Array.from(selectedBrandIds));
    };

    const handleSelectAllProducts = () => setDeselectedIds(new Set());
    const handleDeselectAllProducts = () => setDeselectedIds(new Set(products.map(p => p.id)));

    const handleConfirm = async () => {
        const productIds = products.filter(p => !deselectedIds.has(p.id)).map(p => p.id);
        if (productIds.length === 0) {
            onComplete();
            return;
        }
        setSaving(true);
        setSaveError('');
        try {
            const res = await fetch(`/api/dealer/${slug}/catalog/${groupId}/products`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ productIds }),
            });
            const data = await res.json();
            if (!res.ok) throw new Error(data.error || 'Failed to add products');
            onComplete();
        } catch (err: any) {
            setSaveError(err.message);
        } finally {
            setSaving(false);
        }
    };

    /* ── Derived ───────────────────────────────────────── */
    const filteredBrands = brandSearch.trim()
        ? allBrands.filter(b => b.name.toLowerCase().includes(brandSearch.toLowerCase()))
        : allBrands;

    const selectedCount = products.length - deselectedIds.size;

    /* ── Inline styles via CSS variables only ──────────── */
    // All colours reference --dp-* variables so they automatically adapt to
    // light / dark mode when the wrapper div carries the dealer-portal class.

    /* ── Step indicator ────────────────────────────────── */
    const StepIndicator = () => (
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', fontSize: '0.8125rem', color: 'var(--dp-text-muted)' }}>
            <span style={{
                width: 22, height: 22, borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontSize: '0.75rem', fontWeight: 700, background: 'var(--dp-primary)', color: '#fff'
            }}>1</span>
            <span style={{ fontWeight: step === 'brands' ? 600 : 400, color: step === 'brands' ? 'var(--dp-primary)' : 'var(--dp-text-muted)' }}>
                Select Brands
            </span>
            <svg width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.5"><polyline points="6 4 10 8 6 12" /></svg>
            <span style={{
                width: 22, height: 22, borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontSize: '0.75rem', fontWeight: 700,
                background: step === 'products' ? 'var(--dp-primary)' : 'var(--dp-border)',
                color: step === 'products' ? '#fff' : 'var(--dp-text-muted)',
            }}>2</span>
            <span style={{ fontWeight: step === 'products' ? 600 : 400, color: step === 'products' ? 'var(--dp-primary)' : 'var(--dp-text-muted)' }}>
                Review Products
            </span>
        </div>
    );

    /* ── Footer ───────────────────────────────────────── */
    const footer = step === 'brands' ? (
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', width: '100%' }}>
            <button className="dp-btn dp-btn-ghost" onClick={onComplete}>
                Skip for now
            </button>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                <span style={{ fontSize: '0.8125rem', color: 'var(--dp-text-muted)' }}>
                    {selectedBrandIds.size} brand{selectedBrandIds.size !== 1 ? 's' : ''} selected
                </span>
                <button
                    className="dp-btn dp-btn-primary"
                    onClick={goToProducts}
                    disabled={selectedBrandIds.size === 0}
                >
                    Continue →
                </button>
            </div>
        </div>
    ) : (
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', width: '100%' }}>
            <button className="dp-btn dp-btn-ghost" onClick={() => setStep('brands')}>
                ← Back
            </button>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                {saveError && <span style={{ fontSize: '0.8125rem', color: '#ef4444' }}>✗ {saveError}</span>}
                <span style={{ fontSize: '0.8125rem', color: 'var(--dp-text-muted)' }}>
                    {selectedCount} of {products.length} selected
                </span>
                <button
                    className="dp-btn dp-btn-primary"
                    onClick={handleConfirm}
                    disabled={saving}
                >
                    {saving ? 'Adding…' : `Add ${selectedCount > 0 ? selectedCount : ''} Product${selectedCount !== 1 ? 's' : ''} & Continue →`}
                </button>
            </div>
        </div>
    );

    /* ── Render ───────────────────────────────────────── */
    return (
        // Wrap with dealer-portal so --dp-* variables are in scope inside the portal.
        // The Modal renders via createPortal at document.body (outside dealer-portal-root),
        // so we must re-establish the design-system scope here.
        <div className="dealer-portal" data-dp-theme={dpTheme}>
            <Modal
                isOpen={isOpen}
                onClose={onComplete}
                size="xl"
                title={
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '0.625rem' }}>
                            <span style={{ fontSize: '1.375rem' }}>🎉</span>
                            <span>Welcome! Let&apos;s add products to your new group.</span>
                        </div>
                        <StepIndicator />
                    </div>
                }
                subtitle={
                    step === 'brands'
                        ? 'Select the brands whose products you want to include in this catalog group.'
                        : `Here are all active products from your selected brand${selectedBrandIds.size !== 1 ? 's' : ''}. All are pre-selected — deselect any you'd like to exclude.`
                }
                footer={footer}
            >
                {/* ── STEP 1: BRAND SELECTION ── */}
                {step === 'brands' && (
                    <div style={{ padding: '1.5rem' }}>
                        {/* Search */}
                        <div style={{ position: 'relative', marginBottom: '1.25rem' }}>
                            <svg
                                style={{ position: 'absolute', left: '0.875rem', top: '50%', transform: 'translateY(-50%)', width: 16, height: 16, color: 'var(--dp-text-muted)', pointerEvents: 'none' }}
                                viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.5"
                            >
                                <circle cx="6.5" cy="6.5" r="4.5" /><line x1="10.5" y1="10.5" x2="14" y2="14" />
                            </svg>
                            <input
                                type="text"
                                className="dp-input"
                                style={{ paddingLeft: '2.5rem' }}
                                placeholder="Search brands…"
                                value={brandSearch}
                                onChange={e => setBrandSearch(e.target.value)}
                                autoFocus
                            />
                        </div>

                        {/* Brand grid */}
                        {brandsLoading ? (
                            <div style={{ textAlign: 'center', padding: '3rem', color: 'var(--dp-text-muted)' }}>
                                Loading brands…
                            </div>
                        ) : filteredBrands.length === 0 ? (
                            <div style={{ textAlign: 'center', padding: '2rem', color: 'var(--dp-text-muted)' }}>
                                No brands found
                            </div>
                        ) : (
                            <div style={{
                                display: 'grid',
                                gridTemplateColumns: 'repeat(auto-fill, minmax(190px, 1fr))',
                                gap: '1rem',
                            }}>
                                {filteredBrands.map(brand => {
                                    const isSelected = selectedBrandIds.has(brand.id);
                                    return (
                                        <button
                                            key={brand.id}
                                            onClick={() => toggleBrand(brand.id)}
                                            style={{
                                                display: 'flex',
                                                flexDirection: 'column',
                                                alignItems: 'center',
                                                gap: '0.75rem',
                                                padding: '1.25rem 1rem',
                                                borderRadius: 12,
                                                border: `2px solid ${isSelected ? 'var(--dp-primary)' : 'var(--dp-border)'}`,
                                                background: isSelected
                                                    ? 'var(--dp-primary-subtle)'
                                                    : 'var(--dp-card-bg)',
                                                cursor: 'pointer',
                                                transition: 'all 0.12s',
                                                textAlign: 'center',
                                                position: 'relative',
                                                fontFamily: 'inherit',
                                                boxShadow: isSelected ? '0 0 0 3px rgba(233,69,96,0.15)' : undefined,
                                            }}
                                        >
                                            {/* Selected checkmark */}
                                            {isSelected && (
                                                <span style={{
                                                    position: 'absolute', top: 8, right: 8,
                                                    width: 20, height: 20, borderRadius: '50%',
                                                    background: 'var(--dp-primary)',
                                                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                                                }}>
                                                    <svg width="11" height="11" viewBox="0 0 12 12" fill="none" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                                                        <polyline points="2 6 5 9 10 3" />
                                                    </svg>
                                                </span>
                                            )}

                                            {/* Logo */}
                                            <div style={{ width: '100%', height: 80, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                                                {brand.logoUrl ? (
                                                    <img
                                                        src={brand.logoUrl}
                                                        alt={brand.name}
                                                        style={{ maxWidth: '100%', maxHeight: '100%', objectFit: 'contain' }}
                                                    />
                                                ) : (
                                                    <div style={{
                                                        width: 64, height: 64, borderRadius: 10,
                                                        background: 'var(--dp-surface-raised)',
                                                        display: 'flex', alignItems: 'center', justifyContent: 'center',
                                                        fontSize: '1.5rem', fontWeight: 700,
                                                        color: 'var(--dp-primary)',
                                                    }}>
                                                        {brand.name.charAt(0)}
                                                    </div>
                                                )}
                                            </div>

                                            {/* Name + count */}
                                            <div>
                                                <div style={{
                                                    fontSize: '0.875rem', fontWeight: 600,
                                                    color: isSelected ? 'var(--dp-primary)' : 'var(--dp-text)',
                                                }}>
                                                    {brand.name}
                                                    <span style={{
                                                        fontWeight: 400,
                                                        color: 'var(--dp-text-muted)',
                                                        marginLeft: '0.25rem',
                                                        fontSize: '0.8125rem',
                                                    }}>
                                                        ({brand._count.products})
                                                    </span>
                                                </div>
                                                {brand.manufacturer && (
                                                    <div style={{ fontSize: '0.75rem', color: 'var(--dp-text-muted)', marginTop: '0.125rem' }}>
                                                        {brand.manufacturer.name}
                                                    </div>
                                                )}
                                            </div>
                                        </button>
                                    );
                                })}
                            </div>
                        )}
                    </div>
                )}

                {/* ── STEP 2: PRODUCT REVIEW ── */}
                {step === 'products' && (
                    <div style={{ padding: '1.5rem' }}>
                        {/* Toolbar */}
                        <div style={{
                            display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                            marginBottom: '1rem', padding: '0.75rem 1rem',
                            background: 'var(--dp-surface-raised)',
                            borderRadius: 10, border: '1px solid var(--dp-border)',
                        }}>
                            <span style={{ fontSize: '0.875rem', fontWeight: 600, color: 'var(--dp-text)' }}>
                                {productsLoading ? 'Loading products…' : `${products.length} product${products.length !== 1 ? 's' : ''} found`}
                            </span>
                            {!productsLoading && products.length > 0 && (
                                <div style={{ display: 'flex', gap: '0.5rem' }}>
                                    <button className="dp-btn dp-btn-ghost dp-btn-sm" onClick={handleSelectAllProducts}>
                                        Select All
                                    </button>
                                    <button className="dp-btn dp-btn-ghost dp-btn-sm" onClick={handleDeselectAllProducts}>
                                        Deselect All
                                    </button>
                                </div>
                            )}
                        </div>

                        {/* Product grid */}
                        {productsLoading ? (
                            <div style={{ textAlign: 'center', padding: '3rem', color: 'var(--dp-text-muted)' }}>
                                Loading products…
                            </div>
                        ) : products.length === 0 ? (
                            <div style={{ textAlign: 'center', padding: '2rem', color: 'var(--dp-text-muted)' }}>
                                No active products found for the selected brands.
                            </div>
                        ) : (
                            <div style={{
                                display: 'grid',
                                gridTemplateColumns: 'repeat(auto-fill, minmax(220px, 1fr))',
                                gap: '0.75rem',
                            }}>
                                {products.map(product => {
                                    const isSelected = !deselectedIds.has(product.id);
                                    const thumb = product.images[0]?.url;
                                    return (
                                        <button
                                            key={product.id}
                                            onClick={() => toggleProduct(product.id)}
                                            style={{
                                                display: 'flex',
                                                alignItems: 'center',
                                                gap: '0.75rem',
                                                padding: '0.75rem',
                                                borderRadius: 10,
                                                border: `1.5px solid ${isSelected ? 'var(--dp-primary)' : 'var(--dp-border)'}`,
                                                background: isSelected ? 'var(--dp-primary-subtle)' : 'var(--dp-card-bg)',
                                                cursor: 'pointer',
                                                transition: 'all 0.1s',
                                                textAlign: 'left',
                                                fontFamily: 'inherit',
                                                opacity: isSelected ? 1 : 0.5,
                                            }}
                                        >
                                            {/* Thumbnail */}
                                            {thumb ? (
                                                <img
                                                    src={thumb} alt={product.name}
                                                    style={{ width: 44, height: 44, objectFit: 'cover', borderRadius: 6, flexShrink: 0, background: 'var(--dp-surface-raised)' }}
                                                />
                                            ) : (
                                                <div style={{
                                                    width: 44, height: 44, borderRadius: 6, flexShrink: 0,
                                                    background: 'var(--dp-surface-raised)',
                                                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                                                    fontSize: '1.1rem', color: 'var(--dp-text-muted)',
                                                }}>📦</div>
                                            )}

                                            {/* Info */}
                                            <div style={{ flex: 1, minWidth: 0 }}>
                                                <div style={{
                                                    fontSize: '0.8125rem', fontWeight: 600,
                                                    color: 'var(--dp-text)',
                                                    overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
                                                }}>
                                                    {product.name}
                                                </div>
                                                <div style={{ fontSize: '0.75rem', color: 'var(--dp-text-muted)', marginTop: 2 }}>
                                                    {product.brand.name}{product.modelNumber ? ` · ${product.modelNumber}` : ''}
                                                </div>
                                            </div>

                                            {/* Check indicator */}
                                            <div style={{
                                                width: 18, height: 18, borderRadius: '50%', flexShrink: 0,
                                                background: isSelected ? 'var(--dp-primary)' : 'var(--dp-border)',
                                                display: 'flex', alignItems: 'center', justifyContent: 'center',
                                                transition: 'background 0.1s',
                                            }}>
                                                {isSelected && (
                                                    <svg width="10" height="10" viewBox="0 0 12 12" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                                                        <polyline points="2 6 5 9 10 3" />
                                                    </svg>
                                                )}
                                            </div>
                                        </button>
                                    );
                                })}
                            </div>
                        )}
                    </div>
                )}
            </Modal>
        </div>
    );
}
