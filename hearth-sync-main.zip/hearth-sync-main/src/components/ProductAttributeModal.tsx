"use client";

import { useState, useEffect, useCallback } from 'react';
import Modal from '@/components/Modal';
import SearchableMultiSelect from '@/components/SearchableMultiSelect';

interface AttributeMapping {
    attributeId: string;
    categoryId: string;
    categoryName: string;
    isRequired: boolean;
    isFilterable: boolean;
    defaultValue: string | null;
    sortOrder: number;
    attribute: {
        id: string;
        name: string;
        slug: string;
        description: string | null;
        unit: string | null;
        dataType: string;
        options: string | null;
    };
}

interface Props {
    productId: string;
    /** Trigger text override */
    label?: string;
}

type SaveStatus = 'idle' | 'saving' | 'saved' | 'error';

export default function ProductAttributeModal({ productId, label = 'Edit Attributes →' }: Props) {
    const [isOpen, setIsOpen] = useState(false);
    const [loading, setLoading] = useState(false);
    const [saveStatus, setSaveStatus] = useState<SaveStatus>('idle');
    const [saveError, setSaveError] = useState<string | null>(null);

    const [mappings, setMappings] = useState<AttributeMapping[]>([]);
    const [draftValues, setDraftValues] = useState<Record<string, string>>({});
    const [filledCount, setFilledCount] = useState(0);
    const [totalCount, setTotalCount] = useState(0);

    const fetchData = useCallback(async () => {
        setLoading(true);
        try {
            const res = await fetch(`/api/products/${productId}/attributes`);
            if (!res.ok) throw new Error('Failed to load attributes');
            const data = await res.json();
            setMappings(data.mappings ?? []);
            setDraftValues(data.values ?? {});
            const vals = data.values ?? {};
            const maps = data.mappings ?? [];
            setTotalCount(maps.length);
            setFilledCount(maps.filter((m: AttributeMapping) => {
                const v = vals[m.attributeId];
                return v !== undefined && v !== '' && v !== null;
            }).length);
        } catch (e: any) {
            setSaveError(e.message);
        } finally {
            setLoading(false);
        }
    }, [productId]);

    const openModal = () => {
        setSaveStatus('idle');
        setSaveError(null);
        setIsOpen(true);
        fetchData();
    };

    const closeModal = () => {
        if (saveStatus === 'saving') return;
        setIsOpen(false);
    };

    const setVal = (attributeId: string, value: string) => {
        setDraftValues(prev => ({ ...prev, [attributeId]: value }));
    };

    const handleSave = async () => {
        setSaveStatus('saving');
        setSaveError(null);
        try {
            const res = await fetch(`/api/products/${productId}/attributes`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ values: draftValues }),
            });
            const data = await res.json();
            if (!res.ok) throw new Error(data.error || 'Failed to save');

            // Update filled count with the fresh values returned from API
            const updatedVals = data.values ?? {};
            setFilledCount(mappings.filter(m => {
                const v = updatedVals[m.attributeId];
                return v !== undefined && v !== '' && v !== null;
            }).length);

            setSaveStatus('saved');
            setTimeout(() => {
                setIsOpen(false);
                setSaveStatus('idle');
            }, 900);
        } catch (e: any) {
            setSaveStatus('error');
            setSaveError(e.message);
        }
    };

    // Group mappings by category name
    const grouped = mappings.reduce<Record<string, AttributeMapping[]>>((acc, m) => {
        if (!acc[m.categoryName]) acc[m.categoryName] = [];
        acc[m.categoryName].push(m);
        return acc;
    }, {});

    return (
        <>
            {/* ── Trigger card ──────────────────────────────────────────────── */}
            <div style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                padding: '1rem 1.25rem',
                background: 'var(--color-bg-elevated)',
                border: '1px solid var(--color-border)',
                borderRadius: 'var(--radius-md)',
            }}>
                <div>
                    <div style={{ fontWeight: 600, fontSize: 'var(--font-size-sm)', color: 'var(--color-text-primary)' }}>
                        Product Attributes
                    </div>
                    <div style={{ fontSize: '12px', color: 'var(--color-text-muted)', marginTop: '2px' }}>
                        {totalCount === 0
                            ? 'No attributes available for current categories'
                            : `${filledCount} of ${totalCount} filled`}
                    </div>
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                    {filledCount > 0 && (
                        <span style={{
                            fontSize: '11px',
                            background: 'color-mix(in srgb, var(--color-accent) 12%, transparent)',
                            color: 'var(--color-accent)',
                            border: '1px solid color-mix(in srgb, var(--color-accent) 30%, transparent)',
                            borderRadius: '999px',
                            padding: '2px 8px',
                            fontWeight: 600,
                        }}>
                            {filledCount} filled
                        </span>
                    )}
                    <button
                        type="button"
                        className="btn btn-secondary btn-sm"
                        onClick={openModal}
                    >
                        {label}
                    </button>
                </div>
            </div>

            {/* ── Modal ─────────────────────────────────────────────────────── */}
            <Modal
                isOpen={isOpen}
                onClose={closeModal}
                title="Product Attributes"
                subtitle={totalCount > 0 ? `${totalCount} attribute${totalCount !== 1 ? 's' : ''} across ${Object.keys(grouped).length} categor${Object.keys(grouped).length !== 1 ? 'ies' : 'y'}` : 'No attributes for current categories'}
                size="lg"
                footer={
                    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', width: '100%' }}>
                        {saveStatus === 'saved' && (
                            <span style={{ color: 'var(--color-success)', fontWeight: 600, fontSize: 'var(--font-size-sm)' }}>
                                ✓ Saved
                            </span>
                        )}
                        {saveStatus === 'error' && saveError && (
                            <span style={{ color: 'var(--color-error)', fontSize: 'var(--font-size-sm)' }}>
                                ✕ {saveError}
                            </span>
                        )}
                        {saveStatus !== 'saved' && saveStatus !== 'error' && <span />}
                        <div style={{ display: 'flex', gap: '0.75rem' }}>
                            <button
                                type="button"
                                className="btn btn-secondary"
                                onClick={closeModal}
                                disabled={saveStatus === 'saving'}
                            >
                                Cancel
                            </button>
                            <button
                                type="button"
                                className="btn btn-primary"
                                onClick={handleSave}
                                disabled={saveStatus === 'saving' || loading || totalCount === 0}
                            >
                                {saveStatus === 'saving' ? 'Saving…' : 'Save Attributes'}
                            </button>
                        </div>
                    </div>
                }
            >
                <div style={{ padding: '1.5rem' }}>
                    {/* Loading */}
                    {loading && (
                        <div style={{ textAlign: 'center', padding: '3rem', color: 'var(--color-text-muted)' }}>
                            Loading attributes…
                        </div>
                    )}

                    {/* Empty state */}
                    {!loading && totalCount === 0 && (
                        <div style={{ textAlign: 'center', padding: '3rem 1.5rem', color: 'var(--color-text-muted)', fontSize: 'var(--font-size-sm)' }}>
                            <div style={{ fontSize: '2rem', marginBottom: '0.75rem' }}>📋</div>
                            <p style={{ fontWeight: 600, color: 'var(--color-text-secondary)', marginBottom: '0.5rem' }}>
                                No attributes available
                            </p>
                            <p>Assign categories to this product first, then return here to fill in attribute values.</p>
                        </div>
                    )}

                    {/* Grouped attribute fields */}
                    {!loading && totalCount > 0 && (
                        <div style={{ display: 'flex', flexDirection: 'column', gap: '2rem' }}>
                            {Object.entries(grouped).map(([catName, catMappings]) => (
                                <div key={catName}>
                                    {/* Category section header */}
                                    <div style={{
                                        fontSize: '11px',
                                        fontWeight: 700,
                                        textTransform: 'uppercase',
                                        letterSpacing: '0.07em',
                                        color: 'var(--color-text-muted)',
                                        borderBottom: '1px solid var(--color-border)',
                                        paddingBottom: '0.4rem',
                                        marginBottom: '1rem',
                                    }}>
                                        {catName}
                                    </div>

                                    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(220px, 1fr))', gap: '1.25rem' }}>
                                        {catMappings.map(mapping => {
                                            const attr = mapping.attribute;
                                            const currentValue = draftValues[mapping.attributeId] ?? mapping.defaultValue ?? '';
                                            const options = attr.options
                                                ? attr.options.split(',').map(o => o.trim()).filter(Boolean)
                                                : [];

                                            return (
                                                <div key={mapping.attributeId}>
                                                    <label style={{ display: 'block', marginBottom: '6px' }}>
                                                        <span style={{ fontSize: 'var(--font-size-sm)', fontWeight: 600, color: 'var(--color-text-primary)' }}>
                                                            {attr.name}
                                                        </span>
                                                        {attr.unit && (
                                                            <span style={{ fontSize: '11px', color: 'var(--color-text-muted)', marginLeft: '4px' }}>
                                                                ({attr.unit})
                                                            </span>
                                                        )}
                                                        {mapping.isRequired && (
                                                            <span style={{ color: 'var(--color-error)', marginLeft: '4px' }}>*</span>
                                                        )}
                                                    </label>

                                                    {attr.dataType === 'boolean' ? (
                                                        <label style={{ display: 'flex', alignItems: 'center', gap: '8px', cursor: 'pointer', fontSize: 'var(--font-size-sm)' }}>
                                                            <input
                                                                type="checkbox"
                                                                checked={currentValue === 'true'}
                                                                onChange={e => setVal(mapping.attributeId, e.target.checked ? 'true' : 'false')}
                                                                style={{ width: 16, height: 16 }}
                                                            />
                                                            <span style={{ color: 'var(--color-text-secondary)' }}>
                                                                {currentValue === 'true' ? 'Yes' : 'No'}
                                                            </span>
                                                        </label>
                                                    ) : attr.dataType === 'number' ? (
                                                        <input
                                                            type="number"
                                                            step="any"
                                                            className="form-input"
                                                            style={{ width: '100%' }}
                                                            value={currentValue}
                                                            onChange={e => setVal(mapping.attributeId, e.target.value)}
                                                        />
                                                    ) : attr.dataType === 'range' ? (
                                                        <div style={{ display: 'flex', gap: '0.5rem', alignItems: 'center' }}>
                                                            <input
                                                                type="number"
                                                                step="any"
                                                                className="form-input"
                                                                placeholder="Min"
                                                                style={{ flex: 1 }}
                                                                value={currentValue.split(':')[0] ?? ''}
                                                                onChange={e => {
                                                                    const parts = currentValue.split(':');
                                                                    setVal(mapping.attributeId, `${e.target.value}:${parts[1] ?? ''}`);
                                                                }}
                                                            />
                                                            <span style={{ color: 'var(--color-text-muted)', fontSize: '12px' }}>–</span>
                                                            <input
                                                                type="number"
                                                                step="any"
                                                                className="form-input"
                                                                placeholder="Max"
                                                                style={{ flex: 1 }}
                                                                value={currentValue.split(':')[1] ?? ''}
                                                                onChange={e => {
                                                                    const parts = currentValue.split(':');
                                                                    setVal(mapping.attributeId, `${parts[0] ?? ''}:${e.target.value}`);
                                                                }}
                                                            />
                                                        </div>
                                                    ) : (attr.dataType === 'select' || attr.dataType === 'enum') && options.length > 0 ? (
                                                        <select
                                                            className="form-select"
                                                            style={{ width: '100%' }}
                                                            value={currentValue}
                                                            onChange={e => setVal(mapping.attributeId, e.target.value)}
                                                        >
                                                            <option value="">Select…</option>
                                                            {options.map(opt => (
                                                                <option key={opt} value={opt}>{opt}</option>
                                                            ))}
                                                        </select>
                                                    ) : attr.dataType === 'multi_select' && options.length > 0 ? (
                                                        <SearchableMultiSelect
                                                            options={options.map(o => ({ id: o, name: o }))}
                                                            selected={currentValue ? currentValue.split(',').map(v => v.trim()).filter(Boolean) : []}
                                                            onChange={vals => setVal(mapping.attributeId, vals.join(', '))}
                                                            placeholder={`Select ${attr.name}…`}
                                                        />
                                                    ) : (
                                                        <input
                                                            type="text"
                                                            className="form-input"
                                                            style={{ width: '100%' }}
                                                            value={currentValue}
                                                            onChange={e => setVal(mapping.attributeId, e.target.value)}
                                                            placeholder={attr.description || ''}
                                                        />
                                                    )}

                                                    {attr.description && attr.dataType !== 'boolean' && (
                                                        <p style={{ fontSize: '11px', color: 'var(--color-text-muted)', marginTop: '4px', lineHeight: 1.4 }}>
                                                            {attr.description}
                                                        </p>
                                                    )}
                                                </div>
                                            );
                                        })}
                                    </div>
                                </div>
                            ))}
                        </div>
                    )}
                </div>
            </Modal>
        </>
    );
}
