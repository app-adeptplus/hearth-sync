import React, { useRef, useEffect, useState } from 'react';

interface WysiwygEditorProps {
    value: string;
    onChange: (val: string) => void;
    minHeight?: string;
}

export default function WysiwygEditor({ value, onChange, minHeight = '200px' }: WysiwygEditorProps) {
    const editorRef = useRef<HTMLDivElement>(null);
    const hasInitialized = useRef(false);
    const [isHtmlMode, setIsHtmlMode] = useState(false);

    useEffect(() => {
        if (editorRef.current && !hasInitialized.current) {
            editorRef.current.innerHTML = value;
            hasInitialized.current = true;
        } else if (editorRef.current && document.activeElement !== editorRef.current) {
            // Update if value was changed externally
            if (editorRef.current.innerHTML !== value) {
                editorRef.current.innerHTML = value;
            }
        }
    }, [value]);

    useEffect(() => {
        if (!isHtmlMode && editorRef.current) {
            editorRef.current.innerHTML = value;
        }
    }, [isHtmlMode]);

    const handleInput = () => {
        if (editorRef.current) {
            onChange(editorRef.current.innerHTML);
        }
    };

    const handleHtmlChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
        const newVal = e.target.value;
        onChange(newVal);
        if (editorRef.current) {
            editorRef.current.innerHTML = newVal;
        }
    };

    const execCmd = (cmd: string, val?: string) => {
        document.execCommand(cmd, false, val);
        handleInput();
        if (editorRef.current) {
            editorRef.current.focus();
        }
    };

    return (
        <div style={{ border: '1px solid var(--color-border)', borderRadius: 'var(--radius-md)', overflow: 'hidden', background: 'var(--color-bg)' }}>
            <div style={{ padding: '0.5rem', background: 'var(--color-bg-elevated)', borderBottom: '1px solid var(--color-border)', display: 'flex', gap: '0.5rem', flexWrap: 'wrap', justifyContent: 'space-between', alignItems: 'center' }}>
                <div style={{ display: 'flex', gap: '0.5rem', flexWrap: 'wrap', opacity: isHtmlMode ? 0.5 : 1, pointerEvents: isHtmlMode ? 'none' : 'auto' }}>
                    <button type="button" className="btn btn-ghost btn-sm" onClick={() => execCmd('bold')} title="Bold" style={{ minWidth: '32px' }}><strong>B</strong></button>
                    <button type="button" className="btn btn-ghost btn-sm" onClick={() => execCmd('italic')} title="Italic" style={{ minWidth: '32px' }}><em>I</em></button>
                    <button type="button" className="btn btn-ghost btn-sm" onClick={() => execCmd('underline')} title="Underline" style={{ minWidth: '32px' }}><u>U</u></button>
                    <div style={{ width: '1px', background: 'var(--color-border)', margin: '0 4px' }} />
                    <button type="button" className="btn btn-ghost btn-sm" onClick={() => execCmd('insertUnorderedList')} title="Bullet List">• List</button>
                    <button type="button" className="btn btn-ghost btn-sm" onClick={() => execCmd('insertOrderedList')} title="Numbered List">1. List</button>
                    <div style={{ width: '1px', background: 'var(--color-border)', margin: '0 4px' }} />
                    <button type="button" className="btn btn-ghost btn-sm" onClick={() => execCmd('formatBlock', 'H3')} title="Heading 3">H3</button>
                    <button type="button" className="btn btn-ghost btn-sm" onClick={() => execCmd('formatBlock', 'P')} title="Paragraph">P</button>
                    <button type="button" className="btn btn-ghost btn-sm" onClick={() => execCmd('removeFormat')} title="Clear Format">✕ Clear</button>
                </div>
                <div>
                    <button
                        type="button"
                        className={`btn btn-sm ${isHtmlMode ? 'btn-primary' : 'btn-secondary'}`}
                        onClick={() => setIsHtmlMode(!isHtmlMode)}
                    >
                        {isHtmlMode ? 'View Visual' : 'View HTML'}
                    </button>
                </div>
            </div>
            <div style={{ position: 'relative' }}>
                {isHtmlMode ? (
                    <textarea
                        className="form-input"
                        value={value}
                        onChange={handleHtmlChange}
                        style={{ minHeight, border: 'none', borderRadius: 0, outline: 'none', width: '100%', resize: 'vertical', fontFamily: 'monospace', fontSize: '13px', display: 'block' }}
                    />
                ) : (
                    <div
                        ref={editorRef}
                        className="form-input wysiwyg-content"
                        style={{ minHeight, border: 'none', borderRadius: 0, outline: 'none', overflowY: 'auto' }}
                        contentEditable
                        onInput={handleInput}
                        onBlur={handleInput}
                    />
                )}
            </div>
        </div>
    );
}
