"use client";

import { useState, useRef, useEffect } from 'react';

interface MultiSelectDropdownProps {
    options: { id: string; name: string }[];
    initialSelected: string[];
    name: string;
    placeholder?: string;
}

export default function MultiSelectDropdown({ options, initialSelected, name, placeholder = "Select options..." }: MultiSelectDropdownProps) {
    const [isOpen, setIsOpen] = useState(false);
    const [selected, setSelected] = useState<Set<string>>(new Set(initialSelected));
    const dropdownRef = useRef<HTMLDivElement>(null);

    // Close on click outside
    useEffect(() => {
        function handleClickOutside(event: MouseEvent) {
            if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
                setIsOpen(false);
            }
        }
        document.addEventListener('mousedown', handleClickOutside);
        return () => document.removeEventListener('mousedown', handleClickOutside);
    }, []);

    const toggleSelection = (id: string) => {
        const next = new Set(selected);
        if (next.has(id)) {
            next.delete(id);
        } else {
            next.add(id);
        }
        setSelected(next);
    };

    const selectedArray = Array.from(selected);

    return (
        <div ref={dropdownRef} style={{ position: 'relative', minWidth: '200px' }}>
            {/* Hidden inputs to make HTML forms work natively */}
            {selectedArray.map(id => (
                <input key={id} type="hidden" name={name} value={id} />
            ))}

            <button
                type="button"
                className="form-input"
                style={{
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                    cursor: 'pointer',
                    background: 'var(--color-bg)',
                    whiteSpace: 'nowrap',
                    overflow: 'hidden',
                    textOverflow: 'ellipsis'
                }}
                onClick={() => setIsOpen(!isOpen)}
            >
                <span style={{ overflow: 'hidden', textOverflow: 'ellipsis' }}>
                    {selected.size === 0
                        ? placeholder
                        : selected.size === 1
                            ? options.find(o => o.id === selectedArray[0])?.name || placeholder
                            : `${selected.size} Selected`}
                </span>
                <span style={{ marginLeft: '0.5rem', opacity: 0.5 }}>▼</span>
            </button>

            {isOpen && (
                <div style={{
                    position: 'absolute',
                    top: '100%',
                    left: 0,
                    right: 0,
                    marginTop: '0.25rem',
                    background: 'var(--color-bg-card)',
                    border: '1px solid var(--color-border)',
                    borderRadius: 'var(--radius-md)',
                    boxShadow: 'var(--glass-shadow)',
                    maxHeight: '250px',
                    overflowY: 'auto',
                    zIndex: 200,
                    display: 'flex',
                    flexDirection: 'column',
                    padding: '0.25rem'
                }}>
                    {options.length === 0 ? (
                        <div style={{ padding: '0.5rem', color: 'var(--color-text-muted)', fontSize: 'var(--font-size-sm)', textAlign: 'center' }}>
                            No options available
                        </div>
                    ) : (
                        options.map(option => (
                            <label
                                key={option.id}
                                style={{
                                    display: 'flex',
                                    alignItems: 'center',
                                    padding: '0.5rem',
                                    cursor: 'pointer',
                                    fontSize: 'var(--font-size-sm)',
                                    borderRadius: 'var(--radius-sm)',
                                    transition: 'background var(--transition-fast)'
                                }}
                                onMouseEnter={(e) => e.currentTarget.style.background = 'var(--color-bg-elevated)'}
                                onMouseLeave={(e) => e.currentTarget.style.background = 'transparent'}
                            >
                                <input
                                    type="checkbox"
                                    checked={selected.has(option.id)}
                                    onChange={() => toggleSelection(option.id)}
                                    style={{ marginRight: '0.5rem', cursor: 'pointer' }}
                                />
                                {option.name}
                            </label>
                        ))
                    )}
                </div>
            )}
        </div>
    );
}
