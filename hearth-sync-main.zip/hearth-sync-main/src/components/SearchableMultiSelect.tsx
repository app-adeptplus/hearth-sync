"use client";

import { useState, useRef, useEffect, useCallback } from 'react';

export interface SearchableMultiSelectOption {
    id: string;
    name: string;
}

interface SearchableMultiSelectProps {
    options: SearchableMultiSelectOption[];
    /** IDs of currently selected items */
    selected: string[];
    onChange: (ids: string[]) => void;
    placeholder?: string;
    /** Name used for hidden inputs — enables HTML form compatibility */
    name?: string;
    disabled?: boolean;
    /** Max pills shown before "+N more" */
    maxPillsShown?: number;
}

export default function SearchableMultiSelect({
    options,
    selected,
    onChange,
    placeholder = 'Select...',
    name,
    disabled = false,
    maxPillsShown = 3,
}: SearchableMultiSelectProps) {
    const [isOpen, setIsOpen] = useState(false);
    const [query, setQuery] = useState('');
    const [highlightedIndex, setHighlightedIndex] = useState(0);

    const containerRef = useRef<HTMLDivElement>(null);
    const inputRef = useRef<HTMLInputElement>(null);

    const selectedSet = new Set(selected);

    const filtered = options.filter(o =>
        o.name.toLowerCase().includes(query.toLowerCase())
    );

    // Close on outside click
    useEffect(() => {
        function onMouseDown(e: MouseEvent) {
            if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
                setIsOpen(false);
                setQuery('');
            }
        }
        document.addEventListener('mousedown', onMouseDown);
        return () => document.removeEventListener('mousedown', onMouseDown);
    }, []);

    // Reset highlighted index when filter changes
    useEffect(() => {
        setHighlightedIndex(0);
    }, [query]);

    const toggle = useCallback((id: string) => {
        const next = selectedSet.has(id)
            ? selected.filter(s => s !== id)
            : [...selected, id];
        onChange(next);
    }, [selected, selectedSet, onChange]);

    const removeTag = (id: string, e: React.MouseEvent) => {
        e.stopPropagation();
        onChange(selected.filter(s => s !== id));
    };

    const openDropdown = () => {
        if (!disabled) {
            setIsOpen(true);
            setTimeout(() => inputRef.current?.focus(), 0);
        }
    };

    const handleKeyDown = (e: React.KeyboardEvent) => {
        if (!isOpen) {
            if (e.key === 'Enter' || e.key === ' ' || e.key === 'ArrowDown') {
                e.preventDefault();
                openDropdown();
            }
            return;
        }
        switch (e.key) {
            case 'ArrowDown':
                e.preventDefault();
                setHighlightedIndex(i => Math.min(i + 1, filtered.length - 1));
                break;
            case 'ArrowUp':
                e.preventDefault();
                setHighlightedIndex(i => Math.max(i - 1, 0));
                break;
            case 'Enter':
                e.preventDefault();
                if (filtered[highlightedIndex]) toggle(filtered[highlightedIndex].id);
                break;
            case 'Escape':
                setIsOpen(false);
                setQuery('');
                break;
        }
    };

    const visibleTags = selected.slice(0, maxPillsShown);
    const extraCount = selected.length - maxPillsShown;

    const getOptionName = (id: string) => options.find(o => o.id === id)?.name ?? id;

    return (
        <div
            ref={containerRef}
            style={{ position: 'relative' }}
            onKeyDown={handleKeyDown}
        >
            {/* Hidden inputs for HTML form compat */}
            {name && selected.map(id => (
                <input key={id} type="hidden" name={name} value={id} />
            ))}

            {/* Trigger / pill bar */}
            <div
                onClick={openDropdown}
                style={{
                    display: 'flex',
                    flexWrap: 'wrap',
                    alignItems: 'center',
                    gap: '6px',
                    minHeight: '38px',
                    padding: '5px 10px',
                    background: disabled ? 'var(--color-bg-elevated)' : 'var(--color-bg)',
                    border: `1px solid ${isOpen ? 'var(--color-primary)' : 'var(--color-border)'}`,
                    borderRadius: 'var(--radius-md)',
                    cursor: disabled ? 'not-allowed' : 'pointer',
                    transition: 'border-color var(--transition-fast)',
                    boxShadow: isOpen ? '0 0 0 2px color-mix(in srgb, var(--color-primary) 20%, transparent)' : 'none',
                    opacity: disabled ? 0.6 : 1,
                }}
            >
                {selected.length === 0 ? (
                    <span style={{ color: 'var(--color-text-muted)', fontSize: 'var(--font-size-sm)', userSelect: 'none' }}>
                        {placeholder}
                    </span>
                ) : (
                    <>
                        {visibleTags.map(id => (
                            <span
                                key={id}
                                style={{
                                    display: 'inline-flex',
                                    alignItems: 'center',
                                    gap: '4px',
                                    background: 'var(--color-bg-elevated)',
                                    border: '1px solid var(--color-border)',
                                    borderRadius: '999px',
                                    padding: '2px 8px 2px 10px',
                                    fontSize: '12px',
                                    fontWeight: 500,
                                    color: 'var(--color-text-primary)',
                                    maxWidth: '180px',
                                    whiteSpace: 'nowrap',
                                    overflow: 'hidden',
                                    textOverflow: 'ellipsis',
                                }}
                            >
                                <span style={{ overflow: 'hidden', textOverflow: 'ellipsis' }}>
                                    {getOptionName(id)}
                                </span>
                                {!disabled && (
                                    <button
                                        type="button"
                                        onClick={(e) => removeTag(id, e)}
                                        style={{
                                            background: 'none',
                                            border: 'none',
                                            cursor: 'pointer',
                                            padding: '0',
                                            lineHeight: 1,
                                            color: 'var(--color-text-muted)',
                                            fontSize: '14px',
                                            flexShrink: 0,
                                        }}
                                        aria-label={`Remove ${getOptionName(id)}`}
                                    >
                                        ×
                                    </button>
                                )}
                            </span>
                        ))}
                        {extraCount > 0 && (
                            <span style={{
                                fontSize: '12px',
                                color: 'var(--color-text-muted)',
                                background: 'var(--color-bg-elevated)',
                                border: '1px solid var(--color-border)',
                                borderRadius: '999px',
                                padding: '2px 8px',
                            }}>
                                +{extraCount} more
                            </span>
                        )}
                    </>
                )}

                <span style={{ marginLeft: 'auto', color: 'var(--color-text-muted)', fontSize: '10px', flexShrink: 0 }}>
                    {isOpen ? '▲' : '▼'}
                </span>
            </div>

            {/* Dropdown */}
            {isOpen && (
                <div
                    style={{
                        position: 'absolute',
                        top: 'calc(100% + 4px)',
                        left: 0,
                        right: 0,
                        zIndex: 300,
                        background: 'var(--color-bg-card)',
                        border: '1px solid var(--color-border)',
                        borderRadius: 'var(--radius-md)',
                        boxShadow: 'var(--glass-shadow)',
                        display: 'flex',
                        flexDirection: 'column',
                        overflow: 'hidden',
                        minWidth: '220px',
                    }}
                >
                    {/* Search input */}
                    <div style={{ padding: '8px', borderBottom: '1px solid var(--color-border)' }}>
                        <input
                            ref={inputRef}
                            type="text"
                            value={query}
                            onChange={e => setQuery(e.target.value)}
                            placeholder="Search..."
                            style={{
                                width: '100%',
                                padding: '6px 10px',
                                fontSize: 'var(--font-size-sm)',
                                background: 'var(--color-bg)',
                                border: '1px solid var(--color-border)',
                                borderRadius: 'var(--radius-sm)',
                                color: 'var(--color-text-primary)',
                                outline: 'none',
                            }}
                            onClick={e => e.stopPropagation()}
                        />
                    </div>

                    {/* Options list */}
                    <div style={{ maxHeight: '240px', overflowY: 'auto' }}>
                        {filtered.length === 0 ? (
                            <div style={{ padding: '12px', textAlign: 'center', fontSize: 'var(--font-size-sm)', color: 'var(--color-text-muted)' }}>
                                No results
                            </div>
                        ) : (
                            filtered.map((opt, idx) => {
                                const isSelected = selectedSet.has(opt.id);
                                const isHighlighted = idx === highlightedIndex;
                                return (
                                    <div
                                        key={opt.id}
                                        onClick={() => toggle(opt.id)}
                                        onMouseEnter={() => setHighlightedIndex(idx)}
                                        style={{
                                            display: 'flex',
                                            alignItems: 'center',
                                            gap: '10px',
                                            padding: '8px 12px',
                                            cursor: 'pointer',
                                            fontSize: 'var(--font-size-sm)',
                                            background: isHighlighted
                                                ? 'var(--color-bg-elevated)'
                                                : 'transparent',
                                            color: 'var(--color-text-primary)',
                                            transition: 'background var(--transition-fast)',
                                        }}
                                    >
                                        {/* Custom checkbox */}
                                        <div style={{
                                            width: 16,
                                            height: 16,
                                            flexShrink: 0,
                                            borderRadius: '4px',
                                            border: `2px solid ${isSelected ? 'var(--color-primary)' : 'var(--color-border)'}`,
                                            background: isSelected ? 'var(--color-primary)' : 'transparent',
                                            display: 'flex',
                                            alignItems: 'center',
                                            justifyContent: 'center',
                                            transition: 'all var(--transition-fast)',
                                        }}>
                                            {isSelected && (
                                                <svg width="10" height="8" viewBox="0 0 10 8" fill="none">
                                                    <path d="M1 4L3.5 6.5L9 1" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
                                                </svg>
                                            )}
                                        </div>
                                        <span style={{ fontWeight: isSelected ? 600 : 400 }}>{opt.name}</span>
                                    </div>
                                );
                            })
                        )}
                    </div>

                    {/* Footer: selection count + clear */}
                    {selected.length > 0 && (
                        <div style={{
                            display: 'flex',
                            justifyContent: 'space-between',
                            alignItems: 'center',
                            padding: '6px 12px',
                            borderTop: '1px solid var(--color-border)',
                            fontSize: '12px',
                            color: 'var(--color-text-muted)',
                        }}>
                            <span>{selected.length} selected</span>
                            <button
                                type="button"
                                onClick={(e) => { e.stopPropagation(); onChange([]); }}
                                style={{
                                    background: 'none',
                                    border: 'none',
                                    cursor: 'pointer',
                                    fontSize: '12px',
                                    color: 'var(--color-text-muted)',
                                    padding: '2px 4px',
                                    borderRadius: '4px',
                                }}
                                onMouseEnter={e => (e.currentTarget.style.color = 'var(--color-danger)')}
                                onMouseLeave={e => (e.currentTarget.style.color = 'var(--color-text-muted)')}
                            >
                                Clear all
                            </button>
                        </div>
                    )}
                </div>
            )}
        </div>
    );
}
