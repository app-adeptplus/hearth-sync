'use client';

import React, { useEffect, useState } from 'react';
import { createPortal } from 'react-dom';

export type ModalSize = 'sm' | 'md' | 'lg' | 'xl' | 'full' | 'excel';

export interface ModalProps {
    isOpen: boolean;
    onClose: () => void;
    title?: React.ReactNode;
    subtitle?: React.ReactNode;
    children: React.ReactNode;
    footer?: React.ReactNode;
    size?: ModalSize;
    hideCloseButton?: boolean;
}

export default function Modal({
    isOpen,
    onClose,
    title,
    subtitle,
    children,
    footer,
    size = 'md',
    hideCloseButton = false,
}: ModalProps) {
    const [mounted, setMounted] = useState(false);

    useEffect(() => {
        setMounted(true);
    }, []);

    // Handle Escape key
    useEffect(() => {
        const handleKeyDown = (e: KeyboardEvent) => {
            if (e.key === 'Escape' && isOpen) {
                onClose();
            }
        };
        document.addEventListener('keydown', handleKeyDown);
        return () => document.removeEventListener('keydown', handleKeyDown);
    }, [isOpen, onClose]);

    // Prevent background scrolling when open
    useEffect(() => {
        if (isOpen) {
            document.body.style.overflow = 'hidden';
        } else {
            document.body.style.overflow = 'unset';
        }
        return () => {
            document.body.style.overflow = 'unset';
        };
    }, [isOpen]);

    if (!mounted || !isOpen) return null;

    const getWidth = () => {
        switch (size) {
            case 'sm': return '400px';
            case 'md': return '600px';
            case 'lg': return '800px';
            case 'xl': return '1100px';
            case 'full': return '95vw';
            case 'excel': return '98vw';
            default: return '600px';
        }
    };

    const isFullscreen = size === 'full' || size === 'excel';

    const modalContent = (
        <div style={{
            position: 'fixed',
            top: 0, left: 0, right: 0, bottom: 0,
            zIndex: 9999,
            backgroundColor: 'rgba(0, 0, 0, 0.65)',
            backdropFilter: 'blur(4px)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            padding: isFullscreen ? '1rem' : '2rem'
        }}>

            <div className="card" style={{
                width: '100%',
                maxWidth: getWidth(),
                maxHeight: isFullscreen ? '95vh' : '90vh',
                height: isFullscreen ? '95vh' : 'auto',
                display: 'flex',
                flexDirection: 'column',
                backgroundColor: 'var(--color-bg)',
                padding: 0,
                overflow: 'hidden',
                borderRadius: isFullscreen ? '8px' : '12px',
                boxShadow: '0 25px 50px -12px rgba(0,0,0,0.4)',
                border: '1px solid var(--color-border)'
            }}>

                {/* Header */}
                {(title || subtitle || !hideCloseButton) && (
                    <div style={{
                        flex: 'none',
                        padding: '1.25rem 1.5rem',
                        borderBottom: '1px solid var(--color-border)',
                        backgroundColor: 'var(--color-bg-elevated)',
                        display: 'flex',
                        alignItems: 'flex-start',
                        justifyContent: 'space-between'
                    }}>
                        <div>
                            {title && <h2 style={{ fontSize: '1.25rem', fontWeight: 700, margin: 0, color: 'var(--color-text-primary)' }}>{title}</h2>}
                            {subtitle && <p style={{ fontSize: '0.875rem', marginTop: '0.25rem', marginBottom: 0, color: 'var(--color-text-muted)', fontWeight: 500 }}>{subtitle}</p>}
                        </div>

                        {!hideCloseButton && (
                            <button
                                onClick={onClose}
                                style={{
                                    background: 'transparent',
                                    border: 'none',
                                    cursor: 'pointer',
                                    color: 'var(--color-text-muted)',
                                    padding: '0.5rem',
                                    marginLeft: '1rem',
                                    display: 'flex',
                                    alignItems: 'center',
                                    justifyContent: 'center',
                                    borderRadius: '4px'
                                }}
                                onMouseOver={(e) => e.currentTarget.style.color = 'var(--color-text-primary)'}
                                onMouseOut={(e) => e.currentTarget.style.color = 'var(--color-text-muted)'}
                                aria-label="Close modal"
                            >
                                <svg xmlns="http://www.w3.org/2007/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
                            </button>
                        )}
                    </div>
                )}

                {/* Body */}
                <div style={{
                    flex: '1 1 auto',
                    overflow: 'auto',
                    padding: 0, // Child handles its own padding ideally
                    backgroundColor: 'var(--color-bg)'
                }}>
                    {children}
                </div>

                {/* Footer */}
                {footer && (
                    <div style={{
                        flex: 'none',
                        padding: '1rem 1.5rem',
                        borderTop: '1px solid var(--color-border)',
                        backgroundColor: 'var(--color-bg-elevated)',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'flex-end',
                        gap: '0.75rem'
                    }}>
                        {footer}
                    </div>
                )}
            </div>
        </div>
    );

    return createPortal(modalContent, document.body);
}
