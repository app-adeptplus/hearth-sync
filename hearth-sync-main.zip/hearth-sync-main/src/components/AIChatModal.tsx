'use client';

import { useState, useRef, useEffect, useCallback } from 'react';
import Modal from '@/components/Modal';

// ─── Types ─────────────────────────────────────────────────────────────────

type BuiltInPersona = 'categorization' | 'spec_extractor' | 'scraper_setup';

interface Agent {
    id: string;           // assignmentId or built-in persona key
    label: string;
    description: string;
    icon: string;
    isBuiltIn: boolean;
    serviceId?: string | null;
}

interface Message {
    id: string;
    role: 'user' | 'assistant' | 'system';
    content: string;
    actionPending?: boolean;
    provider?: string;
    model?: string;
    tokensUsed?: number;
}

// ─── Built-in fallback agents ──────────────────────────────────────────────

const BUILT_IN_AGENTS: Agent[] = [
    {
        id: 'categorization',
        label: 'Categorization Bot',
        description: 'Assigns products to the correct Hearth taxonomy category.',
        icon: '📁',
        isBuiltIn: true,
        serviceId: 'categorization',
    },
    {
        id: 'spec_extractor',
        label: 'Spec Extractor',
        description: 'Pulls structured specs from HTML, PDFs, or raw copy.',
        icon: '📋',
        isBuiltIn: true,
        serviceId: 'spec_extractor',
    },
    {
        id: 'scraper_setup',
        label: 'Scraper Assistant',
        description: 'Generates CSS selectors and scraper config rules.',
        icon: '🤖',
        isBuiltIn: true,
        serviceId: 'scraper_setup',
    },
];

const AGENT_INTRO: Record<string, string> = {
    categorization: 'Hello! I\'m the **Categorization Bot**. Paste a product name or description and I\'ll help assign it to the right Hearth category.',
    spec_extractor: 'Hi there! I\'m the **Spec Extractor**. Give me HTML, PDF text, or product copy and I\'ll pull out clean key-value specs.',
    scraper_setup: 'Hey! I\'m your **Scraper Assistant**. Share a site URL or HTML sample and I\'ll help write CSS selectors and scraper config.',
};

// ─── Simple markdown renderer ──────────────────────────────────────────────

function renderMarkdown(text: string): string {
    return text
        // code blocks
        .replace(/```([\s\S]*?)```/g, '<pre style="background:rgba(0,0,0,0.3);padding:0.75rem;border-radius:6px;overflow-x:auto;margin:0.5rem 0;font-size:0.8125rem;line-height:1.5;"><code>$1</code></pre>')
        // inline code
        .replace(/`([^`]+)`/g, '<code style="background:rgba(0,0,0,0.3);padding:1px 5px;border-radius:4px;font-size:0.875em;">$1</code>')
        // bold
        .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
        // italic
        .replace(/\*(.+?)\*/g, '<em>$1</em>')
        // newlines
        .replace(/\n/g, '<br/>');
}

// ─── Component ─────────────────────────────────────────────────────────────

interface AIChatModalProps {
    isOpen: boolean;
    onClose: () => void;
}

export default function AIChatModal({ isOpen, onClose }: AIChatModalProps) {
    const [agents, setAgents] = useState<Agent[]>(BUILT_IN_AGENTS);
    const [activeAgent, setActiveAgent] = useState<Agent>(BUILT_IN_AGENTS[0]);
    const [messages, setMessages] = useState<Message[]>([]);
    const [input, setInput] = useState('');
    const [isTyping, setIsTyping] = useState(false);
    const [lastMeta, setLastMeta] = useState<{ provider?: string; model?: string; tokens?: number } | null>(null);

    const messagesEndRef = useRef<HTMLDivElement>(null);
    const textareaRef = useRef<HTMLTextAreaElement>(null);

    // ── Load assignments on mount
    useEffect(() => {
        async function loadAgents() {
            try {
                const res = await fetch('/api/assignments?serviceType=CHAT_BOT');
                if (!res.ok) return;
                const data = await res.json();
                const list: Agent[] = Array.isArray(data) ? data.map((a: any) => ({
                    id: a.id,
                    label: a.label,
                    description: a.notes ?? `${a.serviceType} agent — ${a.llmConfig?.displayName ?? a.llmConfig?.provider ?? 'LLM'}`,
                    icon: '🤖',
                    isBuiltIn: false,
                    serviceId: a.serviceId,
                })) : [];
                setAgents(list.length > 0 ? list : BUILT_IN_AGENTS);
            } catch {
                setAgents(BUILT_IN_AGENTS);
            }
        }
        loadAgents();
    }, []);

    // ── Reset chat when agent changes
    const switchAgent = useCallback((agent: Agent) => {
        setActiveAgent(agent);
        const intro = agent.isBuiltIn
            ? AGENT_INTRO[agent.id] ?? `Hello! I'm **${agent.label}**. How can I help?`
            : `Hello! I'm **${agent.label}**. ${agent.description}`;
        setMessages([{ id: 'intro', role: 'system', content: intro }]);
        setInput('');
        setLastMeta(null);
    }, []);

    // ── Init messages when modal opens
    useEffect(() => {
        if (isOpen && messages.length === 0) {
            switchAgent(agents[0] ?? BUILT_IN_AGENTS[0]);
        }
    }, [isOpen, agents, messages.length, switchAgent]);

    // ── Auto-scroll to bottom
    useEffect(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, [messages, isTyping]);

    // ── Auto-resize textarea
    useEffect(() => {
        if (textareaRef.current) {
            textareaRef.current.style.height = 'auto';
            textareaRef.current.style.height = Math.min(textareaRef.current.scrollHeight, 120) + 'px';
        }
    }, [input]);

    // ── Send message
    const handleSend = async () => {
        if (!input.trim() || isTyping) return;

        const userMsg: Message = { id: Date.now().toString(), role: 'user', content: input.trim() };
        setMessages(prev => [...prev, userMsg]);
        setInput('');
        setIsTyping(true);

        try {
            const res = await fetch('/api/chat', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    message: input.trim(),
                    persona: activeAgent.isBuiltIn ? activeAgent.id : undefined,
                    assignmentId: activeAgent.isBuiltIn ? undefined : activeAgent.id,
                    history: messages
                        .filter(m => m.role !== 'system')
                        .slice(-8)
                        .map(m => ({ role: m.role, content: m.content })),
                }),
            });

            const data = await res.json();

            setMessages(prev => [...prev, {
                id: (Date.now() + 1).toString(),
                role: 'assistant',
                content: data.error ? `⚠️ Error: ${data.error}` : data.content,
                actionPending: data.actionPending ?? false,
                provider: data.provider,
                model: data.model,
                tokensUsed: data.tokensUsed,
            }]);

            if (data.provider || data.model) {
                setLastMeta({ provider: data.provider, model: data.model, tokens: data.tokensUsed });
            }
        } catch (err: any) {
            setMessages(prev => [...prev, {
                id: (Date.now() + 1).toString(),
                role: 'assistant',
                content: `⚠️ Failed to reach AI: ${err.message}`,
            }]);
        } finally {
            setIsTyping(false);
            setTimeout(() => textareaRef.current?.focus(), 50);
        }
    };

    const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            handleSend();
        }
    };

    // ─── Render ──────────────────────────────────────────────────────────────

    return (
        <Modal
            isOpen={isOpen}
            onClose={onClose}
            title={
                <span style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                    <span style={{
                        background: 'linear-gradient(135deg, #e94560, #f4a261)',
                        WebkitBackgroundClip: 'text',
                        WebkitTextFillColor: 'transparent',
                        backgroundClip: 'text',
                    }}>
                        HearthSync AI
                    </span>
                    <span style={{
                        fontSize: '0.6rem',
                        fontWeight: 600,
                        padding: '2px 6px',
                        borderRadius: '999px',
                        background: 'rgba(233,69,96,0.12)',
                        border: '1px solid rgba(233,69,96,0.25)',
                        color: '#e94560',
                        letterSpacing: '0.08em',
                        textTransform: 'uppercase',
                        WebkitTextFillColor: 'initial',
                    }}>
                        Beta
                    </span>
                </span>
            }
            subtitle="Your integrated AI workspace — manage agents, data, and catalog operations."
            size="xl"
        >
            {/* ── Two-column layout ─────────────────────────────────────── */}
            <div style={{ display: 'flex', height: '65vh', overflow: 'hidden' }}>

                {/* ── Agent Sidebar ──────────────────────────────────────── */}
                <div style={{
                    width: '220px',
                    minWidth: '220px',
                    borderRight: '1px solid var(--color-border)',
                    background: 'var(--color-bg-elevated)',
                    display: 'flex',
                    flexDirection: 'column',
                    overflow: 'hidden',
                }}>
                    <div style={{
                        padding: '0.875rem 1rem 0.5rem',
                        borderBottom: '1px solid var(--color-border)',
                    }}>
                        <span style={{
                            fontSize: '0.6875rem',
                            fontWeight: 700,
                            color: 'var(--color-text-muted)',
                            textTransform: 'uppercase',
                            letterSpacing: '0.08em',
                        }}>
                            Agents
                        </span>
                    </div>

                    <div style={{ flex: 1, overflowY: 'auto', padding: '0.5rem' }}>
                        {agents.map(agent => {
                            const isActive = agent.id === activeAgent.id;
                            return (
                                <button
                                    key={agent.id}
                                    onClick={() => switchAgent(agent)}
                                    style={{
                                        width: '100%',
                                        textAlign: 'left',
                                        padding: '0.625rem 0.75rem',
                                        borderRadius: '8px',
                                        border: isActive
                                            ? '1px solid rgba(233,69,96,0.3)'
                                            : '1px solid transparent',
                                        background: isActive
                                            ? 'linear-gradient(135deg, rgba(233,69,96,0.12), rgba(244,162,97,0.08))'
                                            : 'transparent',
                                        cursor: 'pointer',
                                        marginBottom: '0.25rem',
                                        transition: 'all 0.15s ease',
                                        display: 'flex',
                                        flexDirection: 'column',
                                        gap: '0.125rem',
                                    }}
                                    onMouseEnter={e => {
                                        if (!isActive) {
                                            (e.currentTarget as HTMLElement).style.background = 'var(--color-bg-card)';
                                        }
                                    }}
                                    onMouseLeave={e => {
                                        if (!isActive) {
                                            (e.currentTarget as HTMLElement).style.background = 'transparent';
                                        }
                                    }}
                                >
                                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
                                        <span style={{ fontSize: '0.875rem' }}>{agent.icon}</span>
                                        <span style={{
                                            fontSize: '0.8125rem',
                                            fontWeight: 600,
                                            color: isActive ? 'var(--color-accent)' : 'var(--color-text-primary)',
                                            lineHeight: 1.3,
                                        }}>
                                            {agent.label}
                                        </span>
                                    </div>
                                    <span style={{
                                        fontSize: '0.6875rem',
                                        color: 'var(--color-text-muted)',
                                        lineHeight: 1.4,
                                        paddingLeft: '1.35rem',
                                    }}>
                                        {agent.description.length > 55
                                            ? agent.description.slice(0, 55) + '…'
                                            : agent.description}
                                    </span>
                                </button>
                            );
                        })}
                    </div>

                    {/* Footer hint */}
                    <div style={{
                        padding: '0.75rem 1rem',
                        borderTop: '1px solid var(--color-border)',
                        fontSize: '0.6875rem',
                        color: 'var(--color-text-muted)',
                        lineHeight: 1.4,
                    }}>
                        Agents are configured in{' '}
                        <a href="/admin/models" style={{ color: 'var(--color-accent)', textDecoration: 'none' }}>
                            System Services
                        </a>
                        {' → '}Assignments.
                    </div>
                </div>

                {/* ── Chat Column ────────────────────────────────────────── */}
                <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden', background: 'var(--color-bg)' }}>

                    {/* Active agent header */}
                    <div style={{
                        padding: '0.75rem 1.25rem',
                        borderBottom: '1px solid var(--color-border)',
                        background: 'var(--color-bg-elevated)',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '0.625rem',
                    }}>
                        <span style={{ fontSize: '1rem' }}>{activeAgent.icon}</span>
                        <div>
                            <div style={{ fontSize: '0.875rem', fontWeight: 600, color: 'var(--color-text-primary)' }}>
                                {activeAgent.label}
                            </div>
                            <div style={{ fontSize: '0.6875rem', color: 'var(--color-text-muted)' }}>
                                {activeAgent.description}
                            </div>
                        </div>
                        {lastMeta && (
                            <div style={{
                                marginLeft: 'auto',
                                fontSize: '0.6875rem',
                                color: 'var(--color-text-muted)',
                                display: 'flex',
                                alignItems: 'center',
                                gap: '0.5rem',
                            }}>
                                <span style={{
                                    padding: '2px 7px',
                                    borderRadius: '999px',
                                    background: 'var(--color-bg-card)',
                                    border: '1px solid var(--color-border)',
                                }}>
                                    {lastMeta.provider} · {lastMeta.model}
                                </span>
                                {lastMeta.tokens != null && (
                                    <span style={{ color: 'var(--color-text-muted)' }}>
                                        {lastMeta.tokens.toLocaleString()} tokens
                                    </span>
                                )}
                            </div>
                        )}
                    </div>

                    {/* Messages */}
                    <div style={{
                        flex: 1,
                        overflowY: 'auto',
                        padding: '1.25rem',
                        display: 'flex',
                        flexDirection: 'column',
                        gap: '1rem',
                    }}>
                        {messages.map((msg) => (
                            <div
                                key={msg.id}
                                style={{
                                    display: 'flex',
                                    flexDirection: 'column',
                                    alignItems: msg.role === 'user' ? 'flex-end' : 'flex-start',
                                    gap: '0.25rem',
                                }}
                            >
                                <span style={{
                                    fontSize: '0.6875rem',
                                    color: 'var(--color-text-muted)',
                                    textTransform: 'uppercase',
                                    letterSpacing: '0.06em',
                                    fontWeight: 600,
                                }}>
                                    {msg.role === 'system' ? '🤖 System' : msg.role === 'user' ? 'You' : `✦ ${activeAgent.label}`}
                                </span>

                                <div style={{
                                    maxWidth: '82%',
                                    padding: '0.75rem 1rem',
                                    borderRadius: msg.role === 'user' ? '14px 14px 4px 14px' : '4px 14px 14px 14px',
                                    background: msg.role === 'user'
                                        ? 'linear-gradient(135deg, #e94560, #c73e56)'
                                        : msg.role === 'system'
                                            ? 'var(--color-bg-elevated)'
                                            : 'var(--color-bg-card)',
                                    color: msg.role === 'user' ? '#fff' : 'var(--color-text-primary)',
                                    border: msg.role !== 'user'
                                        ? '1px solid var(--color-border)'
                                        : 'none',
                                    boxShadow: msg.role === 'user'
                                        ? '0 2px 8px rgba(233,69,96,0.2)'
                                        : '0 1px 4px rgba(0,0,0,0.15)',
                                    fontSize: '0.875rem',
                                    lineHeight: 1.6,
                                }}>
                                    <div
                                        dangerouslySetInnerHTML={{ __html: renderMarkdown(msg.content) }}
                                    />

                                    {/* ACTION PENDING buttons */}
                                    {msg.actionPending && (
                                        <div style={{
                                            marginTop: '0.875rem',
                                            paddingTop: '0.75rem',
                                            borderTop: '1px solid var(--color-border)',
                                            display: 'flex',
                                            gap: '0.5rem',
                                            alignItems: 'center',
                                        }}>
                                            <span style={{
                                                fontSize: '0.6875rem',
                                                color: 'var(--color-warning)',
                                                fontWeight: 600,
                                                marginRight: '0.25rem',
                                            }}>
                                                ⚡ Action Pending
                                            </span>
                                            <button
                                                className="btn btn-sm btn-primary"
                                                onClick={() => alert('Action approved. Connect your action handler to process this.')}
                                            >
                                                Approve
                                            </button>
                                            <button
                                                className="btn btn-sm btn-ghost"
                                                onClick={() => {
                                                    setMessages(prev => prev.map(m =>
                                                        m.id === msg.id ? { ...m, actionPending: false } : m
                                                    ));
                                                }}
                                            >
                                                Discard
                                            </button>
                                        </div>
                                    )}
                                </div>
                            </div>
                        ))}

                        {/* Typing indicator */}
                        {isTyping && (
                            <div style={{
                                alignSelf: 'flex-start',
                                display: 'flex',
                                alignItems: 'center',
                                gap: '0.5rem',
                                padding: '0.625rem 1rem',
                                borderRadius: '4px 14px 14px 14px',
                                background: 'var(--color-bg-card)',
                                border: '1px solid var(--color-border)',
                            }}>
                                <TypingDots />
                                <span style={{ fontSize: '0.8125rem', color: 'var(--color-text-muted)' }}>
                                    {activeAgent.label} is thinking…
                                </span>
                            </div>
                        )}

                        <div ref={messagesEndRef} />
                    </div>

                    {/* Input area */}
                    <div style={{
                        padding: '0.875rem 1.25rem',
                        borderTop: '1px solid var(--color-border)',
                        background: 'var(--color-bg-elevated)',
                    }}>
                        <div style={{
                            display: 'flex',
                            gap: '0.75rem',
                            alignItems: 'flex-end',
                            background: 'var(--color-bg)',
                            border: '1px solid var(--color-border)',
                            borderRadius: '12px',
                            padding: '0.625rem 0.875rem',
                            transition: 'border-color 0.15s ease',
                        }}
                            onFocusCapture={e => (e.currentTarget.style.borderColor = 'rgba(233,69,96,0.5)')}
                            onBlurCapture={e => (e.currentTarget.style.borderColor = 'var(--color-border)')}
                        >
                            <textarea
                                ref={textareaRef}
                                value={input}
                                onChange={e => setInput(e.target.value)}
                                onKeyDown={handleKeyDown}
                                placeholder={isTyping ? 'Waiting for response…' : 'Ask something, paste data, or describe an action… (Enter to send, Shift+Enter for newline)'}
                                disabled={isTyping}
                                rows={1}
                                style={{
                                    flex: 1,
                                    background: 'transparent',
                                    border: 'none',
                                    outline: 'none',
                                    resize: 'none',
                                    color: 'var(--color-text-primary)',
                                    fontFamily: 'var(--font-family)',
                                    fontSize: '0.875rem',
                                    lineHeight: 1.5,
                                    minHeight: '24px',
                                    maxHeight: '120px',
                                    overflowY: 'auto',
                                }}
                            />
                            <button
                                onClick={handleSend}
                                disabled={isTyping || !input.trim()}
                                style={{
                                    padding: '0.375rem 0.875rem',
                                    borderRadius: '8px',
                                    border: 'none',
                                    background: (!isTyping && input.trim())
                                        ? 'linear-gradient(135deg, #e94560, #c73e56)'
                                        : 'var(--color-bg-card)',
                                    color: (!isTyping && input.trim()) ? '#fff' : 'var(--color-text-muted)',
                                    fontSize: '0.8125rem',
                                    fontWeight: 600,
                                    cursor: (!isTyping && input.trim()) ? 'pointer' : 'not-allowed',
                                    transition: 'all 0.15s ease',
                                    flexShrink: 0,
                                    boxShadow: (!isTyping && input.trim()) ? '0 2px 8px rgba(233,69,96,0.25)' : 'none',
                                }}
                            >
                                Send ↵
                            </button>
                        </div>
                        <div style={{
                            marginTop: '0.375rem',
                            fontSize: '0.6875rem',
                            color: 'var(--color-text-muted)',
                            textAlign: 'center',
                        }}>
                            AI can make mistakes. Always review suggested actions before approving.
                        </div>
                    </div>

                </div>
            </div>
        </Modal>
    );
}

// ─── Typing dots animation ─────────────────────────────────────────────────

function TypingDots() {
    return (
        <span style={{ display: 'flex', gap: '3px', alignItems: 'center' }}>
            {[0, 1, 2].map(i => (
                <span
                    key={i}
                    style={{
                        width: '5px',
                        height: '5px',
                        borderRadius: '50%',
                        background: 'var(--color-text-muted)',
                        display: 'inline-block',
                        animation: `typingBounce 1.2s ease-in-out ${i * 0.2}s infinite`,
                    }}
                />
            ))}
            <style>{`
                @keyframes typingBounce {
                    0%, 60%, 100% { transform: translateY(0); opacity: 0.4; }
                    30% { transform: translateY(-5px); opacity: 1; }
                }
            `}</style>
        </span>
    );
}
