"use client";

import { useState, useEffect } from 'react';
import Modal from '@/components/Modal';
import Link from 'next/link';
import DOMPurify from 'isomorphic-dompurify';

interface Props {
    productId: string | null;
    onClose: () => void;
}

export default function ProductViewModal({ productId, onClose }: Props) {
    const [product, setProduct] = useState<any>(null);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        if (!productId) { setProduct(null); return; }
        setLoading(true);
        setError(null);
        fetch(`/api/products/${productId}?include=categories,images,attributeValues,brand`)
            .then(r => r.json())
            .then(data => {
                if (data.error) throw new Error(data.error);
                setProduct(data.data ?? data);
            })
            .catch(e => setError(e.message))
            .finally(() => setLoading(false));
    }, [productId]);

    const isOpen = !!productId;

    const primaryImage = product?.images?.find((i: any) => i.isPrimary) ?? product?.images?.[0];

    return (
        <Modal
            isOpen={isOpen}
            onClose={onClose}
            title={product?.name ?? (loading ? 'Loading…' : 'Product')}
            subtitle={product ? `${product.brand?.name ?? ''} · ${product.modelNumber ?? ''} · ${product.sku ?? ''}`.replace(/^·\s*·?\s*|·\s*$|·\s*·/g, '·').replace(/^·\s*/, '').replace(/\s*·$/, '') : undefined}
            size="lg"
            footer={
                <>
                    <button className="btn btn-secondary" onClick={onClose}>Close</button>
                    {product && (
                        <Link href={`/admin/products/${product.id}/edit`} className="btn btn-primary" onClick={onClose}>
                            Edit Product →
                        </Link>
                    )}
                </>
            }
        >
            <div style={{ padding: '1.5rem' }}>
                {loading && (
                    <div style={{ textAlign: 'center', padding: '3rem', color: 'var(--color-text-muted)' }}>
                        Loading…
                    </div>
                )}

                {error && (
                    <div style={{ padding: '1rem', background: 'color-mix(in srgb, var(--color-error) 10%, transparent)', border: '1px solid color-mix(in srgb, var(--color-error) 30%, transparent)', borderRadius: 'var(--radius-md)', color: 'var(--color-error)' }}>
                        {error}
                    </div>
                )}

                {product && !loading && (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>

                        {/* Top row: image + quick stats */}
                        <div style={{ display: 'flex', gap: '1.25rem', alignItems: 'flex-start' }}>
                            {primaryImage ? (
                                <img
                                    src={primaryImage.url}
                                    alt={product.name}
                                    style={{ width: 120, height: 120, objectFit: 'cover', borderRadius: 'var(--radius-md)', border: '1px solid var(--color-border)', flexShrink: 0 }}
                                />
                            ) : (
                                <div style={{ width: 120, height: 120, background: 'var(--color-bg-elevated)', borderRadius: 'var(--radius-md)', border: '1px solid var(--color-border)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '2rem', flexShrink: 0 }}>
                                    🔥
                                </div>
                            )}

                            <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
                                <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', flexWrap: 'wrap' }}>
                                    <span className={`badge badge-${product.status === 'ACTIVE' ? 'active' : product.status === 'DISCONTINUED' ? 'danger' : 'warning'}`}>
                                        {product.status}
                                    </span>
                                    {product.categories?.map((cat: any) => (
                                        <span key={cat.id} style={{ fontSize: '11px', background: 'var(--color-bg-elevated)', color: 'var(--color-text-secondary)', border: '1px solid var(--color-border)', borderRadius: '999px', padding: '2px 8px' }}>
                                            {cat.name}
                                        </span>
                                    ))}
                                </div>
                                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(160px, 1fr))', gap: '0.75rem', marginTop: '0.25rem' }}>
                                    {product.modelNumber && (
                                        <div>
                                            <div style={{ fontSize: '11px', color: 'var(--color-text-muted)', textTransform: 'uppercase', letterSpacing: '0.05em' }}>Model</div>
                                            <div style={{ fontWeight: 500, fontSize: 'var(--font-size-sm)' }}>{product.modelNumber}</div>
                                        </div>
                                    )}
                                    {product.sku && (
                                        <div>
                                            <div style={{ fontSize: '11px', color: 'var(--color-text-muted)', textTransform: 'uppercase', letterSpacing: '0.05em' }}>SKU</div>
                                            <div style={{ fontWeight: 500, fontSize: 'var(--font-size-sm)' }}>{product.sku}</div>
                                        </div>
                                    )}
                                    {product.priceMsrp && (
                                        <div>
                                            <div style={{ fontSize: '11px', color: 'var(--color-text-muted)', textTransform: 'uppercase', letterSpacing: '0.05em' }}>MSRP</div>
                                            <div style={{ fontWeight: 600, fontSize: 'var(--font-size-sm)' }}>${Number(product.priceMsrp).toFixed(2)}</div>
                                        </div>
                                    )}
                                    {product.priceMap && (
                                        <div>
                                            <div style={{ fontSize: '11px', color: 'var(--color-text-muted)', textTransform: 'uppercase', letterSpacing: '0.05em' }}>MAP</div>
                                            <div style={{ fontWeight: 600, fontSize: 'var(--font-size-sm)' }}>${Number(product.priceMap).toFixed(2)}</div>
                                        </div>
                                    )}
                                    {product.ventingType && (
                                        <div>
                                            <div style={{ fontSize: '11px', color: 'var(--color-text-muted)', textTransform: 'uppercase', letterSpacing: '0.05em' }}>Venting</div>
                                            <div style={{ fontWeight: 500, fontSize: 'var(--font-size-sm)' }}>{product.ventingType}</div>
                                        </div>
                                    )}
                                    {product.btuInput && (
                                        <div>
                                            <div style={{ fontSize: '11px', color: 'var(--color-text-muted)', textTransform: 'uppercase', letterSpacing: '0.05em' }}>BTU Input</div>
                                            <div style={{ fontWeight: 500, fontSize: 'var(--font-size-sm)' }}>{Number(product.btuInput).toLocaleString()}</div>
                                        </div>
                                    )}
                                </div>
                            </div>
                        </div>

                        {/* Description */}
                        {(product.shortDescription || product.description) && (
                            <div>
                                <div style={{ fontSize: '11px', color: 'var(--color-text-muted)', textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: '0.5rem' }}>Description</div>
                                <div
                                    className="wysiwyg-content"
                                    style={{ fontSize: 'var(--font-size-sm)', color: 'var(--color-text-secondary)', lineHeight: 1.6, maxHeight: '180px', overflow: 'auto' }}
                                    dangerouslySetInnerHTML={{
                                        __html: DOMPurify.sanitize(product.shortDescription || product.description)
                                    }}
                                />
                            </div>
                        )}

                        {/* Attribute values */}
                        {product.attributeValues?.length > 0 && (
                            <div>
                                <div style={{ fontSize: '11px', color: 'var(--color-text-muted)', textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: '0.5rem' }}>Attributes</div>
                                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(160px, 1fr))', gap: '0.75rem' }}>
                                    {product.attributeValues.map((av: any) => (
                                        <div key={av.id}>
                                            <div style={{ fontSize: '11px', color: 'var(--color-text-muted)' }}>{av.attribute?.name ?? av.attributeId}</div>
                                            <div style={{ fontWeight: 500, fontSize: 'var(--font-size-sm)' }}>
                                                {av.attribute?.dataType === 'boolean' ? (av.value === 'true' ? 'Yes' : 'No') : av.value}
                                                {av.attribute?.unit ? ` ${av.attribute.unit}` : ''}
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        )}

                        {/* Additional images */}
                        {product.images?.length > 1 && (
                            <div>
                                <div style={{ fontSize: '11px', color: 'var(--color-text-muted)', textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: '0.5rem' }}>More Images</div>
                                <div style={{ display: 'flex', gap: '0.5rem', flexWrap: 'wrap' }}>
                                    {product.images.filter((i: any) => i.url !== primaryImage?.url).map((img: any) => (
                                        <img key={img.id} src={img.url} alt="" style={{ width: 72, height: 72, objectFit: 'cover', borderRadius: 'var(--radius-md)', border: '1px solid var(--color-border)' }} />
                                    ))}
                                </div>
                            </div>
                        )}
                    </div>
                )}
            </div>
        </Modal>
    );
}
