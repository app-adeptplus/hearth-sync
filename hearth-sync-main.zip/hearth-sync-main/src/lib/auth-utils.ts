import { createServiceClient } from '@/lib/supabase';

/** Generates a temp password in the format Hearth#XXXXXX (6 random digits). */
export function generateTempPassword(): string {
    const digits = Math.floor(100000 + Math.random() * 900000).toString();
    return `Hearth#${digits}`;
}

export type PortalRole = 'admin' | 'dealer' | 'manufacturer';

interface CreatePortalUserResult {
    user: { id: string; email: string };
    tempPassword: string;
}

/**
 * Creates a new Supabase Auth user tagged with a portal_role in app_metadata.
 *
 * Why app_metadata and not user_metadata?
 * - user_metadata is editable by the user via supabase.auth.updateUser() from the browser.
 * - app_metadata is writable only via the service role key (server-side), making it
 *   tamper-proof and safe to use as a role/permission claim in the JWT.
 *
 * Uses a two-step flow: createUser (sets display fields in user_metadata) then
 * updateUserById (stamps the role into app_metadata).
 */
export async function createPortalUser(
    email: string,
    portalRole: PortalRole,
    displayMetadata: Record<string, string> = {}
): Promise<CreatePortalUserResult> {
    const supabase = createServiceClient();
    const tempPassword = generateTempPassword();

    // Step 1: Create the user (user_metadata for cosmetic fields like full_name only)
    const { data, error } = await supabase.auth.admin.createUser({
        email,
        password: tempPassword,
        email_confirm: true,
        user_metadata: displayMetadata,
    });

    if (error) throw new Error(error.message);
    if (!data.user) throw new Error('User creation returned no user object.');

    // Step 2: Write portal_role into app_metadata (tamper-proof, service-role only)
    const { error: updateError } = await supabase.auth.admin.updateUserById(data.user.id, {
        app_metadata: { portal_role: portalRole },
    });

    if (updateError) {
        // Clean up the user if we can't tag it correctly
        await supabase.auth.admin.deleteUser(data.user.id);
        throw new Error(`Failed to set portal role: ${updateError.message}`);
    }

    return {
        user: { id: data.user.id, email: data.user.email! },
        tempPassword,
    };
}

/**
 * Reads the portal_role from a Supabase user object.
 * Always reads from app_metadata (authoritative), falls back to user_metadata
 * for legacy users created before the app_metadata migration.
 */
export function getPortalRole(user: { app_metadata?: Record<string, unknown>; user_metadata?: Record<string, unknown> }): PortalRole | null {
    const role =
        (user.app_metadata?.portal_role as PortalRole | undefined) ??
        (user.user_metadata?.portal_role as PortalRole | undefined) ??
        null;
    return role;
}
