import OpenAI from 'openai';
import Anthropic from '@anthropic-ai/sdk';
import { GoogleGenerativeAI } from '@google/generative-ai';
import prisma from '@/lib/db';
import { decryptSecret } from '@/lib/encryption';

export interface LlmCallOptions {
    /** Override a specific LlmApiConfig by ID instead of using the default */
    llmConfigId?: string;
    /** Max tokens for this call (falls back to config value) */
    maxTokens?: number;
    /** Temperature for this call (falls back to config value) */
    temperature?: number;
    /** System prompt (if separate from the user message) */
    systemPrompt?: string;
}

export interface LlmCallResult {
    text: string;
    tokensUsed: number;
    provider: string;
    model: string;
}

/**
 * Unified LLM caller — resolves the right provider config,
 * decrypts the API key, and routes to the correct SDK.
 *
 * Supported providers: OpenAI, Azure OpenAI, Anthropic, Google Gemini, Custom (OpenAI-compatible)
 */
export async function callLlm(
    userMessage: string,
    options: LlmCallOptions = {}
): Promise<LlmCallResult> {
    // Resolve the provider config
    const llmConfig = options.llmConfigId
        ? await prisma.llmApiConfig.findUnique({ where: { id: options.llmConfigId } })
        : await prisma.llmApiConfig.findFirst({ where: { isDefault: true, isActive: true } });

    if (!llmConfig) {
        throw new Error(
            'No LLM provider configured. Add one in System Services → API Connections and set it as default.'
        );
    }

    if (!llmConfig.apiKey || !llmConfig.apiKey.includes(':')) {
        throw new Error(
            `LLM provider "${llmConfig.displayName || llmConfig.provider}" has no valid API key stored. ` +
            'Edit it in System Services → API Connections and re-enter the key.'
        );
    }

    const apiKey = decryptSecret(llmConfig.apiKey);
    const maxTokens = options.maxTokens ?? llmConfig.maxTokens ?? 4096;
    const temperature = options.temperature ?? llmConfig.temperature ?? 0.3;

    // Update lastUsedAt
    await prisma.llmApiConfig.update({
        where: { id: llmConfig.id },
        data: { lastUsedAt: new Date() },
    }).catch(() => { /* non-critical */ });

    switch (llmConfig.provider) {
        case 'OPENAI':
        case 'AZURE_OPENAI':
        case 'CUSTOM':
            return callOpenAi({ apiKey, llmConfig, userMessage, systemPrompt: options.systemPrompt, maxTokens, temperature });

        case 'ANTHROPIC':
            return callAnthropic({ apiKey, llmConfig, userMessage, systemPrompt: options.systemPrompt, maxTokens, temperature });

        case 'GOOGLE_GEMINI':
            return callGemini({ apiKey, llmConfig, userMessage, systemPrompt: options.systemPrompt, maxTokens, temperature });

        default:
            throw new Error(`Unknown LLM provider: ${llmConfig.provider}`);
    }
}

interface ProviderCallParams {
    apiKey: string;
    llmConfig: any;
    userMessage: string;
    systemPrompt?: string;
    maxTokens: number;
    temperature: number;
}

async function callOpenAi({
    apiKey, llmConfig, userMessage, systemPrompt, maxTokens, temperature,
}: ProviderCallParams): Promise<LlmCallResult> {
    const client = new OpenAI({
        apiKey,
        ...(llmConfig.baseUrl && { baseURL: llmConfig.baseUrl }),
    });

    const messages: OpenAI.Chat.ChatCompletionMessageParam[] = [];
    if (systemPrompt) {
        messages.push({ role: 'system', content: systemPrompt });
    }
    messages.push({ role: 'user', content: userMessage });

    const response = await client.chat.completions.create({
        model: llmConfig.model,
        messages,
        max_tokens: maxTokens,
        temperature,
        ...(llmConfig.topP !== null && { top_p: llmConfig.topP }),
    });

    return {
        text: response.choices[0]?.message?.content ?? '',
        tokensUsed: response.usage?.total_tokens ?? 0,
        provider: llmConfig.provider,
        model: llmConfig.model,
    };
}

async function callAnthropic({
    apiKey, llmConfig, userMessage, systemPrompt, maxTokens, temperature,
}: ProviderCallParams): Promise<LlmCallResult> {
    const client = new Anthropic({
        apiKey,
        ...(llmConfig.baseUrl && { baseURL: llmConfig.baseUrl }),
    });

    const response = await client.messages.create({
        model: llmConfig.model,
        max_tokens: maxTokens,
        temperature,
        ...(systemPrompt && { system: systemPrompt }),
        messages: [
            { role: 'user', content: userMessage },
        ],
    });

    // Extract text from response content blocks
    const text = response.content
        .filter((block): block is Anthropic.TextBlock => block.type === 'text')
        .map(block => block.text)
        .join('');

    return {
        text,
        tokensUsed: (response.usage?.input_tokens ?? 0) + (response.usage?.output_tokens ?? 0),
        provider: llmConfig.provider,
        model: llmConfig.model,
    };
}

async function callGemini({
    apiKey, llmConfig, userMessage, systemPrompt, maxTokens, temperature,
}: ProviderCallParams): Promise<LlmCallResult> {
    const genAI = new GoogleGenerativeAI(apiKey);
    const model = genAI.getGenerativeModel({
        model: llmConfig.model,
        generationConfig: {
            maxOutputTokens: maxTokens,
            temperature,
            ...(llmConfig.topP !== null && { topP: llmConfig.topP }),
        },
        ...(systemPrompt && {
            systemInstruction: systemPrompt,
        }),
    });

    const result = await model.generateContent(userMessage);
    const response = result.response;
    const text = response.text();
    const usage = response.usageMetadata;

    return {
        text,
        tokensUsed: (usage?.promptTokenCount ?? 0) + (usage?.candidatesTokenCount ?? 0),
        provider: llmConfig.provider,
        model: llmConfig.model,
    };
}

