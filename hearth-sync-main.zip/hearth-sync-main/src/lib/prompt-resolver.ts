import Handlebars from 'handlebars';
import prisma from '@/lib/db';

interface RuntimeVars {
    brand_name?: string;
    brand_website?: string;
    product_type?: string;
    category_context?: string;
    extraction_fields?: string;
    custom_instructions?: string;
    [key: string]: string | undefined;
}

/**
 * Resolves the final system prompt for an automation run.
 *
 * Resolution order:
 * 1. Load PromptTemplate.systemPrompt (if linked via promptTemplateId)
 * 2. Compile with Handlebars and inject runtimeVars
 * 3. Append AutomationConfig.llmInstructions (if any) as a per-config addendum
 * 4. Fallback to the legacy hardcoded constant if nothing is configured
 */
export async function resolvePrompt(
    configId: string,
    runtimeVars: RuntimeVars = {}
): Promise<string> {
    const config = await prisma.automationConfig.findUnique({
        where: { id: configId },
        include: {
            promptTemplate: true,
            brand: true,
        },
    });

    if (!config) throw new Error(`AutomationConfig ${configId} not found`);

    // Fetch all categories and format as context for the LLM
    const categories = await prisma.productCategory.findMany({
        select: { name: true },
        orderBy: { name: 'asc' },
    });

    const vars: RuntimeVars = {
        brand_name: config.brand?.name || '',
        brand_website: config.siteUrl || config.brand?.website || '',
        custom_instructions: config.llmInstructions || '',
        category_context: categories.map(c => c.name).join(', '),
        extraction_fields: [
            'name', 'sku', 'description', 'price',
            'images (array of URLs)', 'categories (array of strings)',
            'width', 'height', 'depth', 'weight', 'btu',
            'productUrl (URL of the product page)'
        ].join(', '),
        ...runtimeVars,
    };

    let prompt = '';

    if (config.promptTemplate) {
        // Compile the Handlebars template
        const compiled = Handlebars.compile(config.promptTemplate.systemPrompt, { strict: false });
        prompt = compiled(vars);
    } else if (config.llmInstructions) {
        // No template linked — use inline instructions directly
        return config.llmInstructions;
    } else {
        // Legacy fallback — compile through Handlebars so {{category_context}} etc. resolve
        const compiled = Handlebars.compile(LEGACY_DEFAULT_PROMPT, { strict: false });
        return compiled(vars);
    }

    // Append per-config addendum if template AND inline instructions both exist
    if (config.promptTemplate && config.llmInstructions) {
        prompt += `\n\nAdditional instructions:\n${config.llmInstructions}`;
    }

    return prompt;
}

/**
 * Resolve a prompt directly from a template ID with provided vars.
 * Useful for previewing templates in the admin UI.
 */
export async function resolveTemplatePreview(
    templateId: string,
    vars: RuntimeVars = {}
): Promise<string> {
    const template = await prisma.promptTemplate.findUnique({ where: { id: templateId } });
    if (!template) throw new Error(`PromptTemplate ${templateId} not found`);
    const compiled = Handlebars.compile(template.systemPrompt, { strict: false });
    return compiled(vars);
}

// The original hardcoded default — kept as fallback for configs with no template
const LEGACY_DEFAULT_PROMPT = `You are a product data extraction assistant for a hearth product catalog.

For each product found on the page, extract the following fields:
1. **Product Name** — Full product name/title as displayed
2. **SKU / Model Number** — The manufacturer SKU, model number, or part number
3. **Images** — All product image URLs (full resolution when available)
4. **Product Description** — Full marketing description and product overview

Return structured JSON for each product. If a field is not available on the page, set it to null.

Available categories in our system: {{category_context}}

When classifying products, prefer these existing categories over creating new ones.
The expected output fields are: {{extraction_fields}}`;
