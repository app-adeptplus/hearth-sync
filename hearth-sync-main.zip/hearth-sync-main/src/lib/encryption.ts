import { createCipheriv, createDecipheriv, randomBytes } from 'crypto';

const ALGORITHM = 'aes-256-gcm';

function getKey(): Buffer {
    const secret = process.env.ENCRYPTION_SECRET;
    if (!secret) {
        throw new Error('ENCRYPTION_SECRET environment variable is not set');
    }
    return Buffer.from(secret, 'hex');
}

/**
 * Encrypts a plaintext string using AES-256-GCM.
 * Returns a colon-delimited string: "iv:authTag:ciphertext" (all base64).
 */
export function encryptSecret(plaintext: string): string {
    const iv = randomBytes(12); // 96-bit IV for GCM
    const key = getKey();
    const cipher = createCipheriv(ALGORITHM, key, iv);
    const encrypted = Buffer.concat([
        cipher.update(plaintext, 'utf8'),
        cipher.final(),
    ]);
    const tag = cipher.getAuthTag();
    return [
        iv.toString('base64'),
        tag.toString('base64'),
        encrypted.toString('base64'),
    ].join(':');
}

/**
 * Decrypts a value produced by encryptSecret.
 */
export function decryptSecret(ciphertext: string): string {
    const parts = ciphertext.split(':');
    if (parts.length !== 3) {
        throw new Error('Invalid encrypted secret format');
    }
    const [ivB64, tagB64, dataB64] = parts;
    const key = getKey();
    const decipher = createDecipheriv(
        ALGORITHM,
        key,
        Buffer.from(ivB64, 'base64')
    );
    decipher.setAuthTag(Buffer.from(tagB64, 'base64'));
    const decrypted = Buffer.concat([
        decipher.update(Buffer.from(dataB64, 'base64')),
        decipher.final(),
    ]);
    return decrypted.toString('utf8');
}

/**
 * Returns true if the value looks like an encrypted secret (has the iv:tag:data format).
 */
export function isEncrypted(value: string): boolean {
    return value.split(':').length === 3;
}

/**
 * Masks a plaintext API key for safe display in the UI.
 * Shows only the last 4 characters.
 */
export function maskSecret(plaintext: string): string {
    if (plaintext.length <= 4) return '****';
    return `****${plaintext.slice(-4)}`;
}

/**
 * Encrypts if not already encrypted. Safe to call on values that may
 * have already been encrypted on a previous write.
 */
export function encryptIfNeeded(value: string): string {
    if (isEncrypted(value)) return value;
    return encryptSecret(value);
}
