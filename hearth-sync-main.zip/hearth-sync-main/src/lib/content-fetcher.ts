/**
 * content-fetcher.ts
 *
 * Fetches web page content for the automation pipeline.
 * Strategy (priority order):
 *   1. Firecrawl — if an active ExternalServiceConfig of type FIRECRAWL exists
 *   2. Basic fetch — fetch() + strip HTML to plain text
 */

import prisma from '@/lib/db';
import { decryptSecret } from '@/lib/encryption';

export interface FetchResult {
    content: string;      // Markdown (Firecrawl) or plain text (fallback)
    url: string;
    title?: string;
    statusCode: number;
    source: 'firecrawl' | 'fetch';
}

/**
 * Fetch page content from a URL using the best available method.
 */
export async function fetchPageContent(url: string): Promise<FetchResult> {
    // Try Firecrawl first
    const firecrawlService = await prisma.externalServiceConfig.findFirst({
        where: { serviceType: 'FIRECRAWL', isActive: true },
    });

    if (firecrawlService) {
        try {
            return await fetchViaFirecrawl(url, firecrawlService);
        } catch (err) {
            console.warn(`⚠️ Firecrawl failed, falling back to basic fetch: ${err instanceof Error ? err.message : err}`);
        }
    }

    // Fallback: basic fetch
    return await fetchViaBasicFetch(url);
}

/**
 * Fetch page content via Firecrawl API.
 */
async function fetchViaFirecrawl(
    url: string,
    service: { id: string; apiKey: string; baseUrl: string | null }
): Promise<FetchResult> {
    const apiKey = decryptSecret(service.apiKey);
    const baseUrl = service.baseUrl || 'https://api.firecrawl.dev';

    const response = await fetch(`${baseUrl}/v1/scrape`, {
        method: 'POST',
        headers: {
            Authorization: `Bearer ${apiKey}`,
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            url,
            formats: ['markdown'],
        }),
        signal: AbortSignal.timeout(60000), // 60s timeout for scraping
    });

    if (!response.ok) {
        const body = await response.json().catch(() => ({}));
        throw new Error(`Firecrawl returned ${response.status}: ${body?.error || response.statusText}`);
    }

    const data = await response.json();
    const result = data?.data ?? data;

    // Update lastUsedAt
    await prisma.externalServiceConfig.update({
        where: { id: service.id },
        data: { lastUsedAt: new Date() },
    }).catch(() => { /* non-critical */ });

    return {
        content: result?.markdown || result?.content || '',
        url,
        title: result?.metadata?.title || undefined,
        statusCode: result?.metadata?.statusCode || 200,
        source: 'firecrawl',
    };
}

/**
 * Fallback: fetch the URL directly and strip HTML to plain text.
 */
async function fetchViaBasicFetch(url: string): Promise<FetchResult> {
    const response = await fetch(url, {
        headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml',
        },
        signal: AbortSignal.timeout(30000),
    });

    if (!response.ok) {
        throw new Error(`Fetch returned HTTP ${response.status} for ${url}`);
    }

    const html = await response.text();
    const text = stripHtmlToText(html);
    const title = extractTitle(html);

    return {
        content: text,
        url,
        title,
        statusCode: response.status,
        source: 'fetch',
    };
}

/**
 * Strip HTML tags and normalize whitespace to produce clean text.
 */
function stripHtmlToText(html: string): string {
    return html
        // Remove script and style blocks entirely
        .replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '')
        .replace(/<style\b[^<]*(?:(?!<\/style>)<[^<]*)*<\/style>/gi, '')
        // Remove nav, header, footer elements
        .replace(/<(nav|header|footer)\b[^<]*(?:(?!<\/\1>)<[^<]*)*<\/\1>/gi, '')
        // Convert block-level tags to newlines
        .replace(/<\/(p|div|h[1-6]|li|tr|br|section|article)>/gi, '\n')
        .replace(/<br\s*\/?>/gi, '\n')
        // Remove all remaining HTML tags
        .replace(/<[^>]+>/g, ' ')
        // Decode common HTML entities
        .replace(/&amp;/g, '&')
        .replace(/&lt;/g, '<')
        .replace(/&gt;/g, '>')
        .replace(/&quot;/g, '"')
        .replace(/&#39;/g, "'")
        .replace(/&nbsp;/g, ' ')
        // Collapse whitespace
        .replace(/[ \t]+/g, ' ')
        .replace(/\n\s*\n/g, '\n\n')
        .trim();
}

/**
 * Extract <title> from HTML.
 */
function extractTitle(html: string): string | undefined {
    const match = html.match(/<title[^>]*>([^<]*)<\/title>/i);
    return match?.[1]?.trim() || undefined;
}

/**
 * Discover all URLs on a site using Firecrawl's /v1/map endpoint.
 * Returns an array of URLs, optionally filtered by a search query.
 * This uses 1 Firecrawl credit regardless of how many URLs are returned.
 */
export async function mapSiteUrls(
    baseUrl: string,
    options: { search?: string; limit?: number } = {}
): Promise<string[]> {
    const firecrawlService = await prisma.externalServiceConfig.findFirst({
        where: { serviceType: 'FIRECRAWL', isActive: true },
    });

    if (!firecrawlService) {
        console.warn('⚠️ No Firecrawl service configured — cannot map site URLs');
        return [];
    }

    const apiKey = decryptSecret(firecrawlService.apiKey);
    const apiBase = firecrawlService.baseUrl || 'https://api.firecrawl.dev';

    const response = await fetch(`${apiBase}/v1/map`, {
        method: 'POST',
        headers: {
            Authorization: `Bearer ${apiKey}`,
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            url: baseUrl,
            search: options.search || 'product',
            limit: options.limit || 200,
            ignoreSitemap: false,
        }),
        signal: AbortSignal.timeout(30000),
    });

    if (!response.ok) {
        const body = await response.json().catch(() => ({}));
        throw new Error(`Firecrawl map returned ${response.status}: ${body?.error || response.statusText}`);
    }

    const data = await response.json();
    const urls: string[] = data?.links || data?.urls || [];
    console.log(`   🗺️ Mapped ${urls.length} URLs from ${baseUrl}`);
    return urls;
}

/**
 * Fetch content from multiple pages with rate limiting.
 * Returns an array of FetchResult (including failures as null).
 */
export async function fetchMultiplePages(
    urls: string[],
    options: { delayMs?: number; maxConcurrent?: number } = {}
): Promise<(FetchResult | null)[]> {
    const delayMs = options.delayMs || 500;
    const results: (FetchResult | null)[] = [];

    for (let i = 0; i < urls.length; i++) {
        try {
            console.log(`   📥 [${i + 1}/${urls.length}] Fetching: ${urls[i]}`);
            const result = await fetchPageContent(urls[i]);
            results.push(result);
        } catch (err) {
            console.warn(`   ⚠️ [${i + 1}/${urls.length}] Failed: ${err instanceof Error ? err.message : err}`);
            results.push(null);
        }

        // Rate limit between requests
        if (i < urls.length - 1) {
            await new Promise(resolve => setTimeout(resolve, delayMs));
        }
    }

    return results;
}

