/**
 * data-package-builder.ts
 *
 * Parses raw LLM output (expected JSON array of products) and creates
 * a DataPackage + DataPackageItem records in the database.
 */

import prisma from '@/lib/db';

export interface BuildResult {
    packageId: string;
    itemCount: number;
    errors: string[];
}

interface RawProduct {
    name?: string;
    productName?: string;
    product_name?: string;
    sku?: string;
    modelNumber?: string;
    model_number?: string;
    model?: string;
    description?: string;
    fullDescription?: string;
    full_description?: string;
    shortDescription?: string;
    short_description?: string;
    images?: string[];
    imageUrls?: string[];
    image_urls?: string[];
    price?: string | number;
    priceMsrp?: string | number;
    productUrl?: string;
    product_url?: string;
    url?: string;
    categories?: string[];
    category?: string;
    series?: string;
    configuration?: string;
    specs?: Record<string, string | number>;
    specifications?: Record<string, string | number>;
    attributes?: Record<string, string | number>;
    dimensions?: Record<string, number>;
    width?: number | string;
    height?: number | string;
    depth?: number | string;
    weight?: number | string;
    btu?: number | string;
    btuInput?: number | string;
    [key: string]: unknown;
}

/**
 * Build a DataPackage from raw LLM output.
 */
export async function buildDataPackage(
    runId: string,
    configId: string,
    brandId: string | null,
    rawLlmOutput: string
): Promise<BuildResult> {
    const errors: string[] = [];

    // Parse JSON from LLM response
    const products = extractJsonArray(rawLlmOutput);
    if (!products || products.length === 0) {
        errors.push('No products could be parsed from LLM output');
        // Still create the package so the raw output is preserved
        const pkg = await prisma.dataPackage.create({
            data: {
                automationRunId: runId,
                name: `Auto-extract ${new Date().toISOString().slice(0, 16)}`,
                brandId,
                status: 'PENDING_REVIEW',
                rawData: { rawOutput: rawLlmOutput, parseError: 'No valid JSON array found' },
            },
        });
        return { packageId: pkg.id, itemCount: 0, errors };
    }

    // Create the DataPackage
    const pkg = await prisma.dataPackage.create({
        data: {
            automationRunId: runId,
            name: `Auto-extract ${new Date().toISOString().slice(0, 16)}`,
            brandId,
            status: 'PENDING_REVIEW',
            rawData: products as any,
        },
    });

    // Create DataPackageItems
    let itemCount = 0;
    for (let i = 0; i < products.length; i++) {
        try {
            const raw = products[i] as RawProduct;
            const mapped = mapProductFields(raw);

            await prisma.dataPackageItem.create({
                data: {
                    packageId: pkg.id,
                    externalId: String(i + 1),
                    rawJson: raw as any,
                    parsedName: mapped.name,
                    parsedSku: mapped.sku,
                    parsedDescription: mapped.description,
                    parsedImages: mapped.images,
                    parsedCategories: mapped.categories,
                    parsedAttributes: mapped.attributes as any,
                    parsedDimensions: mapped.dimensions as any,
                    confidence: mapped.confidence,
                    status: 'pending',
                },
            });
            itemCount++;
        } catch (err) {
            const msg = `Failed to create item ${i + 1}: ${err instanceof Error ? err.message : err}`;
            errors.push(msg);
            console.error(`   ⚠️ ${msg}`);
        }
    }

    return { packageId: pkg.id, itemCount, errors };
}

/**
 * Extract a JSON array from LLM output.
 * Handles: plain JSON, markdown fenced blocks, preamble/postamble text.
 */
function extractJsonArray(text: string): unknown[] | null {
    // Try 1: direct parse
    try {
        const parsed = JSON.parse(text);
        if (Array.isArray(parsed)) return parsed;
        // If it's an object with a products/items/data key holding an array
        if (parsed && typeof parsed === 'object') {
            for (const key of ['products', 'items', 'data', 'results']) {
                if (Array.isArray(parsed[key])) return parsed[key];
            }
        }
    } catch { /* not pure JSON, try extracting */ }

    // Try 2: extract from markdown code fence
    const fenceMatch = text.match(/```(?:json)?\s*\n?([\s\S]*?)```/);
    if (fenceMatch) {
        try {
            const parsed = JSON.parse(fenceMatch[1].trim());
            if (Array.isArray(parsed)) return parsed;
            if (parsed && typeof parsed === 'object') {
                for (const key of ['products', 'items', 'data', 'results']) {
                    if (Array.isArray(parsed[key])) return parsed[key];
                }
            }
        } catch { /* continue */ }
    }

    // Try 3: find the first [ ... ] block
    const bracketStart = text.indexOf('[');
    const bracketEnd = text.lastIndexOf(']');
    if (bracketStart !== -1 && bracketEnd > bracketStart) {
        try {
            const parsed = JSON.parse(text.slice(bracketStart, bracketEnd + 1));
            if (Array.isArray(parsed)) return parsed;
        } catch { /* give up */ }
    }

    return null;
}

/**
 * Normalize an object's keys: strip special chars, lowercase, collapse spaces.
 * "Product Name" → "productname", "Model Number / SKU" → "modelnumber/sku" → "modelnumbersku"
 */
function normalizeKeys(obj: Record<string, unknown>): Record<string, unknown> {
    const result: Record<string, unknown> = {};
    for (const [key, value] of Object.entries(obj)) {
        const normalized = key
            .toLowerCase()
            .replace(/[^a-z0-9]+/g, '') // strip all non-alphanumeric
            .trim();
        result[normalized] = value;
        // Also store with underscores for multi-word lookups
        const underscored = key.toLowerCase().replace(/\s+/g, '_').replace(/[^a-z0-9_]/g, '');
        result[underscored] = value;
    }
    return result;
}

/**
 * Map various LLM output field names to our standard DataPackageItem fields.
 * Handles: camelCase, snake_case, "Title Case With Spaces", slash-separated, etc.
 */
function mapProductFields(raw: RawProduct) {
    const n = normalizeKeys(raw as Record<string, unknown>);

    // Name: try many variants
    const name = stringVal(n, ['name', 'productname', 'product_name', 'title', 'producttitle', 'product_title']) || null;
    
    // SKU / Model Number
    const sku = stringVal(n, ['sku', 'modelnumber', 'model_number', 'modelnumbersku', 'model_number_sku', 'model', 'partnumber', 'part_number', 'mpn']) || null;
    
    // Description
    const description = stringVal(n, [
        'description', 'fulldescription', 'full_description', 'productdescription', 'product_description',
        'shortdescription', 'short_description', 'shortdescriptionfulldescription', 'short_description_full_description',
    ]) || null;
    
    // Images
    const rawImages = arrayVal(n, ['images', 'imageurls', 'image_urls', 'allimages', 'all_images', 'allimageurls', 'all_image_urls', 'allimageurlsfullresolution', 'all_image_urls_full_resolution']) || [];
    const images = rawImages.filter((img): img is string => typeof img === 'string' && img.startsWith('http'));

    // Categories
    const categories: string[] = [];
    const rawCats = arrayVal(n, ['categories', 'category', 'categoryseries', 'category_series']) || [];
    categories.push(...rawCats.filter(c => typeof c === 'string').map(c => String(c)));
    const series = stringVal(n, ['series', 'productseries', 'product_series']);
    if (series) categories.push(series);
    const config = stringVal(n, ['configuration', 'configurationtype', 'configuration_type']);
    if (config) categories.push(config);

    // Attributes
    const attributes: Record<string, string | number> = {};
    const specObj = objectVal(n, ['specs', 'specifications', 'attributes']);
    if (specObj) Object.assign(attributes, specObj);
    
    const price = stringVal(n, ['price', 'pricemsrp', 'price_msrp', 'msrp']);
    if (price) attributes.price = normalizePrice(price);
    
    const productUrl = stringVal(n, ['producturl', 'product_url', 'url', 'productpageurl', 'product_page_url', 'link', 'href']);
    if (productUrl) attributes.productUrl = productUrl;
    
    const btu = stringVal(n, ['btu', 'btuinput', 'btu_input', 'btus']);
    if (btu) attributes.btu = btu;

    // Dimensions
    const dimensions: Record<string, number> = {};
    const dimObj = objectVal(n, ['dimensions']);
    if (dimObj) {
        for (const [k, v] of Object.entries(dimObj)) {
            if (typeof v === 'number') dimensions[k] = v;
            else if (typeof v === 'string') {
                const parsed = normalizeDimension(v);
                if (parsed !== null) dimensions[k] = parsed;
            }
        }
    }
    const w = numVal(n, ['width']) ?? normalizeDimensionFromStr(n, ['width']);
    const h = numVal(n, ['height']) ?? normalizeDimensionFromStr(n, ['height']);
    const d = numVal(n, ['depth']) ?? normalizeDimensionFromStr(n, ['depth']);
    const wt = numVal(n, ['weight']) ?? normalizeDimensionFromStr(n, ['weight']);
    if (w) dimensions.width = w;
    if (h) dimensions.height = h;
    if (d) dimensions.depth = d;
    if (wt) dimensions.weight = wt;

    // Try to parse a combined dimension string like "24.5 x 18 x 12 inches"
    const dimStr = stringVal(n, ['overalldimensions', 'overall_dimensions', 'dimensionswxhxd', 'dimensions_w_x_h_x_d', 'size']);
    if (dimStr && Object.keys(dimensions).length === 0) {
        const parts = dimStr.match(/(\d+\.?\d*)/g);
        if (parts && parts.length >= 2) {
            dimensions.width = parseFloat(parts[0]);
            dimensions.height = parseFloat(parts[1]);
            if (parts[2]) dimensions.depth = parseFloat(parts[2]);
        }
    }

    // Confidence: based on how many core fields are populated
    let filledFields = 0;
    if (name) filledFields++;
    if (sku) filledFields++;
    if (description && description.length > 20) filledFields++;  // Meaningful description
    if (images.length > 0) filledFields++;
    if (categories.length > 0) filledFields++;
    if (Object.keys(attributes).length > 1) filledFields++;  // More than just price
    if (Object.keys(dimensions).length > 0) filledFields++;
    const confidence = Math.min(filledFields / 7, 1.0);

    return {
        name,
        sku,
        description,
        images,
        categories,
        attributes: Object.keys(attributes).length > 0 ? attributes : null,
        dimensions: Object.keys(dimensions).length > 0 ? dimensions : null,
        confidence: Math.round(confidence * 100) / 100,
    };
}

// Helpers to safely extract values from normalized keys
function stringVal(n: Record<string, unknown>, keys: string[]): string | undefined {
    for (const k of keys) {
        const v = n[k];
        if (v && typeof v === 'string' && v.trim()) return v.trim();
    }
    return undefined;
}

function arrayVal(n: Record<string, unknown>, keys: string[]): unknown[] | undefined {
    for (const k of keys) {
        const v = n[k];
        if (Array.isArray(v)) return v;
        // Single string → wrap in array
        if (v && typeof v === 'string' && v.trim()) return [v.trim()];
    }
    return undefined;
}

function numVal(n: Record<string, unknown>, keys: string[]): number | undefined {
    for (const k of keys) {
        const v = n[k];
        if (typeof v === 'number') return v;
        if (v && typeof v === 'string') {
            const parsed = parseFloat(v);
            if (!isNaN(parsed)) return parsed;
        }
    }
    return undefined;
}

function objectVal(n: Record<string, unknown>, keys: string[]): Record<string, string | number> | undefined {
    for (const k of keys) {
        const v = n[k];
        if (v && typeof v === 'object' && !Array.isArray(v)) return v as Record<string, string | number>;
    }
    return undefined;
}

/**
 * Normalize a price string: "$1,674.00" → "1674.00", "€299" → "299"
 */
function normalizePrice(price: string): string {
    const cleaned = price.replace(/[^0-9.,]/g, '').replace(/,/g, '');
    const num = parseFloat(cleaned);
    if (isNaN(num)) return price; // Return original if can't parse
    return num.toFixed(2);
}

/**
 * Normalize a dimension string: "24.5 inches" → 24.5, "24 1/2"" → 24.5
 */
function normalizeDimension(value: string): number | null {
    // Try simple numeric extraction
    const match = value.match(/(\d+\.?\d*)/);
    if (match) return parseFloat(match[1]);
    return null;
}

/**
 * Try to get a dimension from normalized keys, parsing string values.
 */
function normalizeDimensionFromStr(n: Record<string, unknown>, keys: string[]): number | undefined {
    for (const k of keys) {
        const v = n[k];
        if (typeof v === 'string') {
            const parsed = normalizeDimension(v);
            if (parsed !== null) return parsed;
        }
    }
    return undefined;
}
