/* eslint-disable @typescript-eslint/no-explicit-any, @typescript-eslint/no-unused-vars */
import axios from 'axios';

export interface LeadData {
    dealerId: string;
    customerName: string;
    customerEmail: string;
    customerPhone: string;
    projectType: string;
    interestedProducts: string[];
    estimatedValue?: number;
    source: 'WIDGET_CONTACT' | 'WIDGET_ESTIMATOR';
}

export class CRMConnector {
    /**
     * Main router for sending leads to configured CRMs
     */
    static async dispatchLead(dealerId: string, lead: LeadData): Promise<void> {
        // 1. Fetch CRM configurations for this dealer from the DB
        // (mocking this for Phase MVP)
        const crmConfig = {
            hasHubspot: false,
            hasSalesforce: false,
            webhookUrl: 'https://hooks.zapier.com/hooks/catch/123/abc',
        };

        const promises: Promise<any>[] = [];

        // 2. Dispatch to Native Integrations
        if (crmConfig.hasHubspot) {
            promises.push(this.sendToHubSpot(dealerId, lead));
        }

        if (crmConfig.hasSalesforce) {
            promises.push(this.sendToSalesforce(dealerId, lead));
        }

        // 3. Dispatch to fallback Webhook
        if (crmConfig.webhookUrl) {
            promises.push(this.sendToWebhook(crmConfig.webhookUrl, lead));
        }

        try {
            if (promises.length > 0) {
                await Promise.allSettled(promises);
            }
        } catch (e) {
            console.error('[CRM] Critical routing error:', e);
        }
    }

    private static async sendToWebhook(url: string, payload: any) {
        console.log(`[CRM] Sending lead via Webhook to ${url}`);
        try {
            await axios.post(url, payload);
        } catch (e) {
            console.error(`[CRM] Webhook delivery failed:`, e);
        }
    }

    private static async sendToHubSpot(dealerId: string, _lead: LeadData) {
        console.log(`[CRM] Sending lead to HubSpot for dealer ${dealerId}`);
        // Implement HubSpot OAuth / Private App API calls here
    }

    private static async sendToSalesforce(dealerId: string, _lead: LeadData) {
        console.log(`[CRM] Sending lead to Salesforce for dealer ${dealerId}`);
        // Implement Salesforce API calls here
    }
}
