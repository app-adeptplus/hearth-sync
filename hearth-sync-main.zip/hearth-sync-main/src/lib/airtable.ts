/* eslint-disable @typescript-eslint/no-explicit-any */
import Airtable from 'airtable';

// Initialize Airtable client
// Note: Requires AIRTABLE_API_KEY and AIRTABLE_BASE_ID in .env
const airtable = process.env.AIRTABLE_API_KEY
    ? new Airtable({ apiKey: process.env.AIRTABLE_API_KEY }).base(process.env.AIRTABLE_BASE_ID!)
    : null;

export interface AirtableDealerRecord {
    id?: string; // Airtable Record ID
    companyName: string;
    email: string;
    phone?: string;
    status: 'Active' | 'Onboarding' | 'Inactive';
    subscriptionTier: 'Basic' | 'Pro' | 'Enterprise';
    lastSyncDate?: string;
    supabaseUserId?: string;
}

export class AirtableClient {
    private static readonly TABLE_NAME = 'Dealers';

    /**
     * Fetch a dealer record by their Supabase User ID
     */
    static async getDealerByUserId(userId: string): Promise<AirtableDealerRecord | null> {
        if (!airtable) {
            console.warn('Airtable is not configured');
            return null;
        }

        try {
            const records = await airtable(this.TABLE_NAME)
                .select({
                    filterByFormula: `{SupabaseUserId} = '${userId}'`,
                    maxRecords: 1,
                })
                .firstPage();

            if (records.length === 0) return null;

            const record = records[0];
            return this.mapRecord(record);
        } catch (error) {
            console.error('Airtable fetch error:', error);
            return null;
        }
    }

    /**
     * Sync/Create a dealer record from Supabase Auth to Airtable
     */
    static async syncDealerRecord(dealer: AirtableDealerRecord): Promise<string | null> {
        if (!airtable) return null;

        try {
            if (dealer.id) {
                // Update existing
                await airtable(this.TABLE_NAME).update(dealer.id, {
                    'Company Name': dealer.companyName,
                    'Email': dealer.email,
                    'Phone': dealer.phone,
                    'Status': dealer.status,
                    'Subscription Tier': dealer.subscriptionTier,
                    'Last Sync': new Date().toISOString(),
                });
                return dealer.id;
            } else {
                // Create new
                const records = await airtable(this.TABLE_NAME).create([
                    {
                        fields: {
                            'Company Name': dealer.companyName,
                            'Email': dealer.email,
                            'Phone': dealer.phone,
                            'Status': dealer.status,
                            'Subscription Tier': dealer.subscriptionTier,
                            'SupabaseUserId': dealer.supabaseUserId,
                            'Last Sync': new Date().toISOString(),
                        },
                    },
                ]);
                return records[0].id;
            }
        } catch (error) {
            console.error('Airtable sync error:', error);
            return null;
        }
    }

    private static mapRecord(record: any): AirtableDealerRecord {
        return {
            id: record.id,
            companyName: record.get('Company Name') as string,
            email: record.get('Email') as string,
            phone: record.get('Phone') as string,
            status: record.get('Status') as 'Active' | 'Onboarding' | 'Inactive',
            subscriptionTier: record.get('Subscription Tier') as 'Basic' | 'Pro' | 'Enterprise',
            lastSyncDate: record.get('Last Sync') as string,
            supabaseUserId: record.get('SupabaseUserId') as string,
        };
    }
}
