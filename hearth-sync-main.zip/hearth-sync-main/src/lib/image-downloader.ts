/**
 * image-downloader.ts
 *
 * Downloads image URLs and uploads them to the configured storage service.
 * Returns stored URLs ready for ProductImage records.
 */

import { createHash } from 'crypto';
import { StorageService } from '@/lib/storage-service';

const MAX_FILE_SIZE = 10 * 1024 * 1024; // 10MB
const DOWNLOAD_TIMEOUT_MS = 10_000;
const RATE_LIMIT_MS = 200;

const CONTENT_TYPE_TO_EXT: Record<string, string> = {
    'image/jpeg':   'jpg',
    'image/jpg':    'jpg',
    'image/png':    'png',
    'image/webp':   'webp',
    'image/gif':    'gif',
    'image/avif':   'avif',
    'image/svg+xml':'svg',
};

export interface StoredImage {
    url: string;
    altText: string;
    sortOrder: number;
    fileHash: string;
}

/**
 * Download a list of image URLs and upload them to storage.
 * - Deduplicates within the batch by content hash.
 * - Never throws — failed images are collected in `errors` and skipped.
 */
export async function downloadAndStoreImages(
    imageUrls: string[],
    productSlug: string,
    storage: StorageService
): Promise<{ stored: StoredImage[]; errors: string[] }> {
    const stored: StoredImage[] = [];
    const errors: string[] = [];
    const seenHashes = new Set<string>();

    for (let i = 0; i < imageUrls.length; i++) {
        const url = imageUrls[i];

        if (i > 0) {
            await sleep(RATE_LIMIT_MS);
        }

        try {
            const controller = new AbortController();
            const timeout = setTimeout(() => controller.abort(), DOWNLOAD_TIMEOUT_MS);

            let response: Response;
            try {
                response = await fetch(url, { signal: controller.signal });
            } finally {
                clearTimeout(timeout);
            }

            if (!response.ok) {
                errors.push(`${url}: HTTP ${response.status}`);
                continue;
            }

            const rawContentType = response.headers.get('content-type') || '';
            const contentType = rawContentType.split(';')[0].trim().toLowerCase();
            const ext = CONTENT_TYPE_TO_EXT[contentType] ?? guessExtFromUrl(url);

            if (!ext) {
                errors.push(`${url}: unrecognized content type "${contentType}"`);
                continue;
            }

            const arrayBuffer = await response.arrayBuffer();

            if (arrayBuffer.byteLength > MAX_FILE_SIZE) {
                errors.push(`${url}: file too large (${(arrayBuffer.byteLength / 1024 / 1024).toFixed(1)}MB > 10MB)`);
                continue;
            }

            const buffer = Buffer.from(arrayBuffer);
            const hash = createHash('sha256').update(buffer).digest('hex').slice(0, 16);

            // Skip duplicate content within this batch
            if (seenHashes.has(hash)) {
                continue;
            }
            seenHashes.add(hash);

            const key = `products/${productSlug}/${hash}.${ext}`;
            const publicUrl = await storage.upload(key, buffer, contentType || `image/${ext}`);

            stored.push({
                url: publicUrl,
                altText: altTextFromUrl(url),
                sortOrder: stored.length,
                fileHash: hash,
            });
        } catch (err) {
            const msg = err instanceof Error ? err.message : String(err);
            errors.push(`${url}: ${msg}`);
        }
    }

    return { stored, errors };
}

function guessExtFromUrl(url: string): string | null {
    try {
        const pathname = new URL(url).pathname;
        const ext = pathname.split('.').pop()?.toLowerCase();
        if (!ext) return null;
        if (ext === 'jpeg') return 'jpg';
        if (['jpg', 'png', 'webp', 'gif', 'avif', 'svg'].includes(ext)) return ext;
    } catch { /* invalid URL */ }
    return null;
}

function altTextFromUrl(url: string): string {
    try {
        const pathname = new URL(url).pathname;
        const filename = pathname.split('/').pop() || '';
        return filename.replace(/\.[^.]+$/, '').replace(/[-_+]/g, ' ').trim();
    } catch {
        return '';
    }
}

function sleep(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
}
