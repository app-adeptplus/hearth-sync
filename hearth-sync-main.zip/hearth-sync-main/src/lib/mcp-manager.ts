/**
 * mcp-manager.ts
 *
 * Lightweight MCP (Model Context Protocol) server manager.
 * Handles tool discovery and caching for configured MCP servers.
 *
 * Supports: Streamable HTTP and SSE transports (external servers only).
 */

import prisma from '@/lib/db';
import { decryptSecret } from '@/lib/encryption';

export interface McpTool {
    name: string;
    description?: string;
    inputSchema?: Record<string, unknown>;
}

export interface McpServerStatus {
    id: string;
    name: string;
    reachable: boolean;
    tools: McpTool[];
    error?: string;
}

/**
 * Fetch the tool list from a single MCP server via Streamable HTTP (MCP JSON-RPC).
 */
export async function discoverTools(serverId: string): Promise<McpTool[]> {
    const server = await prisma.mcpServerConfig.findUnique({ where: { id: serverId } });
    if (!server) throw new Error(`MCP server ${serverId} not found`);

    const authHeaders: Record<string, string> = {};
    if (server.authToken) {
        const token = decryptSecret(server.authToken);
        authHeaders['Authorization'] = `Bearer ${token}`;
    }

    let endpoint = server.url;
    if (!endpoint.endsWith('/')) endpoint += '/';

    // MCP JSON-RPC: tools/list
    const response = await fetch(`${endpoint}`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            ...authHeaders,
        },
        body: JSON.stringify({
            jsonrpc: '2.0',
            id: 1,
            method: 'tools/list',
            params: {},
        }),
        signal: AbortSignal.timeout(8000),
    });

    if (!response.ok) {
        throw new Error(`MCP server returned ${response.status}`);
    }

    const data = await response.json();
    const tools: McpTool[] = data?.result?.tools ?? [];

    // Cache tools back to the DB
    await prisma.mcpServerConfig.update({
        where: { id: serverId },
        data: {
            discoveredTools: tools as any,
            toolsRefreshedAt: new Date(),
            lastError: null,
        },
    });

    return tools;
}

/**
 * Get all tools for the MCP servers linked to a given automation config.
 * Returns cached tools if available and fresh (within 1 hour).
 */
export async function getLinkedTools(automationId: string): Promise<{ server: string; tools: McpTool[] }[]> {
    const links = await prisma.mcpServerConfigLink.findMany({
        where: { automationId },
        include: { mcpServer: true },
    });

    const results: { server: string; tools: McpTool[] }[] = [];

    for (const link of links) {
        const srv = link.mcpServer;

        // Use cached tools if fresh (< 1 hour old)
        const cacheAge = srv.toolsRefreshedAt
            ? Date.now() - srv.toolsRefreshedAt.getTime()
            : Infinity;

        if (Array.isArray(srv.discoveredTools) && srv.discoveredTools.length > 0 && cacheAge < 3600_000) {
            results.push({ server: srv.name, tools: srv.discoveredTools as unknown as McpTool[] });
        } else {
            try {
                const tools = await discoverTools(srv.id);
                results.push({ server: srv.name, tools });
            } catch {
                // Use stale cache if live discovery fails
                results.push({
                    server: srv.name,
                    tools: Array.isArray(srv.discoveredTools) ? srv.discoveredTools as unknown as McpTool[] : [],
                });
            }
        }
    }

    return results;
}

/**
 * Test connectivity and tool discovery for all active MCP servers.
 */
export async function auditAllServers(): Promise<McpServerStatus[]> {
    const servers = await prisma.mcpServerConfig.findMany({ where: { isActive: true } });
    const results: McpServerStatus[] = [];

    for (const srv of servers) {
        try {
            const tools = await discoverTools(srv.id);
            results.push({ id: srv.id, name: srv.name, reachable: true, tools });
        } catch (e: any) {
            results.push({ id: srv.id, name: srv.name, reachable: false, tools: [], error: e.message });
        }
    }

    return results;
}
