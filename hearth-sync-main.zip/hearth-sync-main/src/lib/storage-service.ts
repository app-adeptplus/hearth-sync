/**
 * storage-service.ts
 *
 * Abstracted storage interface. Currently backed by Supabase Storage.
 * Swap to S3StorageService later without touching call sites.
 */

import { createServiceClient } from '@/lib/supabase';

export interface StorageService {
    /** Upload buffer and return the public URL. Idempotent (upsert). */
    upload(key: string, buffer: Buffer, contentType: string): Promise<string>;
    delete(key: string): Promise<void>;
}

const BUCKET = 'product-images';

export class SupabaseStorageService implements StorageService {
    private client = createServiceClient();

    async upload(key: string, buffer: Buffer, contentType: string): Promise<string> {
        const { error } = await this.client.storage
            .from(BUCKET)
            .upload(key, buffer, { contentType, upsert: true });

        if (error) {
            throw new Error(`Storage upload failed for "${key}": ${error.message}`);
        }

        const { data } = this.client.storage.from(BUCKET).getPublicUrl(key);
        return data.publicUrl;
    }

    async delete(key: string): Promise<void> {
        const { error } = await this.client.storage.from(BUCKET).remove([key]);
        if (error) {
            throw new Error(`Storage delete failed for "${key}": ${error.message}`);
        }
    }
}

export function getStorageService(): StorageService {
    return new SupabaseStorageService();
    // Future: return new S3StorageService();
}
