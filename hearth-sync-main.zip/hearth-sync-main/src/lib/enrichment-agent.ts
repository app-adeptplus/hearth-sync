/**
 * enrichment-agent.ts
 *
 * Core product data enrichment logic.
 * Normalizes names, model numbers, SKUs, and matches existing taxonomy.
 * Returns structured EnrichmentProposal data — never writes directly to DB.
 */

import Handlebars from 'handlebars';
import { callLlm } from './llm-client';
import { slugify } from './utils';
import prisma from '@/lib/db';

// ─── Types ───────────────────────────────────────────────────────────────────

export interface EnrichmentContext {
    brand: {
        id: string;
        name: string;
        brandSku: string | null;
    };
    categories: { id: string; name: string; slug: string; parentId: string | null; likeTerms: string | null }[];
    attributes: { id: string; name: string; slug: string; unit: string | null; dataType: string; options: string | null }[];
    optionGroups: { id: string; name: string; slug: string; options: { id: string; label: string; value: string }[] }[];
}

export interface ProposedData {
    name: string;
    modelNumber: string;
    sku: string;
    modelNumberIsGenerated: boolean;
    description?: string;
    descriptionSummary?: string;       // Clean 1-2 sentence description from LLM
    categoryIds: string[];            // IDs of matched existing categories
    attributeValues: { attributeId: string; attributeName: string; value: string }[];
    optionGroupIds: string[];          // IDs of matched existing option groups
    suggestedNewCategories: { name: string; parentCategoryName?: string; reason: string }[];
    suggestedNewAttributes: { name: string; unit?: string; dataType: string; reason: string }[];
    suggestedNewOptionGroups: { name: string; options: string[]; reason: string }[];
}

// ─── Resolved Agent Type ──────────────────────────────────────────────────────

export interface ResolvedAgent {
    id: string;
    label: string;
    promptTemplate: {
        id: string;
        systemPrompt: string;
        variables: any;
    } | null;
    llmConfig: {
        id: string;
        displayName: string | null;
        model: string;
    };
}

export interface RawProductInput {
    id?: string;           // Product.id if enriching an existing product
    name: string;
    modelNumber?: string | null;
    sku?: string | null;
    description?: string | null;
    categories?: { id: string; name: string }[];
    attributeValues?: { attributeId: string; value: string }[];
    rawText?: string;      // Extra text to give the LLM (from scrape)
}

// ─── Name Normalization ───────────────────────────────────────────────────────

export function normalizeProductName(brandName: string, rawName: string): string {
    const prefix = `${brandName} - `;
    // Strip existing prefix if already applied
    const cleaned = rawName.startsWith(prefix)
        ? rawName.slice(prefix.length).trim()
        : rawName
            .replace(new RegExp(`^${escapeRegex(brandName)}\\s*[-–—:]?\\s*`, 'i'), '')
            .trim();
    return `${brandName} - ${cleaned}`;
}

function escapeRegex(s: string) {
    return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

// ─── Model Number Normalization ───────────────────────────────────────────────

export function normalizeModelNumber(
    modelNumber: string | null | undefined,
    productName: string
): { value: string; isGenerated: boolean } {
    if (modelNumber && modelNumber.trim() && !modelNumber.startsWith('__')) {
        return { value: modelNumber.trim(), isGenerated: false };
    }
    // Generate from product name: abbreviate words + extract numbers
    const words = productName
        .replace(/[^a-zA-Z0-9 ]/g, ' ')
        .split(/\s+/)
        .filter(Boolean);

    const abbr = words
        .filter(w => /[a-zA-Z]/.test(w))
        .slice(0, 3)
        .map(w => w.toUpperCase().slice(0, 3))
        .join('');

    const nums = words.filter(w => /^\d+$/.test(w)).slice(0, 2).join('');
    return { value: `__${abbr}${nums || ''}`, isGenerated: true };
}

// ─── SKU Generation ───────────────────────────────────────────────────────────

export function generateSku(brandSku: string | null, modelNumber: string): string {
    const prefix = brandSku?.toUpperCase() || 'GEN';
    const model = modelNumber.replace(/^__/, '').toUpperCase();
    return `${prefix}-${model}`;
}

// ─── Fuzzy Category Match ─────────────────────────────────────────────────────

export function fuzzyMatchCategory(
    name: string,
    categories: EnrichmentContext['categories']
): string | null {
    const normalized = name.toLowerCase().trim();
    for (const cat of categories) {
        if (cat.name.toLowerCase() === normalized) return cat.id;
        if (cat.slug === slugify(name)) return cat.id;
        // Check likeTerms
        if (cat.likeTerms) {
            const terms = cat.likeTerms.toLowerCase().split(',').map(t => t.trim());
            if (terms.some(t => normalized.includes(t) || t.includes(normalized))) return cat.id;
        }
    }
    return null;
}

// ─── Fuzzy Attribute Match ────────────────────────────────────────────────────

export function fuzzyMatchAttribute(
    name: string,
    attributes: EnrichmentContext['attributes']
): string | null {
    const normalized = name.toLowerCase().trim();
    for (const attr of attributes) {
        if (attr.name.toLowerCase() === normalized) return attr.id;
        if (attr.slug === slugify(name)) return attr.id;
        // partial match
        if (attr.name.toLowerCase().includes(normalized) || normalized.includes(attr.name.toLowerCase())) {
            return attr.id;
        }
    }
    return null;
}

// ─── LLM Enrichment Prompt ───────────────────────────────────────────────────

function buildEnrichmentPrompt(
    product: RawProductInput,
    context: EnrichmentContext,
): string {
    const categoryList = context.categories
        .map(c => `- "${c.name}"${c.likeTerms ? ` (also known as: ${c.likeTerms})` : ''}`)
        .join('\n');

    const attributeList = context.attributes
        .map(a => `- "${a.name}"${a.unit ? ` [unit: ${a.unit}]` : ''}${a.options ? ` [options: ${a.options}]` : ''} (${a.dataType})`)
        .join('\n');

    const optionGroupList = context.optionGroups
        .map(g => `- "${g.name}" (options: ${g.options.map(o => o.label).join(', ')})`)
        .join('\n');

    return `You are a product data enrichment agent for a hearth and outdoor products catalog.

Brand: ${context.brand.name} (SKU prefix: ${context.brand.brandSku || 'N/A'})

Product to enrich:
- Name: ${product.name}
- Model Number: ${product.modelNumber || 'UNKNOWN'}
- Description: ${product.description || 'N/A'}
${product.rawText ? `- Additional page content:\n${product.rawText.slice(0, 3000)}` : ''}

EXISTING CATEGORIES (use ONLY these names, exactly as shown):
${categoryList || '(none loaded)'}

EXISTING ATTRIBUTES (use ONLY these names, exactly as shown):
${attributeList || '(none loaded)'}

EXISTING OPTION GROUPS (use ONLY these names, exactly as shown):
${optionGroupList || '(none loaded)'}

Return a JSON object with EXACTLY these fields:
{
  "normalized_name": "Clean product name without the brand prefix",
  "model_number": "The exact brand SKU/model number if found on the product page, else null",
  "proposed_categories": ["Exact Category Name from the list above"],
  "proposed_attributes": { "Exact Attribute Name": "value" },
  "proposed_option_groups": ["Exact Option Group Name"],
  "suggested_new_categories": [{ "name": "...", "parent_category_name": "...", "reason": "..." }],
  "suggested_new_attributes": [{ "name": "...", "unit": "...", "data_type": "text|number|boolean|select", "reason": "..." }],
  "suggested_new_option_groups": [{ "name": "...", "options": ["..."], "reason": "..." }]
}

RULES:
- proposed_categories: ONLY use exact names from the EXISTING CATEGORIES list. Zero is fine.
- proposed_attributes: ONLY use exact names from the EXISTING ATTRIBUTES list. Zero is fine.
- suggested_new_*: Only suggest truly new items NOT in the existing list. Keep suggestions minimal.
- Return ONLY the JSON object, no markdown, no explanation.`;
}

// ─── Resolve Enrichment Agent ─────────────────────────────────────────────────

export async function resolveEnrichmentAgent(): Promise<ResolvedAgent> {
    const assignment = await prisma.promptAssignment.findFirst({
        where: {
            serviceType: 'ENRICHMENT',
            serviceId: null,
            isActive: true,
        },
        include: {
            promptTemplate: true,
            llmConfig: true,
        },
    });

    if (!assignment) {
        throw new Error(
            'No active Enrichment Agent configured. Create one in System Services → Agents.'
        );
    }

    return {
        id: assignment.id,
        label: assignment.label,
        promptTemplate: assignment.promptTemplate
            ? {
                id: assignment.promptTemplate.id,
                systemPrompt: assignment.promptTemplate.systemPrompt,
                variables: assignment.promptTemplate.variables,
            }
            : null,
        llmConfig: {
            id: assignment.llmConfig.id,
            displayName: assignment.llmConfig.displayName,
            model: assignment.llmConfig.model,
        },
    };
}

// ─── Build Agent Prompt via Handlebars ────────────────────────────────────────

function buildAgentPrompt(
    agent: ResolvedAgent,
    product: RawProductInput,
    context: EnrichmentContext,
): string {
    if (!agent.promptTemplate) {
        // Fall back to hardcoded prompt if agent has no template
        return buildEnrichmentPrompt(product, context);
    }

    const categoryList = context.categories
        .map(c => `- "${c.name}"${c.likeTerms ? ` (also known as: ${c.likeTerms})` : ''}`)
        .join('\n');

    const attributeList = context.attributes
        .map(a => `- "${a.name}"${a.unit ? ` [unit: ${a.unit}]` : ''}${a.options ? ` [options: ${a.options}]` : ''} (${a.dataType})`)
        .join('\n');

    const optionGroupList = context.optionGroups
        .map(g => `- "${g.name}" (options: ${g.options.map(o => o.label).join(', ')})`)
        .join('\n');

    const vars = {
        brand_name: context.brand.name,
        brand_sku: context.brand.brandSku || 'N/A',
        product_name: product.name,
        product_model_number: product.modelNumber || 'UNKNOWN',
        product_sku: product.sku || '',
        product_description: product.description || 'N/A',
        raw_text: product.rawText?.slice(0, 3000) || '',
        category_context: categoryList || '(none loaded)',
        attribute_context: attributeList || '(none loaded)',
        option_group_context: optionGroupList || '(none loaded)',
    };

    const compiled = Handlebars.compile(agent.promptTemplate.systemPrompt, { strict: false });
    return compiled(vars);
}

// ─── Main Enrichment Function ─────────────────────────────────────────────────

function extractJson(text: string): Record<string, unknown> | null {
    try { return JSON.parse(text.trim()); } catch { /* continue */ }
    const fence = text.match(/```(?:json)?\s*([\s\S]*?)```/);
    if (fence) { try { return JSON.parse(fence[1].trim()); } catch { /* continue */ } }
    const obj = text.match(/\{[\s\S]*\}/);
    if (obj) { try { return JSON.parse(obj[0]); } catch { /* give up */ } }
    return null;
}

export async function enrichProduct(
    product: RawProductInput,
    context: EnrichmentContext,
    agent?: ResolvedAgent,
): Promise<{
    proposedData: ProposedData;
    confidence: number;
    notes: string;
}> {
    let prompt: string;
    let systemPrompt: string | undefined;
    const llmOptions: { maxTokens: number; temperature: number; llmConfigId?: string; systemPrompt?: string } = {
        maxTokens: 2000,
        temperature: 0.1,
    };

    if (agent) {
        // Use agent's Handlebars template as system prompt
        systemPrompt = buildAgentPrompt(agent, product, context);
        prompt = `Enrich this product and return the JSON response as instructed.`;
        llmOptions.llmConfigId = agent.llmConfig.id;
        llmOptions.systemPrompt = systemPrompt;
    } else {
        // Legacy fallback: hardcoded prompt as user message
        prompt = buildEnrichmentPrompt(product, context);
    }

    const llmResult = await callLlm(prompt, llmOptions);

    const parsed = extractJson(llmResult.text);
    if (!parsed) {
        throw new Error(`LLM returned unparseable response: ${llmResult.text.slice(0, 200)}`);
    }

    // Normalize name
    const llmName = (parsed.normalized_name as string) || product.name;
    const normalizedName = normalizeProductName(context.brand.name, llmName);

    // Model number
    const { value: modelNumber, isGenerated } = normalizeModelNumber(
        (parsed.model_number as string) || product.modelNumber,
        llmName
    );

    // SKU
    const sku = generateSku(context.brand.brandSku, modelNumber);

    // Match categories
    const proposedCategoryNames = (parsed.proposed_categories as string[]) || [];
    const categoryIds: string[] = [];
    for (const name of proposedCategoryNames) {
        const id = fuzzyMatchCategory(name, context.categories);
        if (id) categoryIds.push(id);
    }

    // Match attributes
    const proposedAttrs = (parsed.proposed_attributes as Record<string, string>) || {};
    const attributeValues: ProposedData['attributeValues'] = [];
    for (const [attrName, value] of Object.entries(proposedAttrs)) {
        const id = fuzzyMatchAttribute(attrName, context.attributes);
        if (id) {
            attributeValues.push({ attributeId: id, attributeName: attrName, value: String(value) });
        }
    }

    // Match option groups
    const proposedGroups = (parsed.proposed_option_groups as string[]) || [];
    const optionGroupIds: string[] = [];
    for (const name of proposedGroups) {
        const grp = context.optionGroups.find(g =>
            g.name.toLowerCase() === name.toLowerCase() || g.slug === slugify(name)
        );
        if (grp) optionGroupIds.push(grp.id);
    }

    // Collect new suggestions
    const suggestedNewCategories = ((parsed.suggested_new_categories as any[]) || []).map(s => ({
        name: s.name || '',
        parentCategoryName: s.parent_category_name,
        reason: s.reason || '',
    }));

    const suggestedNewAttributes = ((parsed.suggested_new_attributes as any[]) || []).map(s => ({
        name: s.name || '',
        unit: s.unit,
        dataType: s.data_type || 'text',
        reason: s.reason || '',
    }));

    const suggestedNewOptionGroups = ((parsed.suggested_new_option_groups as any[]) || []).map(s => ({
        name: s.name || '',
        options: Array.isArray(s.options) ? s.options : [],
        reason: s.reason || '',
    }));

    // Confidence score: 0–1 based on how many core fields were populated
    let score = 0;
    if (!isGenerated) score += 0.25;        // real model number found
    if (categoryIds.length > 0) score += 0.25;
    if (attributeValues.length > 0) score += 0.25;
    if (product.description && product.description.length > 50) score += 0.15;
    if (optionGroupIds.length > 0 || proposedGroups.length > 0) score += 0.10;
    const confidence = Math.min(Math.round(score * 100) / 100, 1.0);

    const descriptionSummary = (parsed.description_summary as string) || undefined;

    const proposedData: ProposedData = {
        name: normalizedName,
        modelNumber,
        sku,
        modelNumberIsGenerated: isGenerated,
        description: product.description || undefined,
        descriptionSummary,
        categoryIds,
        attributeValues,
        optionGroupIds,
        suggestedNewCategories,
        suggestedNewAttributes,
        suggestedNewOptionGroups,
    };

    const notes = `LLM matched ${categoryIds.length} categories, ${attributeValues.length} attributes, ${optionGroupIds.length} option groups. ${suggestedNewCategories.length + suggestedNewAttributes.length + suggestedNewOptionGroups.length} new taxonomy suggestions.`;

    return { proposedData, confidence, notes };
}
