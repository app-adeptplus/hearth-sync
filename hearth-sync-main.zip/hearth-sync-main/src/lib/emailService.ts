/* eslint-disable @typescript-eslint/no-explicit-any */
export interface EmailPayload {
    to: string;
    templateId: 'ESTIMATE_DELIVERY' | 'LEAD_NOTIFICATION' | 'WELCOME_EMAIL';
    data: Record<string, any>;
    dealerInfo?: {
        name: string;
        email: string;
        phone?: string;
    };
}

export class EmailService {
    /**
     * Mock SendGrid / Postmark email delivery service
     */
    static async sendTransactionalEmail(payload: EmailPayload): Promise<boolean> {
        console.log(`[EMAIL] Preparing to send ${payload.templateId} to ${payload.to}`);

        // In production, this would use @sendgrid/mail
        /*
          import sgMail from '@sendgrid/mail';
          sgMail.setApiKey(process.env.SENDGRID_API_KEY!);
          
          await sgMail.send({
            to: payload.to,
            from: 'system@hearthsync.com', // Verified sender
            templateId: process.env[`SENDGRID_TEMPLATE_${payload.templateId}`],
            dynamicTemplateData: {
              ...payload.data,
              dealer: payload.dealerInfo
            }
          });
        */

        // Simulate API delay
        await new Promise(resolve => setTimeout(resolve, 800));

        console.log(`[EMAIL] Successfully dispatched ${payload.templateId} to ${payload.to}`);
        return true;
    }

    /**
     * Specialized wrapper for Dealer Lead Notifications
     */
    static async notifyDealerOfNewLead(dealerEmail: string, leadName: string, projectType: string) {
        return this.sendTransactionalEmail({
            to: dealerEmail,
            templateId: 'LEAD_NOTIFICATION',
            data: { leadName, projectType },
        });
    }

    /**
     * Specialized wrapper for Consumer Estimate Delivery
     */
    static async deliverEstimateToConsumer(consumerEmail: string, estimatePdfUrl: string, dealerName: string) {
        return this.sendTransactionalEmail({
            to: consumerEmail,
            templateId: 'ESTIMATE_DELIVERY',
            data: { estimatePdfUrl },
            dealerInfo: { name: dealerName, email: '' }
        });
    }
}
