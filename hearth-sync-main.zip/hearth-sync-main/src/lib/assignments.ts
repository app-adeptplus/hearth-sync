/**
 * src/lib/assignments.ts
 *
 * Core helper for the PromptAssignment system.
 *
 * Usage:
 *   const assignment = await resolveAssignment('CHAT_BOT', 'categorization');
 *   const apiKey     = await decryptedApiKey(assignment);
 *   assertCanWrite(assignment, 'PRODUCT');
 */

import prisma from '@/lib/db';
import { AssignmentServiceType, AssignmentObjectEntity } from '@prisma/client';
import { decryptSecret, isEncrypted } from '@/lib/encryption';

// Re-export enums for convenience so callers don't need a separate import
export { AssignmentServiceType, AssignmentObjectEntity };

export type ResolvedAssignment = Awaited<ReturnType<typeof resolveAssignment>>;

/**
 * Resolve an assignment for a given service slot.
 * Resolution order (most-specific wins):
 *   1. assignment WHERE serviceType = X AND serviceId = <id>
 *   2. assignment WHERE serviceType = X AND serviceId IS NULL  (type-level default)
 *
 * Returns null if no active assignment is found.
 */
export async function resolveAssignment(
    serviceType: AssignmentServiceType,
    serviceId: string | null = null
) {
    const assignment = await prisma.promptAssignment.findFirst({
        where: {
            serviceType,
            serviceId: serviceId ?? undefined,
            isActive: true,
        },
        include: {
            promptTemplate: true,
            llmConfig: true,
            objectScopes: true,
            mcpLinks: { include: { mcpServer: true } },
        },
        orderBy: { createdAt: 'desc' },
    }) ?? (serviceId
        // Fallback to type-level default when a specific ID was given
        ? await prisma.promptAssignment.findFirst({
            where: { serviceType, serviceId: null, isActive: true },
            include: {
                promptTemplate: true,
                llmConfig: true,
                objectScopes: true,
                mcpLinks: { include: { mcpServer: true } },
            },
            orderBy: { createdAt: 'desc' },
        })
        : null);

    return assignment ?? null;
}

/**
 * Decrypt and return the plain-text API key for an assignment's LLM config.
 */
export function resolvedApiKey(assignment: ResolvedAssignment): string {
    if (!assignment) throw new Error('No assignment provided');
    const raw = assignment.llmConfig.apiKey;
    if (!raw) throw new Error(`LLM config "${assignment.llmConfig.displayName ?? assignment.llmConfig.provider}" has no API key stored.`);
    return isEncrypted(raw) ? decryptSecret(raw) : raw;
}

/**
 * Resolve the full prompt text for an assignment.
 * If a PromptTemplate is linked, returns its systemPrompt.
 * Returns null if no template is linked (caller should use fallback/inline instructions).
 */
export function resolvedPrompt(assignment: ResolvedAssignment): string | null {
    return assignment?.promptTemplate?.systemPrompt ?? null;
}

/**
 * Check if this assignment may read a given entity.
 * Throws if the scope is not granted.
 */
export function assertCanRead(assignment: ResolvedAssignment, entity: AssignmentObjectEntity): void {
    if (!assignment) throw new Error('No assignment');
    const scope = assignment.objectScopes.find(s => s.entity === entity);
    if (!scope?.canRead) {
        throw new Error(
            `Assignment "${assignment.label}" does not have read access to ${entity}. ` +
            `Update its Object Access Scopes in System Services → Assignments.`
        );
    }
}

/**
 * Check if this assignment may write to a given entity.
 * Throws if the scope is not granted.
 */
export function assertCanWrite(assignment: ResolvedAssignment, entity: AssignmentObjectEntity): void {
    if (!assignment) throw new Error('No assignment');
    const scope = assignment.objectScopes.find(s => s.entity === entity);
    if (!scope?.canWrite) {
        throw new Error(
            `Assignment "${assignment.label}" does not have write access to ${entity}. ` +
            `Update its Object Access Scopes in System Services → Assignments.`
        );
    }
}

/**
 * Returns the list of allowed MCP server IDs for this assignment.
 */
export function allowedMcpServerIds(assignment: ResolvedAssignment): string[] {
    return assignment?.mcpLinks.map(l => l.mcpServer.id) ?? [];
}
