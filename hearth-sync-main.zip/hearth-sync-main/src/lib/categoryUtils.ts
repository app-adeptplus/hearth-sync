/**
 * Utility for building a sorted, hierarchical category list for display in
 * SearchableMultiSelect or any other picker.
 *
 * Produces a flat array with parent categories first (sorted alphabetically),
 * each immediately followed by their children (also sorted alphabetically),
 * with a visual indent prefix on children.
 */
export interface CategoryNode {
    id: string;
    name: string;
    parentId?: string | null;
}

export interface CategoryOption {
    id: string;
    name: string;
}

/**
 * Given a flat list of categories with optional parentId relationships,
 * returns an ordered flat list suitable for a picker component:
 * - Top-level categories come first, sorted A→Z
 * - Each top-level category is immediately followed by its children, sorted A→Z
 * - Children are indented with a "└ " prefix
 * - Multi-level nesting (grandchildren etc.) uses "  └ " with extra indentation
 */
export function buildCategoryOptions(categories: CategoryNode[], depth = 0, parentId: string | null = null, prefix = ''): CategoryOption[] {
    const children = categories
        .filter(c => (c.parentId ?? null) === parentId)
        .sort((a, b) => a.name.localeCompare(b.name));

    const result: CategoryOption[] = [];
    for (const cat of children) {
        const indent = depth === 0 ? '' : prefix + '└ ';
        result.push({ id: cat.id, name: indent + cat.name });
        // Recurse for children of this node
        const grandchildren = buildCategoryOptions(categories, depth + 1, cat.id, prefix + '   ');
        result.push(...grandchildren);
    }
    return result;
}
