import { NextResponse, type NextRequest } from 'next/server';
import { createServerClient, type CookieOptions } from '@supabase/ssr';

export async function middleware(request: NextRequest) {
    let response = NextResponse.next({
        request: {
            headers: request.headers,
        },
    });

    const supabase = createServerClient(
        process.env.NEXT_PUBLIC_SUPABASE_URL!,
        process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
        {
            cookies: {
                get(name: string) {
                    return request.cookies.get(name)?.value;
                },
                set(name: string, value: string, options: CookieOptions) {
                    request.cookies.set({ name, value, ...options });
                    response = NextResponse.next({
                        request: { headers: request.headers },
                    });
                    response.cookies.set({ name, value, ...options });
                },
                remove(name: string, options: CookieOptions) {
                    request.cookies.set({ name, value: '', ...options });
                    response = NextResponse.next({
                        request: { headers: request.headers },
                    });
                    response.cookies.set({ name, value: '', ...options });
                },
            },
        }
    );

    const { data: { session } } = await supabase.auth.getSession();
    const pathname = request.nextUrl.pathname;

    // Protect /admin/* routes — require session + portal_role === 'admin'
    // Use exact match logic so paths like /admin-access-* (backdoor) aren't caught
    if (pathname === '/admin' || pathname.startsWith('/admin/')) {
        // Let the login page through
        if (pathname === '/admin/login') {
            // If already logged in as admin, skip the login page
            if (session) {
                const role =
                    (session.user?.app_metadata?.portal_role as string | undefined) ??
                    (session.user?.user_metadata?.portal_role as string | undefined);
                if (role === 'admin') {
                    return NextResponse.redirect(new URL('/admin', request.url));
                }
            }
            return response;
        }

        // No session → redirect to admin login
        if (!session) {
            return NextResponse.redirect(new URL('/admin/login', request.url));
        }

        // Session exists but not an admin → redirect to admin login
        // Check app_metadata first (secure/canonical), fall back to user_metadata for legacy admins
        // Allow untagged users (no portal_role) as admins — consistent with Admin Users page filter
        const role =
            (session.user?.app_metadata?.portal_role as string | undefined) ??
            (session.user?.user_metadata?.portal_role as string | undefined);
        // Allow: no role (legacy admin) OR explicit 'admin' role
        if (role && role !== 'admin') {
            return NextResponse.redirect(new URL('/admin/login', request.url));
        }
    }

    // Protect /dashboard routes → redirect to /login
    if (pathname.startsWith('/dashboard')) {
        if (!session) {
            return NextResponse.redirect(new URL('/login', request.url));
        }
    }

    // Protect /dealer/[slug]/* routes except login and auth callback
    const dealerMatch = pathname.match(/^\/dealer\/([^/]+)(\/.*)?$/);
    if (dealerMatch) {
        const rest = dealerMatch[2] ?? '';
        const isPublic =
            rest === '/login' ||
            rest === '' ||
            rest === '/' ||
            rest.startsWith('/auth/') ||   // /auth/callback handles PKCE exchange
            rest.startsWith('/view/');     // public catalog view pages

        if (!isPublic && !session) {
            const slug = dealerMatch[1];
            return NextResponse.redirect(new URL(`/dealer/${slug}/login`, request.url));
        }

        // Admin sessions pass through all dealer routes freely.
        // Dealer-to-dealer isolation is enforced in DealerLayout (Option B).
        if (!isPublic && session) {
            const role =
                (session.user?.app_metadata?.portal_role as string | undefined) ??
                (session.user?.user_metadata?.portal_role as string | undefined);
            // Admins (explicit or legacy untagged): pass through
            if (!role || role === 'admin') {
                return response;
            }
            // Dealer sessions: also pass through — layout does the ownership check
        }
    }

    // Redirect /login to /dashboard if already logged in (global login page)
    if (pathname === '/login') {
        if (session) {
            return NextResponse.redirect(new URL('/dashboard', request.url));
        }
    }

    return response;
}

export const config = {
    matcher: [
        /*
         * Match all request paths except for:
         * - _next/static (static files)
         * - _next/image (image optimization files)
         * - favicon.ico
         * - api routes (handled separately)
         * - admin-access-* (temporary testing backdoor — bypasses auth entirely)
         */
        '/((?!_next/static|_next/image|favicon.ico|api|admin-access-).*)',
    ],
};
