'use client';

import { useState, useEffect } from 'react';
import { useParams } from 'next/navigation';
import Link from 'next/link';

interface Lead {
    id: string;
    firstName: string;
    lastName: string;
    email: string;
    phone: string | null;
    zip: string | null;
    message: string | null;
    source: string;
    status: string;
    createdAt: string;
}

const STATUS_COLORS: Record<string, { bg: string; color: string }> = {
    NEW: { bg: 'rgba(17,138,178,0.12)', color: '#0369a1' },
    CONTACTED: { bg: 'rgba(245,158,11,0.12)', color: '#b45309' },
    QUALIFIED: { bg: 'rgba(34,197,94,0.12)', color: '#15803d' },
    CLOSED: { bg: 'rgba(113,128,150,0.12)', color: 'var(--dp-text-muted)' },
};

function formatDate(d: string) {
    return new Date(d).toLocaleDateString('en-US', {
        month: 'short', day: 'numeric', year: 'numeric',
        hour: '2-digit', minute: '2-digit',
    });
}

export default function DealerLeadsPage() {
    const params = useParams();
    const slug = params.slug as string;

    const [leads, setLeads] = useState<Lead[]>([]);
    const [total, setTotal] = useState(0);
    const [loading, setLoading] = useState(true);
    const [page, setPage] = useState(1);
    const [selected, setSelected] = useState<Lead | null>(null);

    useEffect(() => {
        const load = async () => {
            setLoading(true);
            try {
                const res = await fetch(`/api/dealer/${slug}/leads?page=${page}`);
                const data = await res.json();
                setLeads(data.leads ?? []);
                setTotal(data.total ?? 0);
            } finally {
                setLoading(false);
            }
        };
        load();
    }, [slug, page]);

    if (loading) {
        return (
            <div style={{ padding: '4rem', textAlign: 'center', color: 'var(--dp-text-muted)' }}>
                Loading leads…
            </div>
        );
    }

    return (
        <div style={{ maxWidth: '1200px', margin: '0 auto', padding: '2rem 1.5rem' }}>
            {/* Header */}
            <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: '1.75rem' }}>
                <div>
                    <h2 style={{ fontSize: '1.5rem', fontWeight: 700, color: 'var(--dp-text)', marginBottom: '0.25rem' }}>
                        Leads
                    </h2>
                    <p style={{ fontSize: '0.875rem', color: 'var(--dp-text-muted)' }}>
                        {total} lead{total !== 1 ? 's' : ''} captured from your catalogs
                    </p>
                </div>
            </div>

            {/* Empty state */}
            {leads.length === 0 ? (
                <div className="dp-card dp-empty" style={{ padding: '3rem 2rem' }}>
                    <div className="dp-empty-icon">📋</div>
                    <h3 style={{ fontSize: '1.125rem', fontWeight: 600, marginBottom: '0.375rem', color: 'var(--dp-text-secondary)' }}>
                        No leads yet
                    </h3>
                    <p style={{ fontSize: '0.875rem', marginBottom: '1.5rem' }}>
                        Enable the lead form on a catalog group to start capturing leads.
                    </p>
                    <Link href={`/dealer/${slug}/catalog`} className="dp-btn dp-btn-primary">
                        Go to Catalog Groups
                    </Link>
                </div>
            ) : (
                <div style={{ display: 'grid', gridTemplateColumns: selected ? '1fr 340px' : '1fr', gap: '1rem', alignItems: 'start' }}>
                    {/* Leads table */}
                    <div className="dp-card" style={{ padding: 0, overflow: 'hidden' }}>
                        <table className="dp-table">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Contact</th>
                                    <th>Status</th>
                                    <th>Source</th>
                                    <th>Date</th>
                                </tr>
                            </thead>
                            <tbody>
                                {leads.map((lead) => {
                                    const isSelected = selected?.id === lead.id;
                                    const statusStyle = STATUS_COLORS[lead.status] ?? STATUS_COLORS.NEW;
                                    return (
                                        <tr
                                            key={lead.id}
                                            onClick={() => setSelected(isSelected ? null : lead)}
                                            style={{
                                                cursor: 'pointer',
                                                background: isSelected ? 'var(--dp-primary-subtle)' : undefined,
                                            }}
                                        >
                                            <td style={{ fontWeight: 500, color: 'var(--dp-text)' }}>
                                                {lead.firstName} {lead.lastName}
                                            </td>
                                            <td style={{ fontSize: '0.8125rem', color: 'var(--dp-text-muted)' }}>
                                                <div>{lead.email}</div>
                                                {lead.phone && <div>{lead.phone}</div>}
                                            </td>
                                            <td>
                                                <span style={{
                                                    display: 'inline-flex', alignItems: 'center',
                                                    padding: '0.2rem 0.625rem', borderRadius: 9999,
                                                    fontSize: '0.6875rem', fontWeight: 600,
                                                    textTransform: 'uppercase', letterSpacing: '0.04em',
                                                    background: statusStyle.bg, color: statusStyle.color,
                                                }}>
                                                    {lead.status.charAt(0) + lead.status.slice(1).toLowerCase()}
                                                </span>
                                            </td>
                                            <td style={{ fontSize: '0.75rem', color: 'var(--dp-text-muted)', textTransform: 'capitalize' }}>
                                                {lead.source.replace(/_/g, ' ')}
                                            </td>
                                            <td style={{ fontSize: '0.75rem', color: 'var(--dp-text-muted)' }}>
                                                {formatDate(lead.createdAt)}
                                            </td>
                                        </tr>
                                    );
                                })}
                            </tbody>
                        </table>
                    </div>

                    {/* Lead detail panel */}
                    {selected && (
                        <div className="dp-card" style={{ padding: '1.25rem', position: 'sticky', top: 'calc(56px + 1rem)' }}>
                            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem' }}>
                                <h3 style={{ fontWeight: 600, fontSize: '1.0625rem', color: 'var(--dp-text)' }}>
                                    {selected.firstName} {selected.lastName}
                                </h3>
                                <button
                                    onClick={() => setSelected(null)}
                                    style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--dp-text-muted)', fontSize: '1.25rem', lineHeight: 1, padding: '0.125rem' }}
                                >✕</button>
                            </div>

                            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.875rem', fontSize: '0.875rem' }}>
                                {[
                                    { label: 'Email', value: selected.email },
                                    { label: 'Phone', value: selected.phone },
                                    { label: 'ZIP', value: selected.zip },
                                    { label: 'Source', value: selected.source.replace(/_/g, ' ') },
                                    { label: 'Submitted', value: formatDate(selected.createdAt) },
                                ].filter(r => r.value).map(({ label, value }) => (
                                    <div key={label}>
                                        <div style={{ fontSize: '0.6875rem', color: 'var(--dp-text-muted)', marginBottom: '2px', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.06em' }}>
                                            {label}
                                        </div>
                                        <div style={{ color: 'var(--dp-text-secondary)' }}>{value}</div>
                                    </div>
                                ))}

                                {selected.message && (
                                    <div>
                                        <div style={{ fontSize: '0.6875rem', color: 'var(--dp-text-muted)', marginBottom: '4px', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.06em' }}>
                                            Message
                                        </div>
                                        <p style={{ background: 'var(--dp-bg)', padding: '0.75rem', borderRadius: 8, border: '1px solid var(--dp-border)', lineHeight: 1.6, whiteSpace: 'pre-wrap', fontSize: '0.875rem', color: 'var(--dp-text-secondary)' }}>
                                            {selected.message}
                                        </p>
                                    </div>
                                )}
                            </div>

                            <div style={{ marginTop: '1.25rem', display: 'flex', gap: '0.5rem' }}>
                                <a href={`mailto:${selected.email}`} className="dp-btn dp-btn-primary" style={{ flex: 1, justifyContent: 'center', textDecoration: 'none' }}>
                                    Email Lead
                                </a>
                                {selected.phone && (
                                    <a href={`tel:${selected.phone}`} className="dp-btn dp-btn-secondary" style={{ textDecoration: 'none' }}>
                                        Call
                                    </a>
                                )}
                            </div>
                        </div>
                    )}
                </div>
            )}

            {/* Pagination */}
            {total > 50 && (
                <div style={{ display: 'flex', gap: '0.5rem', justifyContent: 'center', marginTop: '1.5rem', alignItems: 'center' }}>
                    <button className="dp-btn dp-btn-secondary dp-btn-sm" onClick={() => setPage(p => Math.max(1, p - 1))} disabled={page === 1}>
                        ← Previous
                    </button>
                    <span style={{ padding: '0.375rem 0.75rem', fontSize: '0.875rem', color: 'var(--dp-text-muted)' }}>
                        Page {page} of {Math.ceil(total / 50)}
                    </span>
                    <button className="dp-btn dp-btn-secondary dp-btn-sm" onClick={() => setPage(p => p + 1)} disabled={page * 50 >= total}>
                        Next →
                    </button>
                </div>
            )}
        </div>
    );
}
