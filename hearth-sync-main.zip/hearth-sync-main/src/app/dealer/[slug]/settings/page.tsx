/* eslint-disable @typescript-eslint/no-explicit-any */
'use client';

import { useState, useEffect } from 'react';
import { useParams } from 'next/navigation';
import Link from 'next/link';
import { createBrowserClient } from '@supabase/ssr';

interface DealerUser {
    id: string;
    email: string;
    role: string;
    userId: string | null;
    createdAt: string;
}

interface Dealer {
    id: string;
    companyName: string;
    contactName: string;
    phone: string | null;
    website: string | null;
    city: string | null;
    state: string | null;
    email: string;
    subscriptionTier: string;
}

const TABS = ['Profile', 'Password', 'Users'] as const;
type Tab = typeof TABS[number];

export default function DealerSettingsPage() {
    const params = useParams();
    const slug = params.slug as string;

    const [activeTab, setActiveTab] = useState<Tab>('Profile');
    const [dealer, setDealer] = useState<Dealer | null>(null);
    const [users, setUsers] = useState<DealerUser[]>([]);
    const [loading, setLoading] = useState(true);
    const [saving, setSaving] = useState(false);
    const [error, setError] = useState('');
    const [success, setSuccess] = useState('');

    // Profile form
    const [contactName, setContactName] = useState('');
    const [phone, setPhone] = useState('');
    const [website, setWebsite] = useState('');
    const [city, setCity] = useState('');
    const [state, setState] = useState('');

    // Password form
    const [newPassword, setNewPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');

    // Users form
    const [newUserEmail, setNewUserEmail] = useState('');
    const [newUserRole, setNewUserRole] = useState('member');
    const [inviteTempPassword, setInviteTempPassword] = useState('');

    useEffect(() => {
        const load = async () => {
            try {
                const res = await fetch(`/api/dealer/${slug}/settings`);
                const data = await res.json();
                if (!res.ok) throw new Error(data.error);
                setDealer(data.dealer);
                setUsers(data.users || []);
                setContactName(data.dealer.contactName ?? '');
                setPhone(data.dealer.phone ?? '');
                setWebsite(data.dealer.website ?? '');
                setCity(data.dealer.city ?? '');
                setState(data.dealer.state ?? '');
            } catch (err: any) {
                setError(err.message);
            } finally {
                setLoading(false);
            }
        };
        load();
    }, [slug]);

    const feedback = (msg: string, isError = false) => {
        if (isError) setError(msg);
        else { setSuccess(msg); setTimeout(() => setSuccess(''), 4000); }
    };

    const handleSaveProfile = async () => {
        setSaving(true); setError('');
        try {
            const res = await fetch(`/api/dealer/${slug}/settings`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ contactName, phone, website, city, state }),
            });
            const data = await res.json();
            if (!res.ok) throw new Error(data.error);
            setDealer(data.dealer);
            feedback('Profile updated.');
        } catch (err: any) { feedback(err.message, true); }
        setSaving(false);
    };

    const handleChangePassword = async () => {
        if (!newPassword || newPassword !== confirmPassword)
            return feedback("Passwords don't match or are empty.", true);
        if (newPassword.length < 8)
            return feedback("Password must be at least 8 characters.", true);
        setSaving(true); setError('');
        try {
            const supabase = createBrowserClient(
                process.env.NEXT_PUBLIC_SUPABASE_URL!,
                process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
            );
            const { error: pwError } = await supabase.auth.updateUser({ password: newPassword });
            if (pwError) throw new Error(pwError.message);
            setNewPassword(''); setConfirmPassword('');
            feedback('Password updated successfully.');
        } catch (err: any) { feedback(err.message, true); }
        setSaving(false);
    };

    const handleInviteUser = async () => {
        if (!newUserEmail.trim()) return;
        setSaving(true); setError(''); setInviteTempPassword('');
        try {
            const res = await fetch(`/api/dealer/${slug}/settings/users`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ email: newUserEmail.trim(), role: newUserRole }),
            });
            const data = await res.json();
            if (!res.ok) throw new Error(data.error);
            setUsers(prev => [...prev, data.user]);
            setNewUserEmail('');
            setInviteTempPassword(data.tempPassword || '');
        } catch (err: any) { feedback(err.message, true); }
        setSaving(false);
    };

    const handleRemoveUser = async (userId: string) => {
        if (!confirm('Remove this user from the portal?')) return;
        try {
            await fetch(`/api/dealer/${slug}/settings/users?userId=${userId}`, { method: 'DELETE' });
            setUsers(prev => prev.filter(u => u.id !== userId));
        } catch (err: any) { feedback(err.message, true); }
    };

    if (loading) return (
        <div style={{ padding: '4rem', textAlign: 'center', color: 'var(--dp-text-muted)' }}>Loading…</div>
    );

    return (
        <div style={{ maxWidth: '820px', margin: '0 auto', padding: '2rem 1.5rem' }}>
            {/* Header */}
            <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: '1.5rem' }}>
                <div>
                    <h2 style={{ fontSize: '1.5rem', fontWeight: 700, color: 'var(--dp-text)', marginBottom: '0.25rem' }}>Settings</h2>
                    <p style={{ fontSize: '0.875rem', color: 'var(--dp-text-muted)' }}>{dealer?.companyName}</p>
                </div>
                <Link href={`/dealer/${slug}/catalog`} className="dp-btn dp-btn-ghost">
                    ← Catalog
                </Link>
            </div>

            {/* Feedback banners */}
            {error && (
                <div style={{ padding: '0.75rem 1rem', background: 'rgba(239,68,68,0.08)', border: '1px solid rgba(239,68,68,0.25)', borderRadius: 10, color: '#ef4444', fontSize: '0.875rem', marginBottom: '1rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                    <span>✗</span> {error}
                </div>
            )}
            {success && (
                <div style={{ padding: '0.75rem 1rem', background: 'rgba(34,197,94,0.08)', border: '1px solid rgba(34,197,94,0.25)', borderRadius: 10, color: '#15803d', fontSize: '0.875rem', marginBottom: '1rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                    <span>✓</span> {success}
                </div>
            )}

            {/* Tabs */}
            <div className="dp-tabs">
                {TABS.map(tab => (
                    <button key={tab} onClick={() => setActiveTab(tab)} className={`dp-tab-btn${activeTab === tab ? ' active' : ''}`}>
                        {tab}
                    </button>
                ))}
            </div>

            {/* ── PROFILE TAB ── */}
            {activeTab === 'Profile' && (
                <div className="dp-card" style={{ padding: '1.5rem' }}>
                    <h3 style={{ fontWeight: 600, marginBottom: '1.25rem', fontSize: '1rem', color: 'var(--dp-text)' }}>
                        Profile Information
                    </h3>
                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
                        {[
                            { id: 'contact-name', label: 'Contact Name', type: 'text', value: contactName, onChange: setContactName, placeholder: '' },
                            { id: 'phone', label: 'Phone', type: 'tel', value: phone, onChange: setPhone, placeholder: '(555) 000-0000' },
                            { id: 'website', label: 'Website', type: 'url', value: website, onChange: setWebsite, placeholder: 'https://yourwebsite.com' },
                            { id: 'city', label: 'City', type: 'text', value: city, onChange: setCity, placeholder: '' },
                            { id: 'state-field', label: 'State', type: 'text', value: state, onChange: setState, placeholder: 'e.g. TN' },
                        ].map(f => (
                            <div key={f.id}>
                                <label className="dp-label" htmlFor={f.id}>{f.label}</label>
                                <input id={f.id} type={f.type} className="dp-input" value={f.value} onChange={(e) => f.onChange(e.target.value)} placeholder={f.placeholder} />
                            </div>
                        ))}
                    </div>
                    <div style={{ marginTop: '1.5rem', display: 'flex', justifyContent: 'flex-end' }}>
                        <button className="dp-btn dp-btn-primary" onClick={handleSaveProfile} disabled={saving}>
                            {saving ? 'Saving…' : 'Save Profile'}
                        </button>
                    </div>
                </div>
            )}

            {/* ── PASSWORD TAB ── */}
            {activeTab === 'Password' && (
                <div className="dp-card" style={{ padding: '1.5rem' }}>
                    <h3 style={{ fontWeight: 600, marginBottom: '0.375rem', fontSize: '1rem', color: 'var(--dp-text)' }}>Change Password</h3>
                    <p style={{ fontSize: '0.875rem', color: 'var(--dp-text-muted)', marginBottom: '1.25rem' }}>
                        Your new password must be at least 8 characters.
                    </p>
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem', maxWidth: '420px' }}>
                        <div>
                            <label className="dp-label" htmlFor="new-pw">New Password</label>
                            <input id="new-pw" type="password" className="dp-input" value={newPassword} onChange={(e) => setNewPassword(e.target.value)} placeholder="Min. 8 characters" />
                        </div>
                        <div>
                            <label className="dp-label" htmlFor="confirm-pw">Confirm Password</label>
                            <input id="confirm-pw" type="password" className="dp-input" value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} />
                            {newPassword && confirmPassword && newPassword !== confirmPassword && (
                                <p style={{ fontSize: '0.8125rem', color: '#ef4444', marginTop: '0.375rem' }}>Passwords don&apos;t match</p>
                            )}
                        </div>
                        <button className="dp-btn dp-btn-primary" style={{ alignSelf: 'flex-start' }} onClick={handleChangePassword} disabled={saving || !newPassword}>
                            {saving ? 'Updating…' : 'Update Password'}
                        </button>
                    </div>
                </div>
            )}

            {/* ── USERS TAB ── */}
            {activeTab === 'Users' && (
                <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                    {/* Invite user */}
                    <div className="dp-card" style={{ padding: '1.25rem' }}>
                        <h3 style={{ fontWeight: 600, marginBottom: '1rem', fontSize: '1rem', color: 'var(--dp-text)' }}>Invite a User</h3>
                        <div style={{ display: 'flex', gap: '0.75rem', alignItems: 'flex-end' }}>
                            <div style={{ flex: 1 }}>
                                <label className="dp-label" htmlFor="invite-email">Email Address</label>
                                <input id="invite-email" type="email" className="dp-input" value={newUserEmail} onChange={(e) => setNewUserEmail(e.target.value)} placeholder="user@example.com" />
                            </div>
                            <div>
                                <label className="dp-label" htmlFor="invite-role">Role</label>
                                <select id="invite-role" className="dp-select" value={newUserRole} onChange={(e) => setNewUserRole(e.target.value)} style={{ width: '120px' }}>
                                    <option value="member">Member</option>
                                    <option value="admin">Admin</option>
                                </select>
                            </div>
                            <button className="dp-btn dp-btn-primary" onClick={handleInviteUser} disabled={saving || !newUserEmail.trim()}>
                                Invite
                            </button>
                        </div>

                        {/* Temp password banner — shown once after a successful invite */}
                        {inviteTempPassword && (
                            <div style={{
                                marginTop: '1rem',
                                padding: '0.875rem 1rem',
                                background: 'rgba(34,197,94,0.08)',
                                border: '1px solid rgba(34,197,94,0.25)',
                                borderRadius: 10,
                            }}>
                                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.375rem' }}>
                                    <span style={{ fontWeight: 600, fontSize: '0.875rem', color: '#15803d' }}>✓ User created — share this temporary password:</span>
                                    <button
                                        className="dp-btn dp-btn-ghost dp-btn-sm"
                                        onClick={() => setInviteTempPassword('')}
                                        style={{ fontSize: '0.75rem', padding: '0.125rem 0.5rem' }}
                                    >
                                        Dismiss
                                    </button>
                                </div>
                                <div
                                    style={{
                                        fontFamily: 'monospace',
                                        fontSize: '1.125rem',
                                        fontWeight: 700,
                                        letterSpacing: '0.05em',
                                        color: 'var(--dp-text)',
                                        background: 'var(--dp-card-bg)',
                                        border: '1px solid var(--dp-card-border)',
                                        borderRadius: 6,
                                        padding: '0.5rem 0.75rem',
                                        cursor: 'pointer',
                                        userSelect: 'all',
                                    }}
                                    title="Click to select"
                                    onClick={(e) => {
                                        const range = document.createRange();
                                        range.selectNodeContents(e.currentTarget);
                                        window.getSelection()?.removeAllRanges();
                                        window.getSelection()?.addRange(range);
                                    }}
                                >
                                    {inviteTempPassword}
                                </div>
                                <p style={{ margin: '0.375rem 0 0', fontSize: '0.8125rem', color: 'var(--dp-text-muted)' }}>
                                    Ask the user to change this on their first login. This message will not appear again.
                                </p>
                            </div>
                        )}
                    </div>

                    {/* Users table */}
                    <div className="dp-card" style={{ padding: 0, overflow: 'hidden' }}>
                        <div style={{ padding: '0.75rem 1rem', borderBottom: '1px solid var(--dp-card-border)', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                            <span style={{ fontWeight: 600, fontSize: '0.9375rem', color: 'var(--dp-text)' }}>Portal Users</span>
                            <span style={{ fontSize: '0.8125rem', color: 'var(--dp-text-muted)' }}>{users.length} user{users.length !== 1 ? 's' : ''}</span>
                        </div>
                        <table className="dp-table">
                            <thead>
                                <tr>
                                    <th>Email</th>
                                    <th>Role</th>
                                    <th>Status</th>
                                    <th style={{ width: '80px' }}></th>
                                </tr>
                            </thead>
                            <tbody>
                                {users.length === 0 ? (
                                    <tr>
                                        <td colSpan={4} style={{ textAlign: 'center', color: 'var(--dp-text-muted)', padding: '2rem' }}>
                                            No users yet — invite someone above.
                                        </td>
                                    </tr>
                                ) : users.map((u) => (
                                    <tr key={u.id}>
                                        <td style={{ fontWeight: 500, color: 'var(--dp-text)' }}>{u.email}</td>
                                        <td style={{ textTransform: 'capitalize', color: 'var(--dp-text-muted)', fontSize: '0.875rem' }}>{u.role}</td>
                                        <td>
                                            <span style={{
                                                display: 'inline-flex', alignItems: 'center',
                                                padding: '0.2rem 0.625rem', borderRadius: 9999,
                                                fontSize: '0.6875rem', fontWeight: 600,
                                                textTransform: 'uppercase', letterSpacing: '0.04em',
                                                background: u.userId ? 'rgba(34,197,94,0.12)' : 'rgba(245,158,11,0.12)',
                                                color: u.userId ? '#15803d' : '#b45309',
                                            }}>
                                                {u.userId ? 'Active' : 'Invited'}
                                            </span>
                                        </td>
                                        <td>
                                            <button
                                                className="dp-btn dp-btn-ghost dp-btn-sm"
                                                style={{ color: '#ef4444' }}
                                                onClick={() => handleRemoveUser(u.id)}
                                            >
                                                Remove
                                            </button>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </div>
            )}
        </div>
    );
}
