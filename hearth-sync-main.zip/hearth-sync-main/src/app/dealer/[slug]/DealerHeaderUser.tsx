'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { createBrowserClient } from '@supabase/ssr';

interface Props {
    dealerSlug: string;
}

export default function DealerHeaderUser({ dealerSlug }: Props) {
    const router = useRouter();
    const [displayName, setDisplayName] = useState<string>('');
    const [isAdmin, setIsAdmin] = useState(false);

    useEffect(() => {
        const supabase = createBrowserClient(
            process.env.NEXT_PUBLIC_SUPABASE_URL!,
            process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
        );

        supabase.auth.getSession().then(({ data: { session } }) => {
            if (!session) return;

            const user = session.user;
            const fullName = user.user_metadata?.full_name as string | undefined;
            const email = user.email ?? '';
            const firstName = fullName
                ? fullName.split(' ')[0]
                : email.split('@')[0].replace(/[._-]/g, ' ').replace(/\b\w/g, c => c.toUpperCase());

            // Check portal_role — admins have 'admin' or no role (legacy)
            const role =
                (user.app_metadata?.portal_role as string | undefined) ??
                (user.user_metadata?.portal_role as string | undefined);
            const isAdminSession = !role || role === 'admin';

            setDisplayName(firstName);
            setIsAdmin(isAdminSession);
        });
    }, [dealerSlug]);

    if (!displayName) return null;

    return (
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
            {isAdmin && (
                <div style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '0.5rem',
                    padding: '0.25rem 0.75rem',
                    borderRadius: 9999,
                    background: 'rgba(233,69,96,0.12)',
                    border: '1px solid rgba(233,69,96,0.3)',
                    fontSize: '0.75rem',
                    color: 'var(--dp-primary)',
                    fontWeight: 600,
                }}>
                    <span>🔑</span>
                    <span>Admin View</span>
                    <span style={{ margin: '0 0.25rem', opacity: 0.4 }}>·</span>
                    <button
                        onClick={() => router.push('/admin/dealer-portal/dealers')}
                        style={{
                            background: 'none',
                            border: 'none',
                            color: 'var(--dp-primary)',
                            cursor: 'pointer',
                            fontSize: '0.75rem',
                            fontWeight: 600,
                            padding: 0,
                            textDecoration: 'underline',
                            textUnderlineOffset: '2px',
                        }}
                    >
                        ← Back to Admin
                    </button>
                </div>
            )}
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', fontSize: '0.875rem' }}>
                <span style={{ color: 'var(--dp-text-muted)' }}>Welcome,</span>
                <span style={{ fontWeight: 600, color: 'var(--dp-text)' }}>{displayName}</span>
            </div>
        </div>
    );
}
