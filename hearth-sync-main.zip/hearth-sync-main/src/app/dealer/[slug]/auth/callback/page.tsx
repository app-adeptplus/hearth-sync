'use client';

import { useEffect } from 'react';
import { useRouter, useParams, useSearchParams } from 'next/navigation';
import { createBrowserClient } from '@supabase/ssr';

export default function DealerAuthCallback() {
    const router = useRouter();
    const params = useParams();
    const searchParams = useSearchParams();
    const slug = params.slug as string;

    useEffect(() => {
        const handleAuth = async () => {
            const next = searchParams.get('next') ?? `/dealer/${slug}/catalog`;

            const supabase = createBrowserClient(
                process.env.NEXT_PUBLIC_SUPABASE_URL!,
                process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
            );

            // Handle PKCE flow: ?code= query param
            const code = searchParams.get('code');
            if (code) {
                const { error } = await supabase.auth.exchangeCodeForSession(code);
                if (!error) {
                    router.replace(next);
                    return;
                }
                console.error('[auth/callback] PKCE exchange error:', error.message);
            }

            // Handle implicit flow: #access_token=...&refresh_token=... in hash
            const hash = window.location.hash.slice(1); // remove leading '#'
            if (hash) {
                const hashParams = new URLSearchParams(hash);
                const access_token = hashParams.get('access_token');
                const refresh_token = hashParams.get('refresh_token');

                if (access_token && refresh_token) {
                    const { error } = await supabase.auth.setSession({ access_token, refresh_token });
                    if (!error) {
                        // Clear the hash and redirect
                        router.replace(next);
                        return;
                    }
                    console.error('[auth/callback] setSession error:', error.message);
                }
            }

            // Nothing worked — send to login
            router.replace(`/dealer/${slug}/login?error=auth_failed`);
        };

        handleAuth();
    }, []);

    return (
        <div style={{
            minHeight: '100vh',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            flexDirection: 'column',
            gap: 'var(--space-4)',
            color: 'var(--color-text-muted)',
        }}>
            <div style={{ fontSize: '2rem', animation: 'spin 1s linear infinite' }}>🔑</div>
            <p style={{ fontSize: 'var(--font-size-sm)' }}>Signing you in…</p>
            <style>{`@keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }`}</style>
        </div>
    );
}
