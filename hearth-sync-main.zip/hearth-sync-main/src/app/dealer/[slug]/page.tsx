import { notFound, redirect } from 'next/navigation';
import prisma from '@/lib/db';

interface PageProps {
    params: { slug: string };
}

async function getDealer(slugOrId: string) {
    // Try slug first, then ID fallback
    const dealer = await prisma.dealerAccount.findFirst({
        where: {
            OR: [
                { slug: slugOrId },
                { id: slugOrId },
            ],
        },
    });
    return dealer;
}

export default async function DealerLandingPage({ params }: PageProps) {
    const dealer = await getDealer(params.slug);

    if (!dealer) {
        notFound();
    }

    // If they hit the landing page, send them to login
    redirect(`/dealer/${params.slug}/login`);
}
