import { notFound, redirect } from 'next/navigation';
import { cookies } from 'next/headers';
import { createServerClient } from '@supabase/ssr';
import prisma from '@/lib/db';
import DealerNav from './DealerNav';
import DealerHeaderUser from './DealerHeaderUser';
import '@/styles/dealer-portal.css';

interface LayoutProps {
    children: React.ReactNode;
    params: { slug: string };
}

async function getDealer(slugOrId: string) {
    return prisma.dealerAccount.findFirst({
        where: {
            OR: [
                { slug: slugOrId },
                { id: slugOrId },
            ],
        },
    });
}

export default async function DealerLayout({ children, params }: LayoutProps) {
    const dealer = await getDealer(params.slug);
    if (!dealer) notFound();

    // ── Dealer-to-dealer isolation (Option B) ──────────────────────────────
    // Read the session server-side to enforce ownership without a DB hit in middleware.
    const cookieStore = cookies();
    const supabase = createServerClient(
        process.env.NEXT_PUBLIC_SUPABASE_URL!,
        process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
        {
            cookies: {
                get: (name) => cookieStore.get(name)?.value,
                set: () => {},    // read-only in a Server Component
                remove: () => {},
            },
        }
    );
    const { data: { session } } = await supabase.auth.getSession();

    if (session) {
        const role =
            (session.user?.app_metadata?.portal_role as string | undefined) ??
            (session.user?.user_metadata?.portal_role as string | undefined);

        // Dealer sessions must belong to THIS dealer
        if (role === 'dealer') {
            const userId = session.user.id;
            const membership = await prisma.dealerUser.findFirst({
                where: { userId, dealerId: dealer!.id },
                select: { id: true },
            });
            if (!membership) {
                // Valid dealer session but wrong dealer — send to their own login page
                redirect(`/dealer/${params.slug}/login`);
            }
        }
        // Admin sessions (role === 'admin' or no role) pass through without any extra check
    }
    // ──────────────────────────────────────────────────────────────────────

    return (
        <div className="dealer-portal dp-layout" id="dealer-portal-root">
            {/* Top header bar */}
            <header className="dp-header">
                <div className="dp-header-brand">
                    <span style={{ fontSize: '1.25rem' }}>🔥</span>
                    <span className="dp-header-company">{dealer!.companyName}</span>
                    <span className="dp-header-label">Dealer Portal</span>
                </div>
                {/* Welcome message + admin banner — reads session client-side */}
                <DealerHeaderUser dealerSlug={params.slug} />
            </header>

            {/* Body: sidebar + main content */}
            <div className="dp-body">
                <DealerNav slug={params.slug} companyName={dealer!.companyName} />
                <main className="dp-main">
                    {children}
                </main>
            </div>
        </div>
    );
}
