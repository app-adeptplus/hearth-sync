'use client';

import { useState } from 'react';
import { useRouter, useParams } from 'next/navigation';
import Link from 'next/link';
import { supabase } from '@/lib/supabase';

export default function DealerLoginPage() {
    const params = useParams();
    const slug = params.slug as string;
    const router = useRouter();
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');
    const [loading, setLoading] = useState(false);
    const [forgotMode, setForgotMode] = useState(false);
    const [forgotSent, setForgotSent] = useState(false);

    const handleLogin = async (e: React.FormEvent) => {
        e.preventDefault();
        setLoading(true);
        setError('');

        const { error: signInError } = await supabase.auth.signInWithPassword({ email, password });

        if (signInError) {
            setError(signInError.message);
            setLoading(false);
        } else {
            router.push(`/dealer/${slug}/catalog`);
            router.refresh();
        }
    };

    const handleForgotPassword = async (e: React.FormEvent) => {
        e.preventDefault();
        setLoading(true);
        setError('');
        const redirectTo = `${window.location.origin}/dealer/${slug}/catalog`;
        const { error: resetError } = await supabase.auth.resetPasswordForEmail(email, { redirectTo });
        setLoading(false);
        if (resetError) {
            setError(resetError.message);
        } else {
            setForgotSent(true);
        }
    };

    return (
        <div style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            minHeight: 'calc(100vh - 56px)',
            padding: 'var(--space-8)',
        }}>
            <div style={{
                width: '100%',
                maxWidth: '420px',
                background: 'var(--color-surface)',
                border: '1px solid var(--color-border)',
                borderRadius: 'var(--radius-xl)',
                padding: 'var(--space-8)',
                boxShadow: 'var(--shadow-lg)',
            }}>
                {!forgotMode ? (
                    <>
                        <div style={{ textAlign: 'center', marginBottom: 'var(--space-8)' }}>
                            <div style={{ fontSize: '2rem', marginBottom: 'var(--space-3)' }}>🔐</div>
                            <h1 style={{ fontSize: 'var(--font-size-xl)', fontWeight: 700, marginBottom: 'var(--space-1)' }}>
                                Sign In
                            </h1>
                            <p style={{ fontSize: 'var(--font-size-sm)', color: 'var(--color-text-muted)' }}>
                                Access your dealer portal
                            </p>
                        </div>

                        {error && (
                            <div style={{
                                padding: 'var(--space-3)',
                                background: 'rgba(239,68,68,0.1)',
                                border: '1px solid rgba(239,68,68,0.3)',
                                borderRadius: 'var(--radius-md)',
                                color: '#ef4444',
                                fontSize: 'var(--font-size-sm)',
                                marginBottom: 'var(--space-4)',
                            }}>
                                {error}
                            </div>
                        )}

                        <form onSubmit={handleLogin} style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-4)' }}>
                            <div className="form-group">
                                <label className="form-label" htmlFor="login-email">Email Address</label>
                                <input
                                    id="login-email"
                                    type="email"
                                    required
                                    className="form-input"
                                    placeholder="you@example.com"
                                    value={email}
                                    onChange={(e) => setEmail(e.target.value)}
                                />
                            </div>

                            <div className="form-group">
                                <label className="form-label" htmlFor="login-password">Password</label>
                                <input
                                    id="login-password"
                                    type="password"
                                    required
                                    className="form-input"
                                    placeholder="••••••••"
                                    value={password}
                                    onChange={(e) => setPassword(e.target.value)}
                                />
                            </div>

                            <button type="submit" className="btn btn-primary" disabled={loading} style={{ width: '100%', justifyContent: 'center' }}>
                                {loading ? 'Signing in…' : 'Sign In'}
                            </button>
                        </form>

                        <div style={{ textAlign: 'center', marginTop: 'var(--space-4)' }}>
                            <button
                                onClick={() => setForgotMode(true)}
                                style={{
                                    background: 'none',
                                    border: 'none',
                                    color: 'var(--color-primary)',
                                    cursor: 'pointer',
                                    fontSize: 'var(--font-size-sm)',
                                }}
                            >
                                Forgot password?
                            </button>
                        </div>
                    </>
                ) : (
                    <>
                        <div style={{ textAlign: 'center', marginBottom: 'var(--space-8)' }}>
                            <div style={{ fontSize: '2rem', marginBottom: 'var(--space-3)' }}>📧</div>
                            <h1 style={{ fontSize: 'var(--font-size-xl)', fontWeight: 700, marginBottom: 'var(--space-1)' }}>
                                Reset Password
                            </h1>
                            <p style={{ fontSize: 'var(--font-size-sm)', color: 'var(--color-text-muted)' }}>
                                {forgotSent ? 'Check your email for a reset link.' : "We'll send you a password reset link."}
                            </p>
                        </div>

                        {!forgotSent ? (
                            <>
                                {error && (
                                    <div style={{
                                        padding: 'var(--space-3)',
                                        background: 'rgba(239,68,68,0.1)',
                                        border: '1px solid rgba(239,68,68,0.3)',
                                        borderRadius: 'var(--radius-md)',
                                        color: '#ef4444',
                                        fontSize: 'var(--font-size-sm)',
                                        marginBottom: 'var(--space-4)',
                                    }}>
                                        {error}
                                    </div>
                                )}
                                <form onSubmit={handleForgotPassword} style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-4)' }}>
                                    <div className="form-group">
                                        <label className="form-label" htmlFor="forgot-email">Email Address</label>
                                        <input
                                            id="forgot-email"
                                            type="email"
                                            required
                                            className="form-input"
                                            value={email}
                                            onChange={(e) => setEmail(e.target.value)}
                                        />
                                    </div>
                                    <button type="submit" className="btn btn-primary" disabled={loading} style={{ width: '100%', justifyContent: 'center' }}>
                                        {loading ? 'Sending…' : 'Send Reset Link'}
                                    </button>
                                </form>
                            </>
                        ) : (
                            <div style={{
                                textAlign: 'center',
                                padding: 'var(--space-6)',
                                background: 'rgba(34,197,94,0.1)',
                                border: '1px solid rgba(34,197,94,0.3)',
                                borderRadius: 'var(--radius-md)',
                                color: '#22c55e',
                            }}>
                                ✓ Reset link sent to {email}
                            </div>
                        )}

                        <div style={{ textAlign: 'center', marginTop: 'var(--space-4)' }}>
                            <button
                                onClick={() => { setForgotMode(false); setForgotSent(false); setError(''); }}
                                style={{
                                    background: 'none',
                                    border: 'none',
                                    color: 'var(--color-text-muted)',
                                    cursor: 'pointer',
                                    fontSize: 'var(--font-size-sm)',
                                }}
                            >
                                ← Back to sign in
                            </button>
                        </div>
                    </>
                )}
            </div>
        </div>
    );
}
