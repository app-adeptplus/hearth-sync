'use client';

import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { createBrowserClient } from '@supabase/ssr';
import { useState, useEffect } from 'react';

interface DealerNavProps {
    slug: string;
    companyName: string;
}

/* SVG Icons — avoids emoji rendering issues */
const Icons = {
    catalog: (
        <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
            <rect x="1" y="1" width="5" height="5" rx="1" />
            <rect x="10" y="1" width="5" height="5" rx="1" />
            <rect x="1" y="10" width="5" height="5" rx="1" />
            <rect x="10" y="10" width="5" height="5" rx="1" />
        </svg>
    ),
    leads: (
        <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
            <rect x="2" y="2" width="12" height="12" rx="1.5" />
            <line x1="5" y1="5.5" x2="11" y2="5.5" />
            <line x1="5" y1="8" x2="11" y2="8" />
            <line x1="5" y1="10.5" x2="8.5" y2="10.5" />
        </svg>
    ),
    settings: (
        <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
            <circle cx="8" cy="8" r="2.5" />
            <path d="M8 1.5v1.25M8 13.25V14.5M14.5 8h-1.25M2.75 8H1.5M12.36 3.64l-.88.88M4.52 11.48l-.88.88M12.36 12.36l-.88-.88M4.52 4.52l-.88-.88" />
        </svg>
    ),
    signOut: (
        <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
            <path d="M6 2H3a1 1 0 0 0-1 1v10a1 1 0 0 0 1 1h3" />
            <polyline points="10.5 11.5 14 8 10.5 4.5" />
            <line x1="14" y1="8" x2="6" y2="8" />
        </svg>
    ),
    sun: (
        <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
            <circle cx="8" cy="8" r="3" />
            <line x1="8" y1="1" x2="8" y2="2.5" />
            <line x1="8" y1="13.5" x2="8" y2="15" />
            <line x1="1" y1="8" x2="2.5" y2="8" />
            <line x1="13.5" y1="8" x2="15" y2="8" />
            <line x1="3.22" y1="3.22" x2="4.28" y2="4.28" />
            <line x1="11.72" y1="11.72" x2="12.78" y2="12.78" />
            <line x1="12.78" y1="3.22" x2="11.72" y2="4.28" />
            <line x1="4.28" y1="11.72" x2="3.22" y2="12.78" />
        </svg>
    ),
    moon: (
        <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
            <path d="M13.5 10.5A6 6 0 0 1 5.5 2.5a6.5 6.5 0 1 0 8 8z" />
        </svg>
    ),
};

const NAV_ITEMS = [
    { href: 'catalog', label: 'Catalog Groups', icon: Icons.catalog },
    { href: 'leads', label: 'Leads', icon: Icons.leads },
    { href: 'settings', label: 'Settings', icon: Icons.settings },
] as const;

export default function DealerNav({ slug }: DealerNavProps) {
    const pathname = usePathname();
    const router = useRouter();
    const [loggingOut, setLoggingOut] = useState(false);
    const [theme, setTheme] = useState<'light' | 'dark'>('light');

    // Load theme from localStorage and apply to root element
    useEffect(() => {
        const stored = localStorage.getItem('dp-theme') as 'light' | 'dark' | null;
        const initial = stored ?? 'light';
        setTheme(initial);
        applyTheme(initial);
    }, []);

    function applyTheme(t: 'light' | 'dark') {
        const root = document.getElementById('dealer-portal-root');
        if (root) {
            root.setAttribute('data-dp-theme', t);
        }
    }

    const toggleTheme = () => {
        const next = theme === 'light' ? 'dark' : 'light';
        setTheme(next);
        applyTheme(next);
        localStorage.setItem('dp-theme', next);
    };

    const handleLogout = async () => {
        setLoggingOut(true);
        const supabase = createBrowserClient(
            process.env.NEXT_PUBLIC_SUPABASE_URL!,
            process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
        );
        await supabase.auth.signOut();
        router.push(`/dealer/${slug}/login`);
    };

    return (
        <aside className="dp-sidebar">
            <nav style={{ flex: 1, padding: '0 0.5rem' }}>
                <div className="dp-nav-section-label" style={{ padding: '0 0.75rem 0.5rem', marginBottom: 4 }}>
                    Portal
                </div>
                {NAV_ITEMS.map(({ href, label, icon }) => {
                    const fullHref = `/dealer/${slug}/${href}`;
                    const isActive = pathname.startsWith(fullHref);
                    return (
                        <Link
                            key={href}
                            href={fullHref}
                            className={`dp-nav-link${isActive ? ' active' : ''}`}
                        >
                            {icon}
                            {label}
                        </Link>
                    );
                })}
            </nav>

            <div className="dp-nav-footer">
                <button className="dp-theme-btn" onClick={toggleTheme} title="Toggle light/dark mode">
                    <span style={{ width: 16, height: 16, display: 'inline-flex' }}>
                        {theme === 'dark' ? Icons.sun : Icons.moon}
                    </span>
                    {theme === 'dark' ? 'Light Mode' : 'Dark Mode'}
                </button>
                <button
                    className="dp-signout-btn"
                    onClick={handleLogout}
                    disabled={loggingOut}
                >
                    <span style={{ width: 16, height: 16, display: 'inline-flex' }}>
                        {Icons.signOut}
                    </span>
                    {loggingOut ? 'Signing out…' : 'Sign Out'}
                </button>
            </div>
        </aside>
    );
}
