/* eslint-disable @typescript-eslint/no-explicit-any */
'use client';

import { useState } from 'react';

const FIELD_LABELS: Record<string, string> = {
    name: 'Full Name',
    email: 'Email Address',
    phone: 'Phone Number',
    zip: 'ZIP Code',
    productInterest: 'Product Interest',
    message: 'Message / Notes',
};

const FIELD_TYPES: Record<string, string> = {
    name: 'text',
    email: 'email',
    phone: 'tel',
    zip: 'text',
    productInterest: 'text',
    message: 'textarea',
};

interface LeadFormProps {
    groupId: string;
    dealerSlug: string;
    fields: string[];
}

export default function LeadForm({ groupId, dealerSlug, fields }: LeadFormProps) {
    const [values, setValues] = useState<Record<string, string>>({});
    const [submitting, setSubmitting] = useState(false);
    const [submitted, setSubmitted] = useState(false);
    const [error, setError] = useState('');

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setSubmitting(true);
        setError('');

        try {
            const res = await fetch(`/api/dealer/${dealerSlug}/leads`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ groupId, ...values }),
            });
            const data = await res.json();
            if (!res.ok) throw new Error(data.error || 'Failed to submit');
            setSubmitted(true);
        } catch (err: any) {
            setError(err.message);
        }
        setSubmitting(false);
    };

    if (submitted) {
        return (
            <div style={{
                textAlign: 'center',
                padding: 'var(--space-8)',
                background: 'rgba(34,197,94,0.08)',
                border: '1px solid rgba(34,197,94,0.2)',
                borderRadius: 'var(--radius-md)',
            }}>
                <div style={{ fontSize: '2rem', marginBottom: 'var(--space-3)' }}>✅</div>
                <p style={{ fontWeight: 600, color: '#22c55e', marginBottom: 'var(--space-2)' }}>
                    Thank you!
                </p>
                <p style={{ fontSize: 'var(--font-size-sm)', color: 'var(--color-text-muted)' }}>
                    We&apos;ve received your information and will be in touch shortly.
                </p>
            </div>
        );
    }

    return (
        <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-3)' }}>
            {fields.map((key) => {
                const label = FIELD_LABELS[key] ?? key;
                const type = FIELD_TYPES[key] ?? 'text';
                const isTextarea = type === 'textarea';

                return (
                    <div key={key} className="form-group" style={{ marginBottom: 0 }}>
                        <label className="form-label" htmlFor={`lead-${key}`}>{label}</label>
                        {isTextarea ? (
                            <textarea
                                id={`lead-${key}`}
                                className="form-input"
                                rows={3}
                                style={{ resize: 'vertical' }}
                                value={values[key] ?? ''}
                                onChange={(e) => setValues(prev => ({ ...prev, [key]: e.target.value }))}
                            />
                        ) : (
                            <input
                                id={`lead-${key}`}
                                type={type}
                                className="form-input"
                                value={values[key] ?? ''}
                                onChange={(e) => setValues(prev => ({ ...prev, [key]: e.target.value }))}
                                required={key === 'name' || key === 'email'}
                            />
                        )}
                    </div>
                );
            })}

            {error && (
                <div style={{ color: '#ef4444', fontSize: 'var(--font-size-sm)' }}>✗ {error}</div>
            )}

            <button
                type="submit"
                className="btn btn-primary"
                disabled={submitting}
                style={{ width: '100%', justifyContent: 'center', marginTop: 'var(--space-2)' }}
            >
                {submitting ? 'Submitting…' : 'Send Request'}
            </button>
        </form>
    );
}
