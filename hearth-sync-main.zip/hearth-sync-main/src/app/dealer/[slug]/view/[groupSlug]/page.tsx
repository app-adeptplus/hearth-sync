import { notFound } from 'next/navigation';
import prisma from '@/lib/db';
import type { Metadata } from 'next';
import LeadForm from './LeadForm';

interface PageProps {
    params: { slug: string; groupSlug: string };
}

async function getCatalogGroup(dealerSlug: string, groupSlug: string) {
    return prisma.dealerCatalogGroup.findFirst({
        where: {
            slug: groupSlug,
            isEnabled: true,
            dealer: {
                OR: [{ slug: dealerSlug }, { id: dealerSlug }],
            },
        },
        include: {
            dealer: { select: { companyName: true, website: true, phone: true, city: true, state: true } },
            products: {
                where: { isActive: true },
                orderBy: { sortOrder: 'asc' },
                include: {
                    product: {
                        include: {
                            images: { where: { isPrimary: true }, take: 1 },
                            brand: { select: { name: true } },
                            categories: { select: { name: true }, take: 2 },
                        },
                    },
                },
            },
        },
    });
}

export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
    const group = await getCatalogGroup(params.slug, params.groupSlug);
    if (!group) return { title: 'Catalog Not Found' };
    return {
        title: `${group.name} — ${group.dealer.companyName}`,
        description: group.description ?? `Browse ${group.name} from ${group.dealer.companyName}.`,
    };
}

export default async function PublicCatalogPage({ params }: PageProps) {
    const group = await getCatalogGroup(params.slug, params.groupSlug);
    if (!group) notFound();

    const products = group.products;
    const leadFields: string[] = Array.isArray(group.leadFormFields)
        ? group.leadFormFields as string[]
        : ['name', 'email', 'phone', 'message'];

    return (
        <div style={{ maxWidth: '1200px', margin: '0 auto', padding: 'var(--space-8) var(--space-6)' }}>
            {/* Custom CSS injection */}
            {group.customCss && (
                <style dangerouslySetInnerHTML={{ __html: group.customCss }} />
            )}

            {/* Header */}
            <div style={{ marginBottom: 'var(--space-8)', paddingBottom: 'var(--space-6)', borderBottom: '1px solid var(--color-border)' }}>
                <h1 style={{ fontSize: 'var(--font-size-2xl)', fontWeight: 700, marginBottom: 'var(--space-2)' }}>
                    {group.name}
                </h1>
                {group.description && (
                    <p style={{ fontSize: 'var(--font-size-base)', color: 'var(--color-text-muted)', maxWidth: '720px', lineHeight: 1.6 }}>
                        {group.description}
                    </p>
                )}
                <div style={{ marginTop: 'var(--space-3)', display: 'flex', gap: 'var(--space-4)', fontSize: 'var(--font-size-sm)', color: 'var(--color-text-muted)', flexWrap: 'wrap', alignItems: 'center' }}>
                    <span>🏢 {group.dealer.companyName}</span>
                    {group.dealer.city && group.dealer.state && (
                        <span>📍 {group.dealer.city}, {group.dealer.state}</span>
                    )}
                    {group.dealer.phone && <span>📞 {group.dealer.phone}</span>}
                    {group.dealer.website && (
                        <a href={group.dealer.website} target="_blank" rel="noopener noreferrer" style={{ color: 'var(--color-primary)' }}>
                            🌐 Visit Website
                        </a>
                    )}
                    <span style={{ marginLeft: 'auto', fontWeight: 500 }}>
                        {products.length} product{products.length !== 1 ? 's' : ''}
                    </span>
                </div>
            </div>

            <div style={{
                display: 'grid',
                gridTemplateColumns: group.leadFormEnabled ? '1fr 320px' : '1fr',
                gap: 'var(--space-8)',
                alignItems: 'start',
            }}>
                {/* Product Grid */}
                <div>
                    {products.length === 0 ? (
                        <div style={{ textAlign: 'center', padding: 'var(--space-16)', color: 'var(--color-text-muted)' }}>
                            <div style={{ fontSize: '3rem', marginBottom: 'var(--space-4)' }}>📦</div>
                            <p>No products in this catalog yet.</p>
                        </div>
                    ) : (
                        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(240px, 1fr))', gap: 'var(--space-5)' }}>
                            {products.map(({ product }) => (
                                <div
                                    key={product.id}
                                    className="card"
                                    style={{ padding: 0, overflow: 'hidden' }}
                                >
                                    {/* Product image */}
                                    <div style={{ aspectRatio: '4/3', background: 'var(--color-background)', overflow: 'hidden' }}>
                                        {product.images[0] ? (
                                            <img
                                                src={product.images[0].url}
                                                alt={product.name}
                                                style={{ width: '100%', height: '100%', objectFit: 'cover' }}
                                                loading="lazy"
                                            />
                                        ) : (
                                            <div style={{ width: '100%', height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '2.5rem', color: 'var(--color-border)' }}>
                                                🔥
                                            </div>
                                        )}
                                    </div>

                                    <div style={{ padding: 'var(--space-4)' }}>
                                        <div style={{ fontSize: 'var(--font-size-xs)', color: 'var(--color-text-muted)', marginBottom: 'var(--space-1)' }}>
                                            {product.brand.name}
                                            {product.categories[0] && ` · ${product.categories[0].name}`}
                                        </div>
                                        <h3 style={{ fontWeight: 600, fontSize: 'var(--font-size-sm)', lineHeight: 1.4, marginBottom: 'var(--space-2)' }}>
                                            {product.name}
                                        </h3>
                                        {product.modelNumber && (
                                            <div style={{ fontSize: 'var(--font-size-xs)', color: 'var(--color-text-muted)', fontFamily: 'monospace' }}>
                                                {product.modelNumber}
                                            </div>
                                        )}
                                        {product.shortDescription && (
                                            <p style={{ fontSize: 'var(--font-size-xs)', color: 'var(--color-text-muted)', marginTop: 'var(--space-2)', lineHeight: 1.5 }}>
                                                {product.shortDescription.slice(0, 120)}{product.shortDescription.length > 120 ? '…' : ''}
                                            </p>
                                        )}
                                        {product.priceMap && (
                                            <div style={{ fontWeight: 700, marginTop: 'var(--space-3)', fontSize: 'var(--font-size-sm)' }}>
                                                ${Number(product.priceMap).toLocaleString()}
                                            </div>
                                        )}
                                        {product.productUrl && (
                                            <a
                                                href={product.productUrl}
                                                target="_blank"
                                                rel="noopener noreferrer"
                                                style={{ display: 'inline-block', marginTop: 'var(--space-3)', fontSize: 'var(--font-size-xs)', color: 'var(--color-primary)', textDecoration: 'none', fontWeight: 500 }}
                                            >
                                                View Details →
                                            </a>
                                        )}
                                    </div>
                                </div>
                            ))}
                        </div>
                    )}
                </div>

                {/* Lead Generation Form */}
                {group.leadFormEnabled && (
                    <div className="card" style={{ padding: 'var(--space-6)', position: 'sticky', top: 'calc(var(--space-6) + 56px)' }}>
                        <h2 style={{ fontSize: 'var(--font-size-lg)', fontWeight: 700, marginBottom: 'var(--space-1)' }}>
                            {group.leadFormTitle || 'Request Information'}
                        </h2>
                        <p style={{ fontSize: 'var(--font-size-sm)', color: 'var(--color-text-muted)', marginBottom: 'var(--space-5)' }}>
                            Fill out the form below and we&apos;ll be in touch.
                        </p>
                        <LeadForm
                            groupId={group.id}
                            dealerSlug={params.slug}
                            fields={leadFields}
                        />
                    </div>
                )}
            </div>

            {/* Tracking Scripts (injected at bottom) */}
            {group.trackingScripts && (
                <div dangerouslySetInnerHTML={{ __html: group.trackingScripts }} />
            )}

            {/* Footer credit */}
            <div style={{ marginTop: 'var(--space-12)', paddingTop: 'var(--space-4)', borderTop: '1px solid var(--color-border)', fontSize: 'var(--font-size-xs)', color: 'var(--color-text-muted)', textAlign: 'center' }}>
                Powered by <a href="/" style={{ color: 'var(--color-primary)', textDecoration: 'none' }}>HearthSync</a>
            </div>
        </div>
    );
}
