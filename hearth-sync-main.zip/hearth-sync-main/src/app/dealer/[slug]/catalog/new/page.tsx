'use client';

import { useState } from 'react';
import { useRouter, useParams } from 'next/navigation';
import Link from 'next/link';
import CatalogGroupOnboardingWizard from '@/components/CatalogGroupOnboardingWizard';

export default function NewCatalogGroupPage() {
    const params = useParams();
    const slug = params.slug as string;
    const router = useRouter();

    const [name, setName] = useState('');
    const [description, setDescription] = useState('');
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState('');

    // Wizard state
    const [createdGroupId, setCreatedGroupId] = useState<string | null>(null);
    const [wizardOpen, setWizardOpen] = useState(false);

    const handleCreate = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!name.trim()) return;
        setLoading(true);
        setError('');
        try {
            const res = await fetch(`/api/dealer/${slug}/catalog`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ name: name.trim(), description: description.trim() }),
            });
            const data = await res.json();
            if (!res.ok) throw new Error(data.error);
            // Show onboarding wizard before navigating to the editor
            setCreatedGroupId(data.group.id);
            setWizardOpen(true);
        } catch (err: any) {
            setError(err.message);
            setLoading(false);
        }
    };

    const handleWizardComplete = () => {
        if (createdGroupId) {
            router.push(`/dealer/${slug}/catalog/${createdGroupId}`);
        }
    };

    return (
        <>
            <div style={{ maxWidth: '600px', margin: '0 auto', padding: '2rem 1.5rem' }}>
                {/* Breadcrumb + title */}
                <div style={{ marginBottom: '1.5rem' }}>
                    <div style={{ fontSize: '0.8125rem', color: 'var(--dp-text-muted)', marginBottom: '0.375rem' }}>
                        <Link href={`/dealer/${slug}/catalog`} style={{ color: 'var(--dp-text-muted)', textDecoration: 'none' }}>
                            Catalog
                        </Link>
                        {' / New Group'}
                    </div>
                    <h2 style={{ fontSize: '1.5rem', fontWeight: 700, color: 'var(--dp-text)' }}>
                        New Catalog Group
                    </h2>
                </div>

                {/* Form card */}
                <div className="dp-card" style={{ padding: '1.5rem' }}>
                    {error && (
                        <div style={{
                            padding: '0.75rem',
                            background: 'rgba(239,68,68,0.1)',
                            border: '1px solid rgba(239,68,68,0.3)',
                            borderRadius: 8,
                            color: '#ef4444',
                            fontSize: '0.875rem',
                            marginBottom: '1rem',
                        }}>
                            ✗ {error}
                        </div>
                    )}

                    <form onSubmit={handleCreate} style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                        <div>
                            <label className="dp-label" htmlFor="group-name">
                                Catalog Group Name <span style={{ color: '#ef4444' }}>*</span>
                            </label>
                            <input
                                id="group-name"
                                type="text"
                                className="dp-input"
                                placeholder="e.g. Gas Fireplaces, Wood Stoves, Outdoor Living…"
                                value={name}
                                onChange={(e) => setName(e.target.value)}
                                required
                                autoFocus
                            />
                            <p style={{ fontSize: '0.75rem', color: 'var(--dp-text-muted)', marginTop: '0.25rem' }}>
                                This will also be used as the catalog&apos;s URL slug.
                            </p>
                        </div>

                        <div>
                            <label className="dp-label" htmlFor="group-desc">
                                Description{' '}
                                <span style={{ color: 'var(--dp-text-muted)', fontWeight: 400 }}>(optional)</span>
                            </label>
                            <textarea
                                id="group-desc"
                                className="dp-input"
                                placeholder="A brief description shown to customers…"
                                value={description}
                                onChange={(e) => setDescription(e.target.value)}
                                rows={3}
                                style={{ resize: 'vertical' }}
                            />
                        </div>

                        <div style={{ display: 'flex', gap: '0.75rem', justifyContent: 'flex-end', marginTop: '0.5rem' }}>
                            <Link href={`/dealer/${slug}/catalog`} className="dp-btn dp-btn-secondary">
                                Cancel
                            </Link>
                            <button
                                type="submit"
                                className="dp-btn dp-btn-primary"
                                disabled={loading || !name.trim()}
                            >
                                {loading ? 'Creating…' : 'Create Catalog Group'}
                            </button>
                        </div>
                    </form>
                </div>
            </div>

            {/* Onboarding wizard — shown after group is created */}
            {createdGroupId && (
                <CatalogGroupOnboardingWizard
                    isOpen={wizardOpen}
                    slug={slug}
                    groupId={createdGroupId}
                    onComplete={handleWizardComplete}
                />
            )}
        </>
    );
}

