'use client';

import { useState, useEffect, useCallback, useRef } from 'react';
import { useRouter, useParams } from 'next/navigation';
import Link from 'next/link';

interface Brand { id: string; name: string; }
interface Category { id: string; name: string; parentId: string | null; }

interface Product {
    id: string;
    name: string;
    modelNumber: string | null;
    brand: { id: string; name: string };
    categories?: { id: string; name: string }[];
    images: { url: string }[];
}

interface GroupProduct {
    id: string;
    sortOrder: number;
    isActive: boolean;
    customPrice: number | null;
    product: Product;
}

interface CatalogGroup {
    id: string;
    name: string;
    description: string | null;
    slug: string;
    isEnabled: boolean;
    embedCode: string | null;
    customCss: string | null;
    trackingScripts: string | null;
    leadFormEnabled: boolean;
    leadFormTitle: string | null;
    leadFormFields: string[] | null;
    products: GroupProduct[];
}

const ALL_LEAD_FIELDS = [
    { key: 'name', label: 'Full Name' },
    { key: 'email', label: 'Email Address' },
    { key: 'phone', label: 'Phone Number' },
    { key: 'zip', label: 'ZIP Code' },
    { key: 'productInterest', label: 'Product Interest' },
    { key: 'message', label: 'Message / Notes' },
];

const TABS = ['Products', 'Lead Generation', 'Custom CSS', 'Tracking Scripts', 'Embed Code'] as const;
type Tab = typeof TABS[number];

export default function CatalogGroupEditor() {
    const params = useParams();
    const slug = params.slug as string;
    const groupId = params.groupId as string;
    const router = useRouter();

    const [group, setGroup] = useState<CatalogGroup | null>(null);
    const [loading, setLoading] = useState(true);
    const [saving, setSaving] = useState(false);
    const [error, setError] = useState('');
    const [success, setSuccess] = useState('');
    const [activeTab, setActiveTab] = useState<Tab>('Products');

    // Form state
    const [name, setName] = useState('');
    const [description, setDescription] = useState('');
    const [isEnabled, setIsEnabled] = useState(false);
    const [customCss, setCustomCss] = useState('');
    const [trackingScripts, setTrackingScripts] = useState('');
    const [leadFormEnabled, setLeadFormEnabled] = useState(false);
    const [leadFormTitle, setLeadFormTitle] = useState('Request Information');
    const [leadFormFields, setLeadFormFields] = useState<string[]>(['name', 'email', 'phone', 'message']);

    // Filter state
    const [brands, setBrands] = useState<Brand[]>([]);
    const [categories, setCategories] = useState<Category[]>([]);
    const [productSearch, setProductSearch] = useState('');
    const [selectedBrandId, setSelectedBrandId] = useState('');
    const [selectedCategoryId, setSelectedCategoryId] = useState('');
    const [searchResults, setSearchResults] = useState<Product[]>([]);
    const [searchLoading, setSearchLoading] = useState(false);
    const [searchTotal, setSearchTotal] = useState(0);
    const [removingId, setRemovingId] = useState('');
    const searchTimeout = useRef<ReturnType<typeof setTimeout>>();

    const load = useCallback(async () => {
        setLoading(true);
        try {
            const res = await fetch(`/api/dealer/${slug}/catalog/${groupId}`);
            const data = await res.json();
            if (!res.ok) throw new Error(data.error);
            setGroup(data.group);
            setName(data.group.name);
            setDescription(data.group.description ?? '');
            setIsEnabled(data.group.isEnabled);
            setCustomCss(data.group.customCss ?? '');
            setTrackingScripts(data.group.trackingScripts ?? '');
            setLeadFormEnabled(data.group.leadFormEnabled);
            setLeadFormTitle(data.group.leadFormTitle ?? 'Request Information');
            setLeadFormFields(data.group.leadFormFields ?? ['name', 'email', 'phone', 'message']);
        } catch (err: any) {
            setError(err.message);
        } finally {
            setLoading(false);
        }
    }, [slug, groupId]);

    // Load filter options (brands + categories)
    useEffect(() => {
        Promise.all([
            fetch('/api/brands').then(r => r.json()).catch(() => ({ data: [] })),
            fetch('/api/categories').then(r => r.json()).catch(() => ({ data: [] })),
        ]).then(([bData, cData]) => {
            setBrands(bData.data ?? []);
            setCategories(cData.data ?? []);
        });

    }, []);

    useEffect(() => { load(); }, [load]);

    // Search active products with debounce — runs whenever query/filters change
    const searchProducts = useCallback(async (q: string, brandId: string, categoryId: string) => {
        setSearchLoading(true);
        try {
            const params = new URLSearchParams({ status: 'ACTIVE', limit: '20' });
            if (q.trim()) params.set('q', q.trim());
            if (brandId) params.set('brand', brandId);
            if (categoryId) params.append('category', categoryId);

            const res = await fetch(`/api/products?${params}`);
            const data = await res.json();
            setSearchResults(data.data ?? []);
            setSearchTotal(data.pagination?.total ?? 0);
        } catch {
            setSearchResults([]);
        }
        setSearchLoading(false);
    }, []);

    // Auto-search on tab open and filter changes
    useEffect(() => {
        if (activeTab !== 'Products') return;
        clearTimeout(searchTimeout.current);
        searchTimeout.current = setTimeout(() => {
            searchProducts(productSearch, selectedBrandId, selectedCategoryId);
        }, 300);
        return () => clearTimeout(searchTimeout.current);
    }, [productSearch, selectedBrandId, selectedCategoryId, activeTab, searchProducts]);

    const handleSave = async () => {
        setSaving(true);
        setError('');
        setSuccess('');
        try {
            const res = await fetch(`/api/dealer/${slug}/catalog/${groupId}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ name, description, isEnabled, customCss, trackingScripts, leadFormEnabled, leadFormTitle, leadFormFields }),
            });
            const data = await res.json();
            if (!res.ok) throw new Error(data.error);
            setGroup((prev) => prev ? { ...prev, ...data.group } : data.group);
            setSuccess('Changes saved.');
            setTimeout(() => setSuccess(''), 3000);
        } catch (err: any) {
            setError(err.message);
        } finally {
            setSaving(false);
        }
    };

    const handleAddProduct = async (productId: string) => {
        try {
            const res = await fetch(`/api/dealer/${slug}/catalog/${groupId}/products`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ productId }),
            });
            const data = await res.json();
            if (!res.ok) throw new Error(data.error);
            load();
        } catch (err: any) {
            setError(err.message);
        }
    };

    const handleRemoveProduct = async (productId: string) => {
        setRemovingId(productId);
        try {
            await fetch(`/api/dealer/${slug}/catalog/${groupId}/products/${productId}`, { method: 'DELETE' });
            setGroup((prev) => prev ? { ...prev, products: prev.products.filter(p => p.product.id !== productId) } : prev);
        } catch (err: any) {
            setError(err.message);
        }
        setRemovingId('');
    };

    const toggleLeadField = (key: string) => {
        setLeadFormFields(prev => prev.includes(key) ? prev.filter(f => f !== key) : [...prev, key]);
    };

    if (loading) {
        return (
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '4rem' }}>
                <span style={{ color: 'var(--dp-text-muted, #718096)' }}>Loading catalog group…</span>
            </div>
        );
    }

    if (!group) return null;

    const productCount = group.products.length;
    const addedIds = new Set(group.products.map(gp => gp.product.id));

    return (
        <div style={{ maxWidth: '1100px', margin: '0 auto', padding: '1.5rem' }}>

            {/* Header */}
            <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: '1.5rem', gap: '1rem', flexWrap: 'wrap' }}>
                <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontSize: '0.8125rem', color: 'var(--dp-text-muted)', marginBottom: '0.5rem' }}>
                        <Link href={`/dealer/${slug}/catalog`} style={{ color: 'var(--dp-text-muted)', textDecoration: 'none' }}>
                            Catalog
                        </Link>
                        {' / '}
                        <span style={{ color: 'var(--dp-text)' }}>{group.name}</span>
                    </div>
                    <input
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        className="dp-input"
                        style={{ fontSize: '1.375rem', fontWeight: 700, background: 'transparent', border: 'none', padding: 0, outline: 'none', boxShadow: 'none', width: '100%', maxWidth: '500px', color: 'var(--dp-text)' }}
                        placeholder="Catalog Group Name"
                    />
                </div>
                <div style={{ display: 'flex', gap: '0.5rem', alignItems: 'center', flexShrink: 0 }}>
                    <span style={{
                        display: 'inline-flex', alignItems: 'center', gap: '0.375rem',
                        padding: '0.375rem 0.75rem', borderRadius: 8,
                        fontSize: '0.8125rem', fontWeight: 500,
                        background: isEnabled ? 'rgba(34,197,94,0.1)' : 'rgba(113,128,150,0.1)',
                        color: isEnabled ? '#15803d' : 'var(--dp-text-muted)',
                    }}>
                        <span style={{ width: 7, height: 7, borderRadius: '50%', background: isEnabled ? '#22c55e' : 'var(--dp-text-muted)', display: 'inline-block' }} />
                        {isEnabled ? 'Live' : 'Draft'}
                    </span>
                    <button className={`dp-btn dp-btn-sm ${isEnabled ? 'dp-btn-danger' : 'dp-btn-secondary'}`}
                        onClick={() => setIsEnabled(!isEnabled)}>
                        {isEnabled ? 'Disable' : 'Enable'}
                    </button>
                    {error && <span style={{ color: '#ef4444', fontSize: '0.8125rem' }}>✗ {error}</span>}
                    {success && <span style={{ color: '#22c55e', fontSize: '0.8125rem' }}>✓ {success}</span>}
                    <button className="dp-btn dp-btn-primary" onClick={handleSave} disabled={saving}>
                        {saving ? 'Saving…' : 'Save Changes'}
                    </button>
                </div>
            </div>

            <div style={{ marginBottom: '1rem' }}>
                <textarea
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    className="dp-input"
                    placeholder="Brief description of this catalog group…"
                    rows={2}
                    style={{ resize: 'vertical' }}
                />
            </div>

            {/* Tabs */}
            <div className="dp-tabs">
                {TABS.map((tab) => (
                    <button
                        key={tab}
                        onClick={() => setActiveTab(tab)}
                        className={`dp-tab-btn${activeTab === tab ? ' active' : ''}`}
                    >
                        {tab === 'Products' ? `Products (${productCount}/1000)` : tab}
                    </button>
                ))}
            </div>

            {/* === PRODUCTS TAB === */}
            {activeTab === 'Products' && (
                <div>
                    {/* Search + Filters */}
                    <div className="dp-search-panel">
                        <div style={{ display: 'grid', gridTemplateColumns: '1fr auto auto', gap: '0.75rem', alignItems: 'center' }}>
                            <div style={{ position: 'relative' }}>
                                <svg style={{ position: 'absolute', left: '0.75rem', top: '50%', transform: 'translateY(-50%)', width: 15, height: 15, color: 'var(--dp-text-muted)' }}
                                    viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.5">
                                    <circle cx="6.5" cy="6.5" r="4.5" /><line x1="10.5" y1="10.5" x2="14" y2="14" />
                                </svg>
                                <input
                                    type="text"
                                    className="dp-input"
                                    style={{ paddingLeft: '2.25rem' }}
                                    placeholder="Search products by name, model, SKU…"
                                    value={productSearch}
                                    onChange={(e) => setProductSearch(e.target.value)}
                                    disabled={productCount >= 1000}
                                />
                            </div>
                            <select
                                className="dp-select"
                                style={{ width: '180px' }}
                                value={selectedBrandId}
                                onChange={(e) => setSelectedBrandId(e.target.value)}
                            >
                                <option value="">All Brands</option>
                                {brands.map(b => <option key={b.id} value={b.id}>{b.name}</option>)}
                            </select>
                            <select
                                className="dp-select"
                                style={{ width: '180px' }}
                                value={selectedCategoryId}
                                onChange={(e) => setSelectedCategoryId(e.target.value)}
                            >
                                <option value="">All Categories</option>
                                {categories.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                            </select>
                        </div>

                        {/* Filter summary */}
                        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginTop: '0.625rem', fontSize: '0.8125rem', color: 'var(--dp-text-muted)' }}>
                            <span>
                                {searchLoading ? 'Searching…' : `${searchTotal.toLocaleString()} active products`}
                                {selectedBrandId || selectedCategoryId || productSearch ? ' matching filters' : ' available'}
                            </span>
                            {(selectedBrandId || selectedCategoryId || productSearch) && (
                                <button className="dp-btn dp-btn-ghost dp-btn-sm"
                                    onClick={() => { setProductSearch(''); setSelectedBrandId(''); setSelectedCategoryId(''); }}>
                                    Clear filters
                                </button>
                            )}
                        </div>

                        {/* Search results panel */}
                        {!searchLoading && searchResults.length > 0 && (
                            <div className="dp-search-results" style={{ marginTop: '0.75rem' }}>
                                {searchResults.map((p) => {
                                    const already = addedIds.has(p.id);
                                    return (
                                        <div
                                            key={p.id}
                                            className={`dp-search-result-item${already ? ' already-added' : ''}`}
                                            onClick={() => !already && productCount < 1000 && handleAddProduct(p.id)}
                                        >
                                            {p.images[0] ? (
                                                <img src={p.images[0].url} alt={p.name} className="dp-product-thumb" />
                                            ) : (
                                                <div className="dp-product-thumb-placeholder">📦</div>
                                            )}
                                            <div style={{ flex: 1, minWidth: 0 }}>
                                                <div style={{ fontWeight: 500, fontSize: '0.875rem', color: 'var(--dp-text)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                                                    {p.name}
                                                </div>
                                                <div style={{ fontSize: '0.75rem', color: 'var(--dp-text-muted)' }}>
                                                    {p.brand.name}{p.modelNumber ? ` · ${p.modelNumber}` : ''}
                                                    {p.categories?.length ? ` · ${p.categories[0].name}` : ''}
                                                </div>
                                            </div>
                                            <span style={{ fontSize: '0.8125rem', color: already ? 'var(--dp-text-muted)' : 'var(--dp-primary)', whiteSpace: 'nowrap', fontWeight: 500 }}>
                                                {already ? '✓ Added' : '+ Add'}
                                            </span>
                                        </div>
                                    );
                                })}
                                {searchTotal > 20 && (
                                    <div style={{ padding: '0.625rem 0.875rem', fontSize: '0.8125rem', color: 'var(--dp-text-muted)', textAlign: 'center', borderTop: '1px solid var(--dp-border-light)' }}>
                                        Showing 20 of {searchTotal.toLocaleString()} results — refine your search to narrow down
                                    </div>
                                )}
                            </div>
                        )}

                        {!searchLoading && searchResults.length === 0 && (productSearch || selectedBrandId || selectedCategoryId) && (
                            <div style={{ marginTop: '0.75rem', padding: '1rem', textAlign: 'center', fontSize: '0.875rem', color: 'var(--dp-text-muted)' }}>
                                No active products match your filters
                            </div>
                        )}
                    </div>

                    {/* Added products list */}
                    {group.products.length === 0 ? (
                        <div className="dp-empty">
                            <div className="dp-empty-icon">📦</div>
                            <p style={{ fontWeight: 500, marginBottom: '0.25rem', color: 'var(--dp-text-secondary)' }}>No products added yet</p>
                            <p style={{ fontSize: '0.875rem' }}>Search above or browse to add products to this catalog group.</p>
                        </div>
                    ) : (
                        <div className="dp-card" style={{ padding: 0, overflow: 'hidden' }}>
                            <div style={{ padding: '0.75rem 1rem', borderBottom: '1px solid var(--dp-card-border)', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                                <span style={{ fontWeight: 600, fontSize: '0.9375rem', color: 'var(--dp-text)' }}>
                                    {productCount} Product{productCount !== 1 ? 's' : ''} in this Group
                                </span>
                                <span style={{ fontSize: '0.8125rem', color: 'var(--dp-text-muted)' }}>{productCount}/1,000 used</span>
                            </div>
                            <table className="dp-table">
                                <thead>
                                    <tr>
                                        <th>Product</th>
                                        <th>Brand</th>
                                        <th>Model</th>
                                        <th>Status</th>
                                        <th style={{ width: '80px' }}></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {group.products.map((gp) => (
                                        <tr key={gp.id}>
                                            <td>
                                                <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                                                    {gp.product.images[0] ? (
                                                        <img src={gp.product.images[0].url} alt={gp.product.name} className="dp-product-thumb" style={{ width: 36, height: 36 }} />
                                                    ) : (
                                                        <div className="dp-product-thumb-placeholder" style={{ width: 36, height: 36, fontSize: '1rem' }}>📦</div>
                                                    )}
                                                    <span style={{ fontWeight: 500, fontSize: '0.875rem', color: 'var(--dp-text)' }}>{gp.product.name}</span>
                                                </div>
                                            </td>
                                            <td>{gp.product.brand.name}</td>
                                            <td>{gp.product.modelNumber ?? '—'}</td>
                                            <td>
                                                <span className={`dp-badge ${gp.isActive ? 'dp-badge-active' : 'dp-badge-inactive'}`}>
                                                    {gp.isActive ? 'Active' : 'Hidden'}
                                                </span>
                                            </td>
                                            <td>
                                                <button
                                                    className="dp-btn dp-btn-ghost dp-btn-sm"
                                                    style={{ color: '#ef4444' }}
                                                    onClick={() => handleRemoveProduct(gp.product.id)}
                                                    disabled={removingId === gp.product.id}
                                                >
                                                    {removingId === gp.product.id ? '…' : 'Remove'}
                                                </button>
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    )}
                </div>
            )}

            {/* === LEAD GENERATION TAB === */}
            {activeTab === 'Lead Generation' && (
                <div className="dp-card" style={{ padding: '1.5rem' }}>
                    <h3 style={{ fontWeight: 600, marginBottom: '0.375rem', color: 'var(--dp-text)' }}>Lead Generation Form</h3>
                    <p style={{ fontSize: '0.875rem', color: 'var(--dp-text-muted)', marginBottom: '1.25rem' }}>
                        Enable a contact form on your catalog so visitors can request more information.
                    </p>

                    <label className="dp-toggle-wrap" style={{ marginBottom: '1.25rem' }}>
                        <input type="checkbox" checked={leadFormEnabled} onChange={(e) => setLeadFormEnabled(e.target.checked)} />
                        <span style={{ fontWeight: 500, fontSize: '0.9375rem', color: 'var(--dp-text)' }}>Enable lead generation form</span>
                    </label>

                    {leadFormEnabled && (
                        <>
                            <div style={{ marginBottom: '1rem' }}>
                                <label className="dp-label" htmlFor="lead-form-title">Form Title</label>
                                <input id="lead-form-title" type="text" className="dp-input"
                                    value={leadFormTitle} onChange={(e) => setLeadFormTitle(e.target.value)}
                                    placeholder="Request Information" />
                            </div>
                            <div>
                                <label className="dp-label" style={{ marginBottom: '0.5rem', display: 'block' }}>Form Fields</label>
                                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.5rem' }}>
                                    {ALL_LEAD_FIELDS.map((f) => (
                                        <label key={f.key} style={{
                                            display: 'flex', alignItems: 'center', gap: '0.5rem',
                                            padding: '0.75rem', cursor: 'pointer',
                                            border: `1px solid ${leadFormFields.includes(f.key) ? 'var(--dp-primary)' : 'var(--dp-border)'}`,
                                            borderRadius: 8,
                                            background: leadFormFields.includes(f.key) ? 'var(--dp-primary-subtle)' : 'transparent',
                                            transition: 'all 0.12s',
                                        }}>
                                            <input type="checkbox" checked={leadFormFields.includes(f.key)} onChange={() => toggleLeadField(f.key)} />
                                            <span style={{ fontSize: '0.875rem', fontWeight: 500, color: 'var(--dp-text)' }}>{f.label}</span>
                                        </label>
                                    ))}
                                </div>
                            </div>
                        </>
                    )}
                </div>
            )}

            {/* === CUSTOM CSS TAB === */}
            {activeTab === 'Custom CSS' && (
                <div className="dp-card" style={{ padding: '1.5rem' }}>
                    <h3 style={{ fontWeight: 600, marginBottom: '0.375rem', color: 'var(--dp-text)' }}>Custom CSS</h3>
                    <p style={{ fontSize: '0.875rem', color: 'var(--dp-text-muted)', marginBottom: '1rem' }}>
                        Add custom CSS to style your catalog embed. These styles will be injected into the catalog widget on your website.
                    </p>
                    <textarea value={customCss} onChange={(e) => setCustomCss(e.target.value)} className="dp-input"
                        placeholder={`/* Custom styles */\n.hearth-catalog { font-family: 'Arial'; }`}
                        rows={16} style={{ fontFamily: 'monospace', fontSize: '0.875rem', resize: 'vertical', minHeight: '300px' }} />
                </div>
            )}

            {/* === TRACKING SCRIPTS TAB === */}
            {activeTab === 'Tracking Scripts' && (
                <div className="dp-card" style={{ padding: '1.5rem' }}>
                    <h3 style={{ fontWeight: 600, marginBottom: '0.375rem', color: 'var(--dp-text)' }}>Tracking Scripts</h3>
                    <p style={{ fontSize: '0.875rem', color: 'var(--dp-text-muted)', marginBottom: '1rem' }}>
                        Add Google Analytics, Meta Pixel, or other tracking scripts.
                    </p>
                    <div style={{ padding: '0.75rem', background: 'rgba(245,158,11,0.08)', border: '1px solid rgba(245,158,11,0.25)', borderRadius: 8, marginBottom: '1rem', fontSize: '0.8125rem', color: 'var(--dp-text-secondary)' }}>
                        ⚠️ Only paste scripts from trusted providers. Raw HTML is injected as-is.
                    </div>
                    <textarea value={trackingScripts} onChange={(e) => setTrackingScripts(e.target.value)} className="dp-input"
                        placeholder={`<!-- Google Analytics -->\n<script async src="https://www.googletagmanager.com/gtag/js?id=G-XXXXXX"></script>`}
                        rows={16} style={{ fontFamily: 'monospace', fontSize: '0.875rem', resize: 'vertical', minHeight: '300px' }} />
                </div>
            )}

            {/* === EMBED CODE TAB === */}
            {activeTab === 'Embed Code' && (
                <div className="dp-card" style={{ padding: '1.5rem' }}>
                    <h3 style={{ fontWeight: 600, marginBottom: '0.375rem', color: 'var(--dp-text)' }}>Embed Code</h3>
                    {!isEnabled ? (
                        <div style={{ padding: '2.5rem 1.5rem', textAlign: 'center', background: 'var(--dp-bg)', borderRadius: 10, border: '2px dashed var(--dp-border)', marginTop: '1rem' }}>
                            <div style={{ fontSize: '2rem', marginBottom: '0.75rem' }}>💡</div>
                            <p style={{ fontWeight: 600, marginBottom: '0.375rem', color: 'var(--dp-text)' }}>Enable this catalog to generate an embed code</p>
                            <p style={{ fontSize: '0.875rem', color: 'var(--dp-text-muted)', marginBottom: '1.25rem' }}>
                                Toggle "Enable" in the header and save to generate a unique embed code.
                            </p>
                            <button className="dp-btn dp-btn-primary" onClick={() => { setIsEnabled(true); handleSave(); }}>
                                Enable &amp; Generate Code
                            </button>
                        </div>
                    ) : (
                        <>
                            <p style={{ fontSize: '0.875rem', color: 'var(--dp-text-muted)', marginBottom: '1rem' }}>
                                Copy and paste this snippet into your website's HTML where you want the catalog to appear.
                            </p>
                            <div style={{ position: 'relative' }}>
                                <pre className="dp-code">{group.embedCode || '(Save to generate embed code)'}</pre>
                                <button className="dp-btn dp-btn-secondary dp-btn-sm"
                                    style={{ position: 'absolute', top: '0.75rem', right: '0.75rem' }}
                                    onClick={() => navigator.clipboard.writeText(group.embedCode ?? '')}>
                                    Copy
                                </button>
                            </div>
                            <div style={{ marginTop: '1rem', padding: '1rem', background: 'rgba(34,197,94,0.08)', border: '1px solid rgba(34,197,94,0.2)', borderRadius: 10 }}>
                                <p style={{ fontSize: '0.875rem', fontWeight: 600, color: '#22c55e', marginBottom: '0.25rem' }}>✓ Catalog is live</p>
                                <p style={{ fontSize: '0.8125rem', color: 'var(--dp-text-muted)' }}>This catalog group is enabled and will display wherever the embed code is installed.</p>
                            </div>
                        </>
                    )}
                </div>
            )}
        </div>
    );
}
