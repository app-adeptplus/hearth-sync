import { notFound, redirect } from 'next/navigation';
import Link from 'next/link';
import prisma from '@/lib/db';
import { createServerClient, type CookieOptions } from '@supabase/ssr';
import { cookies } from 'next/headers';

interface PageProps {
    params: { slug: string };
}

const TIER_LIMITS: Record<string, number> = {
    STARTER: 5,
    PROFESSIONAL: 10,
    ENTERPRISE: 20,
};

async function getDealer(slugOrId: string) {
    return prisma.dealerAccount.findFirst({
        where: { OR: [{ slug: slugOrId }, { id: slugOrId }] },
        include: {
            catalogGroups: {
                orderBy: { sortOrder: 'asc' },
                include: { _count: { select: { products: true } } },
            },
        },
    });
}

export default async function DealerCatalogPage({ params }: PageProps) {
    const cookieStore = cookies();
    const supabase = createServerClient(
        process.env.NEXT_PUBLIC_SUPABASE_URL!,
        process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
        {
            cookies: {
                get(name: string) { return cookieStore.get(name)?.value; },
                set(name: string, value: string, options: CookieOptions) { cookieStore.set({ name, value, ...options }); },
                remove(name: string, options: CookieOptions) { cookieStore.delete({ name, ...options }); },
            },
        }
    );
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) redirect(`/dealer/${params.slug}/login`);

    const dealer = await getDealer(params.slug);
    if (!dealer) notFound();

    const limit = TIER_LIMITS[dealer.subscriptionTier] ?? 5;
    const groups = dealer.catalogGroups;
    const tierLabel = dealer.subscriptionTier.charAt(0) + dealer.subscriptionTier.slice(1).toLowerCase();

    return (
        <div style={{ maxWidth: '1200px', margin: '0 auto', padding: '2rem 1.5rem' }}>
            {/* Header */}
            <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: '2rem' }}>
                <div>
                    <h2 style={{ fontSize: '1.5rem', fontWeight: 700, color: 'var(--dp-text)', marginBottom: '0.25rem' }}>
                        Catalog Groups
                    </h2>
                    <p style={{ fontSize: '0.875rem', color: 'var(--dp-text-muted)' }}>
                        {groups.length} of {limit} groups used · {tierLabel} plan
                    </p>
                </div>
                {groups.length < limit && (
                    <Link href={`/dealer/${params.slug}/catalog/new`} className="dp-btn dp-btn-primary">
                        + New Catalog Group
                    </Link>
                )}
            </div>

            {/* Empty state */}
            {groups.length === 0 ? (
                <div className="dp-card dp-empty" style={{ padding: '3rem 2rem' }}>
                    <div className="dp-empty-icon">📚</div>
                    <h3 style={{ fontSize: '1.125rem', fontWeight: 600, marginBottom: '0.375rem', color: 'var(--dp-text-secondary)' }}>
                        No catalog groups yet
                    </h3>
                    <p style={{ fontSize: '0.875rem', marginBottom: '1.5rem' }}>
                        Create your first catalog group to start building your product catalog.
                    </p>
                    <Link href={`/dealer/${params.slug}/catalog/new`} className="dp-btn dp-btn-primary">
                        Create Your First Catalog Group
                    </Link>
                </div>
            ) : (
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))', gap: '1rem' }}>
                    {groups.map((group) => (
                        <div key={group.id} className="dp-card" style={{ padding: '1.25rem' }}>
                            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '0.75rem' }}>
                                <div style={{ flex: 1, minWidth: 0 }}>
                                    <h3 style={{ fontWeight: 600, marginBottom: '0.25rem', color: 'var(--dp-text)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                                        {group.name}
                                    </h3>
                                    {group.description && (
                                        <p style={{ fontSize: '0.8125rem', color: 'var(--dp-text-muted)', lineHeight: 1.4 }}>
                                            {group.description.slice(0, 80)}{group.description.length > 80 ? '…' : ''}
                                        </p>
                                    )}
                                </div>
                                <span className={`dp-badge ${group.isEnabled ? 'dp-badge-active' : 'dp-badge-inactive'}`} style={{ marginLeft: '0.75rem', flexShrink: 0 }}>
                                    {group.isEnabled ? 'Live' : 'Draft'}
                                </span>
                            </div>

                            <div style={{ display: 'flex', gap: '1rem', fontSize: '0.8125rem', color: 'var(--dp-text-muted)', marginBottom: '1rem' }}>
                                <span>📦 {group._count.products} product{group._count.products !== 1 ? 's' : ''}</span>
                                {group.leadFormEnabled && <span>📋 Lead form</span>}
                            </div>

                            <div style={{ display: 'flex', gap: '0.5rem' }}>
                                <Link href={`/dealer/${params.slug}/catalog/${group.id}`}
                                    className="dp-btn dp-btn-secondary"
                                    style={{ flex: 1, justifyContent: 'center' }}>
                                    Edit Group
                                </Link>
                                {group.isEnabled && (
                                    <Link href={`/dealer/${params.slug}/catalog/${group.id}/embed`}
                                        className="dp-btn dp-btn-ghost"
                                        style={{ padding: '0.5rem 0.75rem', fontSize: '0.8125rem' }}
                                        title="Embed code">
                                        {'</>'}
                                    </Link>
                                )}
                            </div>
                        </div>
                    ))}

                    {/* Add new slot */}
                    {groups.length < limit && (
                        <Link
                            href={`/dealer/${params.slug}/catalog/new`}
                            className="dp-card"
                            style={{
                                padding: '1.25rem',
                                display: 'flex',
                                alignItems: 'center',
                                justifyContent: 'center',
                                flexDirection: 'column',
                                gap: '0.5rem',
                                border: '2px dashed var(--dp-border)',
                                color: 'var(--dp-text-muted)',
                                textDecoration: 'none',
                                minHeight: '160px',
                                transition: 'border-color 0.15s, color 0.15s',
                            }}
                        >
                            <span style={{ fontSize: '1.75rem', lineHeight: 1 }}>+</span>
                            <span style={{ fontSize: '0.875rem', fontWeight: 500 }}>New Catalog Group</span>
                        </Link>
                    )}
                </div>
            )}

            {/* Subscription limit notice */}
            {groups.length >= limit && (
                <div style={{
                    padding: '1rem 1.25rem',
                    marginTop: '1.5rem',
                    background: 'rgba(245,158,11,0.08)',
                    border: '1px solid rgba(245,158,11,0.25)',
                    borderRadius: 10,
                    display: 'flex',
                    alignItems: 'center',
                    gap: '0.75rem',
                }}>
                    <span>⚠️</span>
                    <div>
                        <span style={{ fontWeight: 600, color: 'var(--dp-text)' }}>Group limit reached.</span>
                        <span style={{ color: 'var(--dp-text-muted)', marginLeft: '0.5rem', fontSize: '0.875rem' }}>
                            Your {tierLabel} plan allows up to {limit} catalog groups. Upgrade to create more.
                        </span>
                    </div>
                </div>
            )}
        </div>
    );
}
