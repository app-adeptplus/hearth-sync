import { redirect } from 'next/navigation';

/**
 * Temporary backdoor entry point.
 * Hands off to the API route which generates a real Supabase session
 * via magic link for the dev admin user.
 *
 * TODO: Remove before production deployment.
 */
export default function AdminBackdoorPage() {
    redirect('/api/admin-backdoor');
}
