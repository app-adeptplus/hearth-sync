'use client';

import { useState } from 'react';
import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { supabase } from '@/lib/supabase';

export default function PortalLayout({ children }: { children: React.ReactNode }) {
    const pathname = usePathname();
    const router = useRouter();
    const [isLoggingOut, setIsLoggingOut] = useState(false);

    const navItems = [
        { name: 'Dashboard', href: '/dashboard', icon: '📊' },
        { name: 'Master Catalog', href: '/dashboard/catalog', icon: '📚' },
        { name: 'My Products', href: '/dashboard/my-products', icon: '⭐' },
        { name: 'Activity Log', href: '/dashboard/activity', icon: '⚡' },
        { name: 'Widget Settings', href: '/dashboard/widget', icon: '⚙️' },
        { name: 'CRM Integration', href: '/dashboard/integrations', icon: '🔌' },
        { name: 'Account Settings', href: '/dashboard/account', icon: '👤' },
    ];

    const handleLogout = async () => {
        setIsLoggingOut(true);
        await supabase.auth.signOut();
        router.push('/login');
        router.refresh();
    };

    return (
        <div className="layout-container">
            {/* Sidebar Navigation */}
            <nav className="sidebar">
                <div className="sidebar-header">
                    <Link href="/dashboard" className="sidebar-brand">
                        🔥 HearthSync
                    </Link>
                    <div className="text-xs text-[var(--text-secondary)] font-medium tracking-widest uppercase mt-4">
                        Dealer Portal
                    </div>
                </div>

                <div className="sidebar-nav">
                    {navItems.map((item) => {
                        const isActive = pathname === item.href || (pathname.startsWith(item.href) && item.href !== '/dashboard');
                        return (
                            <Link
                                key={item.name}
                                href={item.href}
                                className={`sidebar-link ${isActive ? 'active' : ''}`}
                            >
                                <span className="mr-3">{item.icon}</span>
                                {item.name}
                            </Link>
                        );
                    })}
                </div>

                <div className="mt-auto p-4 border-t border-[var(--border)]">
                    <button
                        onClick={handleLogout}
                        disabled={isLoggingOut}
                        className="flex w-full items-center p-2 text-sm font-medium text-[var(--text-secondary)] hover:text-white hover:bg-[var(--hover-bg)] rounded-md transition-colors"
                    >
                        <span className="mr-3">🚪</span>
                        {isLoggingOut ? 'Signing out...' : 'Sign Out'}
                    </button>
                </div>
            </nav>

            {/* Main Content Area */}
            <main className="main-content">
                <header className="content-header">
                    <div className="text-sm font-medium text-[var(--text-secondary)]">
                        {navItems.find(i => pathname === i.href || (pathname.startsWith(i.href) && i.href !== '/dashboard'))?.name || 'Dashboard'}
                    </div>
                    <div className="flex items-center gap-4">
                        <div className="text-sm border border-[var(--border)] bg-[var(--card-bg)] px-3 py-1.5 rounded-full flex items-center gap-2">
                            <div className="w-2 h-2 rounded-full bg-green-500"></div>
                            Active Session
                        </div>
                    </div>
                </header>

                <div className="p-8 pb-20 max-w-7xl mx-auto">
                    {children}
                </div>
            </main>
        </div>
    );
}
