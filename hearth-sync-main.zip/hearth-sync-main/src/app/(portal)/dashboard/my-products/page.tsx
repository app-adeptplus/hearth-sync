export default function MyProductsPage() {
    return (
        <div className="space-y-6 animate-fade-in">
            <div className="flex items-center justify-between">
                <div>
                    <h1 className="text-3xl font-bold tracking-tight">My Products</h1>
                    <p className="mt-2 text-[var(--text-secondary)]">
                        Manage the products that appear in your website widget and estimate tool.
                    </p>
                </div>
                <div className="flex gap-3">
                    <button className="btn bg-[var(--background)] border border-[var(--border)] hover:bg-[var(--hover-bg)]">
                        Export CSV
                    </button>
                    <button className="btn btn-primary">
                        + Add Products
                    </button>
                </div>
            </div>

            <div className="card overflow-hidden">
                {/* Mock empty state since DealerCatalogSelection logic requires dealer ID parsing from session */}
                <div className="text-center py-24 px-6">
                    <div className="text-5xl mb-4">⭐</div>
                    <h3 className="text-lg font-medium text-[var(--foreground)]">No Products Activated Yet</h3>
                    <p className="mt-2 text-sm text-[var(--text-secondary)] max-w-sm mx-auto">
                        Your catalog is currently empty. Head over to the Master Catalog to browse and add manufacturers or individual products to your selection.
                    </p>
                    <div className="mt-6">
                        <a href="/dashboard/catalog" className="btn btn-primary">
                            Browse Master Catalog
                        </a>
                    </div>
                </div>
            </div>
        </div>
    );
}
