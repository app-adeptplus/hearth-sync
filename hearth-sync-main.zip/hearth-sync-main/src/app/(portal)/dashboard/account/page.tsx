export default function AccountSettingsPage() {
    return (
        <div className="space-y-6 animate-fade-in max-w-3xl">
            <div>
                <h1 className="text-3xl font-bold tracking-tight">Account Settings</h1>
                <p className="mt-2 text-[var(--text-secondary)]">
                    Manage your company profile and portal preferences.
                </p>
            </div>

            <div className="card p-6">
                <h2 className="text-xl font-semibold mb-4 border-b border-[var(--border)] pb-2 flex items-center justify-between">
                    <span>Company Profile</span>
                    <span className="text-xs font-normal px-2 py-1 bg-[#1e1e1e] text-amber-500 border border-amber-900 rounded">
                        Managed via Airtable
                    </span>
                </h2>

                <div className="space-y-6">
                    <div className="grid grid-cols-2 gap-4">
                        <div>
                            <label className="block text-sm font-medium text-[var(--foreground)] mb-1">Company Name</label>
                            <input type="text" className="input w-full bg-[#1e1e1e] text-gray-400" disabled value="Acme Fireplaces, Inc." />
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-[var(--foreground)] mb-1">Primary Email</label>
                            <input type="email" className="input w-full bg-[#1e1e1e] text-gray-400" disabled value="owner@acmefireplaces.test" />
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-[var(--foreground)] mb-1">Phone</label>
                            <input type="text" className="input w-full bg-[#1e1e1e] text-gray-400" disabled value="(555) 123-4567" />
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-[var(--foreground)] mb-1">Subscription Tier</label>
                            <input type="text" className="input w-full bg-[#1e1e1e] text-gray-400" disabled value="Pro Tier" />
                        </div>
                    </div>
                    <p className="text-sm text-[var(--text-secondary)]">
                        To change these details, please contact your distributor representative to update your Airtable record.
                    </p>
                </div>
            </div>

            <div className="card p-6">
                <h2 className="text-xl font-semibold mb-4 border-b border-[var(--border)] pb-2">
                    Notification Preferences
                </h2>

                <div className="space-y-4">
                    <label className="flex items-start gap-3">
                        <input type="checkbox" defaultChecked className="mt-1" />
                        <div>
                            <div className="font-medium">New Products Added</div>
                            <div className="text-sm text-[var(--text-secondary)]">Receive an email when your activated manufacturers add new products.</div>
                        </div>
                    </label>

                    <label className="flex items-start gap-3">
                        <input type="checkbox" defaultChecked className="mt-1" />
                        <div>
                            <div className="font-medium">Products Discontinued</div>
                            <div className="text-sm text-[var(--text-secondary)]">Get notified immediately when an activated product is flagged as discontinued.</div>
                        </div>
                    </label>

                    <label className="flex items-start gap-3">
                        <input type="checkbox" defaultChecked className="mt-1" />
                        <div>
                            <div className="font-medium">Spec Changes</div>
                            <div className="text-sm text-[var(--text-secondary)]">Weekly summary of minor spec updates to your catalog.</div>
                        </div>
                    </label>
                </div>

                <div className="mt-6 pt-6 border-t border-[var(--border)]">
                    <button className="btn btn-primary">Save Preferences</button>
                </div>
            </div>
        </div>
    );
}
