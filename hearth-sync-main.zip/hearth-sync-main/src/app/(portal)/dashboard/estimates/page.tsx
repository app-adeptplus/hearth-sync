export default function InternalEstimatesPage() {
    return (
        <div className="space-y-6 animate-fade-in">
            <div className="flex items-center justify-between">
                <div>
                    <h1 className="text-3xl font-bold tracking-tight">Sales Estimates</h1>
                    <p className="mt-2 text-[var(--text-secondary)]">
                        Create and track project estimates for your customers.
                    </p>
                </div>
                <button className="btn btn-primary">+ New Estimate</button>
            </div>

            <div className="card p-0 overflow-hidden">
                <table className="w-full text-left text-sm whitespace-nowrap">
                    <thead className="bg-[var(--background)] border-b border-[var(--border)] text-[var(--text-secondary)]">
                        <tr>
                            <th className="px-6 py-4 font-medium uppercase tracking-wider text-xs">Estimate / ID</th>
                            <th className="px-6 py-4 font-medium uppercase tracking-wider text-xs">Customer</th>
                            <th className="px-6 py-4 font-medium uppercase tracking-wider text-xs">Date</th>
                            <th className="px-6 py-4 font-medium uppercase tracking-wider text-xs">Total Value</th>
                            <th className="px-6 py-4 font-medium uppercase tracking-wider text-xs">Status</th>
                            <th className="px-6 py-4 font-medium uppercase tracking-wider text-xs text-right">Actions</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-[var(--border)]">
                        {/* Mock Rows */}
                        <tr className="hover:bg-[var(--hover-bg)] transition-colors">
                            <td className="px-6 py-4">
                                <div className="font-medium text-[var(--foreground)]">Townhouse Retrofit</div>
                                <div className="text-xs text-[var(--text-secondary)]">EST-2024-001</div>
                            </td>
                            <td className="px-6 py-4">
                                <div className="font-medium text-[var(--foreground)]">John Smith</div>
                                <div className="text-xs text-[var(--text-secondary)]">john@example.com</div>
                            </td>
                            <td className="px-6 py-4 text-[var(--text-secondary)]">Oct 24, 2024</td>
                            <td className="px-6 py-4 font-medium">$5,240.00</td>
                            <td className="px-6 py-4">
                                <span className="badge bg-green-900/50 text-green-400 border border-green-800">Accepted</span>
                            </td>
                            <td className="px-6 py-4 text-right">
                                <button className="text-[var(--text-secondary)] hover:text-white transition-colors text-xl">⋯</button>
                            </td>
                        </tr>
                        <tr className="hover:bg-[var(--hover-bg)] transition-colors">
                            <td className="px-6 py-4">
                                <div className="font-medium text-[var(--foreground)]">New Build Custom Fireplace</div>
                                <div className="text-xs text-[var(--text-secondary)]">EST-2024-002</div>
                            </td>
                            <td className="px-6 py-4">
                                <div className="font-medium text-[var(--foreground)]">Sarah Jenkins</div>
                                <div className="text-xs text-[var(--text-secondary)]">sarah.j@company.com</div>
                            </td>
                            <td className="px-6 py-4 text-[var(--text-secondary)]">Oct 26, 2024</td>
                            <td className="px-6 py-4 font-medium">$12,850.00</td>
                            <td className="px-6 py-4">
                                <span className="badge bg-blue-900/50 text-blue-400 border border-blue-800">Sent</span>
                            </td>
                            <td className="px-6 py-4 text-right">
                                <button className="text-[var(--text-secondary)] hover:text-white transition-colors text-xl">⋯</button>
                            </td>
                        </tr>
                        <tr className="hover:bg-[var(--hover-bg)] transition-colors">
                            <td className="px-6 py-4">
                                <div className="font-medium text-[var(--foreground)]">Basement Gas Insert</div>
                                <div className="text-xs text-[var(--text-secondary)]">EST-2024-003</div>
                            </td>
                            <td className="px-6 py-4">
                                <div className="font-medium text-[var(--foreground)]">Mike Robertson</div>
                                <div className="text-xs text-[var(--text-secondary)]">mike.robertson@gmail.com</div>
                            </td>
                            <td className="px-6 py-4 text-[var(--text-secondary)]">Oct 27, 2024</td>
                            <td className="px-6 py-4 font-medium">$4,100.00</td>
                            <td className="px-6 py-4">
                                <span className="badge bg-amber-900/50 text-amber-400 border border-amber-800">Draft</span>
                            </td>
                            <td className="px-6 py-4 text-right">
                                <button className="text-[var(--text-secondary)] hover:text-white transition-colors text-xl">⋯</button>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    );
}
