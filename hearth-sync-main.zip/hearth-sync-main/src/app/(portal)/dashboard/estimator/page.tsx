export default function EstimatorConfigPage() {
    return (
        <div className="space-y-6 animate-fade-in">
            <div className="flex items-center justify-between">
                <div>
                    <h1 className="text-3xl font-bold tracking-tight">Estimator Settings</h1>
                    <p className="mt-2 text-[var(--text-secondary)]">
                        Configure the pricing, labor rates, and rules for your consumer-facing project estimator.
                    </p>
                </div>
                <button className="btn btn-primary">Save Settings</button>
            </div>

            <div className="grid gap-6 md:grid-cols-2">
                {/* Pricing Rules */}
                <div className="card p-6">
                    <h2 className="text-xl font-semibold mb-4 border-b border-[var(--border)] pb-2">
                        Global Pricing Rules
                    </h2>
                    <div className="space-y-4">
                        <div>
                            <label className="block text-sm font-medium text-[var(--foreground)] mb-1">
                                Default Equipment Markup (%)
                            </label>
                            <input type="number" defaultValue={20} className="input w-full" />
                            <p className="text-xs text-[var(--text-secondary)] mt-1">Applied to MSRP/MAP.</p>
                        </div>

                        <div className="pt-4 border-t border-[var(--border)]">
                            <label className="flex items-start gap-3">
                                <input type="checkbox" defaultChecked className="mt-1" />
                                <div>
                                    <div className="font-medium">Show Itemized Pricing</div>
                                    <div className="text-sm text-[var(--text-secondary)]">Display exact prices for equipment and labor rather than a single total range.</div>
                                </div>
                            </label>
                        </div>
                    </div>
                </div>

                {/* Labor Rates */}
                <div className="card p-6">
                    <h2 className="text-xl font-semibold mb-4 border-b border-[var(--border)] pb-2 flex justify-between items-center">
                        <span>Standard Labor Rates</span>
                        <button className="text-sm text-[var(--hs-primary)] font-medium">Add Service</button>
                    </h2>
                    <div className="space-y-3">
                        <div className="flex items-center gap-4">
                            <input type="text" className="input flex-1" defaultValue="Standard Gas Insert Install" />
                            <div className="relative">
                                <span className="absolute left-3 top-2.5 text-[var(--text-secondary)]">$</span>
                                <input type="number" className="input w-32 pl-7" defaultValue={850} />
                            </div>
                        </div>
                        <div className="flex items-center gap-4">
                            <input type="text" className="input flex-1" defaultValue="Venting Modification" />
                            <div className="relative">
                                <span className="absolute left-3 top-2.5 text-[var(--text-secondary)]">$</span>
                                <input type="number" className="input w-32 pl-7" defaultValue={450} />
                            </div>
                        </div>
                        <div className="flex items-center gap-4">
                            <input type="text" className="input flex-1" defaultValue="Gas Line Run (per ft)" />
                            <div className="relative">
                                <span className="absolute left-3 top-2.5 text-[var(--text-secondary)]">$</span>
                                <input type="number" className="input w-32 pl-7" defaultValue={25} />
                            </div>
                        </div>
                    </div>
                </div>

                {/* Estimate Branding */}
                <div className="card p-6 md:col-span-2">
                    <h2 className="text-xl font-semibold mb-4 border-b border-[var(--border)] pb-2">
                        PDF Estimate Branding
                    </h2>
                    <div className="flex gap-8">
                        <div className="space-y-4 flex-1">
                            <div>
                                <label className="block text-sm font-medium text-[var(--foreground)] mb-1">Company Logo</label>
                                <div className="flex items-center gap-4">
                                    <div className="h-16 w-32 bg-[var(--background)] border border-dashed border-[var(--border)] rounded flex items-center justify-center text-xs text-gray-500">
                                        Upload Logo
                                    </div>
                                    <input type="file" className="text-sm text-[var(--text-secondary)]" />
                                </div>
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-[var(--foreground)] mb-1">Estimate Footer Notes</label>
                                <textarea className="input w-full h-24" defaultValue="All estimates are valid for 30 days. Permits and standard tax rates apply. Final price subject to on-site inspection."></textarea>
                            </div>
                        </div>
                        <div className="w-1/3 border-l border-[var(--border)] pl-8">
                            <label className="block text-sm font-medium text-[var(--foreground)] mb-3">Preview</label>
                            <div className="bg-white p-4 h-48 rounded shadow-sm flex flex-col items-center justify-center border border-gray-200">
                                <span className="text-4xl mb-2">📄</span>
                                <span className="text-gray-400 text-sm">PDF Layout View</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}
