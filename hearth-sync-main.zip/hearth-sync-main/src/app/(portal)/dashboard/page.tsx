import { createServerClient } from '@supabase/ssr';
import { cookies } from 'next/headers';
import Link from 'next/link';

export default async function DashboardPage() {
    const cookieStore = cookies();
    const supabase = createServerClient(
        process.env.NEXT_PUBLIC_SUPABASE_URL!,
        process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
        {
            cookies: {
                get(name: string) {
                    return cookieStore.get(name)?.value;
                },
            },
        }
    );

    const { data: { session } } = await supabase.auth.getSession();
    const user = session?.user;

    // Ideally, we fetch dealer account details from DB here.
    // For now, placeholder dashboard.

    return (
        <div className="space-y-8 animate-fade-in">
            <div>
                <h1 className="text-3xl font-bold tracking-tight">Welcome, {user?.email}</h1>
                <p className="mt-2 text-[var(--text-secondary)]">
                    Manage your curated hearth product catalog and website integrations.
                </p>
            </div>

            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
                <div className="card p-6 border-l-4 border-blue-500">
                    <div className="text-sm font-medium text-[var(--text-secondary)]">Active Products</div>
                    <div className="mt-2 flex items-baseline gap-2">
                        <span className="text-3xl font-bold">0</span>
                        <span className="text-sm text-[var(--text-secondary)]">/ 1,500</span>
                    </div>
                </div>

                <div className="card p-6 border-l-4 border-amber-500">
                    <div className="text-sm font-medium text-[var(--text-secondary)]">Pending Review</div>
                    <div className="mt-2 text-3xl font-bold">0</div>
                </div>

                <div className="card p-6 border-l-4 border-green-500">
                    <div className="text-sm font-medium text-[var(--text-secondary)]">Catalog Health</div>
                    <div className="mt-2 text-3xl font-bold text-green-500">100%</div>
                </div>

                <div className="card p-6 border-l-4 border-purple-500">
                    <div className="text-sm font-medium text-[var(--text-secondary)]">Widget Views</div>
                    <div className="mt-2 text-3xl font-bold">0</div>
                </div>
            </div>

            <div className="grid gap-6 md:grid-cols-2">
                <div className="card p-6">
                    <h2 className="text-xl font-semibold mb-4 border-b border-[var(--border)] pb-2">
                        Recent Catalog Activity
                    </h2>
                    <div className="space-y-4">
                        <div className="text-sm text-[var(--text-secondary)] italic p-4 text-center bg-[var(--background)] rounded">
                            No recent changes to your active manufacturers.
                        </div>
                    </div>
                </div>

                <div className="card p-6">
                    <h2 className="text-xl font-semibold mb-4 border-b border-[var(--border)] pb-2">
                        Quick Actions
                    </h2>
                    <div className="flex flex-col gap-3">
                        <Link href="/dashboard/catalog" className="btn bg-[var(--background)] border border-[var(--border)] hover:bg-[var(--hover-bg)] w-full text-left justify-start">
                            <span className="mr-3">📚</span> Browse Master Catalog
                        </Link>
                        <Link href="/dashboard/my-products" className="btn bg-[var(--background)] border border-[var(--border)] hover:bg-[var(--hover-bg)] w-full text-left justify-start">
                            <span className="mr-3">⭐</span> Manage My Products
                        </Link>
                        <Link href="/dashboard/widget" className="btn bg-[var(--background)] border border-[var(--border)] hover:bg-[var(--hover-bg)] w-full text-left justify-start">
                            <span className="mr-3">⚙️</span> Configure Website Widget
                        </Link>
                    </div>
                </div>
            </div>
        </div>
    );
}
