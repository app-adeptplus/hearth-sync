import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

export const dynamic = 'force-dynamic';

export default async function ActivityLogPage() {
    // Fetch recent audit logs. In a real scenario, this would be filtered by
    // the products the dealer has activated in their catalog.
    const recentActivity = await prisma.auditLog.findMany({
        orderBy: { createdAt: 'desc' },
        take: 20,
    });

    return (
        <div className="space-y-6 animate-fade-in">
            <div>
                <h1 className="text-3xl font-bold tracking-tight">Activity Log</h1>
                <p className="mt-2 text-[var(--text-secondary)]">
                    Recent updates, additions, and discontinuations from your active manufacturers.
                </p>
            </div>

            <div className="card overflow-hidden">
                <ul className="divide-y divide-[var(--border)]">
                    {recentActivity.map((log) => {
                        const isCreation = log.action === 'CREATED';
                        const isUpdate = log.action === 'UPDATED';
                        const isDiscontinued = log.action === 'DISCONTINUED';

                        let icon = '🔄';
                        let colorClass = 'text-blue-400';

                        if (isCreation) {
                            icon = '✨';
                            colorClass = 'text-green-400';
                        } else if (isDiscontinued) {
                            icon = '🚨';
                            colorClass = 'text-red-400';
                        }

                        return (
                            <li key={log.id} className="p-6 hover:bg-[var(--hover-bg)] transition-colors">
                                <div className="flex gap-4">
                                    <div className={`mt-1 text-xl ${colorClass}`}>
                                        {icon}
                                    </div>
                                    <div className="flex-1 space-y-1">
                                        <div className="flex items-center justify-between">
                                            <p className="text-sm font-medium text-[var(--foreground)]">
                                                Product {isCreation ? 'Added' : isDiscontinued ? 'Discontinued' : 'Updated'}
                                            </p>
                                            <p className="text-sm text-[var(--text-secondary)]">
                                                {new Date(log.createdAt).toLocaleDateString()} at {new Date(log.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                                            </p>
                                        </div>
                                        {/* Excerpt of changes */}
                                        <p className="text-sm text-[var(--text-secondary)]">
                                            Product ID: <span className="font-mono bg-[var(--background)] px-1 rounded">{log.productId}</span>
                                        </p>
                                        {isUpdate && log.after && (
                                            <div className="mt-2 text-xs bg-[var(--background)] border border-[var(--border)] p-3 rounded-md overflow-hidden">
                                                <pre className="text-[var(--text-secondary)] whitespace-pre-wrap">
                                                    {JSON.stringify(log.after, null, 2)}
                                                </pre>
                                            </div>
                                        )}
                                    </div>
                                </div>
                            </li>
                        );
                    })}

                    {recentActivity.length === 0 && (
                        <li className="p-12 text-center text-[var(--text-secondary)]">
                            No recent activity recorded.
                        </li>
                    )}
                </ul>
            </div>
        </div>
    );
}
