export default function WidgetSettingsPage() {
    return (
        <div className="space-y-6 animate-fade-in">
            <div className="flex items-center justify-between">
                <div>
                    <h1 className="text-3xl font-bold tracking-tight">Widget Settings</h1>
                    <p className="mt-2 text-[var(--text-secondary)]">
                        Configure how your curated catalog appears on your website.
                    </p>
                </div>
                <button className="btn btn-primary">Save Changes</button>
            </div>

            <div className="grid gap-6 md:grid-cols-2">
                <div className="space-y-6">
                    <div className="card p-6">
                        <h2 className="text-xl font-semibold mb-4 border-b border-[var(--border)] pb-2">
                            Branding & Colors
                        </h2>
                        <div className="space-y-4">
                            <div>
                                <label className="block text-sm font-medium text-[var(--foreground)] mb-1">Primary Color</label>
                                <div className="flex gap-2">
                                    <input type="color" defaultValue="#eab308" className="h-10 w-20 bg-transparent rounded border border-[var(--border)]" />
                                    <input type="text" defaultValue="#eab308" className="input flex-1" />
                                </div>
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-[var(--foreground)] mb-1">Corner Style</label>
                                <select className="input w-full">
                                    <option>Rounded (Modern)</option>
                                    <option>Square (Sharp)</option>
                                    <option>Pill (Soft)</option>
                                </select>
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-[var(--foreground)] mb-1">Typography</label>
                                <select className="input w-full">
                                    <option>Inherit from my website</option>
                                    <option>Inter (Modern Sans)</option>
                                    <option>Merriweather (Classic Serif)</option>
                                </select>
                            </div>
                        </div>
                    </div>

                    <div className="card p-6">
                        <h2 className="text-xl font-semibold mb-4 border-b border-[var(--border)] pb-2">
                            Embed Code
                        </h2>
                        <p className="text-sm text-[var(--text-secondary)] mb-4">
                            Paste this code into your website's HTML where you want the catalog to appear.
                        </p>
                        <div className="relative">
                            <pre className="bg-[#1e1e1e] p-4 rounded-md text-sm text-gray-300 overflow-x-auto border border-[var(--border)]">
                                {`<div id="hearthsync-catalog"></div>
<script 
  src="https://cdn.hearthsync.com/widget.js" 
  data-dealer-id="dlr_12345"
  async>
</script>`}</pre>
                            <button className="absolute top-2 right-2 p-2 bg-[#2d2d2d] rounded text-xs hover:bg-gray-600 transition-colors">
                                Copy
                            </button>
                        </div>
                    </div>
                </div>

                {/* Live Preview */}
                <div className="card p-6 border-2 border-dashed border-[var(--border)] flex flex-col">
                    <h2 className="text-xl font-semibold mb-4 border-b border-[var(--border)] pb-2 flex justify-between items-center">
                        <span>Live Preview</span>
                        <span className="text-xs font-normal text-[var(--text-secondary)] bg-[var(--background)] px-2 py-1 rounded">Interactive</span>
                    </h2>
                    <div className="flex-1 bg-white rounded-md flex items-center justify-center text-gray-400 overflow-hidden relative min-h-[400px]">
                        {/* Mock widget output */}
                        <div className="absolute inset-0 p-4">
                            <div className="h-12 w-full bg-gray-100 rounded mb-4 flex items-center px-4">
                                <span className="text-gray-400 text-sm">Search catalog...</span>
                            </div>
                            <div className="flex gap-4">
                                <div className="w-1/4 h-64 bg-gray-100 rounded flex flex-col gap-2 p-4">
                                    <div className="w-full h-4 bg-gray-200 rounded"></div>
                                    <div className="w-2/3 h-4 bg-gray-200 rounded"></div>
                                    <div className="w-1/2 h-4 bg-gray-200 rounded mt-4"></div>
                                </div>
                                <div className="flex-1 grid grid-cols-2 gap-4">
                                    <div className="h-48 bg-gray-100 rounded"></div>
                                    <div className="h-48 bg-gray-100 rounded"></div>
                                    <div className="h-48 bg-gray-100 rounded"></div>
                                    <div className="h-48 bg-gray-100 rounded"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}
