export default function IntegrationsPage() {
    return (
        <div className="space-y-6 animate-fade-in">
            <div>
                <h1 className="text-3xl font-bold tracking-tight">CRM Integrations</h1>
                <p className="mt-2 text-[var(--text-secondary)]">
                    Connect your sales tools to automatically receive leads captured from your website catalog.
                </p>
            </div>

            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                {/* HubSpot */}
                <div className="card p-6 flex flex-col">
                    <div className="flex items-center justify-between mb-4">
                        <h3 className="text-lg font-semibold flex items-center gap-2">
                            <span className="text-orange-500">⚙️</span> HubSpot
                        </h3>
                        <span className="badge bg-green-900/50 text-green-400 border border-green-800">Connected</span>
                    </div>
                    <p className="text-sm text-[var(--text-secondary)] mb-6 flex-1">
                        Automatically create Contacts and Deals in HubSpot when a lead is captured.
                    </p>
                    <div className="border-t border-[var(--border)] pt-4 flex justify-between items-center">
                        <button className="text-sm text-[var(--text-secondary)] hover:text-white">Configure Fields</button>
                        <button className="text-sm text-red-400 hover:text-red-300">Disconnect</button>
                    </div>
                </div>

                {/* Salesforce */}
                <div className="card p-6 flex flex-col">
                    <div className="flex items-center justify-between mb-4">
                        <h3 className="text-lg font-semibold flex items-center gap-2">
                            <span className="text-blue-500">☁️</span> Salesforce
                        </h3>
                        <span className="badge bg-[var(--background)] text-[var(--text-secondary)] border border-[var(--border)]">Not Connected</span>
                    </div>
                    <p className="text-sm text-[var(--text-secondary)] mb-6 flex-1">
                        Route catalog leads directly into your Salesforce Sales Cloud instance.
                    </p>
                    <div className="border-t border-[var(--border)] pt-4">
                        <button className="btn bg-[var(--background)] border border-[var(--border)] hover:bg-[var(--hover-bg)] w-full block text-center">
                            Connect Provider
                        </button>
                    </div>
                </div>

                {/* Custom Webhook */}
                <div className="card p-6 flex flex-col">
                    <div className="flex items-center justify-between mb-4">
                        <h3 className="text-lg font-semibold flex items-center gap-2">
                            <span className="text-purple-500">🪝</span> Custom Webhook
                        </h3>
                        <span className="badge bg-[var(--background)] text-[var(--text-secondary)] border border-[var(--border)]">Configured</span>
                    </div>
                    <p className="text-sm text-[var(--text-secondary)] mb-6 flex-1">
                        POST JSON lead payloads to any custom endpoint (e.g., Zapier, Make.com).
                    </p>
                    <div className="border-t border-[var(--border)] pt-4">
                        <button className="btn bg-[var(--background)] border border-[var(--border)] hover:bg-[var(--hover-bg)] w-full block text-center">
                            Edit Endpoint
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
}
