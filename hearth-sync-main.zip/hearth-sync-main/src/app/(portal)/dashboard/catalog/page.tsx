import { PrismaClient } from '@prisma/client';
import Image from 'next/image';

const prisma = new PrismaClient();

export default async function CatalogBrowserPage({
    searchParams,
}: {
    searchParams: { q?: string; brand?: string; category?: string };
}) {
    const query = searchParams.q || '';
    const brandParam = searchParams.brand || '';
    const categoryParam = searchParams.category || '';

    // In a real app, we'd use pagination here.
    const products = await prisma.product.findMany({
        where: {
            status: 'ACTIVE',
            ...(query && {
                OR: [
                    { name: { contains: query, mode: 'insensitive' } },
                    { modelNumber: { contains: query, mode: 'insensitive' } },
                ],
            }),
            ...(brandParam && { brand: { slug: brandParam } }),
        },
        include: {
            brand: true,
            images: { where: { isPrimary: true }, take: 1 },
        },
        take: 50,
    });

    const brands = await prisma.brand.findMany({
        orderBy: { name: 'asc' },
    });

    return (
        <div className="space-y-6 animate-fade-in">
            <div>
                <h1 className="text-3xl font-bold tracking-tight">Master Catalog</h1>
                <p className="mt-2 text-[var(--text-secondary)]">
                    Browse all available products from integrated manufacturers to add to your catalog.
                </p>
            </div>

            {/* Filters */}
            <div className="card p-4 flex flex-wrap gap-4 items-center">
                <form className="flex-1 min-w-[300px] relative">
                    <input
                        type="search"
                        name="q"
                        defaultValue={query}
                        placeholder="Search models, IDs, names..."
                        className="input pl-10 w-full"
                    />
                    <span className="absolute left-3 top-2.5 text-[var(--text-secondary)]">🔍</span>
                </form>

                <form className="flex gap-4">
                    <select
                        name="brand"
                        defaultValue={brandParam}
                        className="input"
                        onChange={(e) => e.target.form?.submit()}
                    >
                        <option value="">All Brands</option>
                        {brands.map((b) => (
                            <option key={b.id} value={b.slug}>
                                {b.name}
                            </option>
                        ))}
                    </select>
                    <select
                        name="category"
                        defaultValue={categoryParam}
                        className="input"
                        onChange={(e) => e.target.form?.submit()}
                    >
                        <option value="">All Categories</option>
                        <option value="fireplaces">Fireplaces</option>
                        <option value="stoves">Stoves</option>
                        <option value="inserts">Inserts</option>
                    </select>
                </form>
            </div>

            {/* Product Grid */}
            <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
                {products.map((product) => (
                    <div key={product.id} className="card overflow-hidden flex flex-col group relative">
                        <div className="aspect-square bg-white relative p-4 flex items-center justify-center">
                            {product.images[0]?.url ? (
                                <div className="relative w-full h-full">
                                    <Image
                                        src={product.images[0].url}
                                        alt={product.name}
                                        fill
                                        className="object-contain"
                                        sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 25vw"
                                    />
                                </div>
                            ) : (
                                <div className="text-[var(--text-secondary)] text-sm">No Image</div>
                            )}
                            {/* Overlay quick actions */}
                            <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-3">
                                <button className="btn btn-primary btn-sm">Add to My Catalog</button>
                                <button className="btn bg-[var(--background)] border border-[var(--border)] btn-sm text-white hover:bg-[var(--hover-bg)]">Details</button>
                            </div>
                        </div>
                        <div className="p-4 flex flex-col flex-1">
                            <div className="text-xs font-semibold text-[var(--text-secondary)] uppercase tracking-wider mb-1">
                                {product.brand.name}
                            </div>
                            <h3 className="font-medium text-[var(--foreground)] line-clamp-2" title={product.name}>
                                {product.name}
                            </h3>
                            <div className="mt-auto pt-4 flex items-center justify-between text-sm text-[var(--text-secondary)]">
                                <span>Model: {product.modelNumber || 'N/A'}</span>
                            </div>
                        </div>
                    </div>
                ))}

                {products.length === 0 && (
                    <div className="col-span-full py-20 text-center text-[var(--text-secondary)]">
                        No products found matching your filters.
                    </div>
                )}
            </div>
        </div>
    );
}
