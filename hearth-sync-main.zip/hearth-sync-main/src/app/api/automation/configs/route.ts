import prisma from '@/lib/db';
import { NextRequest, NextResponse } from 'next/server';

// GET /api/automation/configs — List all automation configs (filterable by sourceType)
export async function GET(request: NextRequest) {
    try {
        const { searchParams } = new URL(request.url);
        const sourceType = searchParams.get('sourceType');

        const configs = await prisma.automationConfig.findMany({
            where: sourceType ? { sourceType: sourceType as any } : undefined,
            include: {
                brand: { select: { id: true, name: true } },
                _count: { select: { runs: true, artifacts: true } },
            },
            orderBy: { updatedAt: 'desc' },
        });

        return NextResponse.json(configs);
    } catch (error: any) {
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}

// POST /api/automation/configs — Create a new automation config
export async function POST(request: NextRequest) {
    try {
        const body = await request.json();
        const {
            name, brandId, sourceType, status, occurrence,
            siteUrl, crawlDepth, apiEndpoint, apiAuthType, apiCredentials,
            ftpHost, ftpPort, ftpUser, ftpPassword, ftpPath,
            llmInstructions, llmModelOverride, notes
        } = body;

        if (!name || !sourceType) {
            return NextResponse.json({ error: 'name and sourceType are required' }, { status: 400 });
        }

        const config = await prisma.automationConfig.create({
            data: {
                name,
                brandId: brandId || null,
                sourceType,
                status: status || 'DRAFT',
                occurrence: occurrence || 'MANUAL',
                siteUrl: siteUrl || null,
                crawlDepth: crawlDepth || 'SHALLOW',
                apiEndpoint: apiEndpoint || null,
                apiAuthType: apiAuthType || null,
                apiCredentials: apiCredentials || null,
                ftpHost: ftpHost || null,
                ftpPort: ftpPort ? parseInt(ftpPort) : null,
                ftpUser: ftpUser || null,
                ftpPassword: ftpPassword || null,
                ftpPath: ftpPath || null,
                llmInstructions: llmInstructions || null,
                llmModelOverride: llmModelOverride || null,
                notes: notes || null,
            } as any,
            include: {
                brand: { select: { id: true, name: true } },
            },
        });

        return NextResponse.json(config, { status: 201 });
    } catch (error: any) {
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}
