import prisma from '@/lib/db';
import { NextRequest, NextResponse } from 'next/server';

// GET /api/automation/configs/:id
export async function GET(
    request: NextRequest,
    { params }: { params: { id: string } }
) {
    try {
        const config = await prisma.automationConfig.findUnique({
            where: { id: params.id },
            include: {
                brand: { select: { id: true, name: true } },
                promptTemplate: { select: { id: true, name: true, category: true } },
                llmConfigOverride: { select: { id: true, displayName: true, provider: true, model: true } },
                mcpServerLinks: {
                    include: { mcpServer: { select: { id: true, name: true, transportType: true } } },
                },
                artifacts: { orderBy: { createdAt: 'desc' }, take: 20 },
                runs: {
                    orderBy: { createdAt: 'desc' },
                    take: 10,
                    include: {
                        dataPackage: { select: { id: true, name: true, status: true } },
                    },
                },
            },
        });

        if (!config) {
            return NextResponse.json({ error: 'Config not found' }, { status: 404 });
        }

        return NextResponse.json(config);
    } catch (error: any) {
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}

// PATCH /api/automation/configs/:id — Update a config
export async function PATCH(
    request: NextRequest,
    { params }: { params: { id: string } }
) {
    try {
        const body = await request.json();
        const {
            name, brandId, sourceType, status, occurrence,
            siteUrl, crawlDepth, apiEndpoint, apiAuthType, apiCredentials,
            ftpHost, ftpPort, ftpUser, ftpPassword, ftpPath,
            llmInstructions, llmModelOverride, notes,
            // New Phase E fields
            promptTemplateId, llmConfigOverrideId, mcpServerIds,
        } = body;

        const data: any = {};
        if (name !== undefined) data.name = name;
        if (brandId !== undefined) data.brandId = brandId || null;
        if (sourceType !== undefined) data.sourceType = sourceType;
        if (status !== undefined) data.status = status;
        if (occurrence !== undefined) data.occurrence = occurrence;
        if (siteUrl !== undefined) data.siteUrl = siteUrl || null;
        if (crawlDepth !== undefined) data.crawlDepth = crawlDepth;
        if (apiEndpoint !== undefined) data.apiEndpoint = apiEndpoint || null;
        if (apiAuthType !== undefined) data.apiAuthType = apiAuthType || null;
        if (apiCredentials !== undefined) data.apiCredentials = apiCredentials || null;
        if (ftpHost !== undefined) data.ftpHost = ftpHost || null;
        if (ftpPort !== undefined) data.ftpPort = ftpPort ? parseInt(ftpPort) : null;
        if (ftpUser !== undefined) data.ftpUser = ftpUser || null;
        if (ftpPassword !== undefined) data.ftpPassword = ftpPassword || null;
        if (ftpPath !== undefined) data.ftpPath = ftpPath || null;
        if (llmInstructions !== undefined) data.llmInstructions = llmInstructions || null;
        if (llmModelOverride !== undefined) data.llmModelOverride = llmModelOverride || null;
        if (notes !== undefined) data.notes = notes || null;
        if (promptTemplateId !== undefined) data.promptTemplateId = promptTemplateId || null;
        if (llmConfigOverrideId !== undefined) data.llmConfigOverrideId = llmConfigOverrideId || null;

        // Sync MCP server links if provided
        if (Array.isArray(mcpServerIds)) {
            await prisma.mcpServerConfigLink.deleteMany({ where: { automationId: params.id } });
            if (mcpServerIds.length > 0) {
                await prisma.mcpServerConfigLink.createMany({
                    data: mcpServerIds.map((mcpServerId: string) => ({ automationId: params.id, mcpServerId })),
                });
            }
        }

        const config = await prisma.automationConfig.update({
            where: { id: params.id },
            data,
            include: {
                brand: { select: { id: true, name: true } },
                promptTemplate: { select: { id: true, name: true, category: true } },
                llmConfigOverride: { select: { id: true, displayName: true, provider: true, model: true } },
                mcpServerLinks: { include: { mcpServer: { select: { id: true, name: true } } } },
            },
        });

        return NextResponse.json(config);
    } catch (error: any) {
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}

// DELETE /api/automation/configs/:id — Soft-archive a config
export async function DELETE(
    request: NextRequest,
    { params }: { params: { id: string } }
) {
    try {
        const config = await prisma.automationConfig.update({
            where: { id: params.id },
            data: { status: 'ARCHIVED' },
        });

        return NextResponse.json({ success: true, id: config.id });
    } catch (error: any) {
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}
