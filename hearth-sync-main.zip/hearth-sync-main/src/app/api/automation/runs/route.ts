import prisma from '@/lib/db';
import { NextRequest, NextResponse } from 'next/server';
import { fetchPageContent, mapSiteUrls, fetchMultiplePages, FetchResult } from '@/lib/content-fetcher';
import { resolvePrompt } from '@/lib/prompt-resolver';
import { callLlm } from '@/lib/llm-client';
import { buildDataPackage } from '@/lib/data-package-builder';

// GET /api/automation/runs — List runs (filterable by configId)
export async function GET(request: NextRequest) {
    try {
        const { searchParams } = new URL(request.url);
        const configId = searchParams.get('configId');

        const runs = await prisma.automationRun.findMany({
            where: configId ? { configId } : undefined,
            include: {
                config: { select: { id: true, name: true, sourceType: true } },
                dataPackage: { select: { id: true, name: true, status: true } },
            },
            orderBy: { createdAt: 'desc' },
            take: 50,
        });

        return NextResponse.json(runs);
    } catch (error: any) {
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}

// POST /api/automation/runs — Trigger a new run for a config
export async function POST(request: NextRequest) {
    try {
        const body = await request.json();
        const { configId } = body;

        if (!configId) {
            return NextResponse.json({ error: 'configId is required' }, { status: 400 });
        }

        // Load full config with relations
        const config = await prisma.automationConfig.findUnique({
            where: { id: configId },
            include: {
                brand: true,
                promptTemplate: true,
            },
        });

        if (!config) {
            return NextResponse.json({ error: 'Config not found' }, { status: 404 });
        }

        if (config.status === 'ARCHIVED') {
            return NextResponse.json({ error: 'Cannot run an archived config' }, { status: 400 });
        }

        // Create the run record
        const run = await prisma.automationRun.create({
            data: {
                configId,
                status: 'PENDING',
            },
        });

        // Update lastRunAt on the config
        await prisma.automationConfig.update({
            where: { id: configId },
            data: { lastRunAt: new Date() },
        });

        // Execute the pipeline asynchronously (don't await — return immediately)
        executeAutomationRun(run.id, config).catch(err => {
            console.error(`❌ Automation run ${run.id} failed:`, err);
        });

        return NextResponse.json(run, { status: 201 });
    } catch (error: any) {
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}

/**
 * Execute the full automation pipeline for a SITE_SCRAPER run.
 * Supports two crawl modes:
 *   - SHALLOW (default): scrape listing page only → extract products from one page
 *   - DEEP: map site → discover product URLs → scrape each → extract full details per page
 */
async function executeAutomationRun(
    runId: string,
    config: any
) {
    try {
        // Mark as RUNNING
        await prisma.automationRun.update({
            where: { id: runId },
            data: { status: 'RUNNING', startedAt: new Date() },
        });

        const crawlDepth = config.crawlDepth || 'SHALLOW';
        console.log(`\n🤖 Automation run ${runId} started for config: ${config.id}`);
        console.log(`   📋 Config: siteUrl=${config.siteUrl}, brand=${config.brand?.name || 'none'}, crawlDepth=${crawlDepth}`);
        console.log(`   📋 LLM: override=${config.llmConfigOverrideId || 'default'}, prompt=${config.promptTemplate?.name || 'none'}`);

        // Step 1: Validate
        if (config.sourceType !== 'SITE_SCRAPER') {
            throw new Error(`Execution for sourceType "${config.sourceType}" is not yet implemented. Only SITE_SCRAPER is supported.`);
        }

        if (!config.siteUrl) {
            throw new Error('No siteUrl configured. Edit the automation config and add a target URL.');
        }

        // Step 2: Resolve the prompt (shared for both modes)
        console.log(`   🧠 Resolving prompt template...`);
        const systemPrompt = await resolvePrompt(config.id, {
            brand_name: config.brand?.name || '',
            brand_website: config.siteUrl || config.brand?.website || '',
        });

        const llmOverrideId = config.llmConfigOverrideId || undefined;

        if (crawlDepth === 'DEEP') {
            await executeDeepCrawl(runId, config, systemPrompt, llmOverrideId);
        } else {
            await executeShallowCrawl(runId, config, systemPrompt, llmOverrideId);
        }

    } catch (error) {
        const msg = error instanceof Error ? error.message : String(error);
        console.error(`   ❌ Run ${runId} failed: ${msg}`);

        await prisma.automationRun.update({
            where: { id: runId },
            data: {
                status: 'FAILED',
                completedAt: new Date(),
                errors: [msg],
                rawOutput: msg,
            },
        }).catch(() => { /* don't mask the original error */ });
    }
}

/**
 * SHALLOW crawl: scrape a single listing page → LLM extracts all products at once.
 */
async function executeShallowCrawl(
    runId: string,
    config: any,
    systemPrompt: string,
    llmOverrideId?: string
) {
    // Fetch the listing page
    console.log(`   📥 [SHALLOW] Fetching content from: ${config.siteUrl}`);
    const fetchResult = await fetchPageContent(config.siteUrl);
    console.log(`   ✅ Fetched ${fetchResult.content.length} chars via ${fetchResult.source}${fetchResult.title ? ` — "${fetchResult.title}"` : ''}`);

    if (!fetchResult.content || fetchResult.content.length < 50) {
        throw new Error(`Fetched content too short (${fetchResult.content.length} chars). The page may be empty or blocked.`);
    }

    // Call the LLM
    const userMessage = `Here is the web page content to extract products from:\n\n---\n${fetchResult.content.slice(0, 30000)}\n---\n\nExtract all products found on this page and return them as a JSON array.`;

    console.log(`   🔮 Calling LLM (override: ${llmOverrideId || 'using default'})...`);
    const llmResult = await callLlm(userMessage, {
        systemPrompt,
        llmConfigId: llmOverrideId,
        maxTokens: 8192,
        temperature: 0.1,
    });
    console.log(`   ✅ LLM responded: ${llmResult.text.length} chars, ${llmResult.tokensUsed} tokens (${llmResult.provider}/${llmResult.model})`);

    // Build DataPackage
    console.log(`   📦 Building data package...`);
    const buildResult = await buildDataPackage(runId, config.id, config.brand?.id || null, llmResult.text);
    console.log(`   ✅ Created DataPackage ${buildResult.packageId} with ${buildResult.itemCount} items`);

    // Mark complete
    await prisma.automationRun.update({
        where: { id: runId },
        data: {
            status: 'COMPLETED',
            completedAt: new Date(),
            productsFound: buildResult.itemCount,
            rawOutput: llmResult.text,
            llmTokensUsed: llmResult.tokensUsed,
            errors: buildResult.errors.length > 0 ? buildResult.errors : undefined,
        },
    });

    console.log(`   🏁 Run ${runId} completed (SHALLOW): ${buildResult.itemCount} products found\n`);
}

/**
 * DEEP crawl: map site → discover product URLs → scrape each → LLM extracts per-page details.
 */
async function executeDeepCrawl(
    runId: string,
    config: any,
    systemPrompt: string,
    llmOverrideId?: string
) {
    console.log(`   🔎 [DEEP] Discovering product URLs from: ${config.siteUrl}`);

    // Step 1: Map the site to discover product URLs
    const allUrls = await mapSiteUrls(config.siteUrl, {
        search: 'product',
        limit: 200,
    });

    // Filter to likely product page URLs (exclude generic pages, assets, etc.)
    const baseHost = new URL(config.siteUrl).hostname;
    const productUrls = allUrls.filter((url: string) => {
        try {
            const u = new URL(url);
            // Must be same domain
            if (u.hostname !== baseHost) return false;
            // Skip common non-product paths
            const path = u.pathname.toLowerCase();
            if (path === '/' || path === '') return false;
            if (/\/(cart|checkout|account|login|signup|contact|about|privacy|terms|blog|news|faq|support|warranty|shipping|returns)/.test(path)) return false;
            if (/\.(jpg|jpeg|png|gif|svg|pdf|css|js|ico|xml|json)$/i.test(path)) return false;
            // Likely a product page if it has a path segment
            return path.split('/').filter(Boolean).length >= 1;
        } catch { return false; }
    });

    console.log(`   📋 Found ${productUrls.length} product-like URLs (filtered from ${allUrls.length} total)`);

    if (productUrls.length === 0) {
        console.log(`   ⚠️ No product URLs found — falling back to shallow crawl`);
        return executeShallowCrawl(runId, config, systemPrompt, llmOverrideId);
    }

    // Cap at 50 pages to avoid excessive API usage
    const maxPages = 50;
    const pagesToScrape = productUrls.slice(0, maxPages);
    if (productUrls.length > maxPages) {
        console.log(`   ⚠️ Capping at ${maxPages} pages (${productUrls.length} found)`);
    }

    // Step 2: Fetch each product page
    console.log(`   📥 Fetching ${pagesToScrape.length} product pages...`);
    const pageResults = await fetchMultiplePages(pagesToScrape, { delayMs: 500 });
    const successfulPages = pageResults.filter((r): r is FetchResult => r !== null);
    console.log(`   ✅ Successfully fetched ${successfulPages.length}/${pagesToScrape.length} pages`);

    if (successfulPages.length === 0) {
        throw new Error('All product page fetches failed. Check the site URL and Firecrawl configuration.');
    }

    // Step 3: Call LLM for each page to extract product details
    console.log(`   🔮 Extracting product details from ${successfulPages.length} pages...`);
    const allProductJsons: unknown[] = [];
    let totalTokens = 0;
    const allRawOutputs: string[] = [];
    const errors: string[] = [];

    for (let i = 0; i < successfulPages.length; i++) {
        const page = successfulPages[i];
        try {
            const userMessage = `Here is a product page from ${config.brand?.name || 'a brand'}. Extract ALL product details and return a JSON array with one entry per product/variant found on this page.\n\nPage URL: ${page.url}\nPage Title: ${page.title || 'Unknown'}\n\n---\n${page.content.slice(0, 20000)}\n---\n\nExtract the product as a JSON array.`;

            const llmResult = await callLlm(userMessage, {
                systemPrompt,
                llmConfigId: llmOverrideId,
                maxTokens: 4096,
                temperature: 0.1,
            });

            totalTokens += llmResult.tokensUsed;
            allRawOutputs.push(llmResult.text);

            // Parse each individual response and collect products
            const parsed = extractJsonArrayFromText(llmResult.text);
            if (parsed && parsed.length > 0) {
                allProductJsons.push(...parsed);
            }

            console.log(`   ✅ [${i + 1}/${successfulPages.length}] ${page.title || page.url}: ${parsed?.length || 0} products (${llmResult.tokensUsed} tokens)`);

            // Update progress incrementally
            await prisma.automationRun.update({
                where: { id: runId },
                data: {
                    productsFound: allProductJsons.length,
                    llmTokensUsed: totalTokens,
                },
            }).catch(() => { /* non-critical */ });
        } catch (err) {
            const msg = `Failed to extract from ${page.url}: ${err instanceof Error ? err.message : err}`;
            errors.push(msg);
            console.warn(`   ⚠️ [${i + 1}/${successfulPages.length}] ${msg}`);
        }
    }

    console.log(`   📊 Deep crawl extracted ${allProductJsons.length} products from ${successfulPages.length} pages (${totalTokens} total tokens)`);

    // Step 4: Build a single DataPackage from all collected products
    const combinedJson = JSON.stringify(allProductJsons);
    console.log(`   📦 Building data package from ${allProductJsons.length} products...`);
    const buildResult = await buildDataPackage(runId, config.id, config.brand?.id || null, combinedJson);
    console.log(`   ✅ Created DataPackage ${buildResult.packageId} with ${buildResult.itemCount} items`);
    errors.push(...buildResult.errors);

    // Step 5: Mark complete
    await prisma.automationRun.update({
        where: { id: runId },
        data: {
            status: 'COMPLETED',
            completedAt: new Date(),
            productsFound: buildResult.itemCount,
            rawOutput: combinedJson.slice(0, 100000), // cap raw output storage
            llmTokensUsed: totalTokens,
            errors: errors.length > 0 ? errors : undefined,
        },
    });

    console.log(`   🏁 Run ${runId} completed (DEEP): ${buildResult.itemCount} products from ${successfulPages.length} pages, ${totalTokens} tokens\n`);
}

/**
 * Quick JSON array extraction for per-page LLM responses.
 */
function extractJsonArrayFromText(text: string): unknown[] | null {
    // Try direct parse
    try {
        const parsed = JSON.parse(text);
        if (Array.isArray(parsed)) return parsed;
        if (parsed && typeof parsed === 'object') {
            for (const key of ['products', 'items', 'data', 'results']) {
                if (Array.isArray(parsed[key])) return parsed[key];
            }
        }
    } catch { /* try code fence */ }

    // Try markdown code fence
    const fenceMatch = text.match(/```(?:json)?\s*\n?([\s\S]*?)```/);
    if (fenceMatch) {
        try {
            const parsed = JSON.parse(fenceMatch[1].trim());
            if (Array.isArray(parsed)) return parsed;
        } catch { /* continue */ }
    }

    // Try bracket extraction
    const start = text.indexOf('[');
    const end = text.lastIndexOf(']');
    if (start !== -1 && end > start) {
        try {
            const parsed = JSON.parse(text.slice(start, end + 1));
            if (Array.isArray(parsed)) return parsed;
        } catch { /* give up */ }
    }

    return null;
}

