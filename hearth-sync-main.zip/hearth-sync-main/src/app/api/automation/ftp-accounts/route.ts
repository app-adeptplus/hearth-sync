import prisma from '@/lib/db';
import { NextRequest, NextResponse } from 'next/server';
import * as crypto from 'crypto';
import * as fs from 'fs';
import * as path from 'path';

// GET /api/automation/ftp-accounts — List all inbound FTP drop zone accounts
export async function GET(request: NextRequest) {
    try {
        const { searchParams } = new URL(request.url);
        const manufacturerId = searchParams.get('manufacturerId');
        const brandId = searchParams.get('brandId');

        const accounts = await prisma.manufacturerFtpAccount.findMany({
            where: {
                ...(manufacturerId ? { manufacturerId } : {}),
                ...(brandId ? { brandId } : {}),
            },
            include: {
                manufacturer: { select: { id: true, name: true, slug: true } },
                brand: { select: { id: true, name: true, slug: true } },
                _count: { select: { uploadLogs: true } },
            },
            orderBy: { createdAt: 'desc' },
        });

        // Never return ftpPassword in list view
        return NextResponse.json(accounts.map((a: any) => ({ ...a, ftpPassword: undefined })));
    } catch (error: any) {
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}

// POST /api/automation/ftp-accounts — Provision a new inbound FTP drop zone
export async function POST(request: NextRequest) {
    try {
        const body = await request.json();
        const { manufacturerId, brandId, label, notes } = body;

        if (!manufacturerId) {
            return NextResponse.json({ error: 'manufacturerId is required' }, { status: 400 });
        }
        if (!brandId) {
            return NextResponse.json({ error: 'brandId is required' }, { status: 400 });
        }
        if (!label) {
            return NextResponse.json({ error: 'label is required' }, { status: 400 });
        }

        // Verify manufacturer exists
        const manufacturer = await prisma.manufacturer.findUnique({
            where: { id: manufacturerId },
            select: { id: true, slug: true },
        });
        if (!manufacturer) {
            return NextResponse.json({ error: 'Manufacturer not found' }, { status: 404 });
        }

        // Verify brand exists and belongs to this manufacturer
        const brand = await prisma.brand.findFirst({
            where: { id: brandId, manufacturerId },
            select: { id: true, name: true, slug: true },
        });
        if (!brand) {
            return NextResponse.json({ error: 'Brand not found or does not belong to the selected manufacturer' }, { status: 400 });
        }

        // Generate unique credentials — use brand slug for the path
        const randomSuffix = crypto.randomBytes(3).toString('hex');
        const ftpUser = `${brand.slug.replace(/[^a-z0-9]/gi, '-').toLowerCase()}-${randomSuffix}`;
        const ftpPasswordPlain = crypto.randomBytes(16).toString('base64url');
        const ftpPath = `./ftp-uploads/${manufacturer.slug}/${brand.slug}/`;
        // Use FTP_HOST env var; falls back to 'localhost' in dev
        const ftpHost = process.env.FTP_HOST || 'localhost';

        // Create the local upload directory
        const absoluteFtpPath = path.join(process.cwd(), 'ftp-uploads', manufacturer.slug, brand.slug);
        if (!fs.existsSync(absoluteFtpPath)) {
            fs.mkdirSync(absoluteFtpPath, { recursive: true });
        }

        const account = await prisma.manufacturerFtpAccount.create({
            data: {
                manufacturerId,
                brandId,
                label,
                ftpHost,
                ftpPort: 22,
                ftpUser,
                ftpPassword: ftpPasswordPlain, // TODO: encrypt at rest (AES-256-GCM)
                ftpPath,
                notes: notes || null,
            },
            include: {
                manufacturer: { select: { id: true, name: true, slug: true } },
                brand: { select: { id: true, name: true, slug: true } },
            },
        });

        // Return password only once on creation
        return NextResponse.json({
            ...account,
            ftpPasswordOnce: ftpPasswordPlain,
        }, { status: 201 });

    } catch (error: any) {
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}
