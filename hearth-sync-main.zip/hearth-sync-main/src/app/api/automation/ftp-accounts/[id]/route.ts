import prisma from '@/lib/db';
import { NextRequest, NextResponse } from 'next/server';

// GET /api/automation/ftp-accounts/:id — Single account with recent upload logs
export async function GET(
    _request: NextRequest,
    { params }: { params: { id: string } }
) {
    try {
        const account = await prisma.manufacturerFtpAccount.findUnique({
            where: { id: params.id },
            include: {
                manufacturer: { select: { id: true, name: true, slug: true } },
                brand: { select: { id: true, name: true, slug: true } },
                uploadLogs: {
                    orderBy: { detectedAt: 'desc' },
                    take: 20,
                },
                _count: { select: { uploadLogs: true } },
            },
        });

        if (!account) {
            return NextResponse.json({ error: 'FTP account not found' }, { status: 404 });
        }

        return NextResponse.json({ ...account, ftpPassword: undefined });
    } catch (error: any) {
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}

// PATCH /api/automation/ftp-accounts/:id — Update label, notes, isActive
export async function PATCH(
    request: NextRequest,
    { params }: { params: { id: string } }
) {
    try {
        const body = await request.json();
        const { label, notes, isActive } = body;

        const data: any = {};
        if (label !== undefined) data.label = label;
        if (notes !== undefined) data.notes = notes || null;
        if (isActive !== undefined) data.isActive = isActive;

        const account = await prisma.manufacturerFtpAccount.update({
            where: { id: params.id },
            data,
            include: {
                manufacturer: { select: { id: true, name: true, slug: true } },
            },
        });

        return NextResponse.json({ ...account, ftpPassword: undefined });
    } catch (error: any) {
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}

// DELETE /api/automation/ftp-accounts/:id — Soft-deactivate (isActive = false)
export async function DELETE(
    _request: NextRequest,
    { params }: { params: { id: string } }
) {
    try {
        const account = await prisma.manufacturerFtpAccount.update({
            where: { id: params.id },
            data: { isActive: false },
        });

        return NextResponse.json({ success: true, id: account.id });
    } catch (error: any) {
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}
