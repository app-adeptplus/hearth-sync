import prisma from '@/lib/db';
import { NextRequest, NextResponse } from 'next/server';
import Papa from 'papaparse';

// ─── Type inference helpers ─────────────────────────────────────────────────

function inferType(values: string[]): 'number' | 'boolean' | 'date' | 'string' {
    const nonEmpty = values.filter(v => v !== '' && v !== null && v !== undefined);
    if (nonEmpty.length === 0) return 'string';

    const isNumber = nonEmpty.every(v => !isNaN(Number(v)) && v.trim() !== '');
    if (isNumber) return 'number';

    const isBool = nonEmpty.every(v => ['true', 'false', '1', '0', 'yes', 'no'].includes(v.toLowerCase()));
    if (isBool) return 'boolean';

    const dateRe = /^\d{4}-\d{2}-\d{2}|^\d{1,2}\/\d{1,2}\/\d{2,4}/;
    const isDate = nonEmpty.every(v => dateRe.test(v));
    if (isDate) return 'date';

    return 'string';
}

function analyzeRows(rows: Record<string, string>[]): {
    columns: { name: string; type: string; example: string }[];
    rowCount: number;
    sample: Record<string, string>[];
} {
    if (rows.length === 0) return { columns: [], rowCount: 0, sample: [] };

    const keys = Object.keys(rows[0]);
    const sampleRows = rows.slice(0, Math.min(50, rows.length));

    const columns = keys.map(key => ({
        name: key,
        type: inferType(sampleRows.map(r => r[key] ?? '')),
        example: rows[0][key] ?? '',
    }));

    return {
        columns,
        rowCount: rows.length,
        sample: rows.slice(0, 5),
    };
}

// ─── Parse helpers ──────────────────────────────────────────────────────────

function parseCsv(text: string): Record<string, string>[] {
    const result = Papa.parse<Record<string, string>>(text, {
        header: true,
        skipEmptyLines: true,
        transformHeader: h => h.trim(),
    });
    return result.data;
}

function parseJson(text: string): Record<string, string>[] {
    const parsed = JSON.parse(text);
    const arr = Array.isArray(parsed) ? parsed : [parsed];
    // Flatten any nested objects to strings for analysis
    return arr.map((row: any) =>
        Object.fromEntries(
            Object.entries(row).map(([k, v]) => [
                k,
                typeof v === 'object' ? JSON.stringify(v) : String(v ?? ''),
            ])
        )
    );
}

function parseTxt(text: string): Record<string, string>[] {
    const lines = text.split('\n').map(l => l.trimEnd()).filter(Boolean);
    if (lines.length < 2) return [];

    // Detect delimiter
    const first = lines[0];
    const delim = first.includes('\t') ? '\t' : first.includes(',') ? ',' : '|';
    const headers = first.split(delim).map(h => h.trim());

    return lines.slice(1).map(line => {
        const vals = line.split(delim);
        return Object.fromEntries(headers.map((h, i) => [h, (vals[i] ?? '').trim()]));
    });
}

// ─── Route Handler ───────────────────────────────────────────────────────────

export async function POST(request: NextRequest) {
    try {
        const formData = await request.formData();
        const file = formData.get('file') as File | null;
        const ftpAccountId = formData.get('ftpAccountId') as string | null;
        const labelOverride = formData.get('label') as string | null;

        if (!file) return NextResponse.json({ error: 'No file uploaded' }, { status: 400 });
        if (!ftpAccountId) return NextResponse.json({ error: 'ftpAccountId is required' }, { status: 400 });

        // Resolve the FTP account → brand
        const ftpAccount = await prisma.manufacturerFtpAccount.findUnique({
            where: { id: ftpAccountId },
            include: { brand: true, manufacturer: true },
        });
        if (!ftpAccount) return NextResponse.json({ error: 'FTP account not found' }, { status: 404 });

        // Read and parse the file
        const text = await file.text();
        const ext = file.name.split('.').pop()?.toLowerCase() ?? '';
        let rows: Record<string, string>[];

        try {
            if (ext === 'json') {
                rows = parseJson(text);
            } else if (ext === 'txt') {
                rows = parseTxt(text);
            } else {
                // Default to CSV for .csv and any unknown extension
                rows = parseCsv(text);
            }
        } catch (parseErr: any) {
            return NextResponse.json({ error: `Could not parse file: ${parseErr.message}` }, { status: 422 });
        }

        const analysis = analyzeRows(rows);

        // Build DataPackage name
        const packageName = labelOverride?.trim()
            || `${ftpAccount.brand.name} — ${file.name} (Test Upload)`;

        // Create the DataPackage record
        const dataPackage = await prisma.dataPackage.create({
            data: {
                name: packageName,
                brandId: ftpAccount.brandId,
                rawData: {
                    source: 'ftp_test_upload',
                    fileName: file.name,
                    fileType: ext,
                    fileSizeBytes: file.size,
                    ftpAccountId: ftpAccount.id,
                    ...analysis,
                },
                status: 'PENDING_REVIEW',
            },
        });

        // Log the upload against the FTP account
        await prisma.ftpUploadLog.create({
            data: {
                accountId: ftpAccountId,
                fileName: file.name,
                fileSizeBytes: file.size,
                fileType: ext,
                status: 'processed',
                dataPackageId: dataPackage.id,
            },
        });

        return NextResponse.json({
            dataPackageId: dataPackage.id,
            fileName: file.name,
            fileType: ext,
            fileSizeBytes: file.size,
            brand: { id: ftpAccount.brand.id, name: ftpAccount.brand.name },
            ...analysis,
        }, { status: 201 });

    } catch (error: any) {
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}
