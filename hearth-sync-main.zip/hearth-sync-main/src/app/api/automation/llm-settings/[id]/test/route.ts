import prisma from '@/lib/db';
import { NextRequest, NextResponse } from 'next/server';
import { decryptSecret, encryptSecret, isEncrypted } from '@/lib/encryption';

// POST /api/automation/llm-settings/[id]/test
// Sends a minimal API call to verify the stored key works
export async function POST(
    _req: NextRequest,
    { params }: { params: { id: string } }
) {
    const start = Date.now();
    try {
        const config = await prisma.llmApiConfig.findUnique({ where: { id: params.id } });
        if (!config) {
            return NextResponse.json({ error: 'Not found' }, { status: 404 });
        }

        // Lazy migration: encrypt any plaintext key that was stored before encryption was added
        let storedKey = config.apiKey;
        if (storedKey && !isEncrypted(storedKey)) {
            const encrypted = encryptSecret(storedKey);
            await prisma.llmApiConfig.update({
                where: { id: params.id },
                data: { apiKey: encrypted },
            });
            storedKey = encrypted;
        }

        if (!storedKey) {
            return NextResponse.json({ error: 'No API key stored for this provider' }, { status: 400 });
        }

        const apiKey = decryptSecret(storedKey);
        let testStatus = 'success';
        let errorMessage: string | null = null;

        try {
            if (config.provider === 'OPENAI' || config.provider === 'AZURE_OPENAI' || config.provider === 'CUSTOM') {
                const baseUrl = config.baseUrl || 'https://api.openai.com/v1';
                const res = await fetch(`${baseUrl}/models`, {
                    headers: { Authorization: `Bearer ${apiKey}` },
                    signal: AbortSignal.timeout(10000),
                });
                if (!res.ok) {
                    const body = await res.json().catch(() => ({}));
                    errorMessage = body?.error?.message || `HTTP ${res.status}`;
                    testStatus = `error: ${errorMessage}`;
                }
            } else if (config.provider === 'ANTHROPIC') {
                const res = await fetch('https://api.anthropic.com/v1/messages', {
                    method: 'POST',
                    headers: {
                        'x-api-key': apiKey,
                        'anthropic-version': '2023-06-01',
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        model: config.model,
                        max_tokens: 1,
                        messages: [{ role: 'user', content: 'ping' }],
                    }),
                    signal: AbortSignal.timeout(10000),
                });
                if (!res.ok) {
                    const body = await res.json().catch(() => ({}));
                    errorMessage = body?.error?.message || `HTTP ${res.status}`;
                    testStatus = `error: ${errorMessage}`;
                }
            } else if (config.provider === 'GOOGLE_GEMINI') {
                const res = await fetch(
                    `https://generativelanguage.googleapis.com/v1/models?key=${apiKey}`,
                    { signal: AbortSignal.timeout(10000) }
                );
                if (!res.ok) {
                    const body = await res.json().catch(() => ({}));
                    errorMessage = body?.error?.message || `HTTP ${res.status}`;
                    testStatus = `error: ${errorMessage}`;
                }
            } else {
                testStatus = 'error: unsupported provider for test';
                errorMessage = 'Unsupported provider';
            }
        } catch (fetchErr: any) {
            testStatus = `error: ${fetchErr.message}`;
            errorMessage = fetchErr.message;
        }

        const latencyMs = Date.now() - start;

        await prisma.llmApiConfig.update({
            where: { id: params.id },
            data: {
                lastTestedAt: new Date(),
                lastTestStatus: testStatus,
            },
        });

        return NextResponse.json({
            success: testStatus === 'success',
            status: testStatus,
            latencyMs,
            error: errorMessage,
        });
    } catch (error: any) {
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}
