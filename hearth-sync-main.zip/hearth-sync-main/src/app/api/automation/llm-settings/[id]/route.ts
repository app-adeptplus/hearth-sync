import prisma from '@/lib/db';
import { NextRequest, NextResponse } from 'next/server';
import { encryptSecret, maskSecret, decryptSecret, isEncrypted } from '@/lib/encryption';

// GET /api/automation/llm-settings/[id]
export async function GET(
    _req: NextRequest,
    { params }: { params: { id: string } }
) {
    try {
        const config = await prisma.llmApiConfig.findUnique({
            where: { id: params.id },
            include: {
                externalServiceLinks: { include: { externalService: true } },
                mcpServerLinks: { include: { mcpServer: true } },
            },
        });
        if (!config) {
            return NextResponse.json({ error: 'Not found' }, { status: 404 });
        }

        // Lazy migration: auto-encrypt plaintext keys stored before encryption was added
        if (config.apiKey && !isEncrypted(config.apiKey)) {
            const encrypted = encryptSecret(config.apiKey);
            await prisma.llmApiConfig.update({ where: { id: params.id }, data: { apiKey: encrypted } });
            config.apiKey = encrypted;
        }

        return NextResponse.json({
            ...config,
            apiKey: config.apiKey ? maskSecret(decryptSecret(config.apiKey)) : '',
        });
    } catch (error: any) {
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}

// PATCH /api/automation/llm-settings/[id]
export async function PATCH(
    request: NextRequest,
    { params }: { params: { id: string } }
) {
    try {
        const body = await request.json();
        const {
            displayName, provider, apiKey, model, baseUrl,
            maxTokens, temperature, topP, isDefault, isActive,
        } = body;

        const data: any = {};
        if (displayName !== undefined) data.displayName = displayName;
        if (provider !== undefined) data.provider = provider;
        if (model !== undefined) data.model = model;
        if (baseUrl !== undefined) data.baseUrl = baseUrl || null;
        if (maxTokens !== undefined) data.maxTokens = maxTokens;
        if (temperature !== undefined) data.temperature = temperature;
        if (topP !== undefined) data.topP = topP ?? null;
        if (isActive !== undefined) data.isActive = isActive;

        // Re-encrypt the key only if a new plaintext key was provided
        if (apiKey !== undefined && !apiKey.startsWith('****')) {
            data.apiKey = encryptSecret(apiKey);
        }

        if (isDefault === true) {
            await prisma.llmApiConfig.updateMany({
                where: { isDefault: true, id: { not: params.id } },
                data: { isDefault: false },
            });
            data.isDefault = true;
        } else if (isDefault === false) {
            data.isDefault = false;
        }

        const updated = await prisma.llmApiConfig.update({
            where: { id: params.id },
            data,
        });

        return NextResponse.json({
            ...updated,
            apiKey: maskSecret(decryptSecret(updated.apiKey)),
        });
    } catch (error: any) {
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}

// DELETE /api/automation/llm-settings/[id]
export async function DELETE(
    _req: NextRequest,
    { params }: { params: { id: string } }
) {
    try {
        // Check if this is the only active default — prevent orphaned state
        const config = await prisma.llmApiConfig.findUnique({ where: { id: params.id } });
        if (!config) return NextResponse.json({ error: 'Not found' }, { status: 404 });

        await prisma.llmApiConfig.delete({ where: { id: params.id } });
        return NextResponse.json({ success: true });
    } catch (error: any) {
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}
