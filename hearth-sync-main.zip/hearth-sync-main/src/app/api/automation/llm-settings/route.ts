import prisma from '@/lib/db';
import { NextRequest, NextResponse } from 'next/server';
import { encryptSecret, maskSecret, decryptSecret, isEncrypted } from '@/lib/encryption';

// GET /api/automation/llm-settings — List all LLM configs
export async function GET() {
    try {
        const configs = await prisma.llmApiConfig.findMany({
            orderBy: [{ isDefault: 'desc' }, { createdAt: 'desc' }],
        });

        // Lazy batch migration: encrypt any plaintext keys stored before encryption was added
        for (const c of configs) {
            if (c.apiKey && !isEncrypted(c.apiKey)) {
                const encrypted = encryptSecret(c.apiKey);
                await prisma.llmApiConfig.update({ where: { id: c.id }, data: { apiKey: encrypted } });
                c.apiKey = encrypted;
            }
        }

        // Mask API keys for safe display
        const masked = configs.map(c => ({
            ...c,
            apiKey: c.apiKey ? maskSecret(decryptSecret(c.apiKey)) : '',
        }));

        return NextResponse.json(masked);
    } catch (error: any) {
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}

// POST /api/automation/llm-settings — Add new provider config
export async function POST(request: NextRequest) {
    try {
        const body = await request.json();
        const { displayName, provider, apiKey, model, baseUrl, maxTokens, temperature, topP, isDefault } = body;

        if (!provider || !apiKey || !model) {
            return NextResponse.json(
                { error: 'provider, apiKey, and model are required' },
                { status: 400 }
            );
        }

        // If setting as default, unset any existing defaults
        if (isDefault) {
            await prisma.llmApiConfig.updateMany({
                where: { isDefault: true },
                data: { isDefault: false },
            });
        }

        const config = await prisma.llmApiConfig.create({
            data: {
                displayName: displayName || null,
                provider,
                apiKey: encryptSecret(apiKey), // ← always encrypt on create
                model,
                baseUrl: baseUrl || null,
                maxTokens: maxTokens || 4096,
                temperature: temperature ?? 0.3,
                topP: topP ?? null,
                isDefault: isDefault || false,
                isActive: true,
            },
        });

        // Return with masked key
        return NextResponse.json(
            { ...config, apiKey: maskSecret(decryptSecret(config.apiKey)) },
            { status: 201 }
        );
    } catch (error: any) {
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}

// PATCH /api/automation/llm-settings — Update an existing config
export async function PATCH(request: NextRequest) {
    try {
        const body = await request.json();
        const { id, provider, apiKey, model, baseUrl, maxTokens, temperature, isDefault, isActive } = body;

        if (!id) {
            return NextResponse.json({ error: 'id is required' }, { status: 400 });
        }

        const data: any = {};
        if (provider !== undefined) data.provider = provider;
        if (apiKey !== undefined) data.apiKey = apiKey;
        if (model !== undefined) data.model = model;
        if (baseUrl !== undefined) data.baseUrl = baseUrl || null;
        if (maxTokens !== undefined) data.maxTokens = maxTokens;
        if (temperature !== undefined) data.temperature = temperature;
        if (isActive !== undefined) data.isActive = isActive;

        // If setting as default, unset any existing defaults
        if (isDefault) {
            await prisma.llmApiConfig.updateMany({
                where: { isDefault: true, id: { not: id } },
                data: { isDefault: false },
            });
            data.isDefault = true;
        } else if (isDefault === false) {
            data.isDefault = false;
        }

        const config = await prisma.llmApiConfig.update({
            where: { id },
            data,
        });

        return NextResponse.json({
            ...config,
            apiKey: `****${config.apiKey.slice(-4)}`,
        });
    } catch (error: any) {
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}
