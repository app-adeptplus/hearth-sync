import prisma from '@/lib/db';
import { NextRequest, NextResponse } from 'next/server';
import { encryptSecret, maskSecret, decryptSecret } from '@/lib/encryption';

// GET /api/automation/mcp-servers/[id]
export async function GET(
    _req: NextRequest,
    { params }: { params: { id: string } }
) {
    try {
        const server = await prisma.mcpServerConfig.findUnique({
            where: { id: params.id },
            include: {
                providerLinks: {
                    include: { llmConfig: { select: { id: true, displayName: true, provider: true } } },
                },
                configLinks: {
                    include: { automation: { select: { id: true, name: true } } },
                },
            },
        });
        if (!server) return NextResponse.json({ error: 'Not found' }, { status: 404 });
        return NextResponse.json({
            ...server,
            authToken: server.authToken ? maskSecret(decryptSecret(server.authToken)) : null,
        });
    } catch (error: any) {
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}

// PATCH /api/automation/mcp-servers/[id]
export async function PATCH(
    request: NextRequest,
    { params }: { params: { id: string } }
) {
    try {
        const body = await request.json();
        const { name, description, transportType, url, headers, authToken, isActive, linkedLlmConfigIds } = body;

        const data: any = {};
        if (name !== undefined) data.name = name;
        if (description !== undefined) data.description = description;
        if (transportType !== undefined) data.transportType = transportType;
        if (url !== undefined) data.url = url;
        if (headers !== undefined) data.headers = headers;
        if (isActive !== undefined) data.isActive = isActive;
        if (authToken !== undefined && !authToken.startsWith('****')) {
            data.authToken = authToken ? encryptSecret(authToken) : null;
        }

        if (linkedLlmConfigIds !== undefined) {
            await prisma.mcpServerProviderLink.deleteMany({ where: { mcpServerId: params.id } });
            if (linkedLlmConfigIds.length > 0) {
                data.providerLinks = {
                    create: linkedLlmConfigIds.map((llmConfigId: string) => ({ llmConfigId })),
                };
            }
        }

        const updated = await prisma.mcpServerConfig.update({ where: { id: params.id }, data });
        return NextResponse.json({
            ...updated,
            authToken: updated.authToken ? '****' : null,
        });
    } catch (error: any) {
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}

// DELETE /api/automation/mcp-servers/[id]
export async function DELETE(
    _req: NextRequest,
    { params }: { params: { id: string } }
) {
    try {
        await prisma.mcpServerConfig.delete({ where: { id: params.id } });
        return NextResponse.json({ success: true });
    } catch (error: any) {
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}
