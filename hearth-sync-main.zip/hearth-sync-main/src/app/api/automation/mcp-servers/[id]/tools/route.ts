import prisma from '@/lib/db';
import { NextRequest, NextResponse } from 'next/server';

// GET /api/automation/mcp-servers/[id]/tools
// Returns the cached list of tools discovered on last connection test
export async function GET(
    _req: NextRequest,
    { params }: { params: { id: string } }
) {
    try {
        const server = await prisma.mcpServerConfig.findUnique({
            where: { id: params.id },
            select: { id: true, discoveredTools: true, toolsRefreshedAt: true },
        });
        if (!server) return NextResponse.json({ error: 'Not found' }, { status: 404 });
        return NextResponse.json({
            tools: server.discoveredTools || [],
            refreshedAt: server.toolsRefreshedAt,
        });
    } catch (error: any) {
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}
