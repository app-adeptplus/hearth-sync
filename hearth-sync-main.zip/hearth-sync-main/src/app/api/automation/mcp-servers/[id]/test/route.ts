import prisma from '@/lib/db';
import { NextRequest, NextResponse } from 'next/server';
import { decryptSecret } from '@/lib/encryption';

// POST /api/automation/mcp-servers/[id]/test
// Attempts to connect via SSE or Streamable HTTP and discover available tools
export async function POST(
    _req: NextRequest,
    { params }: { params: { id: string } }
) {
    const start = Date.now();
    try {
        const server = await prisma.mcpServerConfig.findUnique({ where: { id: params.id } });
        if (!server) return NextResponse.json({ error: 'Not found' }, { status: 404 });

        const authToken = server.authToken ? decryptSecret(server.authToken) : null;
        const headers: Record<string, string> = {
            'Content-Type': 'application/json',
            ...(server.headers as Record<string, string> || {}),
            ...(authToken && { Authorization: `Bearer ${authToken}` }),
        };

        let tools: any[] = [];
        let testStatus = 'success';
        let errorMessage: string | null = null;

        try {
            if (server.transportType === 'STREAMABLE_HTTP') {
                // MCP Streamable HTTP: POST to the endpoint with initialize request
                const initRes = await fetch(server.url, {
                    method: 'POST',
                    headers,
                    body: JSON.stringify({
                        jsonrpc: '2.0', id: 1, method: 'initialize',
                        params: { protocolVersion: '2024-11-05', capabilities: {}, clientInfo: { name: 'HearthSync', version: '1.0.0' } },
                    }),
                    signal: AbortSignal.timeout(15000),
                });
                if (!initRes.ok) {
                    const body = await initRes.json().catch(() => ({}));
                    errorMessage = body?.error?.message || `HTTP ${initRes.status}`;
                    testStatus = `error: ${errorMessage}`;
                } else {
                    // List tools
                    const toolsRes = await fetch(server.url, {
                        method: 'POST',
                        headers,
                        body: JSON.stringify({ jsonrpc: '2.0', id: 2, method: 'tools/list', params: {} }),
                        signal: AbortSignal.timeout(10000),
                    });
                    if (toolsRes.ok) {
                        const toolsData = await toolsRes.json();
                        tools = toolsData?.result?.tools || [];
                    }
                }
            } else if (server.transportType === 'SSE') {
                // SSE: just check the endpoint responds — tool discovery requires SSE streaming
                const res = await fetch(server.url, {
                    headers: { ...headers, Accept: 'text/event-stream' },
                    signal: AbortSignal.timeout(8000),
                });
                if (!res.ok) {
                    errorMessage = `HTTP ${res.status}`;
                    testStatus = `error: ${errorMessage}`;
                }
                // Note: Full tool discovery over SSE requires a persistent connection.
                // Returning empty tools from test is acceptable — user can use "Refresh Tools" later.
            }
        } catch (fetchErr: any) {
            testStatus = `error: ${fetchErr.message}`;
            errorMessage = fetchErr.message;
        }

        const latencyMs = Date.now() - start;
        const now = new Date();

        await prisma.mcpServerConfig.update({
            where: { id: params.id },
            data: {
                lastConnectedAt: testStatus === 'success' ? now : undefined,
                lastError: testStatus !== 'success' ? errorMessage : null,
                ...(tools.length > 0 && {
                    discoveredTools: tools,
                    toolsRefreshedAt: now,
                }),
            },
        });

        return NextResponse.json({
            success: testStatus === 'success',
            status: testStatus,
            latencyMs,
            toolCount: tools.length,
            tools,
            error: errorMessage,
        });
    } catch (error: any) {
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}
