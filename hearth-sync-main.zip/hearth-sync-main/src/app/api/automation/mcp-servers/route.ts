import prisma from '@/lib/db';
import { NextRequest, NextResponse } from 'next/server';
import { encryptSecret, maskSecret, decryptSecret } from '@/lib/encryption';

// GET /api/automation/mcp-servers
export async function GET() {
    try {
        const servers = await prisma.mcpServerConfig.findMany({
            orderBy: { createdAt: 'desc' },
            include: {
                providerLinks: {
                    include: { llmConfig: { select: { id: true, displayName: true, provider: true } } },
                },
            },
        });
        // Mask auth tokens
        const masked = servers.map(s => ({
            ...s,
            authToken: s.authToken ? maskSecret(decryptSecret(s.authToken)) : null,
        }));
        return NextResponse.json(masked);
    } catch (error: any) {
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}

// POST /api/automation/mcp-servers
export async function POST(request: NextRequest) {
    try {
        const body = await request.json();
        const { name, description, transportType, url, headers, authToken, linkedLlmConfigIds } = body;

        if (!name || !transportType || !url) {
            return NextResponse.json(
                { error: 'name, transportType, and url are required' },
                { status: 400 }
            );
        }

        const server = await prisma.mcpServerConfig.create({
            data: {
                name,
                description: description || null,
                transportType,
                url,
                headers: headers || null,
                authToken: authToken ? encryptSecret(authToken) : null,
                isActive: true,
                ...(linkedLlmConfigIds?.length > 0 && {
                    providerLinks: {
                        create: linkedLlmConfigIds.map((llmConfigId: string) => ({ llmConfigId })),
                    },
                }),
            },
        });

        return NextResponse.json(
            { ...server, authToken: server.authToken ? '****' : null },
            { status: 201 }
        );
    } catch (error: any) {
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}
