import prisma from '@/lib/db';
import { NextRequest, NextResponse } from 'next/server';

// POST /api/automation/prompt-templates/[id]/revert/[versionId]
export async function POST(
    _req: NextRequest,
    { params }: { params: { id: string; versionId: string } }
) {
    try {
        const version = await prisma.promptTemplateVersion.findUnique({
            where: { id: params.versionId },
        });
        if (!version || version.templateId !== params.id) {
            return NextResponse.json({ error: 'Version not found' }, { status: 404 });
        }

        const current = await prisma.promptTemplate.findUnique({ where: { id: params.id } });
        if (!current) return NextResponse.json({ error: 'Template not found' }, { status: 404 });

        // Snapshot the current version before reverting
        await prisma.promptTemplateVersion.create({
            data: {
                templateId: params.id,
                version: current.version,
                systemPrompt: current.systemPrompt,
                variables: current.variables as any,
                changeNote: `Auto-snapshot before revert to v${version.version}`,
            },
        });

        // Restore the selected version's content
        const restored = await prisma.promptTemplate.update({
            where: { id: params.id },
            data: {
                systemPrompt: version.systemPrompt,
                variables: version.variables as any,
                version: current.version + 1,
            },
        });

        return NextResponse.json(restored);
    } catch (error: any) {
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}
