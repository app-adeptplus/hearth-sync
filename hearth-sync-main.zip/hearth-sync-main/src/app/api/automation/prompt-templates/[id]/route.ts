import prisma from '@/lib/db';
import { NextRequest, NextResponse } from 'next/server';

// GET /api/automation/prompt-templates/[id]
export async function GET(
    _req: NextRequest,
    { params }: { params: { id: string } }
) {
    try {
        const template = await prisma.promptTemplate.findUnique({
            where: { id: params.id },
            include: {
                versions: { orderBy: { version: 'desc' } },
                automationConfigs: {
                    select: { id: true, name: true, sourceType: true, status: true },
                },
            },
        });
        if (!template) return NextResponse.json({ error: 'Not found' }, { status: 404 });
        return NextResponse.json(template);
    } catch (error: any) {
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}

// PATCH /api/automation/prompt-templates/[id]
// Auto-saves a new version before updating
export async function PATCH(
    request: NextRequest,
    { params }: { params: { id: string } }
) {
    try {
        const body = await request.json();
        const { name, category, systemPrompt, variables, tags, changeNote } = body;

        const existing = await prisma.promptTemplate.findUnique({ where: { id: params.id } });
        if (!existing) return NextResponse.json({ error: 'Not found' }, { status: 404 });

        const nextVersion = existing.version + 1;

        // Save a version snapshot of the current state before overwriting
        await prisma.promptTemplateVersion.create({
            data: {
                templateId: params.id,
                version: existing.version,
                systemPrompt: existing.systemPrompt,
                variables: existing.variables as any,
                changeNote: changeNote || null,
            },
        });

        const data: any = { version: nextVersion };
        if (name !== undefined) data.name = name;
        if (category !== undefined) data.category = category;
        if (systemPrompt !== undefined) data.systemPrompt = systemPrompt;
        if (variables !== undefined) data.variables = variables;
        if (tags !== undefined) data.tags = tags;

        const updated = await prisma.promptTemplate.update({
            where: { id: params.id },
            data,
        });

        return NextResponse.json(updated);
    } catch (error: any) {
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}

// DELETE /api/automation/prompt-templates/[id]
// Archives the template (soft delete) rather than destroying it
export async function DELETE(
    _req: NextRequest,
    { params }: { params: { id: string } }
) {
    try {
        const updated = await prisma.promptTemplate.update({
            where: { id: params.id },
            data: { isActive: false },
        });
        return NextResponse.json(updated);
    } catch (error: any) {
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}
