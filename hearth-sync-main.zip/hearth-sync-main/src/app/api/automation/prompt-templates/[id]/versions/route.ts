import prisma from '@/lib/db';
import { NextRequest, NextResponse } from 'next/server';

// GET /api/automation/prompt-templates/[id]/versions
export async function GET(
    _req: NextRequest,
    { params }: { params: { id: string } }
) {
    try {
        const versions = await prisma.promptTemplateVersion.findMany({
            where: { templateId: params.id },
            orderBy: { version: 'desc' },
        });
        return NextResponse.json(versions);
    } catch (error: any) {
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}
