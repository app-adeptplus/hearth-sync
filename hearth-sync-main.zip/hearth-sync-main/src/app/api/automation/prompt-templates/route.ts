import prisma from '@/lib/db';
import { NextRequest, NextResponse } from 'next/server';

// GET /api/automation/prompt-templates
export async function GET(request: NextRequest) {
    try {
        const { searchParams } = new URL(request.url);
        const category = searchParams.get('category');
        const tag = searchParams.get('tag');

        const templates = await prisma.promptTemplate.findMany({
            where: {
                isActive: true,
                ...(category && { category: category as any }),
                ...(tag && { tags: { has: tag } }),
            },
            include: {
                _count: { select: { automationConfigs: true, versions: true } },
            },
            orderBy: [{ category: 'asc' }, { updatedAt: 'desc' }],
        });
        return NextResponse.json(templates);
    } catch (error: any) {
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}

// POST /api/automation/prompt-templates
export async function POST(request: NextRequest) {
    try {
        const body = await request.json();
        const { name, category, systemPrompt, variables, tags } = body;

        if (!name || !category || !systemPrompt) {
            return NextResponse.json(
                { error: 'name, category, and systemPrompt are required' },
                { status: 400 }
            );
        }

        const template = await prisma.promptTemplate.create({
            data: {
                name,
                category,
                systemPrompt,
                variables: variables || null,
                tags: tags || [],
                version: 1,
                isActive: true,
            },
        });

        return NextResponse.json(template, { status: 201 });
    } catch (error: any) {
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}
