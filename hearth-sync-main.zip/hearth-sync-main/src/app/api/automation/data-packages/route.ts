import prisma from '@/lib/db';
import { NextRequest, NextResponse } from 'next/server';

// GET /api/automation/data-packages — List data packages
export async function GET(request: NextRequest) {
    try {
        const { searchParams } = new URL(request.url);
        const status = searchParams.get('status');
        const brandId = searchParams.get('brandId');

        const where: any = {};
        if (status) where.status = status;
        if (brandId) where.brandId = brandId;

        const packages = await prisma.dataPackage.findMany({
            where,
            include: {
                brand: { select: { id: true, name: true } },
                automationRun: {
                    select: {
                        id: true,
                        config: { select: { id: true, name: true, sourceType: true } },
                    },
                },
                _count: { select: { items: true } },
            },
            orderBy: { createdAt: 'desc' },
        });

        return NextResponse.json(packages);
    } catch (error: any) {
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}

// POST /api/automation/data-packages — Create a manual data package
export async function POST(request: NextRequest) {
    try {
        const body = await request.json();
        const { name, brandId, rawData, reviewNotes } = body;

        if (!name) {
            return NextResponse.json({ error: 'name is required' }, { status: 400 });
        }

        const pkg = await prisma.dataPackage.create({
            data: {
                name,
                brandId: brandId || null,
                rawData: rawData || null,
                reviewNotes: reviewNotes || null,
                status: 'PENDING_REVIEW',
            },
        });

        return NextResponse.json(pkg, { status: 201 });
    } catch (error: any) {
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}
