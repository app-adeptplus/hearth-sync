import prisma from '@/lib/db';
import { NextRequest, NextResponse } from 'next/server';

// GET /api/automation/data-packages/:id — Single package with items
export async function GET(
    request: NextRequest,
    { params }: { params: { id: string } }
) {
    try {
        const pkg = await prisma.dataPackage.findUnique({
            where: { id: params.id },
            include: {
                brand: { select: { id: true, name: true } },
                automationRun: {
                    select: {
                        id: true,
                        status: true,
                        config: { select: { id: true, name: true, sourceType: true } },
                    },
                },
                items: {
                    orderBy: { createdAt: 'desc' },
                },
            },
        });

        if (!pkg) {
            return NextResponse.json({ error: 'Data package not found' }, { status: 404 });
        }

        return NextResponse.json(pkg);
    } catch (error: any) {
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}

// PATCH /api/automation/data-packages/:id — Update status, enrichedData, notes, or perform actions
export async function PATCH(
    request: NextRequest,
    { params }: { params: { id: string } }
) {
    try {
        const body = await request.json();
        const { action, status, enrichedData, reviewNotes } = body;

        // Action: approve-all — bulk approve all pending items in this package
        if (action === 'approve-all') {
            const result = await prisma.dataPackageItem.updateMany({
                where: { packageId: params.id, status: 'pending' },
                data: { status: 'approved' },
            });

            // Also update the package status to APPROVED
            await prisma.dataPackage.update({
                where: { id: params.id },
                data: { status: 'APPROVED' },
            });

            return NextResponse.json({
                action: 'approve-all',
                approvedCount: result.count,
            });
        }

        // Action: reject-all — bulk reject all pending items
        if (action === 'reject-all') {
            const result = await prisma.dataPackageItem.updateMany({
                where: { packageId: params.id, status: 'pending' },
                data: { status: 'rejected' },
            });

            await prisma.dataPackage.update({
                where: { id: params.id },
                data: { status: 'REJECTED' },
            });

            return NextResponse.json({
                action: 'reject-all',
                rejectedCount: result.count,
            });
        }

        // Per-item status update (approve/reject individual items)
        if (body.itemId && body.itemStatus) {
            await prisma.dataPackageItem.update({
                where: { id: body.itemId },
                data: { status: body.itemStatus },
            });
            return NextResponse.json({ updated: true, itemId: body.itemId, status: body.itemStatus });
        }

        // Default: update package fields
        const data: any = {};
        if (status !== undefined) data.status = status;
        if (enrichedData !== undefined) data.enrichedData = enrichedData;
        if (reviewNotes !== undefined) data.reviewNotes = reviewNotes;

        const pkg = await prisma.dataPackage.update({
            where: { id: params.id },
            data,
        });

        return NextResponse.json(pkg);
    } catch (error: any) {
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}
