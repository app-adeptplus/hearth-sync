import prisma from '@/lib/db';
import { NextRequest, NextResponse } from 'next/server';
import { slugify } from '@/lib/utils';
import { getStorageService } from '@/lib/storage-service';
import { downloadAndStoreImages } from '@/lib/image-downloader';

interface ProposedData {
    name: string;
    modelNumber: string;
    sku: string;
    modelNumberIsGenerated: boolean;
    description?: string;
    descriptionSummary?: string;
    categoryIds: string[];
    attributeValues: { attributeId: string; attributeName: string; value: string }[];
    optionGroupIds: string[];
}

/**
 * POST /api/automation/data-packages/:id/import
 *
 * Imports approved DataPackageItems as Product records.
 * - Checks for approved EnrichmentProposals first and uses enriched data when available
 * - Falls back to raw parsed data when no proposal exists
 * - Upserts products on brandId + slug (no duplicates)
 * - Creates ProductImage records from parsedImages
 * - Creates ProductAttributeValue and ProductOptionGroup records from proposals
 * - Marks proposals and enrichment jobs as APPLIED
 * - Updates DataPackage status to IMPORTED
 */
export async function POST(
    _request: NextRequest,
    { params }: { params: { id: string } }
) {
    try {
        // Load the DataPackage with its approved items
        const pkg = await prisma.dataPackage.findUnique({
            where: { id: params.id },
            include: {
                brand: true,
                items: {
                    where: { status: 'approved' },
                },
            },
        });

        if (!pkg) {
            return NextResponse.json({ error: 'Data package not found' }, { status: 404 });
        }

        if (!pkg.brandId || !pkg.brand) {
            return NextResponse.json({ error: 'Data package has no brand assigned. Assign a brand before importing.' }, { status: 400 });
        }

        if (pkg.items.length === 0) {
            return NextResponse.json({ error: 'No approved items to import. Approve items first.' }, { status: 400 });
        }

        if (pkg.status === 'IMPORTED') {
            return NextResponse.json({ error: 'This data package has already been imported.' }, { status: 400 });
        }

        // Pre-load all existing categories for fuzzy matching (fallback for non-proposal items)
        const allCategories = await prisma.productCategory.findMany({
            select: { id: true, name: true, slug: true },
        });
        const categoryIndex = new Map<string, string>();
        for (const cat of allCategories) {
            categoryIndex.set(cat.name.toLowerCase(), cat.id);
            categoryIndex.set(cat.slug.toLowerCase(), cat.id);
        }

        const results = {
            created: 0,
            updated: 0,
            errors: [] as string[],
            imageErrors: [] as string[],
        };

        const storage = getStorageService();
        const appliedProposalIds: string[] = [];

        for (const item of pkg.items) {
            try {
                // Check for an approved EnrichmentProposal for this item
                const proposal = await prisma.enrichmentProposal.findFirst({
                    where: { dataPackageItemId: item.id, status: 'APPROVED' },
                });

                const pd = proposal?.proposedData as ProposedData | null;

                // Use enriched data if available, otherwise fall back to raw data
                const name = pd?.name || item.parsedName;
                if (!name) {
                    results.errors.push(`Item ${item.externalId || item.id}: missing name, skipped`);
                    continue;
                }

                const modelNumber = pd?.modelNumber || item.parsedSku || null;
                const sku = pd?.sku || item.parsedSku || null;
                const description = pd?.descriptionSummary || pd?.description || item.parsedDescription || null;
                const slug = slugify(sku || name);

                // Parse optional fields from raw data
                const dims = item.parsedDimensions as Record<string, number> | null;
                const attrs = item.parsedAttributes as Record<string, string | number> | null;
                const productUrl = attrs?.productUrl ? String(attrs.productUrl) : null;
                const btuInput = (attrs?.btu || attrs?.btuInput) ? (parseInt(String(attrs.btu || attrs.btuInput), 10) || null) : null;
                const priceMsrp = attrs?.price ? (parseFloat(String(attrs.price)) || null) : null;

                // Upsert the product (match on brandId + slug)
                const existing = await prisma.product.findUnique({
                    where: { brandId_slug: { brandId: pkg.brandId!, slug } },
                });

                let product;
                if (existing) {
                    product = await prisma.product.update({
                        where: { id: existing.id },
                        data: {
                            name,
                            slug,
                            modelNumber,
                            sku,
                            description,
                            productUrl,
                            btuInput,
                            priceMsrp,
                            width: dims?.width ?? undefined,
                            height: dims?.height ?? undefined,
                            depth: dims?.depth ?? undefined,
                            weight: dims?.weight ?? undefined,
                        },
                    });
                    results.updated++;
                } else {
                    product = await prisma.product.create({
                        data: {
                            name,
                            slug,
                            brand: { connect: { id: pkg.brandId! } },
                            modelNumber,
                            sku,
                            description,
                            productUrl,
                            status: 'ACTIVE',
                            btuInput,
                            priceMsrp,
                            width: dims?.width ?? undefined,
                            height: dims?.height ?? undefined,
                            depth: dims?.depth ?? undefined,
                            weight: dims?.weight ?? undefined,
                        },
                    });
                    results.created++;
                }

                // Link item to product
                await prisma.dataPackageItem.update({
                    where: { id: item.id },
                    data: { productId: product.id },
                });

                // Download and store images
                if (item.parsedImages && item.parsedImages.length > 0) {
                    const { stored, errors: imgErrs } = await downloadAndStoreImages(
                        item.parsedImages as string[],
                        slug,
                        storage
                    );

                    if (imgErrs.length > 0) {
                        results.imageErrors.push(...imgErrs.map(e => `[${slug}] ${e}`));
                    }

                    if (stored.length > 0) {
                        // Remove existing images before re-importing
                        await prisma.productImage.deleteMany({ where: { productId: product.id } });

                        await prisma.productImage.createMany({
                            data: stored.map((img, i) => ({
                                productId: product.id,
                                url: img.url,
                                altText: img.altText || null,
                                sortOrder: img.sortOrder,
                                isPrimary: i === 0,
                                fileHash: img.fileHash,
                            })),
                        });
                    }
                }

                // ── Category connections ──
                if (pd?.categoryIds?.length) {
                    // Use enriched category IDs (already resolved)
                    await prisma.product.update({
                        where: { id: product.id },
                        data: {
                            categories: {
                                connect: pd.categoryIds.map(id => ({ id })),
                            },
                        },
                    });
                } else if (item.parsedCategories && item.parsedCategories.length > 0) {
                    // Fallback: fuzzy match from raw category names
                    const categoryIds: string[] = [];
                    for (const catName of item.parsedCategories) {
                        const matchId = categoryIndex.get(catName.toLowerCase())
                            || categoryIndex.get(slugify(catName));
                        if (matchId) categoryIds.push(matchId);
                    }

                    if (categoryIds.length > 0) {
                        await prisma.product.update({
                            where: { id: product.id },
                            data: {
                                categories: {
                                    connect: categoryIds.map(id => ({ id })),
                                },
                            },
                        });
                    }
                }

                // ── Attribute values from proposal ──
                if (pd?.attributeValues?.length) {
                    for (const av of pd.attributeValues) {
                        await prisma.productAttributeValue.upsert({
                            where: {
                                productId_attributeId: {
                                    productId: product.id,
                                    attributeId: av.attributeId,
                                },
                            },
                            update: { value: av.value },
                            create: {
                                productId: product.id,
                                attributeId: av.attributeId,
                                value: av.value,
                            },
                        });
                    }
                }

                // ── Option group connections from proposal ──
                if (pd?.optionGroupIds?.length) {
                    for (const groupId of pd.optionGroupIds) {
                        await prisma.productOptionGroup.upsert({
                            where: {
                                productId_groupId: {
                                    productId: product.id,
                                    groupId,
                                },
                            },
                            update: {},
                            create: {
                                productId: product.id,
                                groupId,
                            },
                        });
                    }
                }

                // Track applied proposal
                if (proposal) {
                    appliedProposalIds.push(proposal.id);
                }

            } catch (err) {
                const msg = `Item ${item.externalId || item.id}: ${err instanceof Error ? err.message : err}`;
                results.errors.push(msg);
                console.error(`   ⚠️ Import error: ${msg}`);
            }
        }

        // Mark proposals as APPLIED
        if (appliedProposalIds.length > 0) {
            await prisma.enrichmentProposal.updateMany({
                where: { id: { in: appliedProposalIds } },
                data: { status: 'APPLIED' },
            });
        }

        // Mark enrichment job as APPLIED if it exists
        const enrichedData = pkg.enrichedData as any;
        if (enrichedData?.enrichmentJobId) {
            await prisma.enrichmentJob.update({
                where: { id: enrichedData.enrichmentJobId },
                data: { status: 'APPLIED' },
            }).catch(() => { /* non-critical */ });
        }

        // Update DataPackage status
        await prisma.dataPackage.update({
            where: { id: params.id },
            data: { status: 'IMPORTED' },
        });

        console.log(`📦 Import complete for package ${params.id}: ${results.created} created, ${results.updated} updated, ${results.errors.length} errors, ${appliedProposalIds.length} proposals applied`);

        return NextResponse.json({
            success: true,
            created: results.created,
            updated: results.updated,
            errors: results.errors,
            imageErrors: results.imageErrors,
            proposalsApplied: appliedProposalIds.length,
        });
    } catch (error: any) {
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}
