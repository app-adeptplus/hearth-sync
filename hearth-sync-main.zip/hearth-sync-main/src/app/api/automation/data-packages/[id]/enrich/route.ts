import prisma from '@/lib/db';
import { Prisma } from '@prisma/client';
import { NextRequest, NextResponse } from 'next/server';
import {
    normalizeProductName,
    normalizeModelNumber,
    generateSku,
    fuzzyMatchCategory,
    enrichProduct,
    resolveEnrichmentAgent,
    EnrichmentContext,
    RawProductInput,
} from '@/lib/enrichment-agent';

/**
 * POST /api/automation/data-packages/:id/enrich?phase=normalize|enrich
 *
 * phase=normalize (default):
 *   Deterministic normalization — no LLM calls, no cost.
 *   Results stored in parsedAttributes.enrichmentHints only (never overwrites parsedName/parsedSku).
 *
 * phase=enrich:
 *   Resolves the Enrichment Agent, calls LLM for each item, creates EnrichmentProposals
 *   and TaxonomySuggestions. Sets package status to PENDING_REVIEW after completion.
 */
export async function POST(
    request: NextRequest,
    { params }: { params: { id: string } }
) {
    const phase = request.nextUrl.searchParams.get('phase') || 'normalize';

    if (phase === 'enrich') {
        return handleEnrich(params.id);
    }
    return handleNormalize(params.id);
}

// ═══════════════════════════════════════════════════════════════════════════════
// Phase: NORMALIZE (deterministic, free)
// ═══════════════════════════════════════════════════════════════════════════════

async function handleNormalize(packageId: string) {
    try {
        const pkg = await prisma.dataPackage.findUnique({
            where: { id: packageId },
            include: {
                items: { where: { status: { not: 'rejected' } } },
                brand: { select: { id: true, name: true, brandSku: true } },
            },
        });

        if (!pkg) {
            return NextResponse.json({ error: 'Data package not found' }, { status: 404 });
        }

        const brand = pkg.brand as { id: string; name: string; brandSku: string | null } | null;

        if (!pkg.items.length) {
            return NextResponse.json({ normalizedCount: 0, errors: ['No items to normalize in this package.'] });
        }

        // Load taxonomy context once
        const allCategories = await prisma.productCategory.findMany({
            select: { id: true, name: true, slug: true, parentId: true, likeTerms: true },
        });

        const taxonomyContext: Pick<EnrichmentContext, 'categories' | 'attributes'> = {
            categories: allCategories,
            attributes: [],
        };

        let normalizedCount = 0;
        const errors: string[] = [];

        for (const item of pkg.items) {
            try {
                const currentName = item.parsedName || '';
                const brandName = brand?.name || '';

                // Normalize name
                const normalizedName = brandName && currentName
                    ? normalizeProductName(brandName, currentName)
                    : currentName;

                // Normalize model number — use parsedSku as the candidate model
                const { value: modelNumber, isGenerated } = normalizeModelNumber(
                    item.parsedSku,
                    normalizedName || currentName
                );

                // Generate normalized SKU hint
                const normalizedSku = brand?.brandSku
                    ? generateSku(brand.brandSku, modelNumber)
                    : null;

                // Fuzzy match categories
                const existingCats = (item.parsedCategories as string[]) || [];
                const matchedCategoryIds: string[] = [];
                const unmatchedCategories: string[] = [];
                for (const catName of existingCats) {
                    const id = fuzzyMatchCategory(catName, taxonomyContext.categories);
                    if (id) matchedCategoryIds.push(id);
                    else unmatchedCategories.push(catName);
                }

                // Build updated attributes with enrichment hints
                // IMPORTANT: Store results ONLY in enrichmentHints — never overwrite parsedName/parsedSku
                const existingAttrs = (item.parsedAttributes as Record<string, unknown>) || {};
                const updatedAttrs = {
                    ...existingAttrs,
                    enrichmentHints: {
                        normalizedName: normalizedName !== currentName ? normalizedName : undefined,
                        modelNumber,
                        modelNumberIsGenerated: isGenerated,
                        normalizedSku,
                        matchedCategoryIds,
                        unmatchedCategories,
                    },
                };

                await prisma.dataPackageItem.update({
                    where: { id: item.id },
                    data: {
                        parsedAttributes: updatedAttrs,
                    },
                });

                normalizedCount++;

            } catch (err) {
                const msg = `${item.parsedName || item.id}: ${err instanceof Error ? err.message : err}`;
                errors.push(msg);
                console.error(`[Enrich] Normalize error: ${msg}`);
            }
        }

        console.log(`[Enrich] Normalized ${normalizedCount}/${pkg.items.length} items, ${errors.length} errors`);

        return NextResponse.json({ normalizedCount, skippedCount: errors.length, errors });

    } catch (error: any) {
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}

// ═══════════════════════════════════════════════════════════════════════════════
// Phase: ENRICH (AI-powered, creates proposals)
// ═══════════════════════════════════════════════════════════════════════════════

async function handleEnrich(packageId: string) {
    try {
        // 1. Resolve the enrichment agent
        let agent;
        try {
            agent = await resolveEnrichmentAgent();
        } catch (err: any) {
            return NextResponse.json({ error: err.message }, { status: 400 });
        }

        // 2. Load the package
        const pkg = await prisma.dataPackage.findUnique({
            where: { id: packageId },
            include: {
                items: { where: { status: { not: 'rejected' } } },
                brand: { select: { id: true, name: true, brandSku: true } },
            },
        });

        if (!pkg) {
            return NextResponse.json({ error: 'Data package not found' }, { status: 404 });
        }
        if (!pkg.brand) {
            return NextResponse.json({ error: 'Data package has no brand assigned.' }, { status: 400 });
        }
        if (!pkg.items.length) {
            return NextResponse.json({ error: 'No items to enrich in this package.' }, { status: 400 });
        }

        // If previously enriched, clean up old job so we can re-enrich
        const existingEnrichment = pkg.enrichedData as any;
        if (existingEnrichment?.enrichmentJobId) {
            console.log(`[Enrich] Cleaning up previous enrichment job ${existingEnrichment.enrichmentJobId}`);
            try {
                // Delete old proposals and suggestions (cascades from job delete)
                await prisma.enrichmentJob.delete({
                    where: { id: existingEnrichment.enrichmentJobId },
                }).catch(() => { /* job may already be gone */ });

                // Clear enrichedData so we start fresh
                await prisma.dataPackage.update({
                    where: { id: packageId },
                    data: { enrichedData: Prisma.JsonNull },
                });
            } catch {
                // Non-critical — proceed with enrichment anyway
            }
        }

        // 3. Set status to ENRICHING
        await prisma.dataPackage.update({
            where: { id: packageId },
            data: { status: 'ENRICHING' },
        });

        // 4. Create EnrichmentJob
        const job = await prisma.enrichmentJob.create({
            data: {
                name: `${pkg.name} Enrichment`,
                sourceType: 'DATA_PACKAGE',
                sourceFilter: { packageId: pkg.id },
                status: 'RUNNING',
                totalProducts: pkg.items.length,
            },
        });

        // 5. Load full taxonomy context
        const [allCategories, allAttributes, allOptionGroups] = await Promise.all([
            prisma.productCategory.findMany({
                select: { id: true, name: true, slug: true, parentId: true, likeTerms: true },
            }),
            prisma.productAttribute.findMany({
                select: { id: true, name: true, slug: true, unit: true, dataType: true, options: true },
            }),
            prisma.optionGroup.findMany({
                select: {
                    id: true, name: true, slug: true,
                    options: { select: { id: true, label: true, value: true } },
                },
            }),
        ]);

        const enrichmentContext: EnrichmentContext = {
            brand: {
                id: pkg.brand.id,
                name: pkg.brand.name,
                brandSku: pkg.brand.brandSku ?? null,
            },
            categories: allCategories,
            attributes: allAttributes,
            optionGroups: allOptionGroups,
        };

        // 6. Process each item
        let enrichedCount = 0;
        let suggestionCount = 0;
        const errors: string[] = [];

        for (const item of pkg.items) {
            try {
                // Build raw input from parsed fields
                const rawJson = item.rawJson as Record<string, any> | null;
                const input: RawProductInput = {
                    name: item.parsedName || 'Unnamed Product',
                    modelNumber: item.parsedSku || null,
                    sku: item.parsedSku || null,
                    description: item.parsedDescription || null,
                    rawText: rawJson?.rawText || rawJson?.description || null,
                };

                // Call enrichment
                const result = await enrichProduct(input, enrichmentContext, agent);

                // Create EnrichmentProposal
                const proposal = await prisma.enrichmentProposal.create({
                    data: {
                        jobId: job.id,
                        dataPackageItemId: item.id,
                        proposedData: result.proposedData as any,
                        originalData: {
                            name: item.parsedName,
                            sku: item.parsedSku,
                            categories: item.parsedCategories,
                        },
                        confidence: result.confidence,
                        notes: result.notes,
                    },
                });

                // Create TaxonomySuggestions for new items
                const pd = result.proposedData;

                for (const cat of pd.suggestedNewCategories) {
                    await prisma.taxonomySuggestion.create({
                        data: {
                            jobId: job.id,
                            type: 'CATEGORY',
                            suggestedName: cat.name,
                            suggestedData: { parentCategoryName: cat.parentCategoryName, reason: cat.reason },
                            usedByProposalIds: [proposal.id],
                        },
                    });
                    suggestionCount++;
                }

                for (const attr of pd.suggestedNewAttributes) {
                    await prisma.taxonomySuggestion.create({
                        data: {
                            jobId: job.id,
                            type: 'ATTRIBUTE',
                            suggestedName: attr.name,
                            suggestedData: { unit: attr.unit, dataType: attr.dataType, reason: attr.reason },
                            usedByProposalIds: [proposal.id],
                        },
                    });
                    suggestionCount++;
                }

                for (const og of pd.suggestedNewOptionGroups) {
                    await prisma.taxonomySuggestion.create({
                        data: {
                            jobId: job.id,
                            type: 'OPTION_GROUP',
                            suggestedName: og.name,
                            suggestedData: { options: og.options, reason: og.reason },
                            usedByProposalIds: [proposal.id],
                        },
                    });
                    suggestionCount++;
                }

                // Update processed count
                await prisma.enrichmentJob.update({
                    where: { id: job.id },
                    data: { processedCount: { increment: 1 } },
                });

                enrichedCount++;
                console.log(`[Enrich] ✅ ${item.parsedName} — confidence: ${result.confidence}`);

            } catch (err) {
                const msg = `${item.parsedName || item.id}: ${err instanceof Error ? err.message : err}`;
                errors.push(msg);
                console.error(`[Enrich] ❌ Error: ${msg}`);

                // Increment error count on job
                await prisma.enrichmentJob.update({
                    where: { id: job.id },
                    data: { errorCount: { increment: 1 } },
                }).catch(() => { /* non-critical */ });
            }
        }

        // 7. Update job and package status
        await prisma.enrichmentJob.update({
            where: { id: job.id },
            data: {
                status: 'AWAITING_REVIEW',
                rawLog: errors.length > 0 ? `Errors:\n${errors.join('\n')}` : null,
            },
        });

        await prisma.dataPackage.update({
            where: { id: packageId },
            data: {
                status: 'PENDING_REVIEW',
                enrichedData: { enrichmentJobId: job.id },
            },
        });

        console.log(`[Enrich] Complete: ${enrichedCount}/${pkg.items.length} enriched, ${suggestionCount} suggestions, ${errors.length} errors`);

        return NextResponse.json({
            jobId: job.id,
            enrichedCount,
            suggestionCount,
            errors,
        });

    } catch (error: any) {
        console.error(`[Enrich] Fatal error:`, error);
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}
