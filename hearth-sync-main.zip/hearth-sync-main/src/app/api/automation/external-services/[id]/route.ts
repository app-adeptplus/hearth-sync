import prisma from '@/lib/db';
import { NextRequest, NextResponse } from 'next/server';
import { encryptSecret, maskSecret, decryptSecret } from '@/lib/encryption';

// GET /api/automation/external-services/[id]
export async function GET(
    _req: NextRequest,
    { params }: { params: { id: string } }
) {
    try {
        const service = await prisma.externalServiceConfig.findUnique({
            where: { id: params.id },
            include: {
                providerLinks: {
                    include: { llmConfig: { select: { id: true, displayName: true, provider: true } } },
                },
            },
        });
        if (!service) return NextResponse.json({ error: 'Not found' }, { status: 404 });

        return NextResponse.json({
            ...service,
            apiKey: maskSecret(decryptSecret(service.apiKey)),
        });
    } catch (error: any) {
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}

// PATCH /api/automation/external-services/[id]
export async function PATCH(
    request: NextRequest,
    { params }: { params: { id: string } }
) {
    try {
        const body = await request.json();
        const { displayName, serviceType, apiKey, baseUrl, settings, isActive, linkedLlmConfigIds } = body;

        const data: any = {};
        if (displayName !== undefined) data.displayName = displayName;
        if (serviceType !== undefined) data.serviceType = serviceType;
        if (baseUrl !== undefined) data.baseUrl = baseUrl || null;
        if (settings !== undefined) data.settings = settings;
        if (isActive !== undefined) data.isActive = isActive;
        if (apiKey !== undefined && !apiKey.startsWith('****')) {
            data.apiKey = encryptSecret(apiKey);
        }

        // Update provider links if provided
        if (linkedLlmConfigIds !== undefined) {
            await prisma.externalServiceProviderLink.deleteMany({
                where: { externalServiceId: params.id },
            });
            if (linkedLlmConfigIds.length > 0) {
                data.providerLinks = {
                    create: linkedLlmConfigIds.map((llmConfigId: string) => ({ llmConfigId })),
                };
            }
        }

        const updated = await prisma.externalServiceConfig.update({
            where: { id: params.id },
            data,
            include: { providerLinks: true },
        });

        return NextResponse.json({
            ...updated,
            apiKey: maskSecret(decryptSecret(updated.apiKey)),
        });
    } catch (error: any) {
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}

// DELETE /api/automation/external-services/[id]
export async function DELETE(
    _req: NextRequest,
    { params }: { params: { id: string } }
) {
    try {
        await prisma.externalServiceConfig.delete({ where: { id: params.id } });
        return NextResponse.json({ success: true });
    } catch (error: any) {
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}
