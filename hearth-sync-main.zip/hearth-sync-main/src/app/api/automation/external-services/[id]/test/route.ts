import prisma from '@/lib/db';
import { NextRequest, NextResponse } from 'next/server';
import { decryptSecret } from '@/lib/encryption';

// POST /api/automation/external-services/[id]/test
export async function POST(
    _req: NextRequest,
    { params }: { params: { id: string } }
) {
    const start = Date.now();
    try {
        const service = await prisma.externalServiceConfig.findUnique({ where: { id: params.id } });
        if (!service) return NextResponse.json({ error: 'Not found' }, { status: 404 });

        const apiKey = decryptSecret(service.apiKey);
        let testStatus = 'success';
        let errorMessage: string | null = null;

        try {
            if (service.serviceType === 'FIRECRAWL') {
                const baseUrl = service.baseUrl || 'https://api.firecrawl.dev';
                const res = await fetch(`${baseUrl}/v1/scrape`, {
                    method: 'POST',
                    headers: {
                        Authorization: `Bearer ${apiKey}`,
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({ url: 'https://firecrawl.dev', formats: ['markdown'] }),
                    signal: AbortSignal.timeout(15000),
                });
                if (!res.ok) {
                    const body = await res.json().catch(() => ({}));
                    errorMessage = body?.error || `HTTP ${res.status}`;
                    testStatus = `error: ${errorMessage}`;
                }
            } else if (service.serviceType === 'WEBHOOK') {
                const baseUrl = service.baseUrl;
                if (!baseUrl) {
                    testStatus = 'error: no baseUrl configured for webhook';
                    errorMessage = 'No baseUrl configured';
                } else {
                    const res = await fetch(baseUrl, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ test: true }),
                        signal: AbortSignal.timeout(10000),
                    });
                    if (!res.ok) {
                        testStatus = `error: HTTP ${res.status}`;
                        errorMessage = `HTTP ${res.status}`;
                    }
                }
            } else {
                testStatus = 'error: no test implemented for this service type';
                errorMessage = 'Unsupported service type for automated test';
            }
        } catch (fetchErr: any) {
            testStatus = `error: ${fetchErr.message}`;
            errorMessage = fetchErr.message;
        }

        const latencyMs = Date.now() - start;

        await prisma.externalServiceConfig.update({
            where: { id: params.id },
            data: { lastTestedAt: new Date(), lastTestStatus: testStatus },
        });

        return NextResponse.json({
            success: testStatus === 'success',
            status: testStatus,
            latencyMs,
            error: errorMessage,
        });
    } catch (error: any) {
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}
