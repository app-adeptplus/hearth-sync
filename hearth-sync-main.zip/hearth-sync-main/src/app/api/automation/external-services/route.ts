import prisma from '@/lib/db';
import { NextRequest, NextResponse } from 'next/server';
import { encryptSecret, maskSecret, decryptSecret } from '@/lib/encryption';

// GET /api/automation/external-services — List all external service configs
export async function GET() {
    try {
        const services = await prisma.externalServiceConfig.findMany({
            orderBy: [{ serviceType: 'asc' }, { createdAt: 'desc' }],
            include: {
                providerLinks: {
                    include: { llmConfig: { select: { id: true, displayName: true, provider: true } } },
                },
            },
        });

        const masked = services.map(s => ({
            ...s,
            apiKey: maskSecret(decryptSecret(s.apiKey)),
        }));

        return NextResponse.json(masked);
    } catch (error: any) {
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}

// POST /api/automation/external-services — Create new external service config
export async function POST(request: NextRequest) {
    try {
        const body = await request.json();
        const { displayName, serviceType, apiKey, baseUrl, settings, linkedLlmConfigIds } = body;

        if (!displayName || !serviceType || !apiKey) {
            return NextResponse.json(
                { error: 'displayName, serviceType, and apiKey are required' },
                { status: 400 }
            );
        }

        const service = await prisma.externalServiceConfig.create({
            data: {
                displayName,
                serviceType,
                apiKey: encryptSecret(apiKey),
                baseUrl: baseUrl || null,
                settings: settings || null,
                isActive: true,
                ...(linkedLlmConfigIds?.length > 0 && {
                    providerLinks: {
                        create: linkedLlmConfigIds.map((llmConfigId: string) => ({ llmConfigId })),
                    },
                }),
            },
            include: { providerLinks: true },
        });

        return NextResponse.json(
            { ...service, apiKey: maskSecret(apiKey) },
            { status: 201 }
        );
    } catch (error: any) {
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}
