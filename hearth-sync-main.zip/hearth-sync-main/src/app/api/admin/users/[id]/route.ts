import { NextRequest, NextResponse } from 'next/server';
import { createServiceClient } from '@/lib/supabase';

export async function PATCH(req: NextRequest, context: { params: { id: string } }) {
    try {
        const id = context.params.id;

        if (!id || typeof id !== 'string' || id.trim() === '') {
            return NextResponse.json({ error: 'User ID required' }, { status: 400 });
        }

        const body = await req.json();
        const { name, email, password } = body;

        const supabase = createServiceClient();

        // Build the AdminUserAttributes payload
        const attributes: Record<string, any> = {};
        if (email?.trim()) attributes.email = email.trim().toLowerCase();
        if (password?.trim()) attributes.password = password.trim();
        if (name !== undefined) {
            attributes.user_metadata = { full_name: name.trim() };
        }

        if (Object.keys(attributes).length === 0) {
            return NextResponse.json({ error: 'Nothing to update' }, { status: 400 });
        }

        const { data, error } = await supabase.auth.admin.updateUserById(id.trim(), attributes);
        if (error) {
            // Return a structured orphaned response so the UI can offer "Remove from list"
            if (error.message?.toLowerCase().includes('user not found')) {
                return NextResponse.json({
                    error: 'This account is orphaned — it no longer exists in Supabase Auth.',
                    isOrphaned: true,
                }, { status: 404 });
            }
            throw error;
        }

        return NextResponse.json({ user: data.user });
    } catch (error: any) {
        console.error('[PATCH /api/admin/users/[id]]', error?.message ?? error);
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}

export async function DELETE(_req: NextRequest, context: { params: { id: string } }) {
    try {
        const id = context.params.id;
        if (!id) return NextResponse.json({ error: 'User ID required' }, { status: 400 });

        const supabase = createServiceClient();
        const { error } = await supabase.auth.admin.deleteUser(id);

        // If Supabase says the user doesn't exist, that's fine — treat it as already deleted.
        // This allows removing orphaned entries that exist in our cached list but not in Auth.
        if (error && !error.message?.toLowerCase().includes('user not found')) {
            throw error;
        }

        return NextResponse.json({ ok: true });
    } catch (error: any) {
        console.error('[DELETE /api/admin/users/[id]]', error);
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}


