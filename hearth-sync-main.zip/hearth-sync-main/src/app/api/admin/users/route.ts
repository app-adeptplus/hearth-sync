import { NextRequest, NextResponse } from 'next/server';
import { createServiceClient } from '@/lib/supabase';
import { createPortalUser } from '@/lib/auth-utils';

export async function GET() {
    try {
        const supabase = createServiceClient();
        const { data, error } = await supabase.auth.admin.listUsers();
        if (error) throw error;

        const users = data.users.filter((u) => {
            const meta = (u as any).app_metadata ?? {};
            return meta.portal_role === 'admin';
        });

        return NextResponse.json({ users });
    } catch (error: any) {
        console.error('[GET /api/admin/users]', error);
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}

export async function POST(req: NextRequest) {
    try {
        const { email, name } = await req.json();
        if (!email || !name) {
            return NextResponse.json({ error: 'Email and name are required' }, { status: 400 });
        }

        const { user, tempPassword } = await createPortalUser(email, 'admin', {
            full_name: name,
        });

        return NextResponse.json({ user, tempPassword }, { status: 201 });
    } catch (error: any) {
        console.error('[POST /api/admin/users]', error);
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}
