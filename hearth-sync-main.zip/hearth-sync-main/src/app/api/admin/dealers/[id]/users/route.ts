import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/db';
import { createPortalUser } from '@/lib/auth-utils';
import { createServiceClient } from '@/lib/supabase';

export async function POST(req: NextRequest, { params }: { params: { id: string } }) {
    let createdSupabaseUserId: string | null = null;

    try {
        const body = await req.json();
        const { email, role } = body;

        if (!email) {
            return NextResponse.json({ error: 'Email is required' }, { status: 400 });
        }

        // Step 1: Create a Supabase Auth user for this dealer portal member.
        const { user: supabaseUser, tempPassword } = await createPortalUser(email, 'dealer');
        createdSupabaseUserId = supabaseUser.id;

        // Step 2: Create the DealerUser row linked to the real Supabase UUID.
        const dealerUser = await prisma.dealerUser.create({
            data: {
                dealerId: params.id,
                email,
                userId: supabaseUser.id,
                role: role || 'member',
            },
        });

        return NextResponse.json({ user: dealerUser, tempPassword }, { status: 201 });
    } catch (error: any) {
        console.error(`[POST /api/admin/dealers/${params.id}/users]`, error);

        // If Supabase user was created but Prisma failed, clean up to avoid orphans.
        if (createdSupabaseUserId) {
            try {
                const supabase = createServiceClient();
                await supabase.auth.admin.deleteUser(createdSupabaseUserId);
            } catch (cleanupErr) {
                console.error('[POST dealer users] CLEANUP FAILED — orphaned Supabase user:', createdSupabaseUserId);
            }
        }

        if (error.code === 'P2002') {
            return NextResponse.json({ error: 'A user with this email already exists' }, { status: 409 });
        }
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}

