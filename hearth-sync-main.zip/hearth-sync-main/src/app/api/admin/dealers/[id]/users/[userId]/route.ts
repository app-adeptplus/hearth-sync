import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/db';

export async function PUT(req: NextRequest, { params }: { params: { id: string, userId: string } }) {
    try {
        const body = await req.json();
        const { email, role } = body;

        const dealerUser = await prisma.dealerUser.update({
            where: {
                id: params.userId,
            },
            data: {
                email,
                role,
            },
        });

        return NextResponse.json({ user: dealerUser });
    } catch (error: any) {
        console.error(`[PUT /api/admin/dealers/${params.id}/users/${params.userId}]`, error);
        if (error.code === 'P2002') {
            return NextResponse.json({ error: 'A user with this email already exists' }, { status: 409 });
        }
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}

export async function DELETE(req: NextRequest, { params }: { params: { id: string, userId: string } }) {
    try {
        await prisma.dealerUser.delete({
            where: {
                id: params.userId,
            },
        });

        return NextResponse.json({ success: true });
    } catch (error: any) {
        console.error(`[DELETE /api/admin/dealers/${params.id}/users/${params.userId}]`, error);
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}
