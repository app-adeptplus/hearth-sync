import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/db';

export async function GET(req: NextRequest, { params }: { params: { id: string } }) {
    try {
        const dealer = await prisma.dealerAccount.findUnique({
            where: { id: params.id },
            include: { users: true },
        });

        if (!dealer) {
            return NextResponse.json({ error: 'Dealer not found' }, { status: 404 });
        }

        return NextResponse.json({ dealer });
    } catch (error: any) {
        console.error(`[GET /api/admin/dealers/${params.id}]`, error);
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}

export async function PUT(req: NextRequest, { params }: { params: { id: string } }) {
    try {
        const body = await req.json();
        const { companyName, contactName, phone, city, state, subscriptionTier, subscriptionStatus, slug } = body;

        const dealer = await prisma.dealerAccount.update({
            where: { id: params.id },
            data: {
                companyName,
                contactName,
                phone: phone || null,
                city: city || null,
                state: state || null,
                subscriptionTier,
                subscriptionStatus,
                slug: slug ? slug.trim().toLowerCase() : null,
            },
        });

        return NextResponse.json({ dealer });
    } catch (error: any) {
        console.error(`[PUT /api/admin/dealers/${params.id}]`, error);
        if (error.code === 'P2002') {
            return NextResponse.json({ error: 'This slug is already taken by another dealer' }, { status: 409 });
        }
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}

export async function DELETE(req: NextRequest, { params }: { params: { id: string } }) {
    try {
        await prisma.dealerAccount.delete({ where: { id: params.id } });
        return NextResponse.json({ ok: true });
    } catch (error: any) {
        console.error(`[DELETE /api/admin/dealers/${params.id}]`, error);
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}
