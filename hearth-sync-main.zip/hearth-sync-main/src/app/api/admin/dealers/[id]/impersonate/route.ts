import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/db';
import { createServiceClient } from '@/lib/supabase';

/**
 * GET /api/admin/dealers/[id]/impersonate
 *
 * Opens in a new tab. Generates a Supabase magic link whose redirect_to
 * points to the dealer auth callback page, which handles the implicit
 * #access_token hash and sets the session before forwarding to the catalog.
 */
export async function GET(req: NextRequest, { params }: { params: { id: string } }) {
    const adminUrl = new URL(`/admin/dealer-portal/dealers`, req.url);

    try {
        const dealer = await prisma.dealerAccount.findUnique({
            where: { id: params.id },
            include: {
                users: {
                    orderBy: [{ role: 'asc' }, { createdAt: 'asc' }],
                    take: 1,
                },
            },
        });

        if (!dealer) {
            adminUrl.searchParams.set('error', 'dealer_not_found');
            return NextResponse.redirect(adminUrl);
        }

        const email = dealer.users[0]?.email ?? dealer.email;
        if (!email) {
            adminUrl.searchParams.set('error', 'no_email');
            return NextResponse.redirect(adminUrl);
        }

        const supabase = createServiceClient();
        const dealerSlug = (dealer as any).slug || dealer.id;
        // Derive the base URL from the incoming request so local dev always
        // redirects to localhost and production redirects to the prod domain —
        // no env variable switching required.
        const baseUrl = req.nextUrl.origin;
        const finalDest = `/dealer/${dealerSlug}/catalog`;

        // The redirect_to points to our client-side callback page which handles
        // both PKCE (?code=) and implicit (#access_token=) Supabase flows
        const redirectTo = `${baseUrl}/dealer/${dealerSlug}/auth/callback?next=${encodeURIComponent(finalDest)}`;

        const { data, error } = await supabase.auth.admin.generateLink({
            type: 'magiclink',
            email,
            options: { redirectTo },
        });

        if (error || !data?.properties?.action_link) {
            console.error('[impersonate] generateLink error:', error?.message);
            adminUrl.searchParams.set('error', 'generate_link_failed');
            return NextResponse.redirect(adminUrl);
        }

        // Redirect the browser to the Supabase-hosted action link.
        // Supabase verifies the OTP and then redirects to our callback page
        // with the session tokens in the URL hash.
        return NextResponse.redirect(data.properties.action_link);
    } catch (err: any) {
        console.error('[impersonate] unhandled error:', err?.message ?? err);
        adminUrl.searchParams.set('error', 'impersonate_failed');
        return NextResponse.redirect(adminUrl);
    }
}

export async function POST(req: NextRequest, { params }: { params: { id: string } }) {
    const url = new URL(`/api/admin/dealers/${params.id}/impersonate`, req.url);
    return NextResponse.json({ url: url.toString() });
}
