import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/db';
import { createPortalUser } from '@/lib/auth-utils';
import { createServiceClient } from '@/lib/supabase';

function toSlug(s: string) {
    return s
        .toLowerCase()
        .replace(/[^a-z0-9\s-]/g, '')
        .trim()
        .replace(/\s+/g, '-')
        .replace(/-+/g, '-');
}

export async function GET(req: NextRequest) {
    try {
        const { searchParams } = new URL(req.url);
        const q = searchParams.get('q') ?? '';
        const tier = searchParams.get('tier') ?? '';
        const page = parseInt(searchParams.get('page') ?? '1');
        const pageSize = 50;

        const where: any = {};
        if (q) {
            where.OR = [
                { companyName: { contains: q, mode: 'insensitive' } },
                { contactName: { contains: q, mode: 'insensitive' } },
                { email: { contains: q, mode: 'insensitive' } },
            ];
        }
        if (tier) {
            where.subscriptionTier = tier;
        }

        const [dealers, total] = await Promise.all([
            prisma.dealerAccount.findMany({
                where,
                orderBy: { createdAt: 'desc' },
                skip: (page - 1) * pageSize,
                take: pageSize,
                include: {
                    _count: { select: { catalogSelections: true } },
                },
            }),
            prisma.dealerAccount.count({ where }),
        ]);

        return NextResponse.json({ dealers, total, page, pageSize });
    } catch (error: any) {
        console.error('[GET /api/admin/dealers]', error);
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}

export async function POST(req: NextRequest) {
    let createdSupabaseUserId: string | null = null;

    try {
        const body = await req.json();
        const { companyName, contactName, email, phone, city, state, ownerEmail, subscriptionTier, slug } = body;

        if (!companyName || !contactName || !email || !ownerEmail) {
            return NextResponse.json(
                { error: 'Company Name, Contact Name, Email, and Owner Email are required' },
                { status: 400 }
            );
        }

        // Step 1: Create the Supabase Auth user for the dealer owner FIRST.
        // This gives us the real UUID to use as userId in Prisma.
        const { user: supabaseUser, tempPassword } = await createPortalUser(
            ownerEmail,
            'dealer',
            { full_name: contactName }
        );
        createdSupabaseUserId = supabaseUser.id;

        // Step 2: Generate slug
        const baseSlug = toSlug(slug || companyName);
        let finalSlug = baseSlug;
        const existing = await prisma.dealerAccount.findFirst({ where: { slug: finalSlug } });
        if (existing) {
            finalSlug = `${baseSlug}-${Date.now().toString(36)}`;
        }

        // Step 3: Create DealerAccount + DealerUser in a single transaction using the real UUID.
        const dealer = await prisma.$transaction(async (tx) => {
            const newDealer = await tx.dealerAccount.create({
                data: {
                    userId: supabaseUser.id,   // real Supabase UUID
                    companyName,
                    contactName,
                    email,
                    phone: phone || null,
                    city: city || null,
                    state: state || null,
                    slug: finalSlug,
                    subscriptionTier: subscriptionTier || 'STARTER',
                },
            });

            await tx.dealerUser.create({
                data: {
                    dealerId: newDealer.id,
                    email: ownerEmail,
                    userId: supabaseUser.id,   // link DealerUser to real Supabase Auth user
                    role: 'owner',
                },
            });

            return newDealer;
        });

        // Return tempPassword so the admin can hand it to the dealer owner.
        return NextResponse.json({ dealer, tempPassword }, { status: 201 });
    } catch (error: any) {
        console.error('[POST /api/admin/dealers]', error);

        // If Supabase user was created but Prisma failed, clean up to avoid orphans.
        if (createdSupabaseUserId) {
            try {
                const supabase = createServiceClient();
                await supabase.auth.admin.deleteUser(createdSupabaseUserId);
                console.log(`[POST /api/admin/dealers] Rolled back Supabase user ${createdSupabaseUserId}`);
            } catch (cleanupErr) {
                console.error('[POST /api/admin/dealers] CLEANUP FAILED — orphaned Supabase user:', createdSupabaseUserId, cleanupErr);
            }
        }

        if (error.code === 'P2002') {
            return NextResponse.json({ error: 'A dealer with this email or slug already exists' }, { status: 409 });
        }
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}
