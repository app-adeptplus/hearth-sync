import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/db';
import Papa from 'papaparse';
import { slugify } from '@/lib/utils';

export const dynamic = 'force-dynamic';

// ---------------------------------------------------------------------------
// Sample CSV template download
// ---------------------------------------------------------------------------
export async function GET() {
    const headers = [
        'name',
        'model_number',
        'sku',
        'slug',
        'brand_slug',
        'categories',
        'venting_type',
        'btu_input',
        'btu_output',
        'efficiency_rating',
        'width',
        'height',
        'depth',
        'weight',
        'short_description',
        'description',
        'price_map',
        'price_msrp',
        'product_url',
        'status',
        'images',
        'spec_sheet_url',
        'manual_url',
        'spec_heating_area',
        'spec_ignition',
        'spec_glass_size',
    ];

    const exampleRow = [
        'Cosmo 42 Gas Fireplace',
        'COS-42-NG',
        'HGL-COS-42-NG',
        'cosmo-42-gas-fireplace',
        'heat-n-glo',
        'gas-fireplaces, fireplaces',
        'Direct Vent',
        '35000',
        '28000',
        '84.2',
        '42',
        '34.5',
        '16',
        '185',
        'A stunning linear gas fireplace with clean lines.',
        'The Cosmo 42 features a wide panoramic view and efficient heating...',
        '2199.00',
        '2599.00',
        'https://www.heatnglo.com/cosmo-42',
        'ACTIVE',
        'https://cdn.example.com/cosmo-42-front.jpg, https://cdn.example.com/cosmo-42-side.jpg',
        'https://cdn.example.com/cosmo-42-spec.pdf',
        'https://cdn.example.com/cosmo-42-manual.pdf',
        '1200 sq ft',
        'Electronic Ignition',
        '42" x 16"',
    ];

    const csv = Papa.unparse({ fields: headers, data: [exampleRow] });

    return new NextResponse(csv, {
        status: 200,
        headers: {
            'Content-Type': 'text/csv',
            'Content-Disposition': 'attachment; filename="hearth_product_import_template.csv"',
        },
    });
}

// ---------------------------------------------------------------------------
// Import POST handler
// ---------------------------------------------------------------------------

type RowResult = {
    rowIndex: number;
    name: string;
    status: 'success' | 'error' | 'skipped';
    message?: string;
};

const VALID_STATUSES = ['ACTIVE', 'DRAFT', 'DISCONTINUED', 'COMING_SOON'];

function normalizeStatus(raw: string): string {
    const s = raw?.toLowerCase?.() ?? '';
    if (s === '1' || s === 'true' || s === 'active' || s === 'published') return 'ACTIVE';
    if (s === 'draft') return 'DRAFT';
    if (s === 'discontinued') return 'DISCONTINUED';
    if (s === 'coming_soon' || s === 'coming soon') return 'COMING_SOON';
    return 'DRAFT';
}

// Handled dynamically now with resolveFuelType

function col(row: Record<string, any>, mapping: Record<string, string>, key: string): string {
    const csvCol = mapping[key];
    if (!csvCol) return '';
    return String(row[csvCol] ?? '').trim();
}

function parseDecimal(raw: string): number | null {
    if (!raw) return null;
    const n = parseFloat(raw.replace(/[^0-9.-]/g, ''));
    return isNaN(n) ? null : n;
}

function parseInteger(raw: string): number | null {
    if (!raw) return null;
    const n = parseInt(raw.replace(/[^0-9-]/g, ''), 10);
    return isNaN(n) ? null : n;
}

export async function POST(request: NextRequest) {
    try {
        const formData = await request.formData();
        const file = formData.get('file') as File | null;
        const mappingStr = formData.get('mapping') as string | null;
        const delimitersStr = formData.get('delimiters') as string | null;
        const brandId = formData.get('brandId') as string | null; // explicit brand override
        const format = formData.get('format') as string | null;  // woocommerce | shopify | custom | native
        const mode = (formData.get('mode') as string | null) || 'create';

        if (!file || !mappingStr) {
            return NextResponse.json({ error: 'Missing file or field mapping' }, { status: 400 });
        }

        const mapping: Record<string, string> = JSON.parse(mappingStr);
        const delimiters: Record<string, string> = delimitersStr ? JSON.parse(delimitersStr) : {};
        const getDelim = (key: string) => delimiters[key] || ',';
        const fileContent = await file.text();

        // 1. Parse CSV
        const parseResult = Papa.parse<Record<string, any>>(fileContent, {
            header: true,
            skipEmptyLines: true,
        });

        if (parseResult.errors.length > 0 && parseResult.data.length === 0) {
            return NextResponse.json({ error: 'Error parsing CSV file', details: parseResult.errors }, { status: 400 });
        }

        const rows = parseResult.data;
        const results: RowResult[] = [];

        // 2. Resolve brand and category lookup cache
        const brandCache = new Map<string, string>(); // slug -> brandId
        const categoryCache = new Map<string, string>(); // slug -> categoryId

        const resolveBrandId = async (rawInput: string): Promise<string | null> => {
            if (!rawInput) return null;
            const sanitizedSlug = slugify(rawInput);

            if (brandCache.has(rawInput)) return brandCache.get(rawInput)!;
            if (brandCache.has(sanitizedSlug)) return brandCache.get(sanitizedSlug)!;

            const brand = await prisma.brand.findFirst({
                where: {
                    OR: [
                        { id: rawInput },
                        { slug: { equals: rawInput, mode: 'insensitive' } },
                        { slug: { equals: sanitizedSlug, mode: 'insensitive' } },
                        { name: { equals: rawInput, mode: 'insensitive' } },
                        { name: { equals: sanitizedSlug, mode: 'insensitive' } }
                    ]
                },
            });

            if (brand) {
                brandCache.set(rawInput, brand.id);
                brandCache.set(sanitizedSlug, brand.id);
                return brand.id;
            }
            return null;
        };

        const resolveCategoryId = async (rawInput: string): Promise<string | null> => {
            if (!rawInput) return null;
            const sanitizedSlug = slugify(rawInput);

            if (categoryCache.has(rawInput)) return categoryCache.get(rawInput)!;
            if (categoryCache.has(sanitizedSlug)) return categoryCache.get(sanitizedSlug)!;

            let category = await prisma.productCategory.findFirst({
                where: {
                    OR: [
                        { slug: rawInput },
                        { slug: sanitizedSlug },
                        { name: { equals: rawInput, mode: 'insensitive' } }
                    ]
                }
            });

            if (!category) {
                const isLikelySlug = rawInput === sanitizedSlug && rawInput.includes('-');
                const name = isLikelySlug
                    ? rawInput.split('-').map(s => s.charAt(0).toUpperCase() + s.slice(1)).join(' ')
                    : rawInput; // Preserve their explicit non-slugified casing
                category = await prisma.productCategory.create({ data: { name, slug: sanitizedSlug } });
            }

            categoryCache.set(rawInput, category.id);
            categoryCache.set(sanitizedSlug, category.id);
            return category.id;
        };

        // If a global brandId was provided, validate it exists
        let globalBrandId: string | null = null;
        if (brandId) {
            const brand = await prisma.brand.findUnique({ where: { id: brandId } });
            if (!brand) {
                return NextResponse.json({ error: `Brand with ID "${brandId}" not found` }, { status: 400 });
            }
            globalBrandId = brandId;
        }

        let successCount = 0;
        let errorCount = 0;

        // 3. Process rows
        for (let i = 0; i < rows.length; i++) {
            const row = rows[i];
            const rowNum = i + 1;

            try {
                if (mode === 'update') {
                    const skuRaw = col(row, mapping, 'sku');
                    const modelNumberRaw = col(row, mapping, 'model_number');
                    const nameRaw = col(row, mapping, 'name');

                    if (!skuRaw && !modelNumberRaw) {
                        results.push({ rowIndex: rowNum, name: nameRaw || `Row ${rowNum}`, status: 'skipped', message: 'Missing SKU or Model Number mapped value for update.' });
                        continue;
                    }

                    const existingProduct = await prisma.product.findFirst({
                        where: {
                            OR: [
                                ...(skuRaw ? [{ sku: skuRaw }] : []),
                                ...(modelNumberRaw ? [{ modelNumber: modelNumberRaw }] : [])
                            ]
                        }
                    });

                    if (!existingProduct) {
                        results.push({ rowIndex: rowNum, name: nameRaw || `Row ${rowNum}`, status: 'skipped', message: `Product not found for SKU: ${skuRaw || 'N/A'} / Model: ${modelNumberRaw || 'N/A'}` });
                        continue;
                    }

                    const updateData: any = {};

                    if (nameRaw) updateData.name = nameRaw.trim();
                    const statusRaw = col(row, mapping, 'status');
                    if (statusRaw) updateData.status = normalizeStatus(statusRaw) as any;
                    const shortDescRaw = col(row, mapping, 'short_description');
                    if (shortDescRaw) updateData.shortDescription = shortDescRaw;
                    const descRaw = col(row, mapping, 'description');
                    if (descRaw) updateData.description = descRaw;
                    const urlRaw = col(row, mapping, 'product_url');
                    if (urlRaw) updateData.productUrl = urlRaw;
                    const ventRaw = col(row, mapping, 'venting_type');
                    if (ventRaw) updateData.ventingType = ventRaw;

                    const brandSlugRaw = col(row, mapping, 'brand_slug');
                    // We only update brand if manually mapped or dynamically resolved
                    if (brandSlugRaw) {
                        const bId = await resolveBrandId(brandSlugRaw.split(getDelim('brand_slug'))[0].trim());
                        if (bId) updateData.brandId = bId;
                    }

                    const catRaw = col(row, mapping, 'categories') || col(row, mapping, 'category_slug');
                    if (catRaw) {
                        const catIds: string[] = [];
                        for (const cn of catRaw.split(getDelim('categories'))) {
                            if (!cn.trim()) continue;
                            const cId = await resolveCategoryId(cn.trim());
                            if (cId) catIds.push(cId);
                        }
                        if (catIds.length > 0) updateData.categories = { set: catIds.map(id => ({ id })) };
                    }

                    const btuInputRaw = col(row, mapping, 'btu_input');
                    if (btuInputRaw) updateData.btuInput = parseInteger(btuInputRaw);
                    const btuOutputRaw = col(row, mapping, 'btu_output');
                    if (btuOutputRaw) updateData.btuOutput = parseInteger(btuOutputRaw);
                    const effRaw = col(row, mapping, 'efficiency_rating');
                    if (effRaw) updateData.efficiencyRating = parseDecimal(effRaw);
                    const widthRaw = col(row, mapping, 'width');
                    if (widthRaw) updateData.width = parseDecimal(widthRaw);
                    const heightRaw = col(row, mapping, 'height');
                    if (heightRaw) updateData.height = parseDecimal(heightRaw);
                    const depthRaw = col(row, mapping, 'depth');
                    if (depthRaw) updateData.depth = parseDecimal(depthRaw);
                    const weightRaw = col(row, mapping, 'weight');
                    if (weightRaw) updateData.weight = parseDecimal(weightRaw);
                    const mapRaw = col(row, mapping, 'price_map');
                    if (mapRaw) updateData.priceMap = parseDecimal(mapRaw);
                    const msrpRaw = col(row, mapping, 'price_msrp');
                    if (msrpRaw) updateData.priceMsrp = parseDecimal(msrpRaw);

                    const slRaw = col(row, mapping, 'slug');
                    if (slRaw) updateData.slug = slugify(slRaw);

                    const imageUrls: string[] = [];
                    for (let imgIdx = 1; imgIdx <= 5; imgIdx++) {
                        const u = col(row, mapping, `image_url_${imgIdx}`);
                        if (u) imageUrls.push(u);
                    }
                    const legImg = col(row, mapping, 'images');
                    if (legImg) legImg.split(getDelim('images')).map((u: string) => u.trim()).filter(Boolean).forEach((u: string) => {
                        if (!imageUrls.includes(u)) imageUrls.push(u);
                    });
                    if (imageUrls.length > 0) {
                        const images = imageUrls.map((url, idx) => ({ url, isPrimary: idx === 0, sortOrder: idx, altText: `${existingProduct.name} - Image ${idx + 1}` }));
                        updateData.images = { deleteMany: {}, create: images };
                    }

                    const specDoc = col(row, mapping, 'spec_sheet_url');
                    const manDoc = col(row, mapping, 'manual_url');
                    const docsToCreate = [];
                    if (specDoc) docsToCreate.push({ type: 'SPEC_SHEET', name: `${existingProduct.name} Spec Sheet`, url: specDoc });
                    if (manDoc) docsToCreate.push({ type: 'MANUAL', name: `${existingProduct.name} Manual`, url: manDoc });
                    if (docsToCreate.length > 0) {
                        updateData.documents = { deleteMany: {}, create: docsToCreate };
                    }

                    if (Object.keys(updateData).length > 0) {
                        await prisma.product.update({
                            where: { id: existingProduct.id },
                            data: updateData
                        });

                        for (const [mk, csvCol] of Object.entries(mapping)) {
                            if (mk.startsWith('spec_') && csvCol) {
                                const specVal = String(row[csvCol] ?? '').trim();
                                if (specVal) {
                                    const specName = mk.replace(/^spec_/, '').replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase());
                                    await prisma.productSpec.upsert({
                                        where: { productId_name: { productId: existingProduct.id, name: specName } },
                                        update: { value: specVal },
                                        create: { productId: existingProduct.id, name: specName, value: specVal, group: 'Specifications', sortOrder: 0 }
                                    });
                                }
                            }
                        }

                        await prisma.auditLog.create({
                            data: {
                                productId: existingProduct.id,
                                action: 'UPDATED',
                                entityType: 'product',
                                entityId: existingProduct.id,
                                after: updateData,
                                changedBy: 'csv-bulk-update',
                            },
                        });

                        results.push({ rowIndex: rowNum, name: existingProduct.name, status: 'success', message: `Updated fields: ${Object.keys(updateData).join(', ')}` });
                        successCount++;
                    } else {
                        results.push({ rowIndex: rowNum, name: existingProduct.name, status: 'skipped', message: 'No mapped fields had valid column values.' });
                    }
                    continue;
                }

                // --- Required: name ---
                const name = col(row, mapping, 'name') || col(row, {}, '') || (row['name'] ?? '');
                if (!name) {
                    results.push({ rowIndex: rowNum, name: '(blank)', status: 'skipped', message: 'Missing required field: name' });
                    continue;
                }

                // --- Resolve brand ---
                let resolvedBrandId: string | null = globalBrandId;
                if (!resolvedBrandId) {
                    const brandSlugRaw = col(row, mapping, 'brand_slug');
                    const firstBrandSlug = brandSlugRaw ? brandSlugRaw.split(getDelim('brand_slug'))[0].trim() : null;
                    resolvedBrandId = firstBrandSlug ? await resolveBrandId(firstBrandSlug) : null;

                    if (!resolvedBrandId) {
                        results.push({ rowIndex: rowNum, name, status: 'error', message: `Brand not found: "${brandSlugRaw || 'not mapped'}". Use brand_slug column or select a Brand above.` });
                        errorCount++;
                        continue;
                    }
                }

                // --- Slug and Category ---
                const slugRaw = col(row, mapping, 'slug');
                const slug = slugRaw ? slugify(slugRaw) : slugify(name);

                const categoryRaw = col(row, mapping, 'categories') || col(row, mapping, 'category_slug');
                const categoryIds: string[] = [];
                if (categoryRaw) {
                    for (const catName of categoryRaw.split(getDelim('categories'))) {
                        if (!catName.trim()) continue;
                        const catId = await resolveCategoryId(catName.trim());
                        if (catId) categoryIds.push(catId);
                    }
                }

                // --- Numerical fields ---
                const btuInput = parseInteger(col(row, mapping, 'btu_input'));
                const btuOutput = parseInteger(col(row, mapping, 'btu_output'));
                const efficiencyRating = parseDecimal(col(row, mapping, 'efficiency_rating'));
                const width = parseDecimal(col(row, mapping, 'width'));
                const height = parseDecimal(col(row, mapping, 'height'));
                const depth = parseDecimal(col(row, mapping, 'depth'));
                const weight = parseDecimal(col(row, mapping, 'weight'));
                const priceMap = parseDecimal(col(row, mapping, 'price_map'));
                const priceMsrp = parseDecimal(col(row, mapping, 'price_msrp'));

                const fuelTypeRaw = '';
                const fuelTypeIds: string[] = []; // Handled via categoryMappings (dynamic parent-category mapping)

                const productTypeRaw = '';
                const productTypeIds: string[] = []; // Handled via categoryMappings (dynamic parent-category mapping)

                const statusRaw = col(row, mapping, 'status');
                const status = normalizeStatus(statusRaw) as any;

                // --- Text fields ---
                const modelNumber = col(row, mapping, 'model_number') || null;
                const sku = col(row, mapping, 'sku') || null;
                const ventingType = col(row, mapping, 'venting_type') || null;
                const shortDescription = col(row, mapping, 'short_description') || null;
                const description = col(row, mapping, 'description') || null;
                const productUrl = col(row, mapping, 'product_url') || null;

                // --- Images ---
                const imageUrls: string[] = [];
                for (let imgIdx = 1; imgIdx <= 5; imgIdx++) {
                    const url = col(row, mapping, `image_url_${imgIdx}`);
                    if (url) imageUrls.push(url);
                }
                // Also handle legacy comma-separated images column
                const legacyImages = col(row, mapping, 'images');
                if (legacyImages) {
                    legacyImages.split(getDelim('images')).map((u: string) => u.trim()).filter(Boolean).forEach((u: string) => {
                        if (!imageUrls.includes(u)) imageUrls.push(u);
                    });
                }

                const images = imageUrls.map((url, idx) => ({
                    url,
                    isPrimary: idx === 0,
                    sortOrder: idx,
                    altText: `${name} - Image ${idx + 1}`,
                }));

                // --- Documents ---
                const documents: { type: any; name: string; url: string }[] = [];
                const specSheetUrl = col(row, mapping, 'spec_sheet_url');
                const manualUrl = col(row, mapping, 'manual_url');
                if (specSheetUrl) documents.push({ type: 'SPEC_SHEET', name: `${name} Spec Sheet`, url: specSheetUrl });
                if (manualUrl) documents.push({ type: 'MANUAL', name: `${name} Manual`, url: manualUrl });

                // --- Dynamic specs: any column starting with "spec_" ---
                const specs: { name: string; value: string; group: string; sortOrder: number }[] = [];
                let specOrder = 0;
                for (const [mappingKey, csvCol] of Object.entries(mapping)) {
                    if (mappingKey.startsWith('spec_') && csvCol) {
                        const specName = mappingKey.replace(/^spec_/, '').replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase());
                        const specValue = String(row[csvCol] ?? '').trim();
                        if (specValue) {
                            specs.push({ name: specName, value: specValue, group: 'Specifications', sortOrder: specOrder++ });
                        }
                    }
                }

                // --- Upsert product ---
                const productData: any = {
                    brandId: resolvedBrandId,
                    name: name.trim(),
                    slug,
                    modelNumber,
                    status,
                    shortDescription,
                    description,
                    productUrl,

                    ...(ventingType && { ventingType }),
                    ...(btuInput !== null && { btuInput }),
                    ...(btuOutput !== null && { btuOutput }),
                    ...(efficiencyRating !== null && { efficiencyRating }),
                    ...(width !== null && { width }),
                    ...(height !== null && { height }),
                    ...(depth !== null && { depth }),
                    ...(weight !== null && { weight }),
                    ...(priceMap !== null && { priceMap }),
                    ...(priceMsrp !== null && { priceMsrp }),
                };

                // Only add sku if non-empty (unique constraint)
                if (sku) productData.sku = sku;

                const product = await prisma.product.upsert({
                    where: { brandId_slug: { brandId: resolvedBrandId, slug } },
                    update: {
                        ...productData,
                        ...(categoryIds.length > 0 && { categories: { connect: categoryIds.map(id => ({ id })) } }),
                        ...(images.length > 0 && {
                            images: { deleteMany: {}, create: images },
                        }),
                        ...(documents.length > 0 && {
                            documents: { deleteMany: {}, create: documents },
                        }),
                    },
                    create: {
                        ...productData,
                        ...(categoryIds.length > 0 && { categories: { connect: categoryIds.map(id => ({ id })) } }),
                        ...(images.length > 0 && { images: { create: images } }),
                        ...(documents.length > 0 && { documents: { create: documents } }),
                    },
                });

                // Upsert specs separately (unique constraint on productId+name)
                for (const spec of specs) {
                    await prisma.productSpec.upsert({
                        where: { productId_name: { productId: product.id, name: spec.name } },
                        update: { value: spec.value, group: spec.group, sortOrder: spec.sortOrder },
                        create: { productId: product.id, ...spec },
                    });
                }

                // Audit log
                await prisma.auditLog.create({
                    data: {
                        productId: product.id,
                        action: 'CREATED',
                        entityType: 'product',
                        entityId: product.id,
                        after: { name: product.name, slug: product.slug, brandId: product.brandId },
                        changedBy: 'csv-import',
                    },
                });

                results.push({ rowIndex: rowNum, name, status: 'success' });
                successCount++;
            } catch (err: any) {
                const rowName = col(row, mapping, 'name') || `Row ${rowNum}`;
                results.push({
                    rowIndex: rowNum,
                    name: rowName,
                    status: 'error',
                    message: err?.message ?? 'Unknown error',
                });
                errorCount++;
            }
        }

        return NextResponse.json({
            success: true,
            totalRows: rows.length,
            successCount,
            errorCount,
            skippedCount: rows.length - successCount - errorCount,
            results,
            message: `Import complete: ${successCount} succeeded, ${errorCount} failed, ${rows.length - successCount - errorCount} skipped.`,
        });
    } catch (error: any) {
        console.error('Import API Error:', error);
        return NextResponse.json(
            { error: error.message || 'Failed to import products' },
            { status: 500 }
        );
    }
}
