import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/db';
import Papa from 'papaparse';

export const dynamic = 'force-dynamic';

export async function GET(request: NextRequest) {
    try {
        const searchParams = request.nextUrl.searchParams;
        const brandId = searchParams.get('brandId') ?? undefined;
        const brandSlug = searchParams.get('brandSlug') ?? undefined;
        const status = searchParams.get('status') ?? undefined;

        const where: Record<string, any> = {};
        if (brandId) where.brandId = brandId;
        if (brandSlug) where.brand = { slug: brandSlug };
        if (status) where.status = status;

        const products = await prisma.product.findMany({
            where,
            orderBy: [{ brand: { name: 'asc' } }, { name: 'asc' }],
            include: {
                brand: { select: { name: true, slug: true } },
                images: { orderBy: { sortOrder: 'asc' } },
                documents: true,
                specs: { orderBy: { sortOrder: 'asc' } },
            },
        });

        const rows = products.map((p: typeof products[number]) => {
            const imageUrls: Record<string, string> = {};
            p.images.forEach((img: { url: string }, idx: number) => {
                imageUrls[`image_url_${idx + 1}`] = img.url;
            });

            const specFields: Record<string, string> = {};
            p.specs.forEach((spec: { name: string; value: string }) => {
                const key = `spec_${spec.name.toLowerCase().replace(/[^a-z0-9]+/g, '_')}`;
                specFields[key] = spec.value;
            });

            const specSheet = p.documents.find((d: { type: string; url: string }) => d.type === 'SPEC_SHEET')?.url ?? '';
            const manual = p.documents.find((d: { type: string; url: string }) => d.type === 'MANUAL')?.url ?? '';

            return {
                name: p.name,
                model_number: p.modelNumber ?? '',
                sku: p.sku ?? '',
                slug: p.slug,
                brand_slug: p.brand.slug,
                status: p.status,
                venting_type: p.ventingType ?? '',
                btu_input: p.btuInput ?? '',
                btu_output: p.btuOutput ?? '',
                efficiency_rating: p.efficiencyRating ?? '',
                width: p.width ?? '',
                height: p.height ?? '',
                depth: p.depth ?? '',
                weight: p.weight ?? '',
                short_description: p.shortDescription ?? '',
                description: p.description ?? '',
                product_url: p.productUrl ?? '',
                price_map: p.priceMap ?? '',
                price_msrp: p.priceMsrp ?? '',
                ...imageUrls,
                spec_sheet_url: specSheet,
                manual_url: manual,
                ...specFields,
            };
        });

        const csv = Papa.unparse(rows);
        const filename = `hearth_products_export_${new Date().toISOString().slice(0, 10)}.csv`;

        return new NextResponse(csv, {
            status: 200,
            headers: {
                'Content-Type': 'text/csv',
                'Content-Disposition': `attachment; filename="${filename}"`,
            },
        });
    } catch (error: any) {
        console.error('Product export error:', error);
        return NextResponse.json({ error: 'Failed to export products' }, { status: 500 });
    }
}
