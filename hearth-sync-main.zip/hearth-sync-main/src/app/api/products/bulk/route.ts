import { NextResponse } from 'next/server';
import prisma from '@/lib/db';

export async function DELETE(request: Request) {
    try {
        const body = await request.json();
        const { ids, allPages } = body;

        if (allPages) {
            // Delete all products (no ID filter — used with "Select All Across Pages")
            const result = await prisma.product.deleteMany({});
            return NextResponse.json({ success: true, count: result.count });
        }

        if (!ids || !Array.isArray(ids) || ids.length === 0) {
            return NextResponse.json({ error: 'No IDs provided' }, { status: 400 });
        }

        const result = await prisma.product.deleteMany({
            where: { id: { in: ids } },
        });

        return NextResponse.json({ success: true, count: result.count });
    } catch (error: any) {
        console.error('Bulk delete error:', error);
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}

export async function PATCH(request: Request) {
    try {
        const body = await request.json();
        const { ids, allPages, data } = body;

        if (!allPages && (!ids || !Array.isArray(ids) || ids.length === 0)) {
            return NextResponse.json({ error: 'No IDs provided' }, { status: 400 });
        }
        if (!data || Object.keys(data).length === 0) {
            return NextResponse.json({ error: 'No data provided' }, { status: 400 });
        }

        const { categoryIds, ...scalarData } = data;

        if (categoryIds && Array.isArray(categoryIds) && categoryIds.length > 0) {
            // Category is M2M — must update each product individually
            const targetIds: string[] = allPages
                ? (await prisma.product.findMany({ select: { id: true } })).map(p => p.id)
                : ids;

            const updates = targetIds.map((id: string) =>
                prisma.product.update({
                    where: { id },
                    data: {
                        ...scalarData,
                        categories: {
                            connect: categoryIds.map((cid: string) => ({ id: cid })),
                        },
                    },
                })
            );

            await prisma.$transaction(updates);
            return NextResponse.json({ success: true, count: targetIds.length });
        }

        // Scalar-only update — can use updateMany
        if (allPages) {
            const result = await prisma.product.updateMany({ data: scalarData });
            return NextResponse.json({ success: true, count: result.count });
        }

        const result = await prisma.product.updateMany({
            where: { id: { in: ids } },
            data: scalarData,
        });

        return NextResponse.json({ success: true, count: result.count });
    } catch (error: any) {
        console.error('Bulk update error:', error);
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}
