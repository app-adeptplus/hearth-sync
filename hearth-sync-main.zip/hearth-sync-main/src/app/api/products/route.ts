import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/db';

// GET /api/products — List products with filters and pagination
export async function GET(request: NextRequest) {
    try {
        const searchParams = request.nextUrl.searchParams;
        const page = parseInt(searchParams.get('page') || '1');
        const limit = parseInt(searchParams.get('limit') || '25');
        const skip = (page - 1) * limit;

        const search = searchParams.get('q');
        const brandId = searchParams.get('brand');
        const status = searchParams.get('status');
        const categoryIds = searchParams.getAll('category');

        const where: Record<string, unknown> = {};
        if (search) {
            where.OR = [
                { name: { contains: search, mode: 'insensitive' } },
                { modelNumber: { contains: search, mode: 'insensitive' } },
                { sku: { contains: search, mode: 'insensitive' } },
            ];
        }
        if (brandId) where.brandId = brandId;
        if (status) where.status = status;
        if (categoryIds.length > 0) {
            const categories = categoryIds.length === 1 && categoryIds[0].includes(',')
                ? categoryIds[0].split(',')
                : categoryIds;
            where.categories = { some: { id: { in: categories } } };
        }

        const [products, total] = await Promise.all([
            prisma.product.findMany({
                where,
                skip,
                take: limit,
                orderBy: { updatedAt: 'desc' },
                include: {
                    brand: {
                        select: {
                            name: true,
                            slug: true,
                            manufacturer: { select: { name: true } },
                        },
                    },
                    categories: { select: { id: true, name: true, slug: true } },
                    images: { where: { isPrimary: true }, take: 1 },
                    _count: { select: { specs: true, documents: true, images: true } },
                },
            }),
            prisma.product.count({ where }),
        ]);

        return NextResponse.json({
            data: products,
            pagination: {
                page,
                limit,
                total,
                totalPages: Math.ceil(total / limit),
            },
        });
    } catch (error) {
        console.error('GET /api/products error:', error);
        return NextResponse.json(
            { error: 'Failed to fetch products' },
            { status: 500 }
        );
    }
}

// POST /api/products — Create a new product
export async function POST(request: NextRequest) {
    try {
        const body = await request.json();
        const {
            brandId, name, slug, modelNumber, sku, fuelType, ventingType,
            btuInput, btuOutput, shortDescription, description,
            priceMap, priceMsrp, productUrl, categories,
        } = body;

        if (!brandId || !name || !slug) {
            return NextResponse.json(
                { error: 'brandId, name, and slug are required' },
                { status: 400 }
            );
        }

        const product = await prisma.product.create({
            data: {
                brandId,
                name,
                slug,
                modelNumber,
                sku,
                ventingType,
                btuInput,
                btuOutput,
                shortDescription,
                description,
                priceMap,
                priceMsrp,
                productUrl,
                categories: categories?.length
                    ? { connect: categories.map((id: string) => ({ id })) }
                    : undefined,
            },
            include: { brand: true, categories: true },
        });

        // Audit log
        await prisma.auditLog.create({
            data: {
                productId: product.id,
                action: 'CREATED',
                entityType: 'product',
                entityId: product.id,
                after: JSON.parse(JSON.stringify(product)),
                changedBy: 'system',
            },
        });

        return NextResponse.json({ data: product }, { status: 201 });
    } catch (error) {
        console.error('POST /api/products error:', error);
        return NextResponse.json(
            { error: 'Failed to create product' },
            { status: 500 }
        );
    }
}
