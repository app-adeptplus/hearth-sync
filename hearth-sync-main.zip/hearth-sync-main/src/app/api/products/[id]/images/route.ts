import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/db';
import { createServiceClient } from '@/lib/supabase';

export async function POST(request: NextRequest, { params }: { params: { id: string } }) {
    try {
        const formData = await request.formData();
        const file = formData.get('file') as File;
        const isPrimary = formData.get('isPrimary') === 'true';

        if (!file) {
            return NextResponse.json({ error: 'No file provided' }, { status: 400 });
        }

        const supabase = createServiceClient();
        const fileExt = file.name.split('.').pop();
        const fileName = `${params.id}/${Date.now()}_${Math.random().toString(36).substring(7)}.${fileExt}`;

        // Upload to Supabase Storage
        const buffer = await file.arrayBuffer();
        const { error: uploadError } = await supabase.storage
            .from('products')
            .upload(`images/${fileName}`, buffer, {
                contentType: file.type,
                upsert: false
            });

        if (uploadError) {
            console.error("Supabase upload error:", uploadError);
            throw new Error(`Upload failed: ${uploadError.message}`);
        }

        // Get public URL
        const { data: { publicUrl } } = supabase.storage
            .from('products')
            .getPublicUrl(`images/${fileName}`);

        // Save to Database
        // If this is set to primary, unset others first
        if (isPrimary) {
            await prisma.productImage.updateMany({
                where: { productId: params.id, isPrimary: true },
                data: { isPrimary: false }
            });
        }

        const newImage = await prisma.productImage.create({
            data: {
                productId: params.id,
                url: publicUrl,
                altText: file.name,
                isPrimary: isPrimary,
                sortOrder: 0
            }
        });

        return NextResponse.json({ data: newImage });
    } catch (error: any) {
        console.error('Image upload error:', error);
        return NextResponse.json({ error: error.message || 'Server error' }, { status: 500 });
    }
}

export async function DELETE(request: NextRequest, { params }: { params: { id: string } }) {
    try {
        const url = new URL(request.url);
        const imageId = url.searchParams.get('imageId');

        if (!imageId) {
            return NextResponse.json({ error: 'Image ID required' }, { status: 400 });
        }

        const image = await prisma.productImage.findUnique({ where: { id: imageId } });
        if (!image || image.productId !== params.id) {
            return NextResponse.json({ error: 'Image not found' }, { status: 404 });
        }

        // Delete from database
        await prisma.productImage.delete({ where: { id: imageId } });

        // Optionally delete from storage here, but we'd need to parse the URL.
        // For now, we'll just delete the DB record.
        const supabase = createServiceClient();
        try {
            const urlParts = image.url.split('/products/images/');
            if (urlParts.length > 1) {
                const path = `images/${urlParts[1]}`;
                await supabase.storage.from('products').remove([path]);
            }
        } catch (e) {
            console.warn("Could not delete physical file:", e);
        }

        return NextResponse.json({ success: true });
    } catch (error: any) {
        console.error('Image delete error:', error);
        return NextResponse.json({ error: 'Server error' }, { status: 500 });
    }
}
