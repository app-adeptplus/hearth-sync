import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/db';
import { createServiceClient } from '@/lib/supabase';

// Define expected document enum locally or import it
// enum DocumentType { SPEC_SHEET, MANUAL, INSTALLATION_GUIDE, WARRANTY, BROCHURE, OTHER }

export async function POST(request: NextRequest, { params }: { params: { id: string } }) {
    try {
        const formData = await request.formData();
        const file = formData.get('file') as File;
        const type = (formData.get('type') as string) || 'OTHER';
        const name = (formData.get('name') as string) || file.name;

        if (!file) {
            return NextResponse.json({ error: 'No file provided' }, { status: 400 });
        }

        const supabase = createServiceClient();
        const fileExt = file.name.split('.').pop();
        const fileName = `${params.id}/${Date.now()}_${Math.random().toString(36).substring(7)}.${fileExt}`;

        // Upload to Supabase Storage
        const buffer = await file.arrayBuffer();
        const { error: uploadError } = await supabase.storage
            .from('products')
            .upload(`documents/${fileName}`, buffer, {
                contentType: file.type,
                upsert: false
            });

        if (uploadError) {
            console.error("Supabase upload error:", uploadError);
            throw new Error(`Upload failed: ${uploadError.message}`);
        }

        // Get public URL
        const { data: { publicUrl } } = supabase.storage
            .from('products')
            .getPublicUrl(`documents/${fileName}`);

        // Save to Database
        const newDoc = await prisma.productDocument.create({
            data: {
                productId: params.id,
                url: publicUrl,
                type: type as any,
                name: name,
                fileSize: buffer.byteLength
            }
        });

        return NextResponse.json({ data: newDoc });
    } catch (error: any) {
        console.error('Document upload error:', error);
        return NextResponse.json({ error: error.message || 'Server error' }, { status: 500 });
    }
}

export async function DELETE(request: NextRequest, { params }: { params: { id: string } }) {
    try {
        const url = new URL(request.url);
        const documentId = url.searchParams.get('documentId');

        if (!documentId) {
            return NextResponse.json({ error: 'Document ID required' }, { status: 400 });
        }

        const document = await prisma.productDocument.findUnique({ where: { id: documentId } });
        if (!document || document.productId !== params.id) {
            return NextResponse.json({ error: 'Document not found' }, { status: 404 });
        }

        // Delete from database
        await prisma.productDocument.delete({ where: { id: documentId } });

        // Delete from storage
        const supabase = createServiceClient();
        try {
            const urlParts = document.url.split('/products/documents/');
            if (urlParts.length > 1) {
                const path = `documents/${urlParts[1]}`;
                await supabase.storage.from('products').remove([path]);
            }
        } catch (e) {
            console.warn("Could not delete physical file:", e);
        }

        return NextResponse.json({ success: true });
    } catch (error: any) {
        console.error('Document delete error:', error);
        return NextResponse.json({ error: 'Server error' }, { status: 500 });
    }
}
