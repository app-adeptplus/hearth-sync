import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/db';
import DOMPurify from 'isomorphic-dompurify';

export async function GET(_request: NextRequest, { params }: { params: { id: string } }) {
    try {
        const product = await prisma.product.findUnique({
            where: { id: params.id },
            include: {
                brand: { include: { manufacturer: true } },
                images: { orderBy: { sortOrder: 'asc' } },
                categories: { orderBy: { name: 'asc' } },
                attributeValues: {
                    include: { attribute: true },
                    orderBy: { attribute: { sortOrder: 'asc' } },
                },
            },
        });
        if (!product) return NextResponse.json({ error: 'Not found' }, { status: 404 });
        return NextResponse.json({ data: product });
    } catch (error) {
        console.error('GET /api/products/[id] error:', error);
        return NextResponse.json({ error: 'Failed to fetch product' }, { status: 500 });
    }
}


export async function PATCH(request: NextRequest, { params }: { params: { id: string } }) {
    try {
        const body = await request.json();
        const {
            name, shortDescription, description,
            categoryIds, attributeValues,
            ...otherOptions
        } = body;

        const data: any = { ...otherOptions };

        // Normalise empty strings to null for nullable scalar fields
        const nullableStrings = ['modelNumber', 'sku', 'ventingType', 'productUrl'];
        for (const key of nullableStrings) {
            if (data[key] === '') data[key] = null;
        }

        // Sanitize rich-text fields
        if (name !== undefined) data.name = DOMPurify.sanitize(name);
        if (shortDescription !== undefined) data.shortDescription = DOMPurify.sanitize(shortDescription);
        if (description !== undefined) data.description = DOMPurify.sanitize(description);

        // Categories M2M — replace the full set
        if (Array.isArray(categoryIds)) {
            data.categories = {
                set: categoryIds.map((id: string) => ({ id })),
            };
        }

        // Update the core product record
        const updatedProduct = await prisma.product.update({
            where: { id: params.id },
            data,
        });

        // Upsert attribute values — { [attributeId]: value }
        if (attributeValues && typeof attributeValues === 'object') {
            const upserts = Object.entries(attributeValues)
                .filter(([, value]) => value !== '' && value !== null && value !== undefined)
                .map(([attributeId, value]) =>
                    prisma.productAttributeValue.upsert({
                        where: { productId_attributeId: { productId: params.id, attributeId } },
                        create: { productId: params.id, attributeId, value: String(value) },
                        update: { value: String(value) },
                    })
                );

            // Delete any attribute values explicitly cleared (empty string)
            const deletes = Object.entries(attributeValues)
                .filter(([, value]) => value === '' || value === null)
                .map(([attributeId]) =>
                    prisma.productAttributeValue.deleteMany({
                        where: { productId: params.id, attributeId },
                    })
                );

            if (upserts.length > 0 || deletes.length > 0) {
                await prisma.$transaction([...upserts, ...deletes]);
            }
        }

        return NextResponse.json({ data: updatedProduct });
    } catch (error) {
        console.error('PATCH /api/products/[id] error:', error);
        return NextResponse.json({ error: 'Failed to update product' }, { status: 500 });
    }
}

export async function DELETE(_request: NextRequest, { params }: { params: { id: string } }) {
    try {
        await prisma.product.delete({ where: { id: params.id } });
        return NextResponse.json({ success: true });
    } catch (error) {
        console.error('DELETE /api/products/[id] error:', error);
        return NextResponse.json({ error: 'Failed to delete product' }, { status: 500 });
    }
}
