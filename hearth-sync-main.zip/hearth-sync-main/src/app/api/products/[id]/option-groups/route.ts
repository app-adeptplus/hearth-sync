import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/db';

// GET /api/products/[id]/option-groups — list all option groups assigned to a product
export async function GET(_: NextRequest, { params }: { params: { id: string } }) {
    try {
        const links = await prisma.productOptionGroup.findMany({
            where: { productId: params.id },
            orderBy: { sortOrder: 'asc' },
            include: {
                group: {
                    include: {
                        options: {
                            where: { isActive: true },
                            orderBy: [{ sortOrder: 'asc' }, { label: 'asc' }],
                        },
                    },
                },
            },
        });
        return NextResponse.json({ data: links });
    } catch (error: any) {
        return NextResponse.json({ error: error.message || 'Failed to fetch product option groups' }, { status: 500 });
    }
}

// POST /api/products/[id]/option-groups — assign an option group to a product
export async function POST(request: NextRequest, { params }: { params: { id: string } }) {
    try {
        const body = await request.json();
        const { groupId, sortOrder, isRequired } = body;

        if (!groupId) return NextResponse.json({ error: 'groupId is required' }, { status: 400 });

        // Verify product and group exist
        const [product, group] = await Promise.all([
            prisma.product.findUnique({ where: { id: params.id }, select: { id: true } }),
            prisma.optionGroup.findUnique({ where: { id: groupId }, select: { id: true } }),
        ]);
        if (!product) return NextResponse.json({ error: 'Product not found' }, { status: 404 });
        if (!group) return NextResponse.json({ error: 'Option group not found' }, { status: 404 });

        const link = await prisma.productOptionGroup.upsert({
            where: { productId_groupId: { productId: params.id, groupId } },
            create: {
                productId: params.id,
                groupId,
                sortOrder: sortOrder ?? 0,
                isRequired: isRequired ?? null,
            },
            update: {
                sortOrder: sortOrder ?? 0,
                isRequired: isRequired ?? null,
            },
            include: {
                group: {
                    include: {
                        options: {
                            where: { isActive: true },
                            orderBy: [{ sortOrder: 'asc' }, { label: 'asc' }],
                        },
                    },
                },
            },
        });
        return NextResponse.json({ data: link }, { status: 201 });
    } catch (error: any) {
        return NextResponse.json({ error: error.message || 'Failed to assign option group' }, { status: 500 });
    }
}

// DELETE /api/products/[id]/option-groups — unassign an option group from a product
export async function DELETE(request: NextRequest, { params }: { params: { id: string } }) {
    try {
        const body = await request.json();
        const { groupId } = body;

        if (!groupId) return NextResponse.json({ error: 'groupId is required' }, { status: 400 });

        await prisma.productOptionGroup.delete({
            where: { productId_groupId: { productId: params.id, groupId } },
        });
        return NextResponse.json({ success: true });
    } catch (error: any) {
        if (error.code === 'P2025') return NextResponse.json({ error: 'Assignment not found' }, { status: 404 });
        return NextResponse.json({ error: error.message || 'Failed to unassign option group' }, { status: 500 });
    }
}
