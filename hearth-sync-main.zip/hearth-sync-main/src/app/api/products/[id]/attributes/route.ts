import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/db';

/**
 * GET /api/products/[id]/attributes
 * Returns the attribute mappings for the product's current categories,
 * plus the product's existing saved values.
 */
export async function GET(_request: NextRequest, { params }: { params: { id: string } }) {
    try {
        const product = await prisma.product.findUnique({
            where: { id: params.id },
            include: {
                categories: {
                    include: {
                        attributeMappings: {
                            include: { attribute: true },
                            orderBy: { sortOrder: 'asc' },
                        },
                    },
                },
                attributeValues: {
                    include: { attribute: true },
                },
            },
        });

        if (!product) return NextResponse.json({ error: 'Not found' }, { status: 404 });

        // Build deduplicated, sorted list of attribute mappings from all current categories
        const seen = new Set<string>();
        const mappings: any[] = [];

        for (const cat of product.categories) {
            for (const mapping of cat.attributeMappings) {
                if (!seen.has(mapping.attributeId)) {
                    seen.add(mapping.attributeId);
                    mappings.push({
                        attributeId: mapping.attributeId,
                        categoryId: cat.id,
                        categoryName: cat.name,
                        isRequired: mapping.isRequired,
                        isFilterable: mapping.isFilterable,
                        defaultValue: mapping.defaultValue,
                        sortOrder: mapping.sortOrder,
                        attribute: mapping.attribute,
                    });
                }
            }
        }

        // Sort by category name then sortOrder then attribute name
        mappings.sort((a, b) => {
            if (a.categoryName !== b.categoryName) return a.categoryName.localeCompare(b.categoryName);
            if (a.sortOrder !== b.sortOrder) return a.sortOrder - b.sortOrder;
            return a.attribute.name.localeCompare(b.attribute.name);
        });

        // Build values map: { [attributeId]: string }
        const values: Record<string, string> = {};
        for (const av of product.attributeValues) {
            values[av.attributeId] = av.value;
        }

        return NextResponse.json({ mappings, values });
    } catch (error) {
        console.error('GET /api/products/[id]/attributes error:', error);
        return NextResponse.json({ error: 'Failed to fetch attribute data' }, { status: 500 });
    }
}

/**
 * PUT /api/products/[id]/attributes
 * Body: { values: Record<attributeId, string> }
 * Upserts non-empty values, deletes empty/null values, all in one transaction.
 */
export async function PUT(request: NextRequest, { params }: { params: { id: string } }) {
    try {
        const body = await request.json();
        const { values } = body as { values: Record<string, string> };

        if (!values || typeof values !== 'object') {
            return NextResponse.json({ error: 'values must be an object' }, { status: 400 });
        }

        const upserts = Object.entries(values)
            .filter(([, value]) => value !== '' && value !== null && value !== undefined)
            .map(([attributeId, value]) =>
                prisma.productAttributeValue.upsert({
                    where: { productId_attributeId: { productId: params.id, attributeId } },
                    create: { productId: params.id, attributeId, value: String(value) },
                    update: { value: String(value) },
                })
            );

        const deletes = Object.entries(values)
            .filter(([, value]) => value === '' || value === null || value === undefined)
            .map(([attributeId]) =>
                prisma.productAttributeValue.deleteMany({
                    where: { productId: params.id, attributeId },
                })
            );

        if (upserts.length > 0 || deletes.length > 0) {
            await prisma.$transaction([...upserts, ...deletes]);
        }

        // Return updated values
        const updatedValues = await prisma.productAttributeValue.findMany({
            where: { productId: params.id },
            include: { attribute: true },
        });

        const result: Record<string, string> = {};
        for (const av of updatedValues) {
            result[av.attributeId] = av.value;
        }

        return NextResponse.json({ values: result });
    } catch (error) {
        console.error('PUT /api/products/[id]/attributes error:', error);
        return NextResponse.json({ error: 'Failed to save attribute values' }, { status: 500 });
    }
}
