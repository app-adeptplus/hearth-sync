import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/db';
import { ScraperEngine } from '@/scraper/ScraperEngine';

/**
 * GET /api/cron/process-jobs
 *
 * Called by Vercel Cron (configured in vercel.json) to process pending scraper jobs.
 * Picks up PENDING jobs from the DB and dispatches them to the external worker.
 *
 * Also checks AutomationConfig schedules to create new jobs when they're due.
 */
export async function GET(request: NextRequest) {
    // Verify the request comes from Vercel Cron (in production)
    const authHeader = request.headers.get('authorization');
    if (
        process.env.CRON_SECRET &&
        authHeader !== `Bearer ${process.env.CRON_SECRET}`
    ) {
        return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    try {
        // 1. Find all PENDING scraper jobs
        const pendingJobs = await prisma.scraperJob.findMany({
            where: { status: 'PENDING' },
            take: 10, // Process up to 10 jobs per cron tick
            orderBy: { createdAt: 'asc' },
        });

        const dispatched: string[] = [];
        const errors: string[] = [];

        for (const job of pendingJobs) {
            try {
                await ScraperEngine.dispatch({
                    jobId: job.id,
                    configId: job.scraperConfigId,
                    targetUrl: job.targetUrl ?? undefined,
                });
                dispatched.push(job.id);
            } catch (error) {
                const msg = `Job ${job.id} dispatch failed: ${error instanceof Error ? error.message : error}`;
                errors.push(msg);
                console.error(msg);
            }
        }

        // 2. Check for scheduled automation configs that are due
        // (OccurrenceSchedule: HOURLY, DAILY, WEEKLY, etc.)
        const scheduledConfigs = await prisma.scraperConfig.findMany({
            where: {
                isActive: true,
                syncFrequency: { not: 'MANUAL' },
            },
            select: {
                id: true,
                syncFrequency: true,
                lastSyncAt: true,
            },
        });

        let scheduledCreated = 0;
        const now = new Date();

        for (const config of scheduledConfigs) {
            const isDue = isScheduleDue(config.syncFrequency, config.lastSyncAt, now);
            if (isDue) {
                // Check there's no existing PENDING/RUNNING job for this config
                const existingJob = await prisma.scraperJob.findFirst({
                    where: {
                        scraperConfigId: config.id,
                        status: { in: ['PENDING', 'RUNNING'] },
                    },
                });

                if (!existingJob) {
                    await prisma.scraperJob.create({
                        data: {
                            scraperConfigId: config.id,
                            status: 'PENDING',
                        },
                    });
                    scheduledCreated++;
                }
            }
        }

        return NextResponse.json({
            ok: true,
            pendingFound: pendingJobs.length,
            dispatched: dispatched.length,
            scheduledCreated,
            errors: errors.length > 0 ? errors : undefined,
        });
    } catch (error) {
        console.error('Cron process-jobs error:', error);
        return NextResponse.json(
            { error: 'Failed to process jobs' },
            { status: 500 }
        );
    }
}

function isScheduleDue(
    frequency: string | null,
    lastSyncAt: Date | null,
    now: Date
): boolean {
    if (!frequency || frequency === 'MANUAL') return false;
    if (!lastSyncAt) return true; // Never synced, always due

    const elapsed = now.getTime() - lastSyncAt.getTime();
    const hours = elapsed / (1000 * 60 * 60);

    switch (frequency) {
        case 'HOURLY':
            return hours >= 1;
        case 'DAILY':
            return hours >= 24;
        case 'WEEKLY':
            return hours >= 168;
        case 'BIWEEKLY':
            return hours >= 336;
        case 'MONTHLY':
            return hours >= 720;
        default:
            return false;
    }
}
