import { PrismaClient } from '@prisma/client';
import { NextResponse } from 'next/server';

const prisma = new PrismaClient();

export const dynamic = 'force-dynamic';

export async function GET(
    request: Request,
    { params }: { params: { dealerId: string } }
) {
    const { searchParams } = new URL(request.url);
    const category = searchParams.get('category');
    const fuelType = searchParams.get('fuelType');
    const productType = searchParams.get('productType');
    const brandSlug = searchParams.get('brand');
    const query = searchParams.get('q');

    try {
        // 1. Verify dealer exists and is active
        const dealer = await prisma.dealerAccount.findUnique({
            where: { id: params.dealerId },
            include: {
                catalogSelections: true,
            },
        });

        if (!dealer || dealer.subscriptionStatus !== 'active') {
            return NextResponse.json({ error: 'Dealer not found or inactive' }, { status: 404 });
        }

        // 2. Determine which products/brands this dealer has activated
        const activatedBrandIds: string[] = [];

        const activatedProductIds = dealer.catalogSelections
            .filter((s: any) => s.isActive)
            .map((s: any) => s.productId);

        // 3. Fetch products matching filters AND dealer's selection
        const whereClause: any = {
            status: 'ACTIVE',
            AND: [
                {
                    OR: [
                        { brandId: { in: activatedBrandIds } },
                        { id: { in: activatedProductIds } },
                    ]
                }
            ]
        };

        if (category) {
            whereClause.categories = { some: { slug: category } }; // Fixed category lookup logic
        }
        if (fuelType) {
            // fuelType is now a category slug under the 'fuel-type' parent
            whereClause.categories = { some: { slug: fuelType } };
        }
        if (productType) {
            // productType is now a category slug under a product-type parent
            whereClause.categories = { some: { slug: productType } };
        }
        if (brandSlug) {
            whereClause.brand = { slug: brandSlug };
        }
        if (query) {
            whereClause.AND.push({
                OR: [
                    { name: { contains: query, mode: 'insensitive' } },
                    { modelNumber: { contains: query, mode: 'insensitive' } },
                ],
            });
        }

        const products = await prisma.product.findMany({
            where: whereClause,
            include: {
                brand: { select: { name: true, slug: true } },
                images: { where: { isPrimary: true }, take: 1, select: { url: true } },
                categories: { select: { name: true, parentId: true } },
            },
            take: 100, // Pagination limit for widget
        });

        // Formatting for the widget consumer
        const formattedProducts = products.map((p: any) => ({
            id: p.id,
            name: p.name,
            slug: p.slug,
            brand: p.brand.name,
            modelNumber: p.modelNumber,
            imageUrl: p.images[0]?.url || null,
            priceMsrp: p.priceMsrp ? Number(p.priceMsrp) : null,
        }));

        // Handle CORS for widget embedding
        const headers = new Headers();
        headers.set('Access-Control-Allow-Origin', '*'); // In production, restrict to dealer's verified domains
        headers.set('Access-Control-Allow-Methods', 'GET');

        return NextResponse.json({ products: formattedProducts }, { headers });
    } catch (error) {
        console.error('Widget products error:', error);
        return NextResponse.json({ error: 'Internal Server Error' }, { status: 500 });
    }
}
