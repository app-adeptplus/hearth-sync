import { PrismaClient } from '@prisma/client';
import { NextResponse } from 'next/server';

const prisma = new PrismaClient();

export async function GET(
    request: Request,
    { params }: { params: { dealerId: string } }
) {
    try {
        const config = await prisma.widgetConfig.findUnique({
            where: { dealerId: params.dealerId },
        });

        const headers = new Headers();
        headers.set('Access-Control-Allow-Origin', '*');
        headers.set('Access-Control-Allow-Methods', 'GET');

        if (!config) {
            // Default fallback config
            return NextResponse.json({
                primaryColor: '#eab308',
                fontFamily: 'inherit',
                cornerStyle: 'rounded',
            }, { headers });
        }

        return NextResponse.json(config, { headers });
    } catch (error) {
        return NextResponse.json({ error: 'Internal Server Error' }, { status: 500 });
    }
}
