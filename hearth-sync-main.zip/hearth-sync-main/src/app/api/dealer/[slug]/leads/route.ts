import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/db';

async function getDealer(slugOrId: string) {
    return prisma.dealerAccount.findFirst({
        where: { OR: [{ slug: slugOrId }, { id: slugOrId }] },
    });
}

export async function POST(req: NextRequest, { params }: { params: { slug: string } }) {
    try {
        const dealer = await getDealer(params.slug);
        if (!dealer) return NextResponse.json({ error: 'Dealer not found' }, { status: 404 });

        const body = await req.json();
        const { groupId, name, email, phone, zip, productInterest, message } = body;

        if (!email?.trim() && !phone?.trim()) {
            return NextResponse.json({ error: 'At least email or phone is required' }, { status: 400 });
        }

        // Split name into first/last
        const nameParts = (name ?? '').trim().split(/\s+/);
        const firstName = nameParts[0] || 'Unknown';
        const lastName = nameParts.slice(1).join(' ') || '';

        const lead = await prisma.lead.create({
            data: {
                dealerId: dealer.id,
                firstName,
                lastName,
                email: email?.trim()?.toLowerCase() || `noreply+${Date.now()}@placeholder.com`,
                phone: phone?.trim() || null,
                zip: zip?.trim() || null,
                message: [
                    productInterest ? `Product Interest: ${productInterest}` : null,
                    message || null,
                ].filter(Boolean).join('\n\n') || null,
                source: 'catalog_widget',
            },
        });

        return NextResponse.json({ lead }, { status: 201 });
    } catch (error: any) {
        console.error('[POST /api/dealer/[slug]/leads]', error);
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}

export async function GET(req: NextRequest, { params }: { params: { slug: string } }) {
    try {
        const dealer = await getDealer(params.slug);
        if (!dealer) return NextResponse.json({ error: 'Dealer not found' }, { status: 404 });

        const { searchParams } = new URL(req.url);
        const page = parseInt(searchParams.get('page') ?? '1');
        const pageSize = 50;

        const [leads, total] = await Promise.all([
            prisma.lead.findMany({
                where: { dealerId: dealer.id },
                orderBy: { createdAt: 'desc' },
                skip: (page - 1) * pageSize,
                take: pageSize,
            }),
            prisma.lead.count({ where: { dealerId: dealer.id } }),
        ]);

        return NextResponse.json({ leads, total, page, pageSize });
    } catch (error: any) {
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}
