import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/db';

async function getDealer(slugOrId: string) {
    return prisma.dealerAccount.findFirst({
        where: { OR: [{ slug: slugOrId }, { id: slugOrId }] },
    });
}

async function getGroup(dealerId: string, groupId: string) {
    return prisma.dealerCatalogGroup.findFirst({
        where: { id: groupId, dealerId },
    });
}

export async function GET(req: NextRequest, { params }: { params: { slug: string; groupId: string } }) {
    try {
        const dealer = await getDealer(params.slug);
        if (!dealer) return NextResponse.json({ error: 'Dealer not found' }, { status: 404 });

        const group = await prisma.dealerCatalogGroup.findFirst({
            where: { id: params.groupId, dealerId: dealer.id },
            include: {
                products: {
                    orderBy: { sortOrder: 'asc' },
                    include: {
                        product: {
                            include: {
                                images: { where: { isPrimary: true }, take: 1 },
                                brand: { select: { name: true } },
                            },
                        },
                    },
                },
            },
        });

        if (!group) return NextResponse.json({ error: 'Catalog group not found' }, { status: 404 });
        return NextResponse.json({ group });
    } catch (error: any) {
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}

export async function PUT(req: NextRequest, { params }: { params: { slug: string; groupId: string } }) {
    try {
        const dealer = await getDealer(params.slug);
        if (!dealer) return NextResponse.json({ error: 'Dealer not found' }, { status: 404 });

        const group = await getGroup(dealer.id, params.groupId);
        if (!group) return NextResponse.json({ error: 'Catalog group not found' }, { status: 404 });

        const body = await req.json();
        const {
            name, description, isEnabled, customCss, trackingScripts,
            leadFormEnabled, leadFormTitle, leadFormFields,
        } = body;

        // Generate embed code when enabling
        let embedCode = group.embedCode;
        if (isEnabled && !group.isEnabled) {
            const baseUrl = process.env.NEXT_PUBLIC_APP_URL || 'https://app.hearthhub.com';
            const dealerSlug = dealer.slug || dealer.id;
            const groupSlug = group.slug;
            const viewUrl = `${baseUrl}/dealer/${dealerSlug}/view/${groupSlug}`;
            embedCode = `<!-- HearthSync Catalog: ${name || group.name} -->
<!-- Direct link: ${viewUrl} -->
<div id="hearth-catalog-${group.id}"></div>
<script>
  (function() {
    var s = document.createElement('script');
    s.src = '${baseUrl}/api/widget/catalog/${group.id}/embed.js';
    s.async = true;
    s.dataset.catalogId = '${group.id}';
    s.dataset.dealerId = '${dealer.id}';
    document.head.appendChild(s);
  })();
</script>
<!-- End HearthSync Catalog -->`;
        }

        const updated = await prisma.dealerCatalogGroup.update({
            where: { id: params.groupId },
            data: {
                name: name?.trim() || group.name,
                description: description?.trim() ?? group.description,
                isEnabled: isEnabled ?? group.isEnabled,
                embedCode: isEnabled ? embedCode : group.embedCode,
                customCss: customCss ?? group.customCss,
                trackingScripts: trackingScripts ?? group.trackingScripts,
                leadFormEnabled: leadFormEnabled ?? group.leadFormEnabled,
                leadFormTitle: leadFormTitle ?? group.leadFormTitle,
                leadFormFields: leadFormFields ?? group.leadFormFields,
            },
        });

        return NextResponse.json({ group: updated });
    } catch (error: any) {
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}

export async function DELETE(req: NextRequest, { params }: { params: { slug: string; groupId: string } }) {
    try {
        const dealer = await getDealer(params.slug);
        if (!dealer) return NextResponse.json({ error: 'Dealer not found' }, { status: 404 });

        const group = await getGroup(dealer.id, params.groupId);
        if (!group) return NextResponse.json({ error: 'Catalog group not found' }, { status: 404 });

        await prisma.dealerCatalogGroup.delete({ where: { id: params.groupId } });
        return NextResponse.json({ ok: true });
    } catch (error: any) {
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}
