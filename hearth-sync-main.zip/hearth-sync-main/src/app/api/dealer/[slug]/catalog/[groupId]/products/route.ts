import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/db';

const MAX_PRODUCTS_PER_GROUP = 1000;

async function getDealer(slugOrId: string) {
    return prisma.dealerAccount.findFirst({
        where: { OR: [{ slug: slugOrId }, { id: slugOrId }] },
    });
}

export async function GET(req: NextRequest, { params }: { params: { slug: string; groupId: string } }) {
    try {
        const { searchParams } = new URL(req.url);
        const search = searchParams.get('search') ?? '';
        const page = parseInt(searchParams.get('page') ?? '1');
        const pageSize = 50;

        const dealer = await getDealer(params.slug);
        if (!dealer) return NextResponse.json({ error: 'Dealer not found' }, { status: 404 });

        const where: any = {
            groupId: params.groupId,
        };

        if (search) {
            where.product = {
                OR: [
                    { name: { contains: search, mode: 'insensitive' } },
                    { modelNumber: { contains: search, mode: 'insensitive' } },
                    { sku: { contains: search, mode: 'insensitive' } },
                ],
            };
        }

        const [items, total] = await Promise.all([
            prisma.dealerCatalogGroupProduct.findMany({
                where,
                orderBy: { sortOrder: 'asc' },
                skip: (page - 1) * pageSize,
                take: pageSize,
                include: {
                    product: {
                        include: {
                            images: { where: { isPrimary: true }, take: 1 },
                            brand: { select: { name: true } },
                        },
                    },
                },
            }),
            prisma.dealerCatalogGroupProduct.count({ where }),
        ]);

        return NextResponse.json({ items, total, page, pageSize });
    } catch (error: any) {
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}

export async function POST(req: NextRequest, { params }: { params: { slug: string; groupId: string } }) {
    try {
        const dealer = await getDealer(params.slug);
        if (!dealer) return NextResponse.json({ error: 'Dealer not found' }, { status: 404 });

        // Verify group belongs to dealer
        const group = await prisma.dealerCatalogGroup.findFirst({
            where: { id: params.groupId, dealerId: dealer.id },
            include: { _count: { select: { products: true } } },
        });
        if (!group) return NextResponse.json({ error: 'Catalog group not found' }, { status: 404 });

        const body = await req.json();
        const productIds: string[] = Array.isArray(body.productIds) ? body.productIds : [body.productId];

        // Check capacity
        const available = MAX_PRODUCTS_PER_GROUP - group._count.products;
        if (productIds.length > available) {
            return NextResponse.json({
                error: `Cannot add ${productIds.length} products — group is at ${group._count.products}/${MAX_PRODUCTS_PER_GROUP}. Only ${available} slots remaining.`
            }, { status: 400 });
        }

        // Upsert each product into the group
        const results = await Promise.all(
            productIds.map((productId, i) =>
                prisma.dealerCatalogGroupProduct.upsert({
                    where: { groupId_productId: { groupId: params.groupId, productId } },
                    create: { groupId: params.groupId, productId, sortOrder: group._count.products + i },
                    update: { isActive: true },
                })
            )
        );

        return NextResponse.json({ added: results.length }, { status: 201 });
    } catch (error: any) {
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}
