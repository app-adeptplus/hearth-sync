import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/db';

const TIER_LIMITS: Record<string, number> = {
    STARTER: 5,
    PROFESSIONAL: 10,
    ENTERPRISE: 20,
};

async function getDealer(slugOrId: string) {
    return prisma.dealerAccount.findFirst({
        where: { OR: [{ slug: slugOrId }, { id: slugOrId }] },
    });
}

export async function GET(req: NextRequest, { params }: { params: { slug: string } }) {
    try {
        const dealer = await getDealer(params.slug);
        if (!dealer) return NextResponse.json({ error: 'Dealer not found' }, { status: 404 });

        const groups = await prisma.dealerCatalogGroup.findMany({
            where: { dealerId: dealer.id },
            orderBy: { sortOrder: 'asc' },
            include: { _count: { select: { products: true } } },
        });

        return NextResponse.json({ groups, tier: dealer.subscriptionTier, limit: TIER_LIMITS[dealer.subscriptionTier] ?? 5 });
    } catch (error: any) {
        console.error('[GET /api/dealer/[slug]/catalog]', error);
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}

export async function POST(req: NextRequest, { params }: { params: { slug: string } }) {
    try {
        const dealer = await getDealer(params.slug);
        if (!dealer) return NextResponse.json({ error: 'Dealer not found' }, { status: 404 });

        const body = await req.json();
        const { name, description } = body;

        if (!name?.trim()) {
            return NextResponse.json({ error: 'Catalog group name is required' }, { status: 400 });
        }

        // Check subscription limit
        const currentCount = await prisma.dealerCatalogGroup.count({ where: { dealerId: dealer.id } });
        const limit = TIER_LIMITS[dealer.subscriptionTier] ?? 5;
        if (currentCount >= limit) {
            return NextResponse.json({
                error: `Your ${dealer.subscriptionTier.toLowerCase()} plan allows a maximum of ${limit} catalog groups.`
            }, { status: 403 });
        }

        // Generate slug from name
        const baseSlug = name.toLowerCase().replace(/[^a-z0-9\s-]/g, '').trim().replace(/\s+/g, '-').replace(/-+/g, '-');
        let groupSlug = baseSlug;
        const existingSlug = await prisma.dealerCatalogGroup.findFirst({ where: { dealerId: dealer.id, slug: groupSlug } });
        if (existingSlug) {
            groupSlug = `${baseSlug}-${Date.now().toString(36)}`;
        }

        const group = await prisma.dealerCatalogGroup.create({
            data: {
                dealerId: dealer.id,
                name: name.trim(),
                slug: groupSlug,
                description: description?.trim() || null,
                sortOrder: currentCount,
            },
        });

        return NextResponse.json({ group }, { status: 201 });
    } catch (error: any) {
        console.error('[POST /api/dealer/[slug]/catalog]', error);
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}
