import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/db';

async function getDealer(slugOrId: string) {
    return prisma.dealerAccount.findFirst({
        where: { OR: [{ slug: slugOrId }, { id: slugOrId }] },
    });
}

export async function DELETE(req: NextRequest, { params }: { params: { slug: string; groupId: string; productId: string } }) {
    try {
        const dealer = await getDealer(params.slug);
        if (!dealer) return NextResponse.json({ error: 'Dealer not found' }, { status: 404 });

        await prisma.dealerCatalogGroupProduct.deleteMany({
            where: {
                groupId: params.groupId,
                productId: params.productId,
                group: { dealerId: dealer.id },
            },
        });

        return NextResponse.json({ ok: true });
    } catch (error: any) {
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}

export async function PUT(req: NextRequest, { params }: { params: { slug: string; groupId: string; productId: string } }) {
    try {
        const dealer = await getDealer(params.slug);
        if (!dealer) return NextResponse.json({ error: 'Dealer not found' }, { status: 404 });

        const body = await req.json();
        const { sortOrder, isActive, customPrice, customDescription } = body;

        const item = await prisma.dealerCatalogGroupProduct.update({
            where: { groupId_productId: { groupId: params.groupId, productId: params.productId } },
            data: {
                sortOrder: sortOrder ?? undefined,
                isActive: isActive ?? undefined,
                customPrice: customPrice !== undefined ? customPrice : undefined,
                customDescription: customDescription !== undefined ? customDescription : undefined,
            },
        });

        return NextResponse.json({ item });
    } catch (error: any) {
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}
