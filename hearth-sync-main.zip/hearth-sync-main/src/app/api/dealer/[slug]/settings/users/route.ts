import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/db';
import { createPortalUser } from '@/lib/auth-utils';
import { createServiceClient } from '@/lib/supabase';

async function getDealer(slugOrId: string) {
    return prisma.dealerAccount.findFirst({
        where: { OR: [{ slug: slugOrId }, { id: slugOrId }] },
    });
}

export async function GET(req: NextRequest, { params }: { params: { slug: string } }) {
    try {
        const dealer = await getDealer(params.slug);
        if (!dealer) return NextResponse.json({ error: 'Dealer not found' }, { status: 404 });

        const users = await prisma.dealerUser.findMany({
            where: { dealerId: dealer.id },
            orderBy: { createdAt: 'asc' },
        });

        return NextResponse.json({ users });
    } catch (error: any) {
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}

export async function POST(req: NextRequest, { params }: { params: { slug: string } }) {
    try {
        const dealer = await getDealer(params.slug);
        if (!dealer) return NextResponse.json({ error: 'Dealer not found' }, { status: 404 });

        const body = await req.json();
        const { email, role } = body;

        if (!email?.trim()) {
            return NextResponse.json({ error: 'Email is required' }, { status: 400 });
        }

        // Check if DealerUser already exists for this dealer
        const existing = await prisma.dealerUser.findFirst({
            where: { email: email.trim().toLowerCase(), dealerId: dealer.id },
        });
        if (existing) {
            return NextResponse.json(
                { error: 'This user is already a member of this dealer account' },
                { status: 409 }
            );
        }

        // Create Supabase Auth user with portal_role: 'dealer'
        const { user: authUser, tempPassword } = await createPortalUser(
            email.trim().toLowerCase(),
            'dealer',
            { dealerId: dealer.id, dealerSlug: dealer.slug ?? '' }
        );

        // Create DealerUser row, linked to the new Supabase Auth user
        const user = await prisma.dealerUser.create({
            data: {
                dealerId: dealer.id,
                email: authUser.email,
                role: role || 'member',
                userId: authUser.id,
            },
        });

        return NextResponse.json({ user, tempPassword }, { status: 201 });
    } catch (error: any) {
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}

export async function DELETE(req: NextRequest, { params }: { params: { slug: string } }) {
    try {
        const dealer = await getDealer(params.slug);
        if (!dealer) return NextResponse.json({ error: 'Dealer not found' }, { status: 404 });

        const { searchParams } = new URL(req.url);
        const dealerUserId = searchParams.get('userId');
        if (!dealerUserId) return NextResponse.json({ error: 'userId required' }, { status: 400 });

        // Fetch the record first so we can get the Supabase UUID
        const dealerUser = await prisma.dealerUser.findFirst({
            where: { id: dealerUserId, dealerId: dealer.id },
        });

        if (dealerUser) {
            // Delete from Supabase Auth if the account exists
            if (dealerUser.userId) {
                try {
                    const supabase = createServiceClient();
                    await supabase.auth.admin.deleteUser(dealerUser.userId);
                } catch {
                    // Auth record may already be gone — safe to continue
                }
            }

            await prisma.dealerUser.delete({ where: { id: dealerUserId } });
        }

        return NextResponse.json({ ok: true });
    } catch (error: any) {
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}
