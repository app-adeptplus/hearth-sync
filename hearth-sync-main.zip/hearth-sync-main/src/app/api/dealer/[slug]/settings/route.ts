import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/db';
import { createServiceClient } from '@/lib/supabase';

async function getDealer(slugOrId: string) {
    return prisma.dealerAccount.findFirst({
        where: { OR: [{ slug: slugOrId }, { id: slugOrId }] },
    });
}

/**
 * Returns the set of emails belonging to HearthSync admin accounts.
 * Admins are: users with portal_role === 'admin', OR users with no portal_role
 * (legacy accounts created before the role tagging system).
 * We cache only one page since staff counts are small.
 */
async function getAdminEmails(): Promise<Set<string>> {
    try {
        const supabase = createServiceClient();
        const { data, error } = await supabase.auth.admin.listUsers({ page: 1, perPage: 200 });
        if (error) return new Set();
        const adminEmails = new Set<string>();
        for (const u of data?.users ?? []) {
            const role = u.user_metadata?.portal_role;
            if (!role || role === 'admin') {
                if (u.email) adminEmails.add(u.email.toLowerCase());
            }
        }
        return adminEmails;
    } catch {
        return new Set();
    }
}

export async function GET(req: NextRequest, { params }: { params: { slug: string } }) {
    try {
        const dealer = await getDealer(params.slug);
        if (!dealer) return NextResponse.json({ error: 'Dealer not found' }, { status: 404 });

        const [allUsers, adminEmails] = await Promise.all([
            prisma.dealerUser.findMany({
                where: { dealerId: dealer.id },
                orderBy: { createdAt: 'asc' },
            }),
            getAdminEmails(),
        ]);

        // Exclude DealerUser rows that belong to HearthSync admin accounts
        const users = allUsers.filter((u) => !adminEmails.has(u.email.toLowerCase()));

        return NextResponse.json({ dealer, users });
    } catch (error: any) {
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}

export async function PUT(req: NextRequest, { params }: { params: { slug: string } }) {
    try {
        const dealer = await getDealer(params.slug);
        if (!dealer) return NextResponse.json({ error: 'Dealer not found' }, { status: 404 });

        const body = await req.json();
        const { contactName, phone, website, address, city, state, zip } = body;

        const updated = await prisma.dealerAccount.update({
            where: { id: dealer.id },
            data: {
                contactName: contactName?.trim() || dealer.contactName,
                phone: phone?.trim() || null,
                website: website?.trim() || null,
                address: address?.trim() || null,
                city: city?.trim() || null,
                state: state?.trim() || null,
                zip: zip?.trim() || null,
            },
        });

        return NextResponse.json({ dealer: updated });
    } catch (error: any) {
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}
