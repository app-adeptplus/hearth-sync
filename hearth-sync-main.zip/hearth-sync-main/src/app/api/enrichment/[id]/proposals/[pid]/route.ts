import prisma from '@/lib/db';
import { NextRequest, NextResponse } from 'next/server';

/**
 * PATCH /api/enrichment/:id/proposals/:pid
 * Update an individual proposal's status (APPROVED | REJECTED).
 */
export async function PATCH(
    request: NextRequest,
    { params }: { params: { id: string; pid: string } }
) {
    try {
        const { status, notes } = await request.json();
        const validStatuses = ['APPROVED', 'REJECTED', 'PENDING'];
        if (!validStatuses.includes(status)) {
            return NextResponse.json({ error: `Invalid status. Must be one of: ${validStatuses.join(', ')}` }, { status: 400 });
        }

        const proposal = await prisma.enrichmentProposal.update({
            where: { id: params.pid },
            data: { status, ...(notes !== undefined ? { notes } : {}) },
        });

        return NextResponse.json(proposal);
    } catch (error: any) {
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}
