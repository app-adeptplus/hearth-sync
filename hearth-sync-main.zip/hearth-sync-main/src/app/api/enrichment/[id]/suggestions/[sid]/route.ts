import prisma from '@/lib/db';
import { NextRequest, NextResponse } from 'next/server';
import { slugify } from '@/lib/utils';

/**
 * PATCH /api/enrichment/:id/suggestions/:sid
 * Resolve a taxonomy suggestion.
 *
 * Body:
 *   { action: 'approve' }
 *     → Creates the new Category / Attribute / OptionGroup if it doesn't exist.
 *       Sets suggestion resolvedId = new record id. status = APPROVED.
 *
 *   { action: 'reassign', resolvedId: '<existing taxonomy id>' }
 *     → Maps suggestion to an existing taxonomy item.
 *       status = REASSIGNED, resolvedId = provided id.
 *
 *   { action: 'deny' }
 *     → Rejects the suggestion. status = DENIED. No taxonomy created.
 */
export async function PATCH(
    request: NextRequest,
    { params }: { params: { id: string; sid: string } }
) {
    try {
        const { action, resolvedId } = await request.json();

        const suggestion = await prisma.taxonomySuggestion.findUnique({
            where: { id: params.sid },
        });

        if (!suggestion) {
            return NextResponse.json({ error: 'Suggestion not found' }, { status: 404 });
        }

        if (action === 'deny') {
            await prisma.taxonomySuggestion.update({
                where: { id: params.sid },
                data: { status: 'DENIED' },
            });
            return NextResponse.json({ status: 'DENIED' });
        }

        if (action === 'reassign') {
            if (!resolvedId) {
                return NextResponse.json({ error: 'resolvedId is required for reassign action' }, { status: 400 });
            }
            await prisma.taxonomySuggestion.update({
                where: { id: params.sid },
                data: { status: 'REASSIGNED', resolvedId },
            });
            return NextResponse.json({ status: 'REASSIGNED', resolvedId });
        }

        if (action === 'approve') {
            const data = (suggestion.suggestedData as Record<string, any>) || {};
            let createdId: string;

            if (suggestion.type === 'CATEGORY') {
                // Find parent if specified
                let parentId: string | null = null;
                if (data.parentCategoryName) {
                    const parent = await prisma.productCategory.findFirst({
                        where: { name: { contains: data.parentCategoryName, mode: 'insensitive' } },
                        select: { id: true },
                    });
                    if (parent) parentId = parent.id;
                }
                const existing = await prisma.productCategory.findFirst({
                    where: { name: { equals: suggestion.suggestedName, mode: 'insensitive' } },
                });
                if (existing) {
                    createdId = existing.id;
                } else {
                    const created = await prisma.productCategory.create({
                        data: {
                            name: suggestion.suggestedName,
                            slug: slugify(suggestion.suggestedName),
                            ...(parentId ? { parentId } : {}),
                        },
                    });
                    createdId = created.id;
                }

            } else if (suggestion.type === 'ATTRIBUTE') {
                const existing = await prisma.productAttribute.findFirst({
                    where: { name: { equals: suggestion.suggestedName, mode: 'insensitive' } },
                });
                if (existing) {
                    createdId = existing.id;
                } else {
                    const created = await prisma.productAttribute.create({
                        data: {
                            name: suggestion.suggestedName,
                            slug: slugify(suggestion.suggestedName),
                            unit: data.unit || null,
                            dataType: data.dataType || 'text',
                        },
                    });
                    createdId = created.id;
                }

            } else if (suggestion.type === 'OPTION_GROUP') {
                const existing = await prisma.optionGroup.findFirst({
                    where: { name: { equals: suggestion.suggestedName, mode: 'insensitive' } },
                });
                if (existing) {
                    createdId = existing.id;
                } else {
                    const options: { label: string; value: string }[] = (data.options || []).map((o: string) => ({
                        label: o,
                        value: slugify(o),
                    }));
                    const created = await prisma.optionGroup.create({
                        data: {
                            name: suggestion.suggestedName,
                            slug: slugify(suggestion.suggestedName),
                            options: { create: options },
                        },
                    });
                    createdId = created.id;
                }

            } else {
                return NextResponse.json({ error: `Unknown suggestion type: ${suggestion.type}` }, { status: 400 });
            }

            await prisma.taxonomySuggestion.update({
                where: { id: params.sid },
                data: { status: 'APPROVED', resolvedId: createdId },
            });

            return NextResponse.json({ status: 'APPROVED', resolvedId: createdId });
        }

        return NextResponse.json({ error: 'Invalid action. Use approve, reassign, or deny.' }, { status: 400 });

    } catch (error: any) {
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}
