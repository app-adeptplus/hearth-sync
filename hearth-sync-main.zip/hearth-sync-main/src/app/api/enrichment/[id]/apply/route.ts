import prisma from '@/lib/db';
import { NextRequest, NextResponse } from 'next/server';
import { slugify } from '@/lib/utils';

/**
 * POST /api/enrichment/:id/apply
 *
 * Applies all APPROVED proposals to their product records.
 * For each proposal:
 *   - Normalizes name, modelNumber, sku
 *   - Connects approved category IDs
 *   - Upserts ProductAttributeValue records
 *   - Connects option groups
 *   - Handles SKU collision: if the generated SKU already exists on a different product,
 *     checks whether it's a true duplicate or the same product being updated.
 *
 * Marks proposals as APPLIED and job as APPLIED when all done.
 */
export async function POST(
    _request: NextRequest,
    { params }: { params: { id: string } }
) {
    try {
        const job = await prisma.enrichmentJob.findUnique({
            where: { id: params.id },
            include: {
                proposals: { where: { status: 'APPROVED' } },
                suggestions: { where: { status: { not: 'PENDING' } } },
            },
        });

        if (!job) {
            return NextResponse.json({ error: 'Enrichment job not found' }, { status: 404 });
        }

        if (job.proposals.length === 0) {
            return NextResponse.json({ error: 'No approved proposals to apply.' }, { status: 400 });
        }

        // Build a resolved suggestion map (suggestedName → resolvedId)
        const resolvedSuggestions = new Map<string, string>();
        for (const s of job.suggestions) {
            if (s.status === 'APPROVED' && s.resolvedId) {
                resolvedSuggestions.set(s.suggestedName, s.resolvedId);
            } else if (s.status === 'REASSIGNED' && s.resolvedId) {
                resolvedSuggestions.set(s.suggestedName, s.resolvedId);
            }
        }

        const results = { applied: 0, skipped: 0, errors: [] as string[] };

        for (const proposal of job.proposals) {
            try {
                const proposed = proposal.proposedData as any;
                const productId = proposal.productId;

                if (!productId) {
                    results.skipped++;
                    continue;
                }

                // SKU collision detection
                const generatedSku = proposed.sku;
                if (generatedSku) {
                    const skuOwner = await prisma.product.findUnique({
                        where: { sku: generatedSku },
                        select: { id: true, name: true },
                    });
                    if (skuOwner && skuOwner.id !== productId) {
                        // Different product owns this SKU — this is a collision
                        // Check if the names match closely (same product, different record)
                        const existingProduct = await prisma.product.findUnique({
                            where: { id: productId },
                            select: { name: true, brandId: true },
                        });
                        const nameSimilar = existingProduct && (
                            skuOwner.name.toLowerCase().includes(existingProduct.name.toLowerCase().slice(0, 10)) ||
                            existingProduct.name.toLowerCase().includes(skuOwner.name.toLowerCase().slice(0, 10))
                        );
                        if (nameSimilar) {
                            // Merge into the existing SKU owner instead of creating a collision
                            results.errors.push(`SKU collision: "${generatedSku}" already owned by Product "${skuOwner.name}" (ID: ${skuOwner.id}). Skipping SKU update for "${proposed.name}".`);
                            // Continue but skip SKU field
                            proposed.sku = null;
                        } else {
                            // True different product — append suffix to avoid collision
                            proposed.sku = `${generatedSku}-2`;
                        }
                    }
                }

                // Apply to product
                await prisma.product.update({
                    where: { id: productId },
                    data: {
                        name: proposed.name,
                        slug: slugify(proposed.name),
                        modelNumber: proposed.modelNumber,
                        ...(proposed.sku ? { sku: proposed.sku } : {}),
                        ...(proposed.description ? { description: proposed.description } : {}),
                        ...(proposed.categoryIds?.length > 0 ? {
                            categories: { connect: (proposed.categoryIds as string[]).map((id: string) => ({ id })) },
                        } : {}),
                        ...(proposed.optionGroupIds?.length > 0 ? {
                            optionGroups: {
                                connectOrCreate: (proposed.optionGroupIds as string[]).map((gId: string) => ({
                                    where: { productId_groupId: { productId, groupId: gId } },
                                    create: { groupId: gId },
                                })),
                            },
                        } : {}),
                    },
                });

                // Upsert attribute values
                if (proposed.attributeValues?.length > 0) {
                    for (const av of proposed.attributeValues as any[]) {
                        await prisma.productAttributeValue.upsert({
                            where: { productId_attributeId: { productId, attributeId: av.attributeId } },
                            create: { productId, attributeId: av.attributeId, value: String(av.value) },
                            update: { value: String(av.value) },
                        });
                    }
                }

                // Mark proposal as applied
                await prisma.enrichmentProposal.update({
                    where: { id: proposal.id },
                    data: { status: 'APPLIED' },
                });

                results.applied++;

            } catch (err: any) {
                results.errors.push(`Proposal ${proposal.id}: ${err.message}`);
            }
        }

        // Mark job as APPLIED if all proposals are handled
        const remaining = await prisma.enrichmentProposal.count({
            where: { jobId: job.id, status: { in: ['PENDING', 'APPROVED'] } },
        });
        if (remaining === 0) {
            await prisma.enrichmentJob.update({
                where: { id: job.id },
                data: { status: 'APPLIED' },
            });
        }

        return NextResponse.json({ ...results, remaining });

    } catch (error: any) {
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}
