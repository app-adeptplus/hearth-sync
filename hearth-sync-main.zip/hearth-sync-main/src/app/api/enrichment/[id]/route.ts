import prisma from '@/lib/db';
import { NextRequest, NextResponse } from 'next/server';

/**
 * GET /api/enrichment/:id
 * Returns job status + all proposals and taxonomy suggestions.
 */
export async function GET(
    _request: NextRequest,
    { params }: { params: { id: string } }
) {
    try {
        const job = await prisma.enrichmentJob.findUnique({
            where: { id: params.id },
            include: {
                proposals: {
                    include: {
                        product: {
                            select: { id: true, name: true, sku: true, modelNumber: true },
                        },
                    },
                    orderBy: { createdAt: 'asc' },
                },
                suggestions: { orderBy: { createdAt: 'asc' } },
            },
        });

        if (!job) {
            return NextResponse.json({ error: 'Enrichment job not found' }, { status: 404 });
        }

        return NextResponse.json(job);
    } catch (error: any) {
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}

/**
 * PATCH /api/enrichment/:id
 * Update job status manually (e.g. cancel, reset to PENDING_REVIEW).
 */
export async function PATCH(
    request: NextRequest,
    { params }: { params: { id: string } }
) {
    try {
        const { status } = await request.json();
        const job = await prisma.enrichmentJob.update({
            where: { id: params.id },
            data: { status },
        });
        return NextResponse.json(job);
    } catch (error: any) {
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}
