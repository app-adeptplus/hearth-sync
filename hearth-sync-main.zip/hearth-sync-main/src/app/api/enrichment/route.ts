import prisma from '@/lib/db';
import { NextRequest, NextResponse } from 'next/server';
import { enrichProduct, EnrichmentContext } from '@/lib/enrichment-agent';

/**
 * GET /api/enrichment
 * List all enrichment jobs, most recent first.
 */
export async function GET() {
    try {
        const jobs = await prisma.enrichmentJob.findMany({
            orderBy: { createdAt: 'desc' },
            include: {
                _count: { select: { proposals: true, suggestions: true } },
            },
        });
        return NextResponse.json(jobs);
    } catch (error: any) {
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}

/**
 * POST /api/enrichment
 * Create an enrichment job and immediately kick off processing.
 *
 * Body: {
 *   name: string,
 *   sourceType: 'PRODUCT_QUERY' | 'DATA_PACKAGE' | 'MANUAL_LIST',
 *   sourceFilter: { brandId?, productIds?, packageId? }
 * }
 */
export async function POST(request: NextRequest) {
    try {
        const body = await request.json();
        const { name, sourceType, sourceFilter } = body;

        if (!name || !sourceType) {
            return NextResponse.json({ error: 'name and sourceType are required' }, { status: 400 });
        }

        // Resolve target products
        const productIds = await resolveProductIds(sourceType, sourceFilter || {});
        if (productIds.length === 0) {
            return NextResponse.json({ error: 'No products found matching the source filter.' }, { status: 400 });
        }

        // Create the job
        const job = await prisma.enrichmentJob.create({
            data: {
                name,
                status: 'RUNNING',
                sourceType,
                sourceFilter: sourceFilter || {},
                totalProducts: productIds.length,
            },
        });

        // Run asynchronously (fire-and-forget; Next.js 14 waitUntil not needed for admin tools)
        runEnrichmentJob(job.id, productIds).catch(err => {
            console.error(`[EnrichmentJob ${job.id}] Fatal error:`, err);
        });

        return NextResponse.json({ id: job.id, totalProducts: productIds.length });
    } catch (error: any) {
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

async function resolveProductIds(
    sourceType: string,
    sourceFilter: Record<string, any>
): Promise<string[]> {
    if (sourceType === 'MANUAL_LIST' && Array.isArray(sourceFilter.productIds)) {
        return sourceFilter.productIds;
    }

    if (sourceType === 'DATA_PACKAGE' && sourceFilter.packageId) {
        const pkg = await prisma.dataPackage.findUnique({
            where: { id: sourceFilter.packageId },
            include: { items: { where: { productId: { not: null } }, select: { productId: true } } },
        });
        if (!pkg) return [];
        return pkg.items.map((i: any) => i.productId as string).filter(Boolean);
    }

    // PRODUCT_QUERY — filter by brand, category, etc.
    const where: Record<string, any> = {};
    if (sourceFilter.brandId) where.brandId = sourceFilter.brandId;
    if (sourceFilter.categoryId) where.categories = { some: { id: sourceFilter.categoryId } };
    if (Array.isArray(sourceFilter.productIds) && sourceFilter.productIds.length > 0) {
        where.id = { in: sourceFilter.productIds };
    }

    const products = await prisma.product.findMany({
        where,
        select: { id: true },
        take: 200, // safety cap
    });
    return products.map(p => p.id);
}

async function runEnrichmentJob(jobId: string, productIds: string[]) {
    console.log(`[EnrichmentJob ${jobId}] Starting with ${productIds.length} products`);

    // Load context once — brand will differ per product, but categories/attributes/optionGroups are global
    const [allCategories, allAttributes, allOptionGroups] = await Promise.all([
        prisma.productCategory.findMany({
            select: { id: true, name: true, slug: true, parentId: true, likeTerms: true },
        }),
        prisma.productAttribute.findMany({
            select: { id: true, name: true, slug: true, unit: true, dataType: true, options: true },
        }),
        prisma.optionGroup.findMany({
            select: { id: true, name: true, slug: true, options: { select: { id: true, label: true, value: true } } },
        }),
    ]);

    let processedCount = 0;
    let errorCount = 0;
    const logs: string[] = [];

    for (const productId of productIds) {
        try {
            const product = await prisma.product.findUnique({
                where: { id: productId },
                include: {
                    brand: { select: { id: true, name: true, brandSku: true } },
                    categories: { select: { id: true, name: true } },
                    attributeValues: {
                        select: { attributeId: true, value: true },
                    },
                },
            });

            if (!product) {
                logs.push(`[SKIP] Product ${productId} not found`);
                errorCount++;
                continue;
            }

            const context: EnrichmentContext = {
                brand: product.brand,
                categories: allCategories,
                attributes: allAttributes,
                optionGroups: allOptionGroups,
            };

            const originalData = {
                name: product.name,
                modelNumber: product.modelNumber,
                sku: product.sku,
                categoryIds: product.categories.map((c: any) => c.id),
                attributeValues: product.attributeValues,
            };

            const { proposedData, confidence, notes } = await enrichProduct(
                {
                    id: product.id,
                    name: product.name,
                    modelNumber: product.modelNumber,
                    sku: product.sku,
                    description: product.description,
                    categories: product.categories,
                    attributeValues: product.attributeValues.map((av: any) => ({
                        attributeId: av.attributeId,
                        value: av.value,
                    })),
                },
                context
            );

            // Create taxonomy suggestions first
            const suggestionRefs: string[] = [];
            for (const s of proposedData.suggestedNewCategories) {
                const suggestion = await prisma.taxonomySuggestion.create({
                    data: {
                        jobId,
                        type: 'CATEGORY',
                        suggestedName: s.name,
                        suggestedData: { parentCategoryName: s.parentCategoryName },
                        usedByProposalIds: [], // updated after proposal creation
                    },
                });
                suggestionRefs.push(suggestion.id);
            }
            for (const s of proposedData.suggestedNewAttributes) {
                const suggestion = await prisma.taxonomySuggestion.create({
                    data: {
                        jobId,
                        type: 'ATTRIBUTE',
                        suggestedName: s.name,
                        suggestedData: { unit: s.unit, dataType: s.dataType, reason: s.reason },
                        usedByProposalIds: [],
                    },
                });
                suggestionRefs.push(suggestion.id);
            }
            for (const s of proposedData.suggestedNewOptionGroups) {
                const suggestion = await prisma.taxonomySuggestion.create({
                    data: {
                        jobId,
                        type: 'OPTION_GROUP',
                        suggestedName: s.name,
                        suggestedData: { options: s.options, reason: s.reason },
                        usedByProposalIds: [],
                    },
                });
                suggestionRefs.push(suggestion.id);
            }

            // Create the proposal
            await prisma.enrichmentProposal.create({
                data: {
                    jobId,
                    productId: product.id,
                    status: 'PENDING',
                    proposedData: proposedData as any,
                    originalData: originalData as any,
                    confidence,
                    notes,
                },
            });

            processedCount++;
            logs.push(`[OK] ${product.name} → ${proposedData.name} (conf: ${confidence})`);

        } catch (err: any) {
            errorCount++;
            logs.push(`[ERROR] Product ${productId}: ${err.message}`);
            console.error(`[EnrichmentJob ${jobId}] Product ${productId} error:`, err);
        }

        // Update progress every 5 products
        if (processedCount % 5 === 0) {
            await prisma.enrichmentJob.update({
                where: { id: jobId },
                data: { processedCount, errorCount },
            });
        }

        // Rate limit
        await new Promise(r => setTimeout(r, 300));
    }

    // Finalize job
    await prisma.enrichmentJob.update({
        where: { id: jobId },
        data: {
            status: 'AWAITING_REVIEW',
            processedCount,
            errorCount,
            rawLog: logs.join('\n'),
        },
    });

    console.log(`[EnrichmentJob ${jobId}] Complete: ${processedCount} processed, ${errorCount} errors`);
}
