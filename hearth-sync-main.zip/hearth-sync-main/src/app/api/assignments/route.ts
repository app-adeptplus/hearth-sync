import prisma from '@/lib/db';
import { NextRequest, NextResponse } from 'next/server';
import { AssignmentServiceType } from '@prisma/client';

// GET /api/assignments?serviceType=CHAT_BOT&serviceId=categorization
export async function GET(request: NextRequest) {
    try {
        const { searchParams } = new URL(request.url);
        const serviceType = searchParams.get('serviceType') as AssignmentServiceType | null;
        const serviceId = searchParams.get('serviceId'); // optional

        const assignments = await prisma.promptAssignment.findMany({
            where: {
                ...(serviceType ? { serviceType } : {}),
                ...(serviceId !== null ? { serviceId } : {}),
            },
            include: {
                promptTemplate: { select: { id: true, name: true, category: true } },
                llmConfig: { select: { id: true, displayName: true, provider: true, model: true } },
                objectScopes: true,
                mcpLinks: { include: { mcpServer: { select: { id: true, name: true, transportType: true } } } },
            },
            orderBy: [{ serviceType: 'asc' }, { createdAt: 'desc' }],
        });

        return NextResponse.json(assignments);
    } catch (error: any) {
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}

// POST /api/assignments — create a new assignment with optional scopes and MCP links
export async function POST(request: NextRequest) {
    try {
        const body = await request.json();
        const {
            label, serviceType, serviceId, promptTemplateId,
            llmConfigId, notes, isActive,
            objectScopes = [],  // [{ entity, canRead, canWrite }]
            mcpServerIds = [],  // string[]
        } = body;

        if (!label || !serviceType || !llmConfigId) {
            return NextResponse.json(
                { error: 'label, serviceType, and llmConfigId are required' },
                { status: 400 }
            );
        }

        const assignment = await prisma.promptAssignment.create({
            data: {
                label,
                serviceType,
                serviceId: serviceId || null,
                promptTemplateId: promptTemplateId || null,
                llmConfigId,
                notes: notes || null,
                isActive: isActive ?? true,
                objectScopes: {
                    create: objectScopes.map((s: any) => ({
                        entity: s.entity,
                        canRead: s.canRead ?? true,
                        canWrite: s.canWrite ?? false,
                    })),
                },
                mcpLinks: {
                    create: mcpServerIds.map((id: string) => ({ mcpServerId: id })),
                },
            },
            include: {
                promptTemplate: { select: { id: true, name: true } },
                llmConfig: { select: { id: true, displayName: true, provider: true, model: true } },
                objectScopes: true,
                mcpLinks: { include: { mcpServer: { select: { id: true, name: true } } } },
            },
        });

        return NextResponse.json(assignment, { status: 201 });
    } catch (error: any) {
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}
