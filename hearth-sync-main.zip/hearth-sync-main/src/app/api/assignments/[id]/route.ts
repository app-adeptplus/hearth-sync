import prisma from '@/lib/db';
import { NextRequest, NextResponse } from 'next/server';

// GET /api/assignments/[id]
export async function GET(
    _req: NextRequest,
    { params }: { params: { id: string } }
) {
    try {
        const assignment = await prisma.promptAssignment.findUnique({
            where: { id: params.id },
            include: {
                promptTemplate: { select: { id: true, name: true, category: true } },
                llmConfig: { select: { id: true, displayName: true, provider: true, model: true } },
                objectScopes: true,
                mcpLinks: { include: { mcpServer: { select: { id: true, name: true, transportType: true } } } },
            },
        });
        if (!assignment) return NextResponse.json({ error: 'Not found' }, { status: 404 });
        return NextResponse.json(assignment);
    } catch (error: any) {
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}

// PATCH /api/assignments/[id]
export async function PATCH(
    request: NextRequest,
    { params }: { params: { id: string } }
) {
    try {
        const body = await request.json();
        const {
            label, serviceType, serviceId, promptTemplateId,
            llmConfigId, notes, isActive,
            objectScopes, // if provided, replaces all scopes
            mcpServerIds, // if provided, replaces all mcp links
        } = body;

        const data: any = {};
        if (label !== undefined) data.label = label;
        if (serviceType !== undefined) data.serviceType = serviceType;
        if (serviceId !== undefined) data.serviceId = serviceId || null;
        if (promptTemplateId !== undefined) data.promptTemplateId = promptTemplateId || null;
        if (llmConfigId !== undefined) data.llmConfigId = llmConfigId;
        if (notes !== undefined) data.notes = notes || null;
        if (isActive !== undefined) data.isActive = isActive;

        // Replace object scopes if provided
        if (Array.isArray(objectScopes)) {
            await prisma.assignmentObjectScope.deleteMany({ where: { assignmentId: params.id } });
            data.objectScopes = {
                create: objectScopes.map((s: any) => ({
                    entity: s.entity,
                    canRead: s.canRead ?? true,
                    canWrite: s.canWrite ?? false,
                })),
            };
        }

        // Replace MCP links if provided
        if (Array.isArray(mcpServerIds)) {
            await prisma.assignmentMcpLink.deleteMany({ where: { assignmentId: params.id } });
            data.mcpLinks = {
                create: mcpServerIds.map((id: string) => ({ mcpServerId: id })),
            };
        }

        const updated = await prisma.promptAssignment.update({
            where: { id: params.id },
            data,
            include: {
                promptTemplate: { select: { id: true, name: true } },
                llmConfig: { select: { id: true, displayName: true, provider: true, model: true } },
                objectScopes: true,
                mcpLinks: { include: { mcpServer: { select: { id: true, name: true } } } },
            },
        });

        return NextResponse.json(updated);
    } catch (error: any) {
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}

// DELETE /api/assignments/[id]
export async function DELETE(
    _req: NextRequest,
    { params }: { params: { id: string } }
) {
    try {
        await prisma.promptAssignment.delete({ where: { id: params.id } });
        return NextResponse.json({ success: true });
    } catch (error: any) {
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}
