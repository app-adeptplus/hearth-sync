import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/db';

export async function DELETE(_request: NextRequest, { params }: { params: { id: string } }) {
    try {
        await prisma.manufacturer.delete({ where: { id: params.id } });
        return NextResponse.json({ success: true });
    } catch (error: any) {
        console.error('Failed to delete manufacturer:', error);
        return NextResponse.json(
            { error: error.message || 'Failed to delete manufacturer' },
            { status: 500 }
        );
    }
}

export async function PATCH(request: NextRequest, { params }: { params: { id: string } }) {
    try {
        const body = await request.json();
        const { name, website, country, description, logoUrl, prefix } = body;

        const data: any = {};
        if (name !== undefined) data.name = name;
        if (website !== undefined) data.website = website;
        if (country !== undefined) data.country = country;
        if (description !== undefined) data.description = description;
        if (logoUrl !== undefined) data.logoUrl = logoUrl;
        if (prefix !== undefined) data.prefix = prefix;

        const manufacturer = await prisma.manufacturer.update({
            where: { id: params.id },
            data,
        });

        return NextResponse.json({ data: manufacturer });
    } catch (error: any) {
        console.error('Failed to update manufacturer:', error);
        return NextResponse.json({ error: error.message || 'Failed to update manufacturer' }, { status: 500 });
    }
}
