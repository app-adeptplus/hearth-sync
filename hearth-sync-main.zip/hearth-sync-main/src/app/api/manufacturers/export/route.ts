import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/db';

export async function GET(request: NextRequest) {
    const { searchParams } = new URL(request.url);
    const mode = searchParams.get('mode') || 'manufacturers';

    try {
        const manufacturers = await prisma.manufacturer.findMany({
            orderBy: { name: 'asc' },
            include: {
                integrations: true,
                ...(mode === 'all' ? { brands: { orderBy: { name: 'asc' } } } : {}),
            },
        });

        if (mode === 'manufacturers') {
            // Flat CSV — one row per manufacturer
            const headers = ['Name', 'Prefix', 'Website', 'Country', 'Status', 'Method', 'Estimated Products', 'Created At'];
            const rows = manufacturers.map((m: any) => {
                const integration = m.integrations[0];
                return [
                    m.name,
                    m.prefix ?? '',
                    m.website ?? '',
                    m.country ?? '',
                    integration?.status ?? '',
                    integration?.integrationMethod ?? '',
                    integration?.estimatedProducts ?? '',
                    m.createdAt.toISOString(),
                ];
            });
            const csv = [headers, ...rows].map(r => r.map((v: any) => `"${String(v).replace(/"/g, '""')}"`).join(',')).join('\n');
            return new NextResponse(csv, {
                headers: {
                    'Content-Type': 'text/csv',
                    'Content-Disposition': 'attachment; filename="manufacturers.csv"',
                },
            });
        }

        // mode === 'all' — one row per brand, with manufacturer info repeated
        const headers = ['Manufacturer', 'Manufacturer Prefix', 'Brand Name', 'Brand SKU', 'Brand Website', 'Brand Active', 'Mfr Status', 'Mfr Method', 'Mfr Website', 'Mfr Country'];
        const rows: string[][] = [];
        for (const m of manufacturers as any[]) {
            if (!m.brands || m.brands.length === 0) {
                const integration = m.integrations[0];
                rows.push([m.name, m.prefix ?? '', '', '', '', '', integration?.status ?? '', integration?.integrationMethod ?? '', m.website ?? '', m.country ?? '']);
            } else {
                for (const b of m.brands) {
                    const integration = m.integrations[0];
                    rows.push([m.name, m.prefix ?? '', b.name, b.brandSku ?? '', b.website ?? '', b.isActive ? 'Yes' : 'No', integration?.status ?? '', integration?.integrationMethod ?? '', m.website ?? '', m.country ?? '']);
                }
            }
        }
        const csv = [headers, ...rows].map(r => r.map(v => `"${String(v).replace(/"/g, '""')}"`).join(',')).join('\n');
        return new NextResponse(csv, {
            headers: {
                'Content-Type': 'text/csv',
                'Content-Disposition': 'attachment; filename="manufacturers-all.csv"',
            },
        });
    } catch (error: any) {
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}
