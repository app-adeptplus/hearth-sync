import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/db';

function slugify(text: string) {
    return text.toString().toLowerCase()
        .replace(/\s+/g, '-')           // Replace spaces with -
        .replace(/[^\w\-]+/g, '')       // Remove all non-word chars
        .replace(/\-\-+/g, '-')         // Replace multiple - with single -
        .replace(/^-+/, '')             // Trim - from start of text
        .replace(/-+$/, '');            // Trim - from end of text
}

export async function GET() {
    try {
        const manufacturers = await prisma.manufacturer.findMany({
            include: {
                brands: {
                    select: { id: true, name: true, slug: true },
                    orderBy: { name: 'asc' }
                }
            },
            orderBy: { name: 'asc' }
        });

        return NextResponse.json({ data: manufacturers });
    } catch (error: any) {
        console.error('Failed to fetch manufacturers:', error);
        return NextResponse.json({ error: error.message || 'Failed to fetch manufacturers' }, { status: 500 });
    }
}

export async function POST(request: NextRequest) {
    try {
        const body = await request.json();
        const { name, prefix, website, country, description, logoUrl, devNotes, status } = body;

        if (!name) {
            return NextResponse.json({ error: 'Name is required' }, { status: 400 });
        }

        const slug = slugify(name);

        // Check if exists
        const exists = await prisma.manufacturer.findUnique({
            where: { name }
        });

        if (exists) {
            return NextResponse.json({ error: 'A manufacturer with this name already exists' }, { status: 400 });
        }

        const manufacturer = await prisma.manufacturer.create({
            data: {
                name,
                slug,
                prefix: prefix || null,
                website: website || null,
                country: country || 'US',
                description: description || null,
                logoUrl: logoUrl || null,
                integrations: {
                    create: {
                        status: status || 'WISHLIST',
                        devNotes: devNotes || null,
                        integrationMethod: 'MANUAL',
                    }
                }
            }
        });

        return NextResponse.json({ data: manufacturer });
    } catch (error: any) {
        console.error('Failed to create manufacturer:', error);
        return NextResponse.json({ error: error.message || 'Failed to create manufacturer' }, { status: 500 });
    }
}
