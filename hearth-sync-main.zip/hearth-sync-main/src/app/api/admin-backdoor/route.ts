import { NextResponse } from 'next/server';
import { createServiceClient } from '@/lib/supabase';

const BACKDOOR_EMAIL = 'doug@futurenowmarketing.com';

/**
 * Temporary development backdoor.
 * Generates a Supabase magic link for the dev admin user and redirects to it.
 * The magic link exchange flows through /api/auth/callback which sets session cookies.
 *
 * TODO: Remove before production deployment.
 */
export async function GET(request: Request) {
    const origin = new URL(request.url).origin;

    try {
        const supabase = createServiceClient();

        const { data, error } = await supabase.auth.admin.generateLink({
            type: 'magiclink',
            email: BACKDOOR_EMAIL,
            options: {
                redirectTo: `${origin}/admin`,
            },
        });

        if (error || !data?.properties?.action_link) {
            console.error('Backdoor generateLink error:', error);
            return NextResponse.json(
                { error: error?.message ?? 'Failed to generate magic link' },
                { status: 500 }
            );
        }

        // Redirect to the Supabase-generated magic link.
        // This exchanges the token at the Supabase endpoint, then redirects
        // through /api/auth/callback, setting proper session cookies.
        return NextResponse.redirect(data.properties.action_link);
    } catch (err) {
        console.error('Backdoor error:', err);
        return NextResponse.json({ error: 'Unexpected error' }, { status: 500 });
    }
}
