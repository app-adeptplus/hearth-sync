import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/db';

export async function POST(request: NextRequest) {
    try {
        const body = await request.json();
        const { ids } = body as { ids: string[] };

        if (!Array.isArray(ids) || ids.length === 0) {
            return NextResponse.json({ error: 'No IDs provided' }, { status: 400 });
        }

        // Fetch all requested attributes to check for system flags
        const attributes = await prisma.productAttribute.findMany({
            where: { id: { in: ids } },
            select: { id: true, name: true, isSystem: true },
        });

        const skipped: { id: string; name: string; reason: string }[] = [];
        const toDelete: typeof attributes = [];

        for (const attr of attributes) {
            if (attr.isSystem) {
                skipped.push({ id: attr.id, name: attr.name, reason: 'System attribute' });
            } else {
                toDelete.push(attr);
            }
        }

        if (toDelete.length === 0) {
            return NextResponse.json({ deleted: 0, skipped });
        }

        const deleteIds = toDelete.map(a => a.id);

        // Cascade handles categoryMappings and productValues via schema relations
        await prisma.productAttribute.deleteMany({ where: { id: { in: deleteIds } } });

        return NextResponse.json({ deleted: toDelete.length, skipped });
    } catch (error: any) {
        console.error('Bulk delete attributes failed:', error);
        return NextResponse.json({ error: error.message || 'Bulk delete failed' }, { status: 500 });
    }
}
