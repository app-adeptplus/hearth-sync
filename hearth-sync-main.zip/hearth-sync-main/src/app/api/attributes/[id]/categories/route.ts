import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/db';

/**
 * GET /api/attributes/[id]/categories
 * Returns all current category mappings for this attribute, including allowedOptions.
 */
export async function GET(
    _request: NextRequest,
    { params }: { params: { id: string } }
) {
    try {
        const mappings = await prisma.categoryAttributeMap.findMany({
            where: { attributeId: params.id },
            include: {
                category: {
                    select: { id: true, name: true, slug: true, parentId: true }
                }
            },
            orderBy: [{ sortOrder: 'asc' }],
        });
        return NextResponse.json({ mappings });
    } catch (error) {
        console.error('GET /api/attributes/[id]/categories error:', error);
        return NextResponse.json({ error: 'Failed to fetch mappings' }, { status: 500 });
    }
}

/**
 * PUT /api/attributes/[id]/categories
 * Body: { categoryIds: string[] }
 * Replaces the full set of category mappings for this attribute.
 * Preserves existing isRequired / isFilterable / allowedOptions / sortOrder where a mapping already exists.
 */
export async function PUT(
    request: NextRequest,
    { params }: { params: { id: string } }
) {
    try {
        const body = await request.json();
        const { categoryIds } = body as { categoryIds: string[] };

        if (!Array.isArray(categoryIds)) {
            return NextResponse.json({ error: 'categoryIds must be an array' }, { status: 400 });
        }

        // Fetch existing mappings so we can preserve their flags
        const existing = await prisma.categoryAttributeMap.findMany({
            where: { attributeId: params.id },
        });
        const existingMap = Object.fromEntries(existing.map(m => [m.categoryId, m]));

        // Determine what to add and remove
        const existingIds = new Set(existing.map(m => m.categoryId));
        const newIds = new Set(categoryIds);

        const toDelete = Array.from(existingIds).filter(id => !newIds.has(id));
        const toCreate = Array.from(newIds).filter(id => !existingIds.has(id));

        await prisma.$transaction([
            // Remove mappings no longer needed
            ...toDelete.map(categoryId =>
                prisma.categoryAttributeMap.deleteMany({
                    where: { attributeId: params.id, categoryId },
                })
            ),
            // Add new mappings (with defaults; allowedOptions null = all parent options allowed)
            ...toCreate.map(categoryId =>
                prisma.categoryAttributeMap.create({
                    data: {
                        categoryId,
                        attributeId: params.id,
                        isRequired: false,
                        isFilterable: true,
                        allowedOptions: null,
                        sortOrder: 0,
                    },
                })
            ),
        ]);

        // Return fresh mappings
        const updated = await prisma.categoryAttributeMap.findMany({
            where: { attributeId: params.id },
            include: {
                category: {
                    select: { id: true, name: true, slug: true, parentId: true }
                }
            },
            orderBy: [{ sortOrder: 'asc' }],
        });

        return NextResponse.json({ mappings: updated });
    } catch (error) {
        console.error('PUT /api/attributes/[id]/categories error:', error);
        return NextResponse.json({ error: 'Failed to update category mappings' }, { status: 500 });
    }
}
