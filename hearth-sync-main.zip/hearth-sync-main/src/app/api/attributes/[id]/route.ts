import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/db';

function slugify(text: string) {
    return text.toString().toLowerCase()
        .replace(/\s+/g, '-')
        .replace(/[^\w\-]+/g, '')
        .replace(/\-\-+/g, '-')
        .replace(/^-+/, '')
        .replace(/-+$/, '');
}

export async function GET(_: NextRequest, { params }: { params: { id: string } }) {
    try {
        const attribute = await prisma.productAttribute.findUnique({
            where: { id: params.id },
            include: {
                _count: {
                    select: { categoryMappings: true, productValues: true }
                },
                categoryMappings: {
                    include: {
                        category: {
                            select: { id: true, name: true, slug: true, parentId: true }
                        }
                    },
                    orderBy: { sortOrder: 'asc' }
                }
            }
        });
        if (!attribute) return NextResponse.json({ error: 'Not found' }, { status: 404 });
        return NextResponse.json({ data: attribute });
    } catch (error: any) {
        return NextResponse.json({ error: error.message || 'Failed to fetch attribute' }, { status: 500 });
    }
}

export async function PATCH(request: NextRequest, { params }: { params: { id: string } }) {
    try {
        const body = await request.json();
        const { name, slug, description, unit, dataType, options, industry, isSystem, sortOrder } = body;

        const data: any = {};
        if (name !== undefined) {
            data.name = name;
            // Only auto-generate slug from name if no explicit slug was sent
            if (slug === undefined) data.slug = slugify(name);
        }
        if (slug !== undefined) data.slug = slug;
        if (description !== undefined) data.description = description;
        if (unit !== undefined) data.unit = unit;
        if (dataType !== undefined) data.dataType = dataType;
        if (options !== undefined) data.options = options;
        if (industry !== undefined) data.industry = industry;
        if (isSystem !== undefined) data.isSystem = isSystem;
        if (sortOrder !== undefined) data.sortOrder = sortOrder;

        const updated = await prisma.productAttribute.update({
            where: { id: params.id },
            data,
        });

        return NextResponse.json({ data: updated });
    } catch (error: any) {
        console.error('Failed to update attribute:', error);
        return NextResponse.json({ error: error.message || 'Failed to update attribute' }, { status: 500 });
    }
}

export async function DELETE(_: NextRequest, { params }: { params: { id: string } }) {
    try {
        // Check if system attribute
        const attr = await prisma.productAttribute.findUnique({
            where: { id: params.id },
            select: { isSystem: true, name: true, _count: { select: { productValues: true } } }
        });

        if (!attr) {
            return NextResponse.json({ error: 'Attribute not found' }, { status: 404 });
        }

        if (attr.isSystem) {
            return NextResponse.json({
                error: `"${attr.name}" is a system-managed attribute and cannot be deleted.`,
                code: 'SYSTEM_ATTRIBUTE'
            }, { status: 409 });
        }

        // Delete cascades through the schema (categoryMappings and productValues)
        await prisma.productAttribute.delete({ where: { id: params.id } });
        return NextResponse.json({ success: true });
    } catch (error: any) {
        console.error('Failed to delete attribute:', error);
        return NextResponse.json({ error: error.message || 'Failed to delete attribute' }, { status: 500 });
    }
}
