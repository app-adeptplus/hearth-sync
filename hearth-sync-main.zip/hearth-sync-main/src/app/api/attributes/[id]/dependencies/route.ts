import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/db';

/**
 * GET /api/attributes/[id]/dependencies
 * Returns all AttributeDependency rows where this attribute is the parent trigger.
 * Each row includes full child attribute details so the UI can render them.
 */
export async function GET(
    _request: NextRequest,
    { params }: { params: { id: string } }
) {
    try {
        const dependencies = await prisma.attributeDependency.findMany({
            where: { parentAttributeId: params.id },
            include: {
                childAttribute: {
                    select: {
                        id: true,
                        name: true,
                        slug: true,
                        dataType: true,
                        options: true,
                        unit: true,
                    }
                }
            },
            orderBy: [{ triggerValue: 'asc' }, { sortOrder: 'asc' }],
        });
        return NextResponse.json({ dependencies });
    } catch (error) {
        console.error('GET /api/attributes/[id]/dependencies error:', error);
        return NextResponse.json({ error: 'Failed to fetch dependencies' }, { status: 500 });
    }
}

/**
 * POST /api/attributes/[id]/dependencies
 * Body: { triggerValue: string, childAttributeId: string }
 * Create a new dependency rule: when this attribute = triggerValue, show childAttribute.
 */
export async function POST(
    request: NextRequest,
    { params }: { params: { id: string } }
) {
    try {
        const body = await request.json();
        const { triggerValue, childAttributeId } = body as {
            triggerValue: string;
            childAttributeId: string;
        };

        if (!triggerValue || !childAttributeId) {
            return NextResponse.json(
                { error: 'triggerValue and childAttributeId are required' },
                { status: 400 }
            );
        }

        if (childAttributeId === params.id) {
            return NextResponse.json(
                { error: 'An attribute cannot be a child of itself' },
                { status: 400 }
            );
        }

        const dependency = await prisma.attributeDependency.create({
            data: {
                parentAttributeId: params.id,
                triggerValue: triggerValue.trim(),
                childAttributeId,
                sortOrder: 0,
            },
            include: {
                childAttribute: {
                    select: {
                        id: true,
                        name: true,
                        slug: true,
                        dataType: true,
                        options: true,
                        unit: true,
                    }
                }
            },
        });

        return NextResponse.json({ dependency }, { status: 201 });
    } catch (error: any) {
        if (error.code === 'P2002') {
            return NextResponse.json(
                { error: 'This dependency rule already exists' },
                { status: 409 }
            );
        }
        console.error('POST /api/attributes/[id]/dependencies error:', error);
        return NextResponse.json({ error: 'Failed to create dependency' }, { status: 500 });
    }
}

/**
 * DELETE /api/attributes/[id]/dependencies
 * Body: { dependencyId: string }
 * Remove a single dependency rule by its ID.
 */
export async function DELETE(
    request: NextRequest,
    { params }: { params: { id: string } }
) {
    try {
        const body = await request.json();
        const { dependencyId } = body as { dependencyId: string };

        if (!dependencyId) {
            return NextResponse.json({ error: 'dependencyId is required' }, { status: 400 });
        }

        await prisma.attributeDependency.deleteMany({
            where: { id: dependencyId, parentAttributeId: params.id },
        });

        return NextResponse.json({ success: true });
    } catch (error) {
        console.error('DELETE /api/attributes/[id]/dependencies error:', error);
        return NextResponse.json({ error: 'Failed to delete dependency' }, { status: 500 });
    }
}
