import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/db';

function slugify(text: string) {
    return text.toString().toLowerCase()
        .replace(/\s+/g, '-')
        .replace(/[^\w\-]+/g, '')
        .replace(/\-\-+/g, '-')
        .replace(/^-+/, '')
        .replace(/-+$/, '');
}

export async function GET() {
    try {
        const attributes = await prisma.productAttribute.findMany({
            orderBy: [{ sortOrder: 'asc' }, { name: 'asc' }],
            include: {
                _count: {
                    select: {
                        categoryMappings: true,
                        productValues: true,
                    }
                },
                categoryMappings: {
                    include: {
                        category: {
                            select: { id: true, name: true, slug: true, parentId: true }
                        }
                    },
                    orderBy: { sortOrder: 'asc' }
                }
            }
        });
        return NextResponse.json({ data: attributes });
    } catch (error: any) {
        return NextResponse.json({ error: error.message || 'Failed to fetch attributes' }, { status: 500 });
    }
}

export async function POST(request: NextRequest) {
    try {
        const body = await request.json();
        const { name, description, unit, dataType, options, industry, isSystem, sortOrder } = body;

        if (!name) {
            return NextResponse.json({ error: 'Name is required' }, { status: 400 });
        }

        const slug = slugify(name);

        const attribute = await prisma.productAttribute.create({
            data: {
                name,
                slug,
                description: description || null,
                unit: unit || null,
                dataType: dataType || 'text',
                options: options || null,
                industry: industry || null,
                isSystem: isSystem ?? false,
                sortOrder: sortOrder ?? 0,
            },
        });

        return NextResponse.json({ data: attribute });
    } catch (error: any) {
        console.error('Failed to create attribute:', error);
        return NextResponse.json({ error: error.message || 'Failed to create attribute' }, { status: 500 });
    }
}
