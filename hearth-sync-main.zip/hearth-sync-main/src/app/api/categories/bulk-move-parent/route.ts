import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/db';

export async function POST(request: NextRequest) {
    try {
        const body = await request.json();
        const { ids, parentId } = body as { ids: string[]; parentId: string | null };

        if (!Array.isArray(ids) || ids.length === 0) {
            return NextResponse.json({ error: 'No IDs provided' }, { status: 400 });
        }

        // If setting a parentId, verify the target exists and is itself a top-level category
        // (sub-categories cannot have further children in this data model)
        if (parentId) {
            const targetParent = await prisma.productCategory.findUnique({
                where: { id: parentId },
                select: { id: true, name: true, parentId: true },
            });
            if (!targetParent) {
                return NextResponse.json({ error: 'Target parent category not found' }, { status: 404 });
            }
            if (targetParent.parentId) {
                return NextResponse.json({
                    error: `"${targetParent.name}" is already a sub-category and cannot be used as a parent.`,
                    code: 'INVALID_PARENT',
                }, { status: 409 });
            }
        }

        // Bulk update the parentId for all requested categories
        await prisma.productCategory.updateMany({
            where: { id: { in: ids } },
            data: { parentId: parentId ?? null },
        });

        return NextResponse.json({ updated: ids.length });
    } catch (error: any) {
        console.error('Bulk move parent failed:', error);
        return NextResponse.json({ error: error.message || 'Bulk move failed' }, { status: 500 });
    }
}
