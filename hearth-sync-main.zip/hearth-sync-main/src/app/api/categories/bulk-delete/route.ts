import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/db';

export async function POST(request: NextRequest) {
    try {
        const body = await request.json();
        const { ids } = body as { ids: string[] };

        if (!Array.isArray(ids) || ids.length === 0) {
            return NextResponse.json({ error: 'No IDs provided' }, { status: 400 });
        }

        // Fetch all requested categories with relationship counts
        const categories = await prisma.productCategory.findMany({
            where: { id: { in: ids } },
            include: {
                _count: { select: { children: true, products: true, scraperConfigs: true } },
            },
        });

        const skipped: { id: string; name: string; reason: string }[] = [];
        const toDelete: typeof categories = [];

        for (const cat of categories) {
            if (cat._count.children > 0) {
                skipped.push({
                    id: cat.id,
                    name: cat.name,
                    reason: `Has ${cat._count.children} sub-categor${cat._count.children === 1 ? 'y' : 'ies'}`,
                });
            } else {
                toDelete.push(cat);
            }
        }

        if (toDelete.length === 0) {
            return NextResponse.json({ deleted: 0, skipped });
        }

        const deleteIds = toDelete.map(c => c.id);

        await prisma.$transaction(async (tx) => {
            // Disconnect products from each category being deleted
            const withProducts = toDelete.filter(c => c._count.products > 0);
            for (const cat of withProducts) {
                await tx.productCategory.update({
                    where: { id: cat.id },
                    data: { products: { set: [] } },
                });
            }

            // Disconnect scraper configs
            const withScrapers = toDelete.filter(c => c._count.scraperConfigs > 0);
            for (const cat of withScrapers) {
                await tx.productCategory.update({
                    where: { id: cat.id },
                    data: { scraperConfigs: { set: [] } },
                });
            }

            // Delete all in one go
            await tx.productCategory.deleteMany({ where: { id: { in: deleteIds } } });
        }, { timeout: 30000 });

        return NextResponse.json({ deleted: toDelete.length, skipped });
    } catch (error: any) {
        console.error('Bulk delete categories failed:', error);
        return NextResponse.json({ error: error.message || 'Bulk delete failed' }, { status: 500 });
    }
}
