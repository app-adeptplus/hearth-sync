import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/db';

// GET - fetch all attributes mapped to a specific category
export async function GET(_: NextRequest, { params }: { params: { id: string } }) {
    try {
        const mappings = await prisma.categoryAttributeMap.findMany({
            where: { categoryId: params.id },
            orderBy: [{ sortOrder: 'asc' }, { attribute: { name: 'asc' } }],
            include: {
                attribute: {
                    select: {
                        id: true,
                        name: true,
                        slug: true,
                        dataType: true,
                        unit: true,
                        options: true,
                        description: true,
                        isSystem: true,
                    }
                }
            }
        });

        return NextResponse.json({ data: mappings });
    } catch (error: any) {
        return NextResponse.json({ error: error.message || 'Failed to fetch category attributes' }, { status: 500 });
    }
}

// POST - map an attribute to a category (also handles flag/allowedOptions updates via upsert)
export async function POST(request: NextRequest, { params }: { params: { id: string } }) {
    try {
        const body = await request.json();
        const { attributeId, isRequired, isFilterable, defaultValue, sortOrder, allowedOptions } = body;

        if (!attributeId) {
            return NextResponse.json({ error: 'attributeId is required' }, { status: 400 });
        }

        // Check the category exists
        const category = await prisma.productCategory.findUnique({ where: { id: params.id } });
        if (!category) {
            return NextResponse.json({ error: 'Category not found' }, { status: 404 });
        }

        // Check the attribute exists
        const attribute = await prisma.productAttribute.findUnique({ where: { id: attributeId } });
        if (!attribute) {
            return NextResponse.json({ error: 'Attribute not found' }, { status: 404 });
        }

        // Build partial update — only include fields that were explicitly sent
        const updateData: Record<string, any> = {};
        if (isRequired !== undefined) updateData.isRequired = isRequired;
        if (isFilterable !== undefined) updateData.isFilterable = isFilterable;
        if (defaultValue !== undefined) updateData.defaultValue = defaultValue || null;
        if (sortOrder !== undefined) updateData.sortOrder = sortOrder;
        // allowedOptions: null means "all allowed"; a string means comma-separated allow-list
        if ('allowedOptions' in body) updateData.allowedOptions = allowedOptions;

        const mapping = await prisma.categoryAttributeMap.upsert({
            where: {
                categoryId_attributeId: {
                    categoryId: params.id,
                    attributeId,
                }
            },
            create: {
                categoryId: params.id,
                attributeId,
                isRequired: isRequired ?? false,
                isFilterable: isFilterable ?? true,
                defaultValue: defaultValue || null,
                sortOrder: sortOrder ?? 0,
                allowedOptions: 'allowedOptions' in body ? allowedOptions : undefined,
            },
            update: updateData,
            include: {
                attribute: {
                    select: { id: true, name: true, slug: true, dataType: true, unit: true }
                }
            }
        });

        return NextResponse.json({ data: mapping });
    } catch (error: any) {
        console.error('Failed to map attribute to category:', error);
        return NextResponse.json({ error: error.message || 'Failed to map attribute' }, { status: 500 });
    }
}

// DELETE - remove a specific attribute mapping (attributeId in query params)
export async function DELETE(request: NextRequest, { params }: { params: { id: string } }) {
    try {
        const url = new URL(request.url);
        const attributeId = url.searchParams.get('attributeId');

        if (!attributeId) {
            return NextResponse.json({ error: 'attributeId query param is required' }, { status: 400 });
        }

        await prisma.categoryAttributeMap.delete({
            where: {
                categoryId_attributeId: {
                    categoryId: params.id,
                    attributeId,
                }
            }
        });

        return NextResponse.json({ success: true });
    } catch (error: any) {
        console.error('Failed to unmap attribute from category:', error);
        return NextResponse.json({ error: error.message || 'Failed to unmap attribute' }, { status: 500 });
    }
}
