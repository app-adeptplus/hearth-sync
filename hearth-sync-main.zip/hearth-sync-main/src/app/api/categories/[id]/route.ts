import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/db';

export async function PATCH(request: NextRequest, { params }: { params: { id: string } }) {
    try {
        const body = await request.json();
        const { name, slug, parentId, sortOrder, categoryResearch, likeTerms } = body;

        const data: any = {};
        if (name !== undefined) data.name = name;
        if (slug !== undefined) data.slug = slug;
        if (parentId !== undefined) data.parentId = parentId;
        if (sortOrder !== undefined) data.sortOrder = sortOrder;
        if (categoryResearch !== undefined) data.categoryResearch = categoryResearch;
        if (likeTerms !== undefined) data.likeTerms = likeTerms;

        const updatedCategory = await prisma.productCategory.update({
            where: { id: params.id },
            data,
        });

        return NextResponse.json({ data: updatedCategory });
    } catch (error: any) {
        console.error('Failed to update category:', error);
        return NextResponse.json({ error: error.message || 'Failed to update category' }, { status: 500 });
    }
}

// GET - fetch category details including counts for deletion warnings
export async function GET(_: NextRequest, { params }: { params: { id: string } }) {
    try {
        const category = await prisma.productCategory.findUnique({
            where: { id: params.id },
            include: {
                _count: {
                    select: { children: true, products: true, scraperConfigs: true }
                },
                children: { select: { id: true, name: true } },
            }
        });

        if (!category) {
            return NextResponse.json({ error: 'Category not found' }, { status: 404 });
        }

        return NextResponse.json({ data: category });
    } catch (error: any) {
        return NextResponse.json({ error: error.message || 'Failed to fetch category' }, { status: 500 });
    }
}

export async function DELETE(request: NextRequest, { params }: { params: { id: string } }) {
    try {
        // Fetch category with relationships
        const category = await prisma.productCategory.findUnique({
            where: { id: params.id },
            include: {
                _count: {
                    select: { children: true, products: true, scraperConfigs: true }
                }
            }
        });

        if (!category) {
            return NextResponse.json({ error: 'Category not found' }, { status: 404 });
        }

        // Block deletion of parent categories that still have children
        if (category._count.children > 0) {
            return NextResponse.json({
                error: `Cannot delete "${category.name}" because it has ${category._count.children} sub-categor${category._count.children === 1 ? 'y' : 'ies'}. Please move or delete all sub-categories first.`,
                code: 'HAS_CHILDREN',
                childCount: category._count.children,
            }, { status: 409 });
        }

        // Check the URL for a force parameter and a moveToCategory parameter
        const url = new URL(request.url);
        const force = url.searchParams.get('force') === 'true';
        const moveToCategoryId = url.searchParams.get('moveTo');

        // If category has products and this is not a force-delete, return a 409 with info
        if (category._count.products > 0 && !force) {
            return NextResponse.json({
                error: `"${category.name}" has ${category._count.products} product${category._count.products === 1 ? '' : 's'} associated. Choose to move them to another category or remove the association.`,
                code: 'HAS_PRODUCTS',
                productCount: category._count.products,
            }, { status: 409 });
        }

        // Use a transaction with extended timeout for safe deletion
        const result = await prisma.$transaction(async (tx) => {
            let productsMoved = 0;
            let productsDisconnected = 0;
            let scrapersDisconnected = 0;

            // If moveTo is specified, move products to that category
            if (moveToCategoryId && category._count.products > 0) {
                // Get all products currently linked to this category
                const productsInCategory = await tx.product.findMany({
                    where: { categories: { some: { id: params.id } } },
                    select: { id: true }
                });

                // Use the category's update to disconnect + connect in bulk
                // First connect all products to the new category
                await tx.productCategory.update({
                    where: { id: moveToCategoryId },
                    data: {
                        products: {
                            connect: productsInCategory.map(p => ({ id: p.id }))
                        }
                    }
                });

                // Then disconnect all products from the old category
                await tx.productCategory.update({
                    where: { id: params.id },
                    data: {
                        products: {
                            set: [] // Remove all product associations
                        }
                    }
                });

                productsMoved = productsInCategory.length;
            } else if (category._count.products > 0) {
                // Disconnect all products at once (remove association only)
                const productsInCategory = await tx.product.findMany({
                    where: { categories: { some: { id: params.id } } },
                    select: { id: true }
                });

                await tx.productCategory.update({
                    where: { id: params.id },
                    data: {
                        products: {
                            set: [] // Remove all product associations
                        }
                    }
                });

                productsDisconnected = productsInCategory.length;
            }

            // Disconnect scraper configs at once
            if (category._count.scraperConfigs > 0) {
                const scrapersInCategory = await tx.scraperConfig.findMany({
                    where: { defaultCategories: { some: { id: params.id } } },
                    select: { id: true }
                });

                await tx.productCategory.update({
                    where: { id: params.id },
                    data: {
                        scraperConfigs: {
                            set: [] // Remove all scraper associations
                        }
                    }
                });

                scrapersDisconnected = scrapersInCategory.length;
            }

            // Now safe to delete
            await tx.productCategory.delete({ where: { id: params.id } });

            return { productsMoved, productsDisconnected, scrapersDisconnected };
        }, { timeout: 30000 });

        return NextResponse.json({
            success: true,
            deleted: category.name,
            ...result,
        });
    } catch (error: any) {
        console.error('Failed to delete category:', error);
        return NextResponse.json({ error: error.message || 'Failed to delete category' }, { status: 500 });
    }
}
