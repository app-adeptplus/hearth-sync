import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/db';

export async function GET(_request: NextRequest) {
    try {
        const categories = await prisma.productCategory.findMany({
            orderBy: { name: 'asc' },
            select: { id: true, name: true, slug: true, parentId: true },
        });
        return NextResponse.json({ data: categories });
    } catch (error: any) {
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}

function slugify(text: string) {
    return text.toString().toLowerCase()
        .replace(/\s+/g, '-')
        .replace(/[^\w\-]+/g, '')
        .replace(/\-\-+/g, '-')
        .replace(/^-+/, '')
        .replace(/-+$/, '');
}

export async function POST(request: NextRequest) {
    try {
        const body = await request.json();
        const { name, parentId, sortOrder, categoryResearch, likeTerms } = body;

        if (!name) {
            return NextResponse.json({ error: 'Name is required' }, { status: 400 });
        }

        const slug = slugify(name);

        const newCategory = await prisma.productCategory.create({
            data: {
                name,
                slug,
                parentId: parentId || null,
                sortOrder: sortOrder || 0,
                categoryResearch: categoryResearch || null,
                likeTerms: likeTerms || null,
            }
        });

        return NextResponse.json({ data: newCategory });
    } catch (error: any) {
        console.error('Failed to create category:', error);
        return NextResponse.json({ error: error.message || 'Failed to create category' }, { status: 500 });
    }
}
