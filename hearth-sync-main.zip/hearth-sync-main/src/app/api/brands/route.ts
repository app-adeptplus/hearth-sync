import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/db';

export async function GET(request: NextRequest) {
    try {
        const searchParams = request.nextUrl.searchParams;
        const hasProducts = searchParams.get('hasProducts') === 'true';

        const where: Record<string, unknown> = { isActive: true };
        if (hasProducts) {
            where.products = { some: { status: 'ACTIVE' } };
        }

        const brands = await prisma.brand.findMany({
            where,
            orderBy: { name: 'asc' },
            select: {
                id: true,
                name: true,
                slug: true,
                logoUrl: true,
                manufacturer: { select: { name: true } },
                _count: { select: { products: true } },
            },
        });
        return NextResponse.json({ data: brands });
    } catch (error: any) {
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}

function slugify(text: string) {
    return text.toString().toLowerCase()
        .replace(/\s+/g, '-')
        .replace(/[^\w\-]+/g, '')
        .replace(/\-\-+/g, '-')
        .replace(/^-+/, '')
        .replace(/-+$/, '');
}

export async function POST(request: NextRequest) {
    try {
        const body = await request.json();
        const { name, manufacturerId, website, logoUrl, brandSku, isActive } = body;

        if (!name || !manufacturerId) {
            return NextResponse.json({ error: 'Name and Manufacturer ID are required' }, { status: 400 });
        }

        const slug = slugify(name);

        const newBrand = await prisma.brand.create({
            data: {
                name,
                slug,
                manufacturerId,
                website: website || null,
                logoUrl: logoUrl || null,
                brandSku: brandSku || null,
                isActive: isActive !== undefined ? isActive : true,
            }
        });

        return NextResponse.json({ data: newBrand });
    } catch (error: any) {
        console.error('Failed to create brand:', error);
        return NextResponse.json({ error: error.message || 'Failed to create brand' }, { status: 500 });
    }
}
