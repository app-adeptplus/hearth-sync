import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/db';

export async function PATCH(request: NextRequest, { params }: { params: { id: string } }) {
    try {
        const body = await request.json();
        const { name, website, logoUrl, brandSku, isActive, manufacturerId, deleteManufacturerIfEmpty } = body;

        const data: any = {};
        if (name !== undefined) data.name = name;
        if (website !== undefined) data.website = website || null;
        if (logoUrl !== undefined) data.logoUrl = logoUrl || null;
        if (brandSku !== undefined) data.brandSku = brandSku || null;
        if (isActive !== undefined) data.isActive = isActive;

        // Track original manufacturer before reassignment
        let originalManufacturerId: string | undefined;
        if (manufacturerId !== undefined) {
            const brand = await prisma.brand.findUnique({ where: { id: params.id }, select: { manufacturerId: true } });
            originalManufacturerId = brand?.manufacturerId;
            data.manufacturerId = manufacturerId;
        }

        const updatedBrand = await prisma.brand.update({
            where: { id: params.id },
            data,
        });

        // Optionally delete the original manufacturer if it now has no remaining brands
        if (deleteManufacturerIfEmpty && originalManufacturerId) {
            const remaining = await prisma.brand.count({ where: { manufacturerId: originalManufacturerId } });
            if (remaining === 0) {
                await prisma.manufacturer.delete({ where: { id: originalManufacturerId } });
            }
        }

        return NextResponse.json({ data: updatedBrand });
    } catch (error: any) {
        console.error('Failed to update brand:', error);
        return NextResponse.json({ error: error.message || 'Failed to update brand' }, { status: 500 });
    }
}

export async function DELETE(request: NextRequest, { params }: { params: { id: string } }) {
    try {
        await prisma.brand.delete({
            where: { id: params.id }
        });

        return NextResponse.json({ success: true });
    } catch (error: any) {
        console.error('Failed to delete brand:', error);
        return NextResponse.json({ error: error.message || 'Failed to delete brand' }, { status: 500 });
    }
}
