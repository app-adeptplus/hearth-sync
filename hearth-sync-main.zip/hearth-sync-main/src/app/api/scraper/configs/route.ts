import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/db';

export async function POST(request: NextRequest) {
    try {
        const body = await request.json();
        const { name, brandId, type, baseUrl, isActive, notes, config, defaultCategoryIds } = body;

        const scraperType = type || 'PRODUCT_LIST';
        const isCategoryType = scraperType === 'CATEGORY';

        // Brand is only required for Category configs
        if (isCategoryType && !brandId) {
            return NextResponse.json({ error: 'Brand ID is required for Category scrapers' }, { status: 400 });
        }

        const data: any = {
            name: name || 'New Scraper',
            type: scraperType,
            isActive: isActive ?? false,
            config: config || {},
        };

        // Only apply brand-specific fields for Category type
        if (isCategoryType) {
            data.brandId = brandId;
            if (baseUrl) data.baseUrl = baseUrl;
            if (Array.isArray(defaultCategoryIds) && defaultCategoryIds.length > 0) {
                data.defaultCategories = {
                    connect: defaultCategoryIds.map((id: string) => ({ id }))
                };
            }
        }

        if (notes) data.notes = notes;

        const newConfig = await prisma.scraperConfig.create({ data });

        return NextResponse.json({ data: newConfig }, { status: 201 });
    } catch (error: any) {
        console.error('Failed to create scraper config:', error);
        return NextResponse.json({ error: error.message || 'Failed to create config' }, { status: 500 });
    }
}
