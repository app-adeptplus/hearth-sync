import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/db';
import { scraperQueue } from '@/scraper/queue';

// GET /api/scraper — List scraper jobs
export async function GET(request: NextRequest) {
    try {
        const searchParams = request.nextUrl.searchParams;
        const status = searchParams.get('status');
        const configId = searchParams.get('configId');

        const where: Record<string, unknown> = {};
        if (status) where.status = status;
        if (configId) where.scraperConfigId = parseInt(configId);

        const jobs = await prisma.scraperJob.findMany({
            where,
            take: 100,
            orderBy: { createdAt: 'desc' },
            include: {
                scraperConfig: {
                    include: {
                        brand: {
                            select: {
                                name: true,
                                manufacturer: { select: { name: true } },
                            },
                        },
                    },
                },
            },
        });

        return NextResponse.json({ data: jobs });
    } catch (error) {
        console.error('GET /api/scraper error:', error);
        return NextResponse.json(
            { error: 'Failed to fetch scraper jobs' },
            { status: 500 }
        );
    }
}

// POST /api/scraper — Trigger a new scrape job
export async function POST(request: NextRequest) {
    try {
        const body = await request.json();
        const { scraperConfigId, dryRun, targetUrl } = body;

        if (!scraperConfigId) {
            return NextResponse.json(
                { error: 'scraperConfigId is required' },
                { status: 400 }
            );
        }

        const config = await prisma.scraperConfig.findUnique({
            where: { id: parseInt(scraperConfigId) },
            include: { brand: true },
        });

        if (!config) {
            return NextResponse.json(
                { error: 'Scraper config not found' },
                { status: 404 }
            );
        }

        // Create a pending job record
        const job = await prisma.scraperJob.create({
            data: {
                scraperConfigId: parseInt(scraperConfigId),
                status: 'PENDING',
                targetUrl: targetUrl || null
            },
        });

        // TODO: In production, this would enqueue a BullMQ job
        // For development, we trigger the background process directly
        await scraperQueue.add(job.id, parseInt(scraperConfigId), dryRun, targetUrl);

        return NextResponse.json(
            {
                data: job,
                message: `Scrape job created for ${config.brand?.name ?? 'config #' + scraperConfigId}${dryRun ? ' (dry run)' : ''}`,
            },
            { status: 201 }
        );
    } catch (error) {
        console.error('POST /api/scraper error:', error);
        return NextResponse.json(
            { error: 'Failed to create scraper job' },
            { status: 500 }
        );
    }
}
