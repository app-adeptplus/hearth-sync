import { NextResponse } from 'next/server';
import prisma from '@/lib/db';

/**
 * POST /api/scraper/clone-as-category
 * Clones every PRODUCT_LIST scraper config as a CATEGORY type config for the same brand.
 * Skips brands that already have a CATEGORY config.
 * Idempotent — safe to run multiple times.
 */
export async function POST() {
    try {
        const productListConfigs = await prisma.scraperConfig.findMany({
            where: { type: 'PRODUCT_LIST' },
            include: { brand: { select: { name: true } } }
        });

        const existingCategoryBrandIds = new Set(
            (await prisma.scraperConfig.findMany({
                where: { type: 'CATEGORY' },
                select: { brandId: true }
            })).map(c => c.brandId)
        );

        let created = 0;
        let skipped = 0;

        for (const config of productListConfigs) {
            if (!config.brand || !config.brandId) { skipped++; continue; }
            if (existingCategoryBrandIds.has(config.brandId)) { skipped++; continue; }

            await prisma.scraperConfig.create({
                data: {
                    name: `${config.brand.name} – Categories`,
                    brandId: config.brandId!,
                    type: 'CATEGORY',
                    integrationMethod: config.integrationMethod,
                    baseUrl: config.baseUrl,
                    syncFrequency: config.syncFrequency,
                    isActive: false,
                    notes: `Auto-created as category scraper for ${config.brand.name}. Configure selectors before activating.`,
                    config: {},
                }
            });

            created++;
        }

        return NextResponse.json({
            message: `Created ${created} category scrapers, skipped ${skipped} (already had one).`,
            created,
            skipped,
        }, { status: 201 });
    } catch (error: any) {
        console.error('Failed to clone scrapers as category:', error);
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}
