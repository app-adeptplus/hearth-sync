import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/db';

export async function POST(request: NextRequest) {
    try {
        const body = await request.json();
        const {
            name,
            brandId,
            isActive,
            categoryConfigId,
            productListConfigId,
            productPageConfigId
        } = body;

        if (!name || !brandId) {
            return NextResponse.json(
                { message: 'Name and Brand are required' },
                { status: 400 }
            );
        }

        const workflow = await prisma.scraperWorkflow.create({
            data: {
                name,
                brandId,
                isActive: isActive ?? true,
                categoryConfigId,
                productListConfigId,
                productPageConfigId
            }
        });

        return NextResponse.json({ data: workflow }, { status: 201 });
    } catch (error: any) {
        return NextResponse.json(
            { message: error.message || 'Failed to create workflow' },
            { status: 500 }
        );
    }
}
