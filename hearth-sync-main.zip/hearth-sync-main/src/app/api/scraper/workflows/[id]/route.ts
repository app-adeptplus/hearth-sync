import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/db';

export async function PUT(request: NextRequest, { params }: { params: { id: string } }) {
    try {
        const body = await request.json();
        const {
            name,
            brandId,
            isActive,
            categoryConfigId,
            productListConfigId,
            productPageConfigId
        } = body;

        const workflow = await prisma.scraperWorkflow.update({
            where: { id: params.id },
            data: {
                name,
                brandId,
                isActive,
                categoryConfigId,
                productListConfigId,
                productPageConfigId
            }
        });

        return NextResponse.json({ data: workflow });
    } catch (error: any) {
        return NextResponse.json(
            { message: error.message || 'Failed to update workflow' },
            { status: 500 }
        );
    }
}
