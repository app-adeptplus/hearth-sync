import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/db';

export async function PATCH(request: NextRequest, { params }: { params: { id: string } }) {
    try {
        const body = await request.json();
        const { name, isActive, notes, config, baseUrl, defaultCategoryIds } = body;
        const configId = parseInt(params.id);

        // Fetch existing config to know its type (gates which fields are editable)
        const existing = await prisma.scraperConfig.findUnique({
            where: { id: configId },
            select: { type: true }
        });

        if (!existing) {
            return NextResponse.json({ error: 'Scraper config not found' }, { status: 404 });
        }

        const isCategoryType = existing.type === 'CATEGORY';

        const data: any = {};
        if (name !== undefined) data.name = name;
        if (isActive !== undefined) data.isActive = isActive;
        if (notes !== undefined) data.notes = notes;
        if (config !== undefined) data.config = config;

        // Only apply category-specific fields for CATEGORY type configs
        if (isCategoryType) {
            if (baseUrl !== undefined) data.baseUrl = baseUrl;
            if (Array.isArray(defaultCategoryIds)) {
                data.defaultCategories = {
                    set: defaultCategoryIds.map((id: string) => ({ id }))
                };
            }
        }

        const updatedConfig = await prisma.scraperConfig.update({
            where: { id: configId },
            data,
        });

        return NextResponse.json({ data: updatedConfig });
    } catch (error: any) {
        console.error('Failed to update scraper config:', error);
        return NextResponse.json({ error: error.message || 'Failed to update config' }, { status: 500 });
    }
}
