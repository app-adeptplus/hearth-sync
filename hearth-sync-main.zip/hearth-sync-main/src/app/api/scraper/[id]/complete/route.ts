import { NextRequest, NextResponse } from 'next/server';
import { ScraperEngine } from '@/scraper/ScraperEngine';

/**
 * POST /api/scraper/[id]/complete
 *
 * Callback endpoint for the external scraper worker to submit results.
 * The worker sends scraped product data here after completing a job.
 */
export async function POST(
    request: NextRequest,
    { params }: { params: { id: string } }
) {
    // Verify shared secret
    const authHeader = request.headers.get('authorization');
    if (
        process.env.SCRAPER_WORKER_SECRET &&
        authHeader !== `Bearer ${process.env.SCRAPER_WORKER_SECRET}`
    ) {
        return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    try {
        const { id: jobId } = params;
        const body = await request.json();
        const { products = [], errors = [] } = body;

        const result = await ScraperEngine.processResults(jobId, products, errors);

        return NextResponse.json({
            ok: true,
            productsFound: result.productsFound,
            productsAdded: result.productsAdded,
            productsUpdated: result.productsUpdated,
            productsRemoved: result.productsRemoved,
        });
    } catch (error) {
        console.error('POST /api/scraper/[id]/complete error:', error);
        return NextResponse.json(
            { error: 'Failed to process scrape results' },
            { status: 500 }
        );
    }
}
