import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/db';

// PUT /api/option-groups/[id]/options/[optionId] — update a single option
export async function PUT(
    request: NextRequest,
    { params }: { params: { id: string; optionId: string } }
) {
    try {
        const body = await request.json();
        const { label, value, description, priceAdjust, swatchColor, imageUrl, isDefault, isActive, sortOrder } = body;

        const updateData: Record<string, any> = {};
        if (label !== undefined) updateData.label = label.trim();
        if (value !== undefined) updateData.value = value.trim().toLowerCase().replace(/\s+/g, '-');
        if (description !== undefined) updateData.description = description || null;
        if (priceAdjust !== undefined) updateData.priceAdjust = priceAdjust != null ? priceAdjust : null;
        if (swatchColor !== undefined) updateData.swatchColor = swatchColor || null;
        if (imageUrl !== undefined) updateData.imageUrl = imageUrl || null;
        if (isDefault !== undefined) updateData.isDefault = isDefault;
        if (isActive !== undefined) updateData.isActive = isActive;
        if (sortOrder !== undefined) updateData.sortOrder = sortOrder;

        const option = await prisma.option.update({
            where: { id: params.optionId },
            data: updateData,
        });
        return NextResponse.json({ data: option });
    } catch (error: any) {
        if (error.code === 'P2025') return NextResponse.json({ error: 'Option not found' }, { status: 404 });
        if (error.code === 'P2002') return NextResponse.json({ error: 'An option with that value already exists in this group' }, { status: 409 });
        return NextResponse.json({ error: error.message || 'Failed to update option' }, { status: 500 });
    }
}

// DELETE /api/option-groups/[id]/options/[optionId] — remove a single option
export async function DELETE(
    _: NextRequest,
    { params }: { params: { id: string; optionId: string } }
) {
    try {
        await prisma.option.delete({ where: { id: params.optionId } });
        return NextResponse.json({ success: true });
    } catch (error: any) {
        if (error.code === 'P2025') return NextResponse.json({ error: 'Option not found' }, { status: 404 });
        return NextResponse.json({ error: error.message || 'Failed to delete option' }, { status: 500 });
    }
}
