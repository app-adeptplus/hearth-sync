import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/db';

// GET /api/option-groups/[id]/options — list all options for a group
export async function GET(_: NextRequest, { params }: { params: { id: string } }) {
    try {
        const options = await prisma.option.findMany({
            where: { groupId: params.id },
            orderBy: [{ sortOrder: 'asc' }, { label: 'asc' }],
        });
        return NextResponse.json({ data: options });
    } catch (error: any) {
        return NextResponse.json({ error: error.message || 'Failed to fetch options' }, { status: 500 });
    }
}

// POST /api/option-groups/[id]/options — add a new option to a group
export async function POST(request: NextRequest, { params }: { params: { id: string } }) {
    try {
        const body = await request.json();
        const { label, value, description, priceAdjust, swatchColor, imageUrl, isDefault, isActive, sortOrder } = body;

        if (!label?.trim()) return NextResponse.json({ error: 'Label is required' }, { status: 400 });
        if (!value?.trim()) return NextResponse.json({ error: 'Value is required' }, { status: 400 });

        // Check group exists
        const group = await prisma.optionGroup.findUnique({ where: { id: params.id } });
        if (!group) return NextResponse.json({ error: 'Option group not found' }, { status: 404 });

        const option = await prisma.option.create({
            data: {
                groupId: params.id,
                label: label.trim(),
                value: value.trim().toLowerCase().replace(/\s+/g, '-'),
                description: description || null,
                priceAdjust: priceAdjust != null ? priceAdjust : null,
                swatchColor: swatchColor || null,
                imageUrl: imageUrl || null,
                isDefault: isDefault ?? false,
                isActive: isActive ?? true,
                sortOrder: sortOrder ?? 0,
            },
        });
        return NextResponse.json({ data: option }, { status: 201 });
    } catch (error: any) {
        if (error.code === 'P2002') {
            return NextResponse.json({ error: 'An option with that value already exists in this group' }, { status: 409 });
        }
        return NextResponse.json({ error: error.message || 'Failed to create option' }, { status: 500 });
    }
}
