import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/db';

// GET /api/option-groups/[id] — fetch single group with full options
export async function GET(_: NextRequest, { params }: { params: { id: string } }) {
    try {
        const group = await prisma.optionGroup.findUnique({
            where: { id: params.id },
            include: {
                options: { orderBy: [{ sortOrder: 'asc' }, { label: 'asc' }] },
                productLinks: {
                    include: {
                        product: {
                            select: { id: true, name: true, sku: true, modelNumber: true },
                        },
                    },
                    orderBy: { sortOrder: 'asc' },
                },
                _count: { select: { options: true, productLinks: true } },
            },
        });
        if (!group) return NextResponse.json({ error: 'Option group not found' }, { status: 404 });
        return NextResponse.json({ data: group });
    } catch (error: any) {
        return NextResponse.json({ error: error.message || 'Failed to fetch option group' }, { status: 500 });
    }
}

// PUT /api/option-groups/[id] — update group metadata
export async function PUT(request: NextRequest, { params }: { params: { id: string } }) {
    try {
        const body = await request.json();
        const { name, description, inputType, isRequired, allowMultiple, sortOrder } = body;

        const updateData: Record<string, any> = {};
        if (name !== undefined) updateData.name = name.trim();
        if (description !== undefined) updateData.description = description || null;
        if (inputType !== undefined) updateData.inputType = inputType;
        if (isRequired !== undefined) updateData.isRequired = isRequired;
        if (allowMultiple !== undefined) updateData.allowMultiple = allowMultiple;
        if (sortOrder !== undefined) updateData.sortOrder = sortOrder;

        const group = await prisma.optionGroup.update({
            where: { id: params.id },
            data: updateData,
        });
        return NextResponse.json({ data: group });
    } catch (error: any) {
        if (error.code === 'P2025') return NextResponse.json({ error: 'Option group not found' }, { status: 404 });
        return NextResponse.json({ error: error.message || 'Failed to update option group' }, { status: 500 });
    }
}

// DELETE /api/option-groups/[id] — delete group (cascades to options + product assignments)
export async function DELETE(_: NextRequest, { params }: { params: { id: string } }) {
    try {
        await prisma.optionGroup.delete({ where: { id: params.id } });
        return NextResponse.json({ success: true });
    } catch (error: any) {
        if (error.code === 'P2025') return NextResponse.json({ error: 'Option group not found' }, { status: 404 });
        return NextResponse.json({ error: error.message || 'Failed to delete option group' }, { status: 500 });
    }
}
