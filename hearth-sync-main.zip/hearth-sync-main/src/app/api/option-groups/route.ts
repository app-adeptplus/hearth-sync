import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/db';

function slugify(text: string) {
    return text.toString().toLowerCase()
        .replace(/\s+/g, '-')
        .replace(/[^\w\-]+/g, '')
        .replace(/\-\-+/g, '-')
        .replace(/^-+/, '')
        .replace(/-+$/, '');
}

// GET /api/option-groups — list all option groups with counts
export async function GET() {
    try {
        const groups = await prisma.optionGroup.findMany({
            orderBy: [{ sortOrder: 'asc' }, { name: 'asc' }],
            include: {
                _count: {
                    select: { options: true, productLinks: true },
                },
            },
        });
        return NextResponse.json({ data: groups });
    } catch (error: any) {
        return NextResponse.json({ error: error.message || 'Failed to fetch option groups' }, { status: 500 });
    }
}

// POST /api/option-groups — create a new option group
export async function POST(request: NextRequest) {
    try {
        const body = await request.json();
        const { name, description, inputType, isRequired, allowMultiple, sortOrder } = body;

        if (!name?.trim()) {
            return NextResponse.json({ error: 'Name is required' }, { status: 400 });
        }

        const slug = slugify(name);

        const group = await prisma.optionGroup.create({
            data: {
                name: name.trim(),
                slug,
                description: description || null,
                inputType: inputType || 'select',
                isRequired: isRequired ?? false,
                allowMultiple: allowMultiple ?? false,
                sortOrder: sortOrder ?? 0,
            },
        });

        return NextResponse.json({ data: group }, { status: 201 });
    } catch (error: any) {
        if (error.code === 'P2002') {
            return NextResponse.json({ error: 'An option group with that name already exists' }, { status: 409 });
        }
        return NextResponse.json({ error: error.message || 'Failed to create option group' }, { status: 500 });
    }
}
