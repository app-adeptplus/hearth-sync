import { NextRequest, NextResponse } from 'next/server';
import { callLlm } from '@/lib/llm-client';
import { resolveAssignment, resolvedApiKey, resolvedPrompt } from '@/lib/assignments';

// ── Built-in system prompts (fallback when no assignment template is set) ──

const BUILT_IN_PROMPTS: Record<string, string> = {
    categorization: `You are a Hearth product categorization assistant for HearthSync, a B2B product catalog platform.
You help catalog administrators assign products to the correct categories within the Hearth taxonomy (fireplaces, inserts, stoves, grills, outdoor heating, accessories, etc.).
When given a product name or description, respond with:
1. The most appropriate category and why
2. Any secondary categories if applicable
3. Suggested attributes or tags
Be concise and practical. If you identify a DB action should be taken (e.g. update a product's categoryId), mark it clearly with "ACTION PENDING:" so the admin knows to approve it.`,

    spec_extractor: `You are a product specification extractor for HearthSync, a B2B hearth product catalog.
When given raw HTML, PDF text, or product copy, extract structured specifications as clean key-value pairs.
Format output as:
- Key: Value
Always include: BTU rating, fuel type, dimensions (HxWxD), weight, efficiency rating, ignition type, and any other specs found.
If a value is unclear or absent, note it as "Not specified".
If you are ready to write specs to the database, prefix your response with "ACTION PENDING:" followed by the JSON payload.`,

    scraper_setup: `You are a web scraper configuration assistant for HearthSync.
When given a website URL or HTML sample, help the user write a scraper configuration by identifying:
1. CSS selectors or XPath for: product name, SKU/model number, images, description, price, specs
2. Pagination patterns if visible
3. Any anti-scraping measures to be aware of
Format selector suggestions as a JSON object. If you think the config is ready to save, prefix with "ACTION PENDING:".`,
};

const DEFAULT_PROMPT = `You are HearthSync AI, an intelligent assistant for the HearthSync B2B product catalog platform.
You help administrators manage products, manufacturers, brands, categories, attributes, data imports, and scraper configurations.
Be concise, practical, and data-driven. When recommending a database change, prefix your response with "ACTION PENDING:" so the admin can review and approve it.`;

export async function POST(request: NextRequest) {
    try {
        const { message, persona, assignmentId, history } = await request.json();

        if (!message?.trim()) {
            return NextResponse.json({ error: 'Message is required' }, { status: 400 });
        }

        let systemPrompt: string | null = null;
        let llmConfigId: string | undefined;

        // ── 1. Try to resolve a Prompt Assignment ──────────────────────────
        if (assignmentId || persona) {
            const serviceId = assignmentId ?? persona ?? null;
            try {
                const assignment = await resolveAssignment('CHAT_BOT', serviceId);
                if (assignment) {
                    // Use the assignment's LLM config
                    llmConfigId = assignment.llmConfig.id;
                    // Use the linked prompt template if available
                    systemPrompt = resolvedPrompt(assignment);
                }
            } catch {
                // Non-fatal — fall through to default
            }
        }

        // ── 2. Fall back to built-in inline prompts ────────────────────────
        if (!systemPrompt) {
            systemPrompt = (persona && BUILT_IN_PROMPTS[persona]) ?? DEFAULT_PROMPT;
        }

        // ── 3. Build conversation context ──────────────────────────────────
        const recentHistory: string = (history ?? [])
            .slice(-8)
            .map((m: { role: string; content: string }) =>
                `${m.role === 'user' ? 'User' : 'Assistant'}: ${m.content}`
            )
            .join('\n');

        const fullMessage = recentHistory
            ? `Previous conversation:\n${recentHistory}\n\nUser: ${message}`
            : message;

        // ── 4. Call LLM ────────────────────────────────────────────────────
        const result = await callLlm(fullMessage, {
            systemPrompt: systemPrompt ?? undefined,
            maxTokens: 1024,
            temperature: 0.4,
            ...(llmConfigId && { llmConfigId }),
        });

        // ── 5. Detect ACTION PENDING ───────────────────────────────────────
        const actionPending = result.text.includes('ACTION PENDING:');

        return NextResponse.json({
            content: result.text,
            actionPending,
            tokensUsed: result.tokensUsed,
            provider: result.provider,
            model: result.model,
        });

    } catch (error: any) {
        if (error.message?.includes('No LLM provider configured')) {
            return NextResponse.json({
                content: '⚠️ No LLM provider is configured yet. Go to **System Services → API Connections** and add an API key for OpenAI, Anthropic, or another provider, then set it as the default.',
                actionPending: false,
                tokensUsed: 0,
            });
        }

        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}
