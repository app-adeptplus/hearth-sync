import type { Metadata } from 'next';
import '@/styles/globals.css';

export const metadata: Metadata = {
    title: 'HearthSync — Product Catalog Platform',
    description:
        'Master product catalog platform for the hearth industry. Aggregate, manage, and stream fireplace product data to dealer websites.',
};

export default function RootLayout({
    children,
}: {
    children: React.ReactNode;
}) {
    return (
        <html lang="en">
            <body>{children}</body>
        </html>
    );
}
