'use client';

import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { useState } from 'react';
import { createBrowserClient } from '@supabase/ssr';
import AIChatModal from '@/components/AIChatModal';

const NAV_ITEMS = [
    {
        section: 'Catalog',
        links: [
            { href: '/admin', label: 'Dashboard', icon: '📊' },
            { href: '/admin/manufacturers', label: 'Manufacturers', icon: '🏭' },
            { href: '/admin/products', label: 'Products', icon: '🔥' },
            { href: '/admin/categories', label: 'Taxonomy', icon: '📁' },
            { href: '/admin/option-groups', label: 'Option Groups', icon: '🎛️' },
        ],
    },
    {
        section: 'Data Pipeline',
        links: [
            { href: '/admin/product-automation', label: 'Product Automation', icon: '⚡' },
            { href: '/admin/enrichment', label: 'Enrichment Jobs', icon: '🔬' },
            { href: '/admin/scraper', label: 'Scraper Jobs', icon: '🤖' },
            { href: '/admin/audit', label: 'Audit Log', icon: '📝' },
            { href: '/admin/models', label: 'System Services', icon: '🔩' },
        ],
    },
    {
        section: 'HearthSync Portal',
        links: [
            { href: '/admin/dealer-portal/users', label: 'Admin Users', icon: '👤' },
            { href: '/admin/dealer-portal/dealers', label: 'Dealer Accounts', icon: '🏪' },
        ],
    },
];

export default function AdminLayout({
    children,
}: {
    children: React.ReactNode;
}) {
    const pathname = usePathname();
    const router = useRouter();
    const [isChatOpen, setIsChatOpen] = useState(false);

    // Don't wrap the login page in the admin layout
    if (pathname === '/admin/login') {
        return <>{children}</>;
    }

    const handleSignOut = async () => {
        const supabase = createBrowserClient(
            process.env.NEXT_PUBLIC_SUPABASE_URL!,
            process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
        );
        await supabase.auth.signOut();
        window.location.href = '/admin/login';
    };

    return (
        <div className="app-layout">
            <aside className="app-sidebar">
                <div className="sidebar-logo">
                    <span style={{ fontSize: '1.5rem' }}>🔥</span>
                    <h1>HearthSync</h1>
                </div>
                <nav className="sidebar-nav">
                    {NAV_ITEMS.map((section) => (
                        <div key={section.section}>
                            <div className="sidebar-nav-section">{section.section}</div>
                            {section.links.map((link) => (
                                <Link
                                    key={link.href}
                                    href={link.href}
                                    className={
                                        pathname === link.href ||
                                            (link.href !== '/admin' && pathname.startsWith(link.href))
                                            ? 'active'
                                            : ''
                                    }
                                >
                                    <span>{link.icon}</span>
                                    {link.label}
                                </Link>
                            ))}
                        </div>
                    ))}
                </nav>
                <div
                    style={{
                        padding: 'var(--space-4)',
                        borderTop: '1px solid var(--color-border)',
                        display: 'flex',
                        flexDirection: 'column',
                        gap: 'var(--space-2)',
                    }}
                >
                    <button
                        onClick={handleSignOut}
                        style={{
                            display: 'flex',
                            alignItems: 'center',
                            gap: 'var(--space-2)',
                            background: 'none',
                            border: '1px solid var(--color-border)',
                            borderRadius: 'var(--radius-md)',
                            padding: '0.5rem 0.75rem',
                            color: 'var(--color-text-secondary)',
                            fontSize: 'var(--font-size-sm)',
                            cursor: 'pointer',
                            width: '100%',
                            justifyContent: 'center',
                            transition: 'all 0.15s ease',
                        }}
                        onMouseEnter={(e) => {
                            e.currentTarget.style.background = 'rgba(239, 68, 68, 0.1)';
                            e.currentTarget.style.borderColor = 'rgba(239, 68, 68, 0.3)';
                            e.currentTarget.style.color = '#ef4444';
                        }}
                        onMouseLeave={(e) => {
                            e.currentTarget.style.background = 'none';
                            e.currentTarget.style.borderColor = 'var(--color-border)';
                            e.currentTarget.style.color = 'var(--color-text-secondary)';
                        }}
                    >
                        🚪 Sign Out
                    </button>
                    <span
                        style={{
                            fontSize: 'var(--font-size-xs)',
                            color: 'var(--color-text-muted)',
                            textAlign: 'center',
                        }}
                    >
                        HearthSync v0.1.0
                    </span>
                </div>
            </aside>

            <main className="app-main">
                <header className="app-header">
                    <div style={{ display: 'flex', alignItems: 'center', gap: 'var(--space-3)', flex: 1 }}>
                        <div className="search-bar">
                            <span className="search-icon">🔍</span>
                            <input type="text" placeholder="Search products, brands..." />
                        </div>
                        <button
                            id="ai-chat-trigger"
                            onClick={() => setIsChatOpen(true)}
                            style={{
                                display: 'flex',
                                alignItems: 'center',
                                gap: '0.375rem',
                                padding: '0.4rem 0.875rem',
                                borderRadius: 'var(--radius-lg)',
                                border: '1px solid rgba(233,69,96,0.35)',
                                background: 'linear-gradient(135deg, rgba(233,69,96,0.12), rgba(244,162,97,0.08))',
                                color: '#e94560',
                                fontFamily: 'var(--font-family)',
                                fontSize: 'var(--font-size-sm)',
                                fontWeight: 600,
                                cursor: 'pointer',
                                transition: 'all 0.15s ease',
                                whiteSpace: 'nowrap',
                            }}
                            onMouseEnter={e => {
                                e.currentTarget.style.background = 'linear-gradient(135deg, rgba(233,69,96,0.2), rgba(244,162,97,0.14))';
                                e.currentTarget.style.borderColor = 'rgba(233,69,96,0.6)';
                                e.currentTarget.style.boxShadow = '0 2px 12px rgba(233,69,96,0.2)';
                            }}
                            onMouseLeave={e => {
                                e.currentTarget.style.background = 'linear-gradient(135deg, rgba(233,69,96,0.12), rgba(244,162,97,0.08))';
                                e.currentTarget.style.borderColor = 'rgba(233,69,96,0.35)';
                                e.currentTarget.style.boxShadow = 'none';
                            }}
                        >
                            <span style={{ fontSize: '0.9rem' }}>✦</span>
                            Ask AI
                        </button>
                    </div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 'var(--space-4)' }}>
                        <span style={{ color: 'var(--color-text-secondary)', fontSize: 'var(--font-size-sm)' }}>
                            Admin
                        </span>
                    </div>
                </header>
                <AIChatModal isOpen={isChatOpen} onClose={() => setIsChatOpen(false)} />
                <div className="app-content">{children}</div>
            </main>
        </div>
    );
}
