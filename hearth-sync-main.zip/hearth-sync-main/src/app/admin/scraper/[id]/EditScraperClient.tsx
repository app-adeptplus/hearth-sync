"use client";

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import MultiSelectDropdown from '@/components/MultiSelectDropdown';

interface ScraperFieldMapping {
    field: string;
    selector: string;
    delimiter: string;
    extractType: 'Text' | 'HTML' | 'Attribute' | 'Property';
    extractValue: string;
}

const COMMON_FIELDS = [
    'name', 'price', 'description', 'short_description', 'sku', 'images', 'productId', 'in_stock' // Or they can type custom
];

export default function EditScraperClient({
    config,
    allCategories,
    allBrands,
    isNew,
    from
}: {
    config?: any,
    allCategories: any[],
    allBrands: any[],
    isNew?: boolean,
    from?: string
}) {
    const router = useRouter();
    // When creating new, pre-select the type matching the tab we came from
    const defaultType = from === 'CATEGORY' ? 'CATEGORY' : from === 'PRODUCT_PAGE' ? 'PRODUCT_PAGE' : 'PRODUCT_LIST';
    const [brandId, setBrandId] = useState(config?.brandId || (allBrands.length > 0 ? allBrands[0].id : ''));
    const [name, setName] = useState(config?.name || 'New Scraper');
    const [type, setType] = useState(config?.type || defaultType);
    const [baseUrl, setBaseUrl] = useState(config?.baseUrl || '');
    const [isActive, setIsActive] = useState(config?.isActive || false);
    const [configJson, setConfigJson] = useState(JSON.stringify(config?.config || {}, null, 2));
    const [notes, setNotes] = useState(config?.notes || '');
    const [categoryIds, setCategoryIds] = useState<string[]>(config?.defaultCategories?.map((c: any) => c.id) || []);
    const [isSaving, setIsSaving] = useState(false);
    const [saveStatus, setSaveStatus] = useState<'idle' | 'saved' | 'error'>('idle');
    const [saveError, setSaveError] = useState('');

    const [wrapperSelector, setWrapperSelector] = useState(config?.config?.wrapper || '');
    const [fieldMappings, setFieldMappings] = useState<ScraperFieldMapping[]>(
        Array.isArray(config?.config?.fields) ? config.config.fields : []
    );

    const addFieldMapping = () => {
        setFieldMappings([...fieldMappings, {
            field: '',
            selector: '',
            delimiter: ' ',
            extractType: 'Text',
            extractValue: ''
        }]);
    };

    const removeFieldMapping = (index: number) => {
        setFieldMappings(fieldMappings.filter((_, i) => i !== index));
    };

    const updateFieldMapping = (index: number, key: keyof ScraperFieldMapping, val: string) => {
        const updated = [...fieldMappings];
        updated[index] = { ...updated[index], [key]: val };
        setFieldMappings(updated);
    };

    const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
        e.preventDefault();
        setIsSaving(true);
        setSaveStatus('idle');
        setSaveError('');

        try {
            const formData = new FormData(e.currentTarget);
            const selectedCategories = formData.getAll('categoryIds') as string[];

            let parsedJson = {};
            if (type === 'CATEGORY') {
                try {
                    parsedJson = JSON.parse(configJson);
                } catch (err) {
                    throw new Error("Invalid JSON in CSS selectors config (Category Config)");
                }
            } else {
                parsedJson = {
                    wrapper: wrapperSelector,
                    fields: fieldMappings
                };
            }

            const payload = {
                name,
                brandId,
                type,
                baseUrl,
                isActive,
                notes,
                config: parsedJson,
                defaultCategoryIds: selectedCategories,
            };

            const url = isNew ? '/api/scraper/configs' : `/api/scraper/${config.id}`;
            const method = isNew ? 'POST' : 'PATCH';

            const res = await fetch(url, {
                method,
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload),
            });

            if (!res.ok) {
                const data = await res.json();
                throw new Error(data.error || 'Failed to update scraper config');
            }

            setSaveStatus('saved');
            // Redirect back to the section this scraper belongs to
            const returnTab = isNew ? type : (config?.type || type);
            router.push(`/admin/scraper?tab=${returnTab}`);
        } catch (error: any) {
            setSaveStatus('error');
            setSaveError(error.message);
        } finally {
            setIsSaving(false);
        }
    };

    return (
        <form onSubmit={handleSubmit} className="flex flex-col gap-10" style={{ display: 'flex', flexDirection: 'column', gap: '2.5rem' }}>
            <div className="card p-8 flex flex-col gap-8" style={{ padding: '2rem', display: 'flex', flexDirection: 'column', gap: '2rem' }}>
                <h3 className="text-xl font-semibold border-b border-[var(--color-border)] pb-3">General Settings</h3>

                {/* Scraper Type — only shown when creating new */}
                {isNew && (
                    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '2rem' }}>
                        <div>
                            <label className="block text-sm font-semibold mb-2">Scraper Type</label>
                            <select className="form-select w-full" value={type} onChange={e => setType(e.target.value)}>
                                <option value="CATEGORY">Category Links</option>
                                <option value="PRODUCT_LIST">Product References</option>
                                <option value="PRODUCT_PAGE">Deep Product Page</option>
                            </select>
                            <p className="text-xs text-[var(--color-text-muted)] mt-1">
                                {type === 'CATEGORY'
                                    ? 'Brand-specific — discovers category/collection URLs for a brand.'
                                    : type === 'PRODUCT_LIST'
                                        ? 'Generic template — reuse across brands via Workflows.'
                                        : 'Generic template — scrapes deep product detail pages via Workflows.'}
                            </p>
                        </div>

                        {/* Brand — only for Category type */}
                        {type === 'CATEGORY' && (
                            <div>
                                <label className="block text-sm font-semibold mb-2">Brand</label>
                                <select className="form-select w-full" value={brandId} onChange={e => setBrandId(e.target.value)}>
                                    {allBrands.map(b => (
                                        <option key={b.id} value={b.id}>{b.name}</option>
                                    ))}
                                </select>
                            </div>
                        )}
                    </div>
                )}

                {/* Name + Base URL (CATEGORY only) + Status */}
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '2rem' }}>
                    <div>
                        <label className="block text-sm font-semibold mb-2">Scraper Name</label>
                        <input type="text" className="form-input w-full" value={name} onChange={e => setName(e.target.value)} placeholder="e.g. WooCommerce Product List" required />
                    </div>
                    {type === 'CATEGORY' && (
                        <div>
                            <label className="block text-sm font-semibold mb-2">Base URL</label>
                            <input type="url" className="form-input w-full" value={baseUrl} onChange={e => setBaseUrl(e.target.value)} placeholder="https://" />
                        </div>
                    )}
                    <div>
                        <label className="block text-sm font-semibold mb-2">Status</label>
                        <select className="form-select w-full" value={isActive ? 'true' : 'false'} onChange={e => setIsActive(e.target.value === 'true')}>
                            <option value="true">Active</option>
                            <option value="false">Paused</option>
                        </select>
                    </div>
                </div>
            </div>

            {/* Auto-Categorization — CATEGORY type only */}
            {type === 'CATEGORY' && (
                <div className="card p-8 flex flex-col gap-8" style={{ padding: '2rem', display: 'flex', flexDirection: 'column', gap: '2rem' }}>
                    <div>
                        <h3 className="text-xl font-semibold border-b border-[var(--color-border)] pb-3 mb-4">Auto-Categorization</h3>
                        <p className="text-sm text-[var(--color-text-muted)]">When the scraper finds a new product, automatically assign these default product categories to it.</p>
                    </div>
                    <div>
                        <label className="block text-sm font-semibold mb-2">Default Product Categories</label>
                        <MultiSelectDropdown
                            options={allCategories}
                            initialSelected={categoryIds}
                            name="categoryIds"
                            placeholder="Select Default Categories..."
                        />
                    </div>
                </div>
            )}

            <div className="card p-8 flex flex-col gap-8" style={{ padding: '2rem', display: 'flex', flexDirection: 'column', gap: '2rem' }}>
                <h3 className="text-xl font-semibold border-b border-[var(--color-border)] pb-3">Scraping Engine</h3>

                {type === 'CATEGORY' ? (
                    <div>
                        <label className="block text-sm font-semibold mb-2">CSS Selectors (JSON Config)</label>
                        <textarea
                            className="form-input w-full font-mono text-sm"
                            rows={12}
                            value={configJson}
                            onChange={e => setConfigJson(e.target.value)}
                            placeholder='{ "selectors": { "title": "h1.product-title" } }'
                        />
                    </div>
                ) : (
                    <div className="flex flex-col gap-8" style={{ display: 'flex', flexDirection: 'column', gap: '2rem' }}>
                        <div>
                            <label className="block text-sm font-semibold mb-2">Wrapper CSS Selector</label>
                            <input
                                type="text"
                                className="form-input w-full"
                                value={wrapperSelector}
                                onChange={e => setWrapperSelector(e.target.value)}
                                placeholder=".product-card-container"
                            />
                            <p className="text-xs text-[var(--color-text-muted)] mt-1">The CSS class that contains a single product item / or the main body of a single page.</p>
                        </div>

                        <div>
                            <div className="flex justify-between items-center mb-2">
                                <label className="block text-sm font-semibold">Element Field Mappings</label>
                                <button type="button" className="btn btn-sm btn-secondary" onClick={addFieldMapping}>➕ Add Field</button>
                            </div>

                            {fieldMappings.length === 0 ? (
                                <p className="text-sm text-[var(--color-text-muted)] italic">No field mappings configured. Add one above.</p>
                            ) : (
                                <div className="border border-[var(--color-border)] rounded-md overflow-hidden bg-[#fbfbfc] dark:bg-transparent">
                                    <table className="w-full text-left text-sm whitespace-nowrap">
                                        <thead className="bg-[#f0f1f3] dark:bg-[#1f2937] border-b border-[var(--color-border)]">
                                            <tr>
                                                <th className="p-3 font-semibold text-xs tracking-wider uppercase text-[var(--color-text-muted)]">Product Field</th>
                                                <th className="p-3 font-semibold text-xs tracking-wider uppercase text-[var(--color-text-muted)]">CSS Selector</th>
                                                <th className="p-3 font-semibold text-xs tracking-wider uppercase text-[var(--color-text-muted)]">Join Delimiter</th>
                                                <th className="p-3 font-semibold text-xs tracking-wider uppercase text-[var(--color-text-muted)]">Extract Type</th>
                                                <th className="p-3 font-semibold text-xs tracking-wider uppercase text-[var(--color-text-muted)]">Attributes</th>
                                                <th className="p-3 text-right"></th>
                                            </tr>
                                        </thead>
                                        <tbody className="divide-y divide-[var(--color-border)]">
                                            {fieldMappings.map((mapping, i) => (
                                                <tr key={i} className="hover:bg-black/[0.02] dark:hover:bg-white/[0.02] transition-colors">
                                                    <td className="p-2">
                                                        <input
                                                            type="text"
                                                            list="common-fields"
                                                            className="form-input w-full min-w-[120px] text-sm py-2 px-3 bg-white border border-[#cbd5e1] rounded shadow-sm focus:border-[var(--color-primary)] focus:ring-[var(--color-primary)] dark:bg-[#111827] dark:border-gray-700"
                                                            value={mapping.field}
                                                            onChange={e => updateFieldMapping(i, 'field', e.target.value)}
                                                            placeholder="e.g. name"
                                                            required
                                                        />
                                                    </td>
                                                    <td className="p-2">
                                                        <input
                                                            type="text"
                                                            className="form-input w-full min-w-[140px] font-mono text-sm py-2 px-3 bg-white border border-[#cbd5e1] rounded shadow-sm focus:border-[var(--color-primary)] focus:ring-[var(--color-primary)] dark:bg-[#111827] dark:border-gray-700"
                                                            value={mapping.selector}
                                                            onChange={e => updateFieldMapping(i, 'selector', e.target.value)}
                                                            placeholder="e.g. h1.title"
                                                            required
                                                        />
                                                    </td>
                                                    <td className="p-2">
                                                        <select
                                                            className="form-select w-full min-w-[100px] text-sm py-2 px-3 bg-white border border-[#cbd5e1] rounded shadow-sm focus:border-[var(--color-primary)] focus:ring-[var(--color-primary)] dark:bg-[#111827] dark:border-gray-700"
                                                            value={mapping.delimiter}
                                                            onChange={e => updateFieldMapping(i, 'delimiter', e.target.value)}
                                                        >
                                                            <option value=" ">Space</option>
                                                            <option value=",">Comma</option>
                                                            <option value="\n">New Line</option>
                                                            <option value="">None</option>
                                                        </select>
                                                    </td>
                                                    <td className="p-2">
                                                        <select
                                                            className="form-select w-full min-w-[110px] text-sm py-2 px-3 bg-white border border-[#cbd5e1] rounded shadow-sm focus:border-[var(--color-primary)] focus:ring-[var(--color-primary)] dark:bg-[#111827] dark:border-gray-700"
                                                            value={mapping.extractType}
                                                            onChange={e => updateFieldMapping(i, 'extractType', e.target.value as any)}
                                                        >
                                                            <option value="Text">Text</option>
                                                            <option value="HTML">HTML</option>
                                                            <option value="Attribute">Attribute</option>
                                                            <option value="Property">Property</option>
                                                        </select>
                                                    </td>
                                                    <td className="p-2">
                                                        {(mapping.extractType === 'Attribute' || mapping.extractType === 'Property') ? (
                                                            <input
                                                                type="text"
                                                                className="form-input w-full min-w-[120px] font-mono text-sm py-2 px-3 bg-white border border-[#cbd5e1] rounded shadow-sm focus:border-[var(--color-primary)] focus:ring-[var(--color-primary)] dark:bg-[#111827] dark:border-gray-700"
                                                                value={mapping.extractValue}
                                                                onChange={e => updateFieldMapping(i, 'extractValue', e.target.value)}
                                                                placeholder={mapping.extractType === 'Attribute' ? "src" : "baseURI"}
                                                                required
                                                            />
                                                        ) : (
                                                            <div className="text-[var(--color-text-muted)] text-sm italic px-2 py-2 flex items-center justify-center bg-gray-50 dark:bg-white/5 rounded border border-transparent">
                                                                Not needed
                                                            </div>
                                                        )}
                                                    </td>
                                                    <td className="p-2 text-right align-middle">
                                                        <div className="flex gap-1.5 items-center justify-end px-1">
                                                            <button type="button" onClick={() => {
                                                                const newRow = { ...mapping };
                                                                const updated = [...fieldMappings];
                                                                updated.splice(i + 1, 0, newRow);
                                                                setFieldMappings(updated);
                                                            }} className="w-8 h-8 flex-shrink-0 shadow-sm bg-white rounded-full border border-[#cbd5e1] text-[#6b7280] hover:bg-[#eff6ff] hover:text-[#3b82f6] hover:border-[#3b82f6] flex items-center justify-center transition-all dark:bg-[#1f2937] dark:border-gray-600 dark:text-gray-300" title="Add Row below">
                                                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line></svg>
                                                            </button>
                                                            <button type="button" onClick={() => removeFieldMapping(i)} className="w-8 h-8 flex-shrink-0 shadow-sm bg-white rounded-full border border-[#cbd5e1] text-[#6b7280] hover:bg-[#fee2e2] hover:text-[#ef4444] hover:border-[#ef4444] flex items-center justify-center transition-all dark:bg-[#1f2937] dark:border-gray-600 dark:text-gray-300" title="Remove Row">
                                                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><line x1="5" y1="12" x2="19" y2="12"></line></svg>
                                                            </button>
                                                        </div>
                                                    </td>
                                                </tr>
                                            ))}
                                        </tbody>
                                    </table>
                                    <datalist id="common-fields">
                                        {COMMON_FIELDS.map(f => <option key={f} value={f} />)}
                                    </datalist>
                                </div>
                            )}
                        </div>
                    </div>
                )}

                <div>
                    <label className="block text-sm font-semibold mb-2">Developer Notes / Exclusions</label>
                    <textarea
                        className="form-input w-full"
                        rows={3}
                        value={notes}
                        onChange={e => setNotes(e.target.value)}
                    />
                </div>
            </div>

            <div className="flex justify-between items-center pt-6 mb-8 border-t border-[var(--color-border)]">
                {!isNew ? (
                    <button
                        type="button"
                        className="btn btn-secondary px-6"
                        onClick={async () => {
                            try {
                                const res = await fetch('/api/scraper', {
                                    method: 'POST',
                                    headers: { 'Content-Type': 'application/json' },
                                    body: JSON.stringify({ scraperConfigId: config.id }),
                                });
                                if (!res.ok) throw new Error('Failed to run scraper');
                                alert('Scrape job started in the background!');
                                router.push('/admin/scraper');
                            } catch (err: any) {
                                alert(err.message);
                            }
                        }}
                    >
                        🤖 Run Scraper Now
                    </button>
                ) : (
                    <div></div>
                )}
                <button type="submit" className="btn btn-primary px-8" disabled={isSaving}>
                    {isSaving ? 'Saving...' : 'Save Configuration'}
                </button>
            </div>
            {saveStatus === 'error' && (
                <div style={{
                    background: 'var(--color-error-bg, #fef2f2)',
                    border: '1px solid var(--color-error, #ef4444)',
                    borderRadius: '8px',
                    padding: '1rem 1.25rem',
                    color: 'var(--color-error, #dc2626)',
                    fontSize: '14px',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '0.5rem'
                }}>
                    ⚠️ {saveError}
                </div>
            )}
        </form>
    );
}
