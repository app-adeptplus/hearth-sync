import prisma from '@/lib/db';
import { notFound } from 'next/navigation';
import Link from 'next/link';
import EditScraperClient from './EditScraperClient';

export default async function ScraperConfigPage({
    params,
    searchParams
}: {
    params: { id: string };
    searchParams: { from?: string };
}) {
    const isNew = params.id === 'new';
    const from = searchParams.from || 'PRODUCT_LIST';

    let config = null;
    if (!isNew) {
        config = await prisma.scraperConfig.findUnique({
            where: { id: parseInt(params.id) },
            include: {
                brand: { select: { name: true } },
                defaultCategories: true
            }
        });
        if (!config) return notFound();
    }

    const allCategories = await prisma.productCategory.findMany({
        orderBy: [{ parentId: 'asc' }, { sortOrder: 'asc' }, { name: 'asc' }]
    });

    // Only fetch brands when relevant: new configs (any type might be created) or editing a Category config
    const needsBrands = isNew || config?.type === 'CATEGORY';
    const allBrands = needsBrands
        ? await prisma.brand.findMany({ orderBy: { name: 'asc' } })
        : [];

    const tabLabels: Record<string, string> = {
        CATEGORY: 'Categories',
        PRODUCT_LIST: 'Product Lists',
        PRODUCT_PAGE: 'Product Pages',
        WORKFLOW: 'Workflows',
        HISTORY: 'Job History',
    };

    return (
        <div className="max-w-4xl mx-auto space-y-6">
            <div className="page-header pb-6 border-b border-[var(--color-border)]">
                <div>
                    <Link
                        href={`/admin/scraper?tab=${from}`}
                        className="text-sm text-[var(--color-text-muted)] mb-2 block"
                    >
                        ← Back to {tabLabels[from] || 'Scrapers'}
                    </Link>
                    <h2 className="text-2xl font-bold">
                        {isNew
                            ? 'New Scraper Configuration'
                            : `${config?.name} Scraper Configuration`}
                    </h2>
                    <p className="text-[var(--color-text-secondary)] mt-1">
                        {isNew
                            ? 'Create a new ingestion configuration'
                            : 'Manage ingestion settings'}
                    </p>
                </div>
            </div>

            <EditScraperClient
                config={config}
                allCategories={allCategories}
                allBrands={allBrands}
                isNew={isNew}
                from={from}
            />
        </div>
    );
}
