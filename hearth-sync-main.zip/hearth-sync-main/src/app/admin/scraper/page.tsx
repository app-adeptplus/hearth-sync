import { Suspense } from 'react';
import prisma from '@/lib/db';
import ScraperDashboardClient from './ScraperDashboardClient';

async function getScraperData() {
    try {
        const [jobs, configs, workflows] = await Promise.all([
            prisma.scraperJob.findMany({
                take: 50,
                orderBy: { createdAt: 'desc' },
                include: {
                    scraperConfig: {
                        include: { brand: { select: { name: true, manufacturer: { select: { name: true } } } } },
                    },
                },
            }),
            prisma.scraperConfig.findMany({
                include: { brand: { select: { name: true } } },
                orderBy: { brand: { name: 'asc' } },
            }),
            prisma.scraperWorkflow.findMany({
                include: { brand: { select: { name: true } } },
                orderBy: { name: 'asc' }
            })
        ]);
        return { jobs, configs, workflows };
    } catch {
        return { jobs: [], configs: [], workflows: [] };
    }
}

export default async function ScraperPage() {
    const { jobs, configs, workflows } = await getScraperData();

    return (
        <Suspense fallback={<div className="p-6">Loading...</div>}>
            <ScraperDashboardClient jobs={jobs} configs={configs} workflows={workflows} />
        </Suspense>
    );
}
