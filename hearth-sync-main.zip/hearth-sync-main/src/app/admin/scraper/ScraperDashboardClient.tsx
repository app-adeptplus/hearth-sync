'use client';

import { useRouter, useSearchParams } from 'next/navigation';
import Link from 'next/link';
import JobHistoryClient from './JobHistoryClient';

type TabType = 'CATEGORY' | 'PRODUCT_LIST' | 'PRODUCT_PAGE' | 'WORKFLOW' | 'HISTORY';

interface ScraperDashboardClientProps {
    jobs: any[];
    configs: any[];
    workflows: any[];
    initialTab?: TabType;
}

export default function ScraperDashboardClient({ jobs, configs, workflows, initialTab }: ScraperDashboardClientProps) {
    const router = useRouter();
    const searchParams = useSearchParams();
    const activeTab: TabType = (searchParams.get('tab') as TabType) || initialTab || 'CATEGORY';

    const setTab = (tab: TabType) => {
        router.push(`/admin/scraper?tab=${tab}`);
    };

    const filteredConfigs = configs.filter(c => c.type === activeTab);

    const tabLabel: Record<TabType, string> = {
        CATEGORY: 'Category',
        PRODUCT_LIST: 'Product List',
        PRODUCT_PAGE: 'Product Page',
        WORKFLOW: 'Workflow',
        HISTORY: 'History',
    };

    return (
        <>
            <div className="page-header">
                <div>
                    <h2 className="page-title">Scraper Jobs</h2>
                    <p className="page-subtitle">
                        {configs.length} configs · {workflows.length} workflows
                    </p>
                </div>
                <div style={{ display: 'flex', gap: 'var(--space-3)' }}>
                    {activeTab === 'WORKFLOW' ? (
                        <Link href="/admin/scraper/workflows/new" className="btn btn-primary" style={{ textDecoration: 'none' }}>
                            ➕ New Workflow
                        </Link>
                    ) : activeTab !== 'HISTORY' ? (
                        <Link
                            href={`/admin/scraper/new?from=${activeTab}`}
                            className="btn btn-primary"
                            style={{ textDecoration: 'none' }}
                        >
                            ➕ New Config
                        </Link>
                    ) : null}
                </div>
            </div>

            {/* Tabs */}
            <div style={{
                display: 'flex',
                gap: 'var(--space-2)',
                marginBottom: 'var(--space-6)',
                borderBottom: '1px solid var(--color-border)',
                paddingBottom: 'var(--space-3)',
                overflowX: 'auto'
            }}>
                <button
                    className={`btn ${activeTab === 'CATEGORY' ? 'btn-primary' : 'btn-ghost'}`}
                    onClick={() => setTab('CATEGORY')}
                >
                    📂 Categories
                </button>
                <button
                    className={`btn ${activeTab === 'PRODUCT_LIST' ? 'btn-primary' : 'btn-ghost'}`}
                    onClick={() => setTab('PRODUCT_LIST')}
                >
                    📋 Product Lists
                </button>
                <button
                    className={`btn ${activeTab === 'PRODUCT_PAGE' ? 'btn-primary' : 'btn-ghost'}`}
                    onClick={() => setTab('PRODUCT_PAGE')}
                >
                    📄 Product Pages
                </button>
                <button
                    className={`btn ${activeTab === 'WORKFLOW' ? 'btn-primary' : 'btn-ghost'}`}
                    onClick={() => setTab('WORKFLOW')}
                >
                    🔗 Workflows
                </button>
                <button
                    className={`btn ${activeTab === 'HISTORY' ? 'btn-primary' : 'btn-ghost'}`}
                    onClick={() => setTab('HISTORY')}
                >
                    🕒 Job History
                </button>
            </div>

            {/* Active Content */}
            {activeTab === 'CATEGORY' || activeTab === 'PRODUCT_LIST' || activeTab === 'PRODUCT_PAGE' ? (
                <div id="configs" className="card" style={{ marginBottom: 'var(--space-6)' }}>
                    <div className="card-header">
                        <h3 className="card-title">
                            {tabLabel[activeTab]} Scrapers
                        </h3>
                    </div>
                    {filteredConfigs.length === 0 ? (
                        <div className="empty-state" style={{ padding: 'var(--space-6) 0' }}>
                            <p>No {tabLabel[activeTab]} configs found.</p>
                        </div>
                    ) : (
                        <div className="data-table" style={{ width: '100%', textAlign: 'left', borderCollapse: 'collapse' }}>
                            <table style={{ width: '100%' }}>
                                <thead>
                                    <tr style={{ borderBottom: '1px solid var(--color-border)' }}>
                                        <th style={{ padding: 'var(--space-2)' }}>Name</th>
                                        {activeTab === 'CATEGORY' && (
                                            <th style={{ padding: 'var(--space-2)' }}>Brand</th>
                                        )}
                                        <th style={{ padding: 'var(--space-2)' }}>Base URL</th>
                                        <th style={{ padding: 'var(--space-2)' }}>Status</th>
                                        <th style={{ padding: 'var(--space-2)' }}>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {filteredConfigs.map((config: any) => (
                                        <tr key={config.id} style={{ borderBottom: '1px solid var(--color-border-light)' }}>
                                            <td style={{ padding: 'var(--space-3) var(--space-2)' }}>
                                                <div style={{ fontWeight: 600, color: 'var(--color-text-primary)' }}>{config.name || 'Unnamed Scraper'}</div>
                                                <div style={{ fontSize: '11px', color: 'var(--color-text-muted)', fontFamily: 'monospace' }}>#{config.id}</div>
                                            </td>
                                            {activeTab === 'CATEGORY' && (
                                                <td style={{ padding: 'var(--space-3) var(--space-2)', fontWeight: 500 }}>{config.brand?.name || '—'}</td>
                                            )}
                                            <td style={{ padding: 'var(--space-3) var(--space-2)', color: 'var(--color-text-muted)', fontSize: '13px' }}>
                                                {config.baseUrl || 'Dynamic Integration'}
                                            </td>
                                            <td style={{ padding: 'var(--space-3) var(--space-2)' }}>
                                                <span className={`badge ${config.isActive ? 'badge-active' : 'badge-inactive'}`}>
                                                    {config.isActive ? 'Active' : 'Paused'}
                                                </span>
                                            </td>
                                            <td style={{ padding: 'var(--space-3) var(--space-2)' }}>
                                                <Link
                                                    href={`/admin/scraper/${config.id}?from=${activeTab}`}
                                                    className="btn btn-sm btn-secondary"
                                                >
                                                    Edit
                                                </Link>
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    )}
                </div>
            ) : activeTab === 'WORKFLOW' ? (
                <div id="workflows" className="card" style={{ marginBottom: 'var(--space-6)' }}>
                    <div className="card-header">
                        <h3 className="card-title">Scraper Workflows</h3>
                    </div>
                    {workflows.length === 0 ? (
                        <div className="empty-state" style={{ padding: 'var(--space-6) 0' }}>
                            <p>No workflows have been created yet.</p>
                        </div>
                    ) : (
                        <div className="data-table" style={{ width: '100%', textAlign: 'left', borderCollapse: 'collapse' }}>
                            <table style={{ width: '100%' }}>
                                <thead>
                                    <tr style={{ borderBottom: '1px solid var(--color-border)' }}>
                                        <th style={{ padding: 'var(--space-2)' }}>Name</th>
                                        <th style={{ padding: 'var(--space-2)' }}>Brand</th>
                                        <th style={{ padding: 'var(--space-2)' }}>Status</th>
                                        <th style={{ padding: 'var(--space-2)' }}>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {workflows.map((wf: any) => (
                                        <tr key={wf.id} style={{ borderBottom: '1px solid var(--color-border-light)' }}>
                                            <td style={{ padding: 'var(--space-3) var(--space-2)' }}>{wf.name}</td>
                                            <td style={{ padding: 'var(--space-3) var(--space-2)' }}>{wf.brand?.name}</td>
                                            <td style={{ padding: 'var(--space-3) var(--space-2)' }}>
                                                <span className={`badge ${wf.isActive ? 'badge-active' : 'badge-inactive'}`}>
                                                    {wf.isActive ? 'Active' : 'Inactive'}
                                                </span>
                                            </td>
                                            <td style={{ padding: 'var(--space-3) var(--space-2)' }}>
                                                <Link href={`/admin/scraper/workflows/${wf.id}`} className="btn btn-sm btn-secondary">
                                                    Edit
                                                </Link>
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    )}
                </div>
            ) : activeTab === 'HISTORY' ? (
                <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
                    <div style={{ padding: 'var(--space-6)', borderBottom: '1px solid var(--color-border)' }}>
                        <h3 className="card-title">Job History</h3>
                    </div>
                    <JobHistoryClient initialJobs={jobs} />
                </div>
            ) : null}
        </>
    );
}
