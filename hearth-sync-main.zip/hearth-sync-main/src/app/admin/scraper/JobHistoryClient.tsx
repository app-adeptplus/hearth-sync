"use client";

import { useEffect, useState } from "react";

const statusStyles: Record<string, string> = {
    PENDING: 'warning',
    RUNNING: 'info',
    COMPLETED: 'active',
    FAILED: 'danger',
    CANCELLED: 'inactive',
};

export default function JobHistoryClient({ initialJobs }: { initialJobs: any[] }) {
    const [jobs, setJobs] = useState(initialJobs);

    useEffect(() => {
        const interval = setInterval(async () => {
            try {
                const res = await fetch('/api/scraper');
                if (res.ok) {
                    const data = await res.json();
                    setJobs(data.data);
                }
            } catch (err) {
                console.error("Failed to fetch jobs polling:", err);
            }
        }, 5000);
        return () => clearInterval(interval);
    }, []);

    return (
        <table className="data-table">
            <thead>
                <tr>
                    <th>Brand</th>
                    <th>Status</th>
                    <th>Found</th>
                    <th>Added</th>
                    <th>Updated</th>
                    <th>Removed</th>
                    <th>Started</th>
                    <th>Duration</th>
                </tr>
            </thead>
            <tbody>
                {jobs.length === 0 ? (
                    <tr>
                        <td colSpan={8}>
                            <div className="empty-state">
                                <h3>No scraper jobs yet</h3>
                                <p>Click &quot;New Scrape Job&quot; to run your first scraper.</p>
                            </div>
                        </td>
                    </tr>
                ) : (
                    jobs.map((job: any) => {
                        const duration = job.startedAt && job.completedAt
                            ? Math.round((new Date(job.completedAt).getTime() - new Date(job.startedAt).getTime()) / 1000)
                            : null;
                        return (
                            <tr key={job.id}>
                                <td style={{ fontWeight: 500 }}>
                                    {job.scraperConfig?.brand?.name || 'Unknown Brand'}
                                    <div style={{ fontSize: 'var(--font-size-xs)', color: 'var(--color-text-muted)' }}>
                                        {job.scraperConfig?.brand?.manufacturer?.name || 'Unknown Manufacturer'}
                                    </div>
                                </td>
                                <td>
                                    <span className={`badge badge-${statusStyles[job.status]}`}>
                                        {job.status}
                                    </span>
                                </td>
                                <td>{job.productsFound}</td>
                                <td style={{ color: 'var(--color-success)' }}>+{job.productsAdded}</td>
                                <td style={{ color: 'var(--color-info)' }}>~{job.productsUpdated}</td>
                                <td style={{ color: 'var(--color-danger)' }}>-{job.productsRemoved}</td>
                                <td style={{ fontSize: 'var(--font-size-xs)', color: 'var(--color-text-muted)' }}>
                                    {job.startedAt ? new Date(job.startedAt).toLocaleString() : '—'}
                                </td>
                                <td style={{ fontSize: 'var(--font-size-xs)' }}>
                                    {duration !== null ? `${duration}s` : '—'}
                                </td>
                            </tr>
                        );
                    })
                )}
            </tbody>
        </table>
    );
}
