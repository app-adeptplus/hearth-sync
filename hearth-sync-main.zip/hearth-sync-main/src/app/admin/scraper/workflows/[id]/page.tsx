import prisma from '@/lib/db';
import { notFound } from 'next/navigation';
import EditWorkflowClient from './EditWorkflowClient';

export default async function EditWorkflowPage({ params }: { params: { id: string } }) {
    if (params.id !== 'new') {
        const workflow = await prisma.scraperWorkflow.findUnique({
            where: { id: params.id },
            include: { brand: true },
        });

        if (!workflow) return notFound();

        const allConfigs = await prisma.scraperConfig.findMany({
            where: { brandId: workflow.brandId }
        });

        return <EditWorkflowClient initialWorkflow={workflow} availableConfigs={allConfigs} />;
    }

    // Creating a new Workflow - fetch all active configs
    const allActiveConfigs = await prisma.scraperConfig.findMany({
        where: { isActive: true },
        include: { brand: true },
        orderBy: { brand: { name: 'asc' } }
    });

    return <EditWorkflowClient availableConfigs={allActiveConfigs} />;
}
