'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';

export default function EditWorkflowClient({
    initialWorkflow,
    availableConfigs
}: {
    initialWorkflow?: any,
    availableConfigs: any[]
}) {
    const router = useRouter();
    const [name, setName] = useState(initialWorkflow?.name || '');
    const [isActive, setIsActive] = useState(initialWorkflow?.isActive ?? true);

    // Step Selection
    const [categoryConfigId, setCategoryConfigId] = useState(initialWorkflow?.categoryConfigId || '');
    const [productListConfigId, setProductListConfigId] = useState(initialWorkflow?.productListConfigId || '');
    const [productPageConfigId, setProductPageConfigId] = useState(initialWorkflow?.productPageConfigId || '');

    const [isSaving, setIsSaving] = useState(false);
    const [error, setError] = useState('');

    const categoriesConfigs = availableConfigs.filter(c => c.type === 'CATEGORY');
    const productListConfigs = availableConfigs.filter(c => c.type === 'PRODUCT_LIST');
    const productPageConfigs = availableConfigs.filter(c => c.type === 'PRODUCT_PAGE');

    const handleSave = async () => {
        setIsSaving(true);
        setError('');

        try {
            const method = initialWorkflow ? 'PUT' : 'POST';
            const url = initialWorkflow
                ? `/api/scraper/workflows/${initialWorkflow.id}`
                : '/api/scraper/workflows';

            // Just passing the brandId from the first config selected, or needing a generic brand picker for 'new' workflows.
            // Assuming this form is only accessed from existing config pages or we pass brandId some other way if new.
            // For now, require at least one config to be picked to inherit brandId if making a new one.
            const brandId = initialWorkflow?.brandId ||
                availableConfigs.find(c => c.id === categoryConfigId || c.id === productListConfigId)?.brandId;

            if (!brandId) throw new Error('Cannot determine Brand. Please select at least one configuration.');

            const payload = {
                name,
                brandId,
                isActive,
                categoryConfigId: categoryConfigId || null,
                productListConfigId: productListConfigId || null,
                productPageConfigId: productPageConfigId || null
            };

            const res = await fetch(url, {
                method,
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload)
            });

            if (!res.ok) {
                const data = await res.json();
                throw new Error(data.message || 'Failed to save workflow');
            }

            router.push('/admin/scraper');
            router.refresh();
        } catch (err: any) {
            setError(err.message);
        } finally {
            setIsSaving(false);
        }
    };

    return (
        <div className="card">
            <div className="card-header">
                <h3 className="card-title">{initialWorkflow ? 'Edit Workflow' : 'Create New Workflow'}</h3>
            </div>
            {error && (
                <div className="form-group">
                    <p style={{ color: 'var(--color-danger)' }}>{error}</p>
                </div>
            )}
            <div className="form-group">
                <label className="form-label">Workflow Name</label>
                <input
                    type="text"
                    className="form-input"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="e.g. Weekly Woodard Sync"
                />
            </div>

            <div className="form-group" style={{ display: 'flex', alignItems: 'center', gap: 'var(--space-2)' }}>
                <input
                    type="checkbox"
                    id="isActive"
                    checked={isActive}
                    onChange={(e) => setIsActive(e.target.checked)}
                />
                <label htmlFor="isActive" style={{ margin: 0 }}>Active Workflow Configuration</label>
            </div>

            <div style={{ marginTop: 'var(--space-6)', marginBottom: 'var(--space-4)' }}>
                <h4>Workflow Steps</h4>
                <p className="page-subtitle" style={{ marginBottom: 'var(--space-4)' }}>
                    Chain your scraper configurations together. The output of one step is fed into the next step.
                </p>

                <div className="form-group" style={{ padding: 'var(--space-4)', border: '1px solid var(--color-border)', borderRadius: 'var(--radius-md)', background: 'var(--color-bg-elevated)' }}>
                    <label className="form-label">Step 1: Categories Scraper</label>
                    <select
                        className="form-select"
                        value={categoryConfigId}
                        onChange={(e) => setCategoryConfigId(e.target.value)}
                    >
                        <option value="">-- Skip this step --</option>
                        {categoriesConfigs.map(c => (
                            <option key={c.id} value={c.id}>{c.brand.name} (ID: {c.id})</option>
                        ))}
                    </select>
                    <p className="page-subtitle" style={{ fontSize: '12px', marginTop: 'var(--space-2)' }}>Scrapes category links to feed into Step 2.</p>
                </div>

                <div className="form-group" style={{ padding: 'var(--space-4)', border: '1px solid var(--color-border)', borderRadius: 'var(--radius-md)', background: 'var(--color-bg-elevated)' }}>
                    <label className="form-label">Step 2: Product List Scraper</label>
                    <select
                        className="form-select"
                        value={productListConfigId}
                        onChange={(e) => setProductListConfigId(e.target.value)}
                    >
                        <option value="">-- Skip this step --</option>
                        {productListConfigs.map(c => (
                            <option key={c.id} value={c.id}>{c.brand.name} (ID: {c.id})</option>
                        ))}
                    </select>
                    <p className="page-subtitle" style={{ fontSize: '12px', marginTop: 'var(--space-2)' }}>Scrapes product cards. Creates basic records and feeds product links into Step 3.</p>
                </div>

                <div className="form-group" style={{ padding: 'var(--space-4)', border: '1px solid var(--color-border)', borderRadius: 'var(--radius-md)', background: 'var(--color-bg-elevated)' }}>
                    <label className="form-label">Step 3: Product Page Scraper</label>
                    <select
                        className="form-select"
                        value={productPageConfigId}
                        onChange={(e) => setProductPageConfigId(e.target.value)}
                    >
                        <option value="">-- Skip this step --</option>
                        {productPageConfigs.map(c => (
                            <option key={c.id} value={c.id}>{c.brand.name} (ID: {c.id})</option>
                        ))}
                    </select>
                    <p className="page-subtitle" style={{ fontSize: '12px', marginTop: 'var(--space-2)' }}>Deep scrape of product details to complete records.</p>
                </div>
            </div>

            <div style={{ display: 'flex', gap: 'var(--space-4)', marginTop: 'var(--space-6)' }}>
                <button
                    type="button"
                    className="btn btn-primary"
                    onClick={handleSave}
                    disabled={isSaving}
                >
                    {isSaving ? 'Saving...' : '💾 Save Workflow'}
                </button>
                <button
                    type="button"
                    className="btn btn-secondary"
                    onClick={() => router.push('/admin/scraper')}
                >
                    Cancel
                </button>
            </div>
        </div>
    );
}
