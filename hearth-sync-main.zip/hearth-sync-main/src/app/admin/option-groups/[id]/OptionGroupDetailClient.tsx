"use client";

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import Modal from '@/components/Modal';
import ConfirmDialog from '@/components/ui/ConfirmDialog';

export default function OptionGroupDetailClient({ group }: { group: any }) {
    const router = useRouter();

    // ── Option form state ─────────────────────────────────────────────────────
    const [optionModal, setOptionModal] = useState<any | null>(null); // null = closed, {} = new, option = edit
    const [optLabel, setOptLabel] = useState('');
    const [optValue, setOptValue] = useState('');
    const [optDesc, setOptDesc] = useState('');
    const [optPrice, setOptPrice] = useState('');
    const [optSwatch, setOptSwatch] = useState('');
    const [optDefault, setOptDefault] = useState(false);
    const [optActive, setOptActive] = useState(true);
    const [optSort, setOptSort] = useState('0');
    const [isSavingOpt, setIsSavingOpt] = useState(false);

    // ── Delete option state ───────────────────────────────────────────────────
    const [confirmDeleteOpt, setConfirmDeleteOpt] = useState<{ id: string; label: string } | null>(null);
    const [isDeletingOpt, setIsDeletingOpt] = useState(false);

    const isAddingOpt = optionModal && !optionModal.id;

    const openAddOption = () => {
        setOptionModal({});
        setOptLabel(''); setOptValue(''); setOptDesc(''); setOptPrice('');
        setOptSwatch(''); setOptDefault(false); setOptActive(true); setOptSort('0');
    };

    const openEditOption = (opt: any) => {
        setOptionModal(opt);
        setOptLabel(opt.label); setOptValue(opt.value); setOptDesc(opt.description || '');
        setOptPrice(opt.priceAdjust != null ? opt.priceAdjust.toString() : '');
        setOptSwatch(opt.swatchColor || ''); setOptDefault(opt.isDefault); setOptActive(opt.isActive);
        setOptSort(opt.sortOrder?.toString() || '0');
    };

    const closeOptModal = () => setOptionModal(null);

    const saveOption = async () => {
        if (!optLabel.trim()) { alert('Label is required'); return; }
        setIsSavingOpt(true);
        try {
            const payload = {
                label: optLabel, value: optValue || optLabel,
                description: optDesc || null,
                priceAdjust: optPrice !== '' ? parseFloat(optPrice) : null,
                swatchColor: optSwatch || null, isDefault: optDefault, isActive: optActive,
                sortOrder: parseInt(optSort) || 0,
            };
            const url = isAddingOpt
                ? `/api/option-groups/${group.id}/options`
                : `/api/option-groups/${group.id}/options/${optionModal.id}`;
            const res = await fetch(url, {
                method: isAddingOpt ? 'POST' : 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload),
            });
            if (!res.ok) { const d = await res.json(); throw new Error(d.error || 'Failed to save'); }
            router.refresh(); closeOptModal();
        } catch (err: any) { alert(err.message); } finally { setIsSavingOpt(false); }
    };

    const deleteOption = async () => {
        if (!confirmDeleteOpt) return;
        setIsDeletingOpt(true);
        try {
            const res = await fetch(`/api/option-groups/${group.id}/options/${confirmDeleteOpt.id}`, { method: 'DELETE' });
            if (!res.ok) { const d = await res.json(); throw new Error(d.error || 'Failed to delete'); }
            router.refresh();
        } catch (err: any) { alert(err.message); } finally { setIsDeletingOpt(false); setConfirmDeleteOpt(null); }
    };

    return (
        <>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr minmax(0, 300px)', gap: '1.5rem', alignItems: 'start' }}>
                {/* Options list */}
                <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
                    <div style={{ padding: 'var(--space-4)', borderBottom: '1px solid var(--color-border)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                        <div>
                            <h3 className="card-title text-lg font-semibold">Options</h3>
                            <p style={{ fontSize: '12px', color: 'var(--color-text-muted)', marginTop: '2px' }}>
                                Buyer-selectable choices for this group
                            </p>
                        </div>
                        <button className="btn btn-primary btn-sm" onClick={openAddOption}>+ Add Option</button>
                    </div>
                    <table className="data-table">
                        <thead>
                            <tr>
                                <th>Label</th>
                                <th>Value</th>
                                <th>Price Δ</th>
                                <th>Swatch</th>
                                <th style={{ textAlign: 'center' }}>Flags</th>
                                <th style={{ textAlign: 'right' }}>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            {group.options.map((opt: any) => (
                                <tr key={opt.id} style={{ opacity: opt.isActive ? 1 : 0.5 }}>
                                    <td style={{ fontWeight: 500, paddingLeft: 'var(--space-4)' }}>
                                        {opt.label}
                                        {opt.description && (
                                            <div style={{ fontSize: '11px', color: 'var(--color-text-muted)' }}>{opt.description}</div>
                                        )}
                                    </td>
                                    <td style={{ fontFamily: 'monospace', fontSize: '12px', color: 'var(--color-text-secondary)' }}>{opt.value}</td>
                                    <td style={{ fontSize: '13px', color: opt.priceAdjust > 0 ? 'var(--color-success)' : opt.priceAdjust < 0 ? 'var(--color-danger)' : 'var(--color-text-muted)' }}>
                                        {opt.priceAdjust != null
                                            ? `${opt.priceAdjust > 0 ? '+' : ''}$${Number(opt.priceAdjust).toFixed(2)}`
                                            : '—'}
                                    </td>
                                    <td>
                                        {opt.swatchColor ? (
                                            <span style={{ display: 'inline-block', width: '20px', height: '20px', borderRadius: '4px', background: opt.swatchColor, border: '1px solid var(--color-border)', verticalAlign: 'middle' }} title={opt.swatchColor} />
                                        ) : '—'}
                                    </td>
                                    <td style={{ textAlign: 'center' }}>
                                        <div style={{ display: 'flex', gap: '4px', justifyContent: 'center' }}>
                                            {opt.isDefault && <span style={{ fontSize: '10px', background: 'var(--color-primary)', color: 'white', padding: '1px 6px', borderRadius: '8px', fontWeight: 600 }}>Default</span>}
                                            {!opt.isActive && <span style={{ fontSize: '10px', background: 'var(--color-bg-elevated)', color: 'var(--color-text-muted)', padding: '1px 6px', borderRadius: '8px', border: '1px solid var(--color-border)' }}>Inactive</span>}
                                        </div>
                                    </td>
                                    <td style={{ textAlign: 'right', whiteSpace: 'nowrap' }}>
                                        <button className="btn btn-sm btn-ghost" onClick={() => openEditOption(opt)}>Edit</button>
                                        <button
                                            className="btn btn-sm btn-ghost" style={{ color: 'var(--color-danger)', marginLeft: '4px' }}
                                            onClick={() => setConfirmDeleteOpt({ id: opt.id, label: opt.label })}
                                        >✕</button>
                                    </td>
                                </tr>
                            ))}
                            {group.options.length === 0 && (
                                <tr>
                                    <td colSpan={6} style={{ padding: '2rem', textAlign: 'center', color: 'var(--color-text-muted)' }}>
                                        No options yet. Click "+ Add Option" to get started.
                                    </td>
                                </tr>
                            )}
                        </tbody>
                    </table>
                </div>

                {/* Products using this group */}
                <div className="card p-5">
                    <h3 className="font-semibold mb-3 pb-2 border-b border-[var(--color-border)]">
                        Products Using This Group
                    </h3>
                    {group.productLinks.length === 0 ? (
                        <p style={{ fontSize: '13px', color: 'var(--color-text-muted)', fontStyle: 'italic' }}>
                            Not yet assigned to any product.
                        </p>
                    ) : (
                        <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
                            {group.productLinks.map((link: any) => (
                                <Link
                                    key={link.id}
                                    href={`/admin/products/${link.product.id}`}
                                    style={{ fontSize: '13px', color: 'var(--color-primary)', textDecoration: 'none', padding: '4px 0' }}
                                >
                                    {link.product.name}
                                    {link.product.modelNumber && (
                                        <span style={{ fontSize: '11px', color: 'var(--color-text-muted)', marginLeft: '6px' }}>
                                            {link.product.modelNumber}
                                        </span>
                                    )}
                                </Link>
                            ))}
                        </div>
                    )}
                </div>
            </div>

            {/* Add/Edit Option Modal */}
            <Modal
                isOpen={!!optionModal}
                onClose={closeOptModal}
                title={isAddingOpt ? 'Add Option' : 'Edit Option'}
                subtitle={isAddingOpt ? `Adding to "${group.name}"` : optionModal?.label}
                size="md"
                footer={
                    <div style={{ display: 'flex', justifyContent: 'space-between', width: '100%' }}>
                        {!isAddingOpt && optionModal?.id ? (
                            <button type="button" className="btn btn-ghost" style={{ color: 'var(--color-danger)' }}
                                onClick={() => { closeOptModal(); setConfirmDeleteOpt({ id: optionModal.id, label: optLabel }); }}
                            >Delete</button>
                        ) : <div />}
                        <div style={{ display: 'flex', gap: '0.5rem' }}>
                            <button type="button" className="btn btn-secondary" onClick={closeOptModal}>Cancel</button>
                            <button type="button" className="btn btn-primary" onClick={saveOption} disabled={isSavingOpt}>
                                {isSavingOpt ? 'Saving…' : 'Save'}
                            </button>
                        </div>
                    </div>
                }
            >
                <div style={{ padding: '1.5rem', display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
                        <div>
                            <label className="block text-sm font-semibold mb-1">Label *</label>
                            <input type="text" className="form-input w-full" value={optLabel}
                                onChange={e => { setOptLabel(e.target.value); if (isAddingOpt && !optValue) setOptValue(e.target.value.toLowerCase().replace(/\s+/g, '-')); }}
                                placeholder="e.g. Matte Black" />
                        </div>
                        <div>
                            <label className="block text-sm font-semibold mb-1">Value <span style={{ fontWeight: 400, color: 'var(--color-text-muted)' }}>(internal key)</span></label>
                            <input type="text" className="form-input w-full" value={optValue}
                                onChange={e => setOptValue(e.target.value.toLowerCase().replace(/\s+/g, '-'))}
                                placeholder="e.g. matte-black" style={{ fontFamily: 'monospace', fontSize: '13px' }} />
                        </div>
                    </div>
                    <div>
                        <label className="block text-sm font-semibold mb-1">Description</label>
                        <input type="text" className="form-input w-full" value={optDesc}
                            onChange={e => setOptDesc(e.target.value)} placeholder="Optional short description" />
                    </div>
                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '1rem' }}>
                        <div>
                            <label className="block text-sm font-semibold mb-1">Price Adjustment</label>
                            <input type="number" step="0.01" className="form-input w-full" value={optPrice}
                                onChange={e => setOptPrice(e.target.value)} placeholder="e.g. +50 or -25" />
                        </div>
                        <div>
                            <label className="block text-sm font-semibold mb-1">Swatch Color</label>
                            <input type="text" className="form-input w-full" value={optSwatch}
                                onChange={e => setOptSwatch(e.target.value)} placeholder="#2D2D2D" />
                        </div>
                        <div>
                            <label className="block text-sm font-semibold mb-1">Sort Order</label>
                            <input type="number" className="form-input w-full" value={optSort} onChange={e => setOptSort(e.target.value)} />
                        </div>
                    </div>
                    <div style={{ display: 'flex', gap: '1.5rem' }}>
                        <label style={{ display: 'flex', alignItems: 'center', gap: '6px', cursor: 'pointer', fontSize: '13px' }}>
                            <input type="checkbox" checked={optDefault} onChange={e => setOptDefault(e.target.checked)} />
                            Default selection
                        </label>
                        <label style={{ display: 'flex', alignItems: 'center', gap: '6px', cursor: 'pointer', fontSize: '13px' }}>
                            <input type="checkbox" checked={optActive} onChange={e => setOptActive(e.target.checked)} />
                            Active
                        </label>
                    </div>
                </div>
            </Modal>

            <ConfirmDialog
                isOpen={!!confirmDeleteOpt}
                title="Delete Option"
                message={`Delete "${confirmDeleteOpt?.label}"? This cannot be undone.`}
                confirmLabel="Delete"
                variant="danger"
                onConfirm={deleteOption}
                onCancel={() => setConfirmDeleteOpt(null)}
                isLoading={isDeletingOpt}
            />
        </>
    );
}
