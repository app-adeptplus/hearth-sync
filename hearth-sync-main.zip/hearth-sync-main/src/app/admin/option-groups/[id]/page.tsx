import prisma from '@/lib/db';
import { notFound } from 'next/navigation';
import Link from 'next/link';
import OptionGroupDetailClient from './OptionGroupDetailClient';

export const dynamic = 'force-dynamic';

export default async function OptionGroupDetailPage({ params }: { params: { id: string } }) {
    const group = await prisma.optionGroup.findUnique({
        where: { id: params.id },
        include: {
            options: { orderBy: [{ sortOrder: 'asc' }, { label: 'asc' }] },
            productLinks: {
                include: {
                    product: {
                        select: { id: true, name: true, sku: true, modelNumber: true },
                    },
                },
                orderBy: { sortOrder: 'asc' },
            },
        },
    });

    if (!group) notFound();

    return (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem', maxWidth: '64rem', margin: '0 auto' }}>
            <div className="page-header pb-6 border-b border-[var(--color-border)] flex justify-between items-end">
                <div>
                    <h2 className="page-title">{group.name}</h2>
                    <p className="page-subtitle">
                        {group.options.length} option{group.options.length !== 1 ? 's' : ''} ·{' '}
                        {group.productLinks.length} product{group.productLinks.length !== 1 ? 's' : ''} assigned
                    </p>
                </div>
                <Link href="/admin/option-groups" className="btn btn-secondary text-sm">← Option Groups</Link>
            </div>
            <OptionGroupDetailClient group={group} />
        </div>
    );
}
