"use client";

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import Modal from '@/components/Modal';
import ConfirmDialog from '@/components/ui/ConfirmDialog';

const INPUT_TYPES = [
    { value: 'select', label: 'Select (dropdown)' },
    { value: 'radio', label: 'Radio buttons' },
    { value: 'checkbox', label: 'Checkboxes (multi)' },
    { value: 'swatch', label: 'Color / image swatches' },
];

export default function OptionGroupsClient({ groups }: { groups: any[] }) {
    const router = useRouter();

    // ── Modal state ───────────────────────────────────────────────────────────
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [editTarget, setEditTarget] = useState<any | null>(null);

    // ── Form state ────────────────────────────────────────────────────────────
    const [name, setName] = useState('');
    const [description, setDescription] = useState('');
    const [inputType, setInputType] = useState('select');
    const [isRequired, setIsRequired] = useState(false);
    const [allowMultiple, setAllowMultiple] = useState(false);
    const [sortOrder, setSortOrder] = useState('0');
    const [isSaving, setIsSaving] = useState(false);

    // ── Delete state ──────────────────────────────────────────────────────────
    const [confirmDelete, setConfirmDelete] = useState<{ id: string; name: string } | null>(null);
    const [isDeleting, setIsDeleting] = useState(false);

    const isAdding = isModalOpen && !editTarget?.id;
    const editingId: string | null = editTarget?.id ?? null;

    const openAddModal = () => {
        setEditTarget({});
        setName(''); setDescription(''); setInputType('select');
        setIsRequired(false); setAllowMultiple(false); setSortOrder('0');
        setIsModalOpen(true);
    };

    const openEditModal = (group: any) => {
        setEditTarget(group);
        setName(group.name); setDescription(group.description || '');
        setInputType(group.inputType || 'select');
        setIsRequired(group.isRequired ?? false);
        setAllowMultiple(group.allowMultiple ?? false);
        setSortOrder(group.sortOrder?.toString() || '0');
        setIsModalOpen(true);
    };

    const closeModal = () => { setIsModalOpen(false); setEditTarget(null); };

    const saveGroup = async () => {
        if (!name.trim()) { alert('Name is required'); return; }
        setIsSaving(true);
        try {
            const payload = { name, description: description || null, inputType, isRequired, allowMultiple, sortOrder: parseInt(sortOrder) || 0 };
            const res = isAdding
                ? await fetch('/api/option-groups', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) })
                : await fetch(`/api/option-groups/${editingId}`, { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
            if (!res.ok) { const d = await res.json(); throw new Error(d.error || 'Failed to save'); }
            router.refresh(); closeModal();
        } catch (err: any) { alert(err.message); } finally { setIsSaving(false); }
    };

    const executeDelete = async () => {
        if (!confirmDelete) return;
        setIsDeleting(true);
        try {
            const res = await fetch(`/api/option-groups/${confirmDelete.id}`, { method: 'DELETE' });
            if (!res.ok) { const d = await res.json(); throw new Error(d.error || 'Failed to delete'); }
            router.refresh(); if (editingId === confirmDelete.id) closeModal();
        } catch (err: any) { alert(err.message); } finally { setIsDeleting(false); setConfirmDelete(null); }
    };

    const inputTypeLabel = (val: string) => INPUT_TYPES.find(t => t.value === val)?.label ?? val;

    return (
        <>
            <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
                {/* Header */}
                <div style={{ padding: 'var(--space-4)', borderBottom: '1px solid var(--color-border)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <h3 className="card-title text-lg font-semibold">
                        All Option Groups <span style={{ fontSize: '13px', fontWeight: 400, color: 'var(--color-text-muted)', marginLeft: '6px' }}>({groups.length})</span>
                    </h3>
                    <button className="btn btn-primary btn-sm" onClick={openAddModal}>+ New Option Group</button>
                </div>

                <table className="data-table">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Input Type</th>
                            <th style={{ textAlign: 'center' }}>Options</th>
                            <th style={{ textAlign: 'center' }}>Products</th>
                            <th>Flags</th>
                            <th style={{ textAlign: 'right' }}>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {groups.map((group) => (
                            <tr key={group.id}>
                                <td style={{ fontWeight: 500, paddingLeft: 'var(--space-4)' }}>
                                    <Link href={`/admin/option-groups/${group.id}`} style={{ color: 'var(--color-primary)', textDecoration: 'none' }}>
                                        {group.name}
                                    </Link>
                                    {group.description && (
                                        <div style={{ fontSize: '11px', color: 'var(--color-text-muted)', marginTop: '2px' }}>{group.description}</div>
                                    )}
                                </td>
                                <td>
                                    <span style={{ fontSize: '11px', background: 'var(--color-bg-elevated)', padding: '2px 8px', borderRadius: '10px', color: 'var(--color-text-secondary)', border: '1px solid var(--color-border)' }}>
                                        {inputTypeLabel(group.inputType)}
                                    </span>
                                </td>
                                <td style={{ textAlign: 'center' }}>
                                    <span style={{ fontSize: '12px', background: 'var(--color-bg-elevated)', padding: '2px 8px', borderRadius: '12px', color: 'var(--color-text-secondary)' }}>
                                        {group._count.options}
                                    </span>
                                </td>
                                <td style={{ textAlign: 'center' }}>
                                    <span style={{ fontSize: '12px', background: 'var(--color-bg-elevated)', padding: '2px 8px', borderRadius: '12px', color: 'var(--color-text-secondary)' }}>
                                        {group._count.productLinks}
                                    </span>
                                </td>
                                <td>
                                    <div style={{ display: 'flex', gap: '4px', flexWrap: 'wrap' }}>
                                        {group.isRequired && (
                                            <span style={{ fontSize: '10px', background: 'var(--color-warning)', color: 'white', padding: '1px 7px', borderRadius: '8px', fontWeight: 600 }}>Required</span>
                                        )}
                                        {group.allowMultiple && (
                                            <span style={{ fontSize: '10px', background: 'var(--color-primary)', color: 'white', padding: '1px 7px', borderRadius: '8px', fontWeight: 600 }}>Multi</span>
                                        )}
                                    </div>
                                </td>
                                <td style={{ textAlign: 'right', whiteSpace: 'nowrap' }}>
                                    <Link href={`/admin/option-groups/${group.id}`} className="btn btn-sm btn-ghost">Manage</Link>
                                    <button className="btn btn-sm btn-ghost" onClick={() => openEditModal(group)} style={{ marginLeft: '4px' }}>Edit</button>
                                    <button
                                        className="btn btn-sm btn-ghost"
                                        style={{ color: 'var(--color-danger)', marginLeft: '4px' }}
                                        onClick={() => setConfirmDelete({ id: group.id, name: group.name })}
                                        disabled={isDeleting}
                                    >✕</button>
                                </td>
                            </tr>
                        ))}
                        {groups.length === 0 && (
                            <tr>
                                <td colSpan={6} style={{ padding: '2rem', textAlign: 'center', color: 'var(--color-text-muted)' }}>
                                    No option groups yet. Click "+ New Option Group" to get started.
                                </td>
                            </tr>
                        )}
                    </tbody>
                </table>
            </div>

            {/* Add / Edit Modal */}
            <Modal
                isOpen={isModalOpen}
                onClose={closeModal}
                title={isAdding ? 'New Option Group' : 'Edit Option Group'}
                subtitle={isAdding ? 'Define a reusable set of buyer choices' : editTarget?.name}
                size="md"
                footer={
                    <div style={{ display: 'flex', justifyContent: 'space-between', width: '100%' }}>
                        {editingId ? (
                            <button type="button" className="btn btn-ghost" style={{ color: 'var(--color-danger)' }}
                                onClick={() => { closeModal(); setConfirmDelete({ id: editingId, name: name }); }} disabled={isDeleting}>
                                Delete
                            </button>
                        ) : <div />}
                        <div style={{ display: 'flex', gap: '0.5rem' }}>
                            <button type="button" className="btn btn-secondary" onClick={closeModal}>Cancel</button>
                            <button type="button" className="btn btn-primary" onClick={saveGroup} disabled={isSaving}>
                                {isSaving ? 'Saving…' : 'Save'}
                            </button>
                        </div>
                    </div>
                }
            >
                <div style={{ padding: '1.5rem', display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                    <div>
                        <label className="block text-sm font-semibold mb-1">Name *</label>
                        <input type="text" className="form-input w-full" value={name} onChange={e => setName(e.target.value)}
                            placeholder="e.g. Finish, Fuel Type, Surround Kit" />
                    </div>
                    <div>
                        <label className="block text-sm font-semibold mb-1">Description</label>
                        <textarea className="form-input w-full" rows={2} value={description}
                            onChange={e => setDescription(e.target.value)}
                            placeholder="Optional description shown to buyers" style={{ resize: 'vertical' }} />
                    </div>
                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
                        <div>
                            <label className="block text-sm font-semibold mb-1">Input Type</label>
                            <select className="form-select w-full" value={inputType} onChange={e => setInputType(e.target.value)}>
                                {INPUT_TYPES.map(t => <option key={t.value} value={t.value}>{t.label}</option>)}
                            </select>
                        </div>
                        <div>
                            <label className="block text-sm font-semibold mb-1">Sort Order</label>
                            <input type="number" className="form-input w-full" value={sortOrder} onChange={e => setSortOrder(e.target.value)} />
                        </div>
                    </div>
                    <div style={{ display: 'flex', gap: '1.5rem' }}>
                        <label style={{ display: 'flex', alignItems: 'center', gap: '6px', cursor: 'pointer', fontSize: '13px' }}>
                            <input type="checkbox" checked={isRequired} onChange={e => setIsRequired(e.target.checked)} />
                            Required (buyer must choose)
                        </label>
                        <label style={{ display: 'flex', alignItems: 'center', gap: '6px', cursor: 'pointer', fontSize: '13px' }}>
                            <input type="checkbox" checked={allowMultiple} onChange={e => setAllowMultiple(e.target.checked)} />
                            Allow multiple selections
                        </label>
                    </div>
                </div>
            </Modal>

            {/* Delete confirmation */}
            <ConfirmDialog
                isOpen={!!confirmDelete}
                title="Delete Option Group"
                message={`Delete "${confirmDelete?.name}"? All options and product assignments for this group will also be removed. This cannot be undone.`}
                confirmLabel="Delete"
                variant="danger"
                onConfirm={executeDelete}
                onCancel={() => setConfirmDelete(null)}
                isLoading={isDeleting}
            />
        </>
    );
}
