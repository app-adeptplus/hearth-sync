import prisma from '@/lib/db';
import Link from 'next/link';
import OptionGroupsClient from './OptionGroupsClient';

export const dynamic = 'force-dynamic';

export default async function OptionGroupsPage() {
    const groups = await prisma.optionGroup.findMany({
        orderBy: [{ sortOrder: 'asc' }, { name: 'asc' }],
        include: {
            _count: {
                select: { options: true, productLinks: true },
            },
        },
    });

    return (
        <div className="space-y-6">
            <div className="page-header pb-6 border-b border-[var(--color-border)] mb-6 flex justify-between items-end">
                <div>
                    <h2 className="text-2xl font-bold">Option Groups</h2>
                    <p className="text-[var(--text-secondary)] mt-1">
                        Define reusable ecommerce option sets (e.g. Finish, Fuel Type, Surround Kit) and assign them to products.
                    </p>
                </div>
            </div>
            <OptionGroupsClient groups={groups} />
        </div>
    );
}
