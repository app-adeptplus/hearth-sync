'use client';

import { useState, useEffect, useCallback, useRef } from 'react';
import Papa from 'papaparse';
import { useRouter } from 'next/navigation';
import Modal from '@/components/Modal';

// ─── Types ──────────────────────────────────────────────────────────────────

type ImportFormat = 'native' | 'woocommerce' | 'shopify' | 'custom';

type Brand = { id: string; name: string; slug: string };
type Manufacturer = { id: string; name: string; brands: Brand[] };

type RowResult = {
    rowIndex: number;
    name: string;
    status: 'success' | 'error' | 'skipped';
    message?: string;
};

type ImportResult = {
    totalRows: number;
    successCount: number;
    errorCount: number;
    skippedCount: number;
    results: RowResult[];
    message: string;
};

// ─── Field definitions ───────────────────────────────────────────────────────

const SYSTEM_FIELDS = [
    { key: 'name', label: 'Product Name', required: true, group: 'Core', span: 12 },
    { key: 'sku', label: 'SKU', group: 'Core', span: 6 },
    { key: 'model_number', label: 'Model Number', group: 'Core', span: 6 },
    { key: 'brand_slug', label: 'Brand Slug (delimited)', group: 'Core', span: 6 },
    { key: 'categories', label: 'Categories (delimited)', group: 'Core', span: 6 },
    { key: 'status', label: 'Status', group: 'Core', span: 12 },
    { key: 'short_description', label: 'Short Description', group: 'Core', span: 6 },
    { key: 'description', label: 'Long Description', group: 'Core', span: 6 },
    { key: 'price_msrp', label: 'MSRP Price', group: 'Core', span: 6 },
    { key: 'product_url', label: 'Product URL', group: 'Core', span: 6 },
    { key: 'fuel_type', label: 'Fuel Types (delimited)', group: 'Product Info', span: 6 },
    { key: 'venting_type', label: 'Venting Type', group: 'Product Info', span: 6 },
    { key: 'btu_input', label: 'BTU Input', group: 'Product Info', span: 4 },
    { key: 'btu_output', label: 'BTU Output', group: 'Product Info', span: 4 },
    { key: 'efficiency_rating', label: 'Efficiency Rating (%)', group: 'Product Info', span: 4 },
    { key: 'width', label: 'Width (in)', group: 'Dimensions', span: 4 },
    { key: 'height', label: 'Height (in)', group: 'Dimensions', span: 4 },
    { key: 'depth', label: 'Depth (in)', group: 'Dimensions', span: 4 },
    { key: 'weight', label: 'Weight (lbs)', group: 'Dimensions', span: 4 },
    { key: 'images', label: 'Images (delimited)', group: 'Media', span: 12 },
    { key: 'image_url_1', label: 'Image URL 1', group: 'Media', span: 3 },
    { key: 'image_url_2', label: 'Image URL 2', group: 'Media', span: 3 },
    { key: 'image_url_3', label: 'Image URL 3', group: 'Media', span: 3 },
    { key: 'image_url_4', label: 'Image URL 4', group: 'Media', span: 3 },
    { key: 'image_url_5', label: 'Image URL 5', group: 'Media', span: 3 },
    { key: 'spec_sheet_url', label: 'Spec Sheet URL', group: 'Documents', span: 6 },
    { key: 'manual_url', label: 'Manual URL', group: 'Documents', span: 6 },
];

const FORMAT_PRESETS: Record<ImportFormat, Record<string, string>> = {
    native: {
        name: 'name', model_number: 'model_number', sku: 'sku', slug: 'slug',
        brand_slug: 'brand_slug', categories: 'categories', fuel_type: 'fuel_type', venting_type: 'venting_type',
        btu_input: 'btu_input', btu_output: 'btu_output', efficiency_rating: 'efficiency_rating',
        width: 'width', height: 'height', depth: 'depth', weight: 'weight',
        short_description: 'short_description', description: 'description',
        product_url: 'product_url', price_msrp: 'price_msrp',
        images: 'images',
        spec_sheet_url: 'spec_sheet_url', manual_url: 'manual_url', status: 'status',
    },
    woocommerce: {
        name: 'Name', slug: 'Slug', sku: 'SKU', description: 'Description',
        short_description: 'Short description', price_msrp: 'Regular price',
        images: 'Images', status: 'Published',
    },
    shopify: {
        name: 'Title', slug: 'Handle', sku: 'Variant SKU',
        description: 'Body (HTML)', price_msrp: 'Variant Price',
        image_url_1: 'Image Src', status: 'Status',
    },
    custom: {},
};

// ─── Component ───────────────────────────────────────────────────────────────

export default function ProductImportPage() {
    const router = useRouter();

    // Steps: 1 = settings+file, 2 = mapping, 3 = preview, 4 = importing, 5 = results
    const [step, setStep] = useState<1 | 2 | 3 | 4 | 5>(1);

    // Settings
    const [format, setFormat] = useState<ImportFormat>('native');
    const [selectedBrandId, setSelectedBrandId] = useState<string>('');
    const [manufacturers, setManufacturers] = useState<Manufacturer[]>([]);
    const [loadingManufacturers, setLoadingManufacturers] = useState(true);

    // File / CSV state
    const [file, setFile] = useState<File | null>(null);
    const [isParsing, setIsParsing] = useState(false);
    const [csvHeaders, setCsvHeaders] = useState<string[]>([]);
    const [allCsvData, setAllCsvData] = useState<Record<string, any>[]>([]);
    const [totalRows, setTotalRows] = useState(0);

    // Modal & Preview state
    const [showPreviewModal, setShowPreviewModal] = useState(false);
    const [previewPage, setPreviewPage] = useState(1);
    const PREVIEW_PAGE_SIZE = 100;

    // Field mapping & Mode
    const [importMode, setImportMode] = useState<'create' | 'update'>('create');
    const [fieldMap, setFieldMap] = useState<Record<string, string>>(FORMAT_PRESETS['native']);

    // Import progress & results
    const [isImporting, setIsImporting] = useState(false);
    const [importResult, setImportResult] = useState<ImportResult | null>(null);
    const [liveResults, setLiveResults] = useState<RowResult[]>([]);
    const [importProgress, setImportProgress] = useState(0);
    const abortControllerRef = useRef<AbortController | null>(null);

    // Client Mounted Portal
    const [mounted, setMounted] = useState(false);
    useEffect(() => setMounted(true), []);

    // Feature Toggles for UX
    const [showProductInfo, setShowProductInfo] = useState(false);
    const [useDelimitedImages, setUseDelimitedImages] = useState(true);

    // Custom delimiters map
    const [delimiters, setDelimiters] = useState<Record<string, string>>({
        brand_slug: ',',
        categories: ',',
        fuel_type: ',',
        images: ',',
    });

    // ─── Load manufacturers ──────────────────────────────────────────────────
    useEffect(() => {
        fetch('/api/manufacturers')
            .then(r => r.json())
            .then(data => setManufacturers(data.data ?? []))
            .catch(console.error)
            .finally(() => setLoadingManufacturers(false));
    }, []);

    // ─── Format or Mode change ───────────────────────────────────────────────
    const handleFormatChange = (f: ImportFormat) => {
        setFormat(f);
        if (importMode === 'create') {
            setFieldMap(FORMAT_PRESETS[f]);
        }
    };

    const handleModeChange = (mode: 'create' | 'update') => {
        setImportMode(mode);
        if (mode === 'update') {
            setFieldMap({}); // Clear all mappings for update
        } else {
            setFieldMap(FORMAT_PRESETS[format]); // Restore defaults for format
        }
    };

    // ─── File upload / parse ─────────────────────────────────────────────────
    const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
        const uploadedFile = e.target.files?.[0];
        if (!uploadedFile) return;
        setFile(uploadedFile);
        setIsParsing(true);

        Papa.parse(uploadedFile, {
            header: true,
            skipEmptyLines: true,
            complete: (results) => {
                const headers = results.meta.fields || [];
                setCsvHeaders(headers);
                setAllCsvData(results.data as Record<string, any>[]);
                setTotalRows(results.data.length);
                setIsParsing(false);
            },
            error: () => {
                setIsParsing(false);
                alert('Failed to parse CSV. Make sure it is a valid UTF-8 CSV file.');
            },
        });
    };

    const handleContinueToMapping = () => {
        if (!file || isParsing) return;
        setStep(2);
    };

    const handlePreview = () => {
        if (importMode === 'update') {
            if (!fieldMap['sku'] && !fieldMap['model_number']) {
                alert('For Bulk Update, you must map either "Variant SKU" or "Model Number" to identify existing products.');
                return;
            }
        }
        setShowPreviewModal(true);
        setStep(3);
    };

    // ─── Submit import ───────────────────────────────────────────────────────
    const handleImport = async () => {
        if (!allCsvData.length) return;
        setIsImporting(true);
        setStep(4);

        let successCount = 0;
        let errorCount = 0;
        let skippedCount = 0;
        const currentResults: RowResult[] = [];
        setLiveResults([]);
        setImportProgress(0);

        const batchSize = 50;
        abortControllerRef.current = new AbortController();

        for (let i = 0; i < allCsvData.length; i += batchSize) {
            if (abortControllerRef.current.signal.aborted) {
                break;
            }

            const batch = allCsvData.slice(i, i + batchSize);
            const chunkCsv = Papa.unparse(batch);
            const chunkBlob = new Blob([chunkCsv], { type: 'text/csv' });

            const formData = new FormData();
            formData.append('file', chunkBlob, 'chunk.csv');
            formData.append('format', format);
            formData.append('mode', importMode);
            formData.append('mapping', JSON.stringify(fieldMap));
            formData.append('delimiters', JSON.stringify(delimiters));
            if (selectedBrandId) formData.append('brandId', selectedBrandId);

            try {
                const res = await fetch('/api/products/import', {
                    method: 'POST',
                    body: formData,
                    signal: abortControllerRef.current.signal
                });

                const data = await res.json();

                if (data.results) {
                    const mappedResults = data.results.map((r: any) => ({
                        ...r,
                        rowIndex: i + r.rowIndex
                    }));
                    currentResults.push(...mappedResults);
                    setLiveResults([...currentResults]);

                    successCount += data.successCount || 0;
                    errorCount += data.errorCount || 0;
                    skippedCount += data.skippedCount || 0;
                } else if (!res.ok) {
                    throw new Error(data.error || 'Import failed');
                }
            } catch (err: any) {
                if (err.name !== 'AbortError') {
                    console.error('Batch error:', err);
                }
            }

            setImportProgress(Math.min(allCsvData.length, i + batchSize));
        }

        setIsImporting(false);
        setImportResult({
            totalRows: abortControllerRef.current?.signal.aborted ? currentResults.length : totalRows,
            successCount,
            errorCount,
            skippedCount,
            results: currentResults,
            message: "Import processing finished."
        });
        setStep(5);
    };

    const handleStopImport = () => {
        abortControllerRef.current?.abort();
    };

    // ─── Helpers ─────────────────────────────────────────────────────────────
    const allBrands = manufacturers.flatMap(m => m.brands.map(b => ({ ...b, manufacturerName: m.name })));

    const finalFields = SYSTEM_FIELDS.filter(f => {
        if (f.group === 'Product Info' || f.group === 'Dimensions') return showProductInfo;
        if (f.key.startsWith('image_url_')) return !useDelimitedImages;
        if (f.key === 'images') return useDelimitedImages;
        return true;
    });

    const fieldGroups = finalFields.reduce<Record<string, typeof SYSTEM_FIELDS>>((acc, f) => {
        if (!acc[f.group]) acc[f.group] = [];
        acc[f.group].push(f);
        return acc;
    }, {});

    const mappedColumnCount = Object.values(fieldMap).filter(Boolean).length;

    // ─── Render ───────────────────────────────────────────────────────────────
    return (
        <div className="animate-fade-in app-content" style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem', maxWidth: '72rem', margin: '0 auto' }}>

            {/* Header */}
            <div className="page-header pb-6 border-b border-[var(--color-border)]">
                <div>
                    <h2 className="page-title">Bulk Product Import</h2>
                    <p className="page-subtitle">
                        Upload a CSV to import products into the master catalog. Supports Hearth Native, WooCommerce, Shopify, and custom CSV formats.
                    </p>
                </div>
                <div className="flex gap-3" style={{ display: 'flex', gap: '0.75rem' }}>
                    <a
                        href="/api/products/import"
                        download="hearth_product_import_template.csv"
                        className="btn btn-secondary text-sm"
                    >
                        ↓ Download Template CSV
                    </a>
                    <a href="/api/products/export" download className="btn btn-secondary text-sm">
                        ↓ Export Current Products
                    </a>
                </div>
            </div>

            {/* Step Progress Bar */}
            <div className="flex items-center gap-2 text-sm mb-2" style={{ display: 'flex', alignItems: 'center', gap: '1rem', flexWrap: 'wrap', marginBottom: '2rem' }}>
                {(['Settings', 'Mapping', 'Preview', 'Import', 'Results'] as const).map((label, idx) => {
                    const stepNum = (idx + 1) as 1 | 2 | 3 | 4 | 5;
                    const isActive = step === stepNum;
                    const isDone = step > stepNum;
                    return (
                        <div key={label} className="flex items-center gap-2" style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                            <div className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold transition-colors
                                ${isDone ? 'bg-[var(--color-success)] text-white' :
                                    isActive ? 'bg-[var(--color-accent)] text-white' :
                                        'bg-[var(--color-bg-elevated)] text-[var(--color-text-muted)]'}`}
                                style={{ width: '28px', height: '28px', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', color: (isDone || isActive) ? 'white' : 'inherit' }}>
                                {isDone ? '✓' : stepNum}
                            </div>
                            <span className={isActive ? 'font-semibold text-[var(--color-text-primary)]' : 'text-[var(--color-text-muted)]'} style={{ fontWeight: isActive ? 600 : 400 }}>
                                {label}
                            </span>
                            {idx < 4 && <span className="text-[var(--color-border)]" style={{ margin: '0 0.25rem' }}>→</span>}
                        </div>
                    );
                })}
            </div>

            {/* ── STEP 1: Settings ── */}
            {step === 1 && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6" style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', gap: '1.5rem' }}>
                    {/* Format Card */}
                    <div className="card p-6 space-y-5">
                        <h3 className="font-semibold text-lg border-b border-[var(--color-border)] pb-2">
                            1. Source Format
                        </h3>

                        <div className="form-group">
                            <label className="form-label text-[var(--color-text-muted)] font-normal mb-2 text-sm">
                                Choose the format of your CSV file.
                            </label>
                            <select
                                value={format}
                                onChange={e => handleFormatChange(e.target.value as ImportFormat)}
                                className="form-select mb-4"
                            >
                                <option value="native">🔥 Hearth Native (Our standard template)</option>
                                <option value="woocommerce">🛒 WooCommerce (WC product export CSV)</option>
                                <option value="shopify">🏪 Shopify (Shopify product CSV)</option>
                                <option value="custom">⚙️ Custom (Manual column mapping)</option>
                            </select>

                            <label className="form-label text-[var(--color-text-muted)] font-normal mb-2 text-sm">
                                Import Type
                            </label>
                            <select
                                value={importMode}
                                onChange={e => handleModeChange(e.target.value as 'create' | 'update')}
                                className="form-select"
                            >
                                <option value="create">✨ Import Missing Products (Create/Upsert)</option>
                                <option value="update">✏️ Bulk Update Existing Products</option>
                            </select>
                            {importMode === 'update' && (
                                <p className="text-xs text-[var(--color-accent)] mt-2 font-medium">
                                    Updating products requires a matched SKU or Model Number column. Mappings are cleared so you only update fields you map. Blank column values in the CSV will be ignored.
                                </p>
                            )}
                        </div>
                    </div>

                    {/* Brand + File Card */}
                    <div className="card p-6 space-y-5">
                        <h3 className="font-semibold text-lg border-b border-[var(--color-border)] pb-2">
                            2. Brand &amp; File
                        </h3>

                        <div className="form-group">
                            <label className="form-label">
                                Brand Override <span className="text-[var(--color-text-muted)] font-normal">(optional)</span>
                            </label>
                            <p className="text-xs text-[var(--color-text-muted)] mb-2">
                                Select a brand to assign all rows to. If left blank, each row must have a <code>brand_slug</code> column.
                            </p>
                            {loadingManufacturers ? (
                                <div className="text-sm text-[var(--color-text-muted)] animate-pulse">Loading brands…</div>
                            ) : (
                                <select
                                    value={selectedBrandId}
                                    onChange={e => setSelectedBrandId(e.target.value)}
                                    className="form-select"
                                >
                                    <option value="">— Per-row brand_slug column —</option>
                                    {manufacturers.map(m => (
                                        <optgroup key={m.id} label={m.name}>
                                            {m.brands.map(b => (
                                                <option key={b.id} value={b.id}>{b.name}</option>
                                            ))}
                                        </optgroup>
                                    ))}
                                </select>
                            )}
                        </div>

                        <div className="form-group">
                            <label className="form-label">Upload CSV File</label>
                            <div className={`border-2 border-dashed rounded-xl p-8 text-center transition-colors ${isParsing ? 'border-[var(--color-accent)] bg-[var(--color-accent)]/5' : 'border-[var(--color-border)] hover:border-[var(--color-border-hover)]'
                                }`}>
                                {isParsing ? (
                                    <p className="text-[var(--color-accent)] animate-pulse text-sm font-medium">Parsing CSV…</p>
                                ) : (
                                    <>
                                        <div className="text-3xl mb-2">📂</div>
                                        <p className="text-sm text-[var(--color-text-secondary)] mb-3">
                                            {file ? `✓ ${file.name} (${totalRows} rows)` : 'Drag & drop or click to upload'}
                                        </p>
                                        <input
                                            type="file"
                                            accept=".csv"
                                            onChange={handleFileUpload}
                                            className="block w-full text-sm text-[var(--color-text-secondary)]
                                                file:mr-4 file:py-2 file:px-4 file:rounded-md file:border-0
                                                file:text-sm file:font-semibold file:bg-[var(--color-bg-elevated)]
                                                file:text-[var(--color-text-primary)] hover:file:bg-[var(--color-border)] cursor-pointer"
                                        />
                                    </>
                                )}
                            </div>
                        </div>

                        <div className="flex justify-end pt-4" style={{ display: 'flex', justifyContent: 'flex-end', paddingTop: '1rem' }}>
                            <button
                                className="btn btn-primary"
                                onClick={handleContinueToMapping}
                                disabled={!file || isParsing}
                            >
                                Continue to Mapping →
                            </button>
                        </div>
                    </div>
                </div>
            )}

            {/* ── STEP 2: Column Mapping ── */}
            {step === 2 && (
                <div className="card p-6">
                    <div className="flex justify-between items-start mb-5 pb-4 border-b border-[var(--color-border)]" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                        <div>
                            <h3 className="font-semibold text-lg">Column Mapping</h3>
                            <p className="text-sm text-[var(--color-text-muted)] mt-0.5">
                                {totalRows} rows detected · {mappedColumnCount} fields mapped · Match each Hearth field to a CSV column.
                            </p>
                        </div>
                        <div className="flex gap-3" style={{ display: 'flex', gap: '0.75rem' }}>
                            <button className="btn btn-secondary text-sm" onClick={() => setStep(1)}>← Back</button>
                            <button className="btn btn-primary text-sm" onClick={handlePreview}>
                                Preview {totalRows} Rows →
                            </button>
                        </div>
                    </div>

                    <div style={{ display: 'flex', flexDirection: 'column', gap: '2rem' }}>
                        {Object.entries(fieldGroups).map(([group, fields]) => (
                            <div key={group} className="pb-10 border-b border-[var(--color-border)] last:border-0 border-opacity-50">
                                <h4 className="text-lg font-bold uppercase tracking-wider text-[var(--color-text-primary)] mb-6 underline underline-offset-[6px]">
                                    {group}
                                </h4>

                                {group === 'Media' && (
                                    <div className="mb-6">
                                        <label className="flex items-center gap-2 cursor-pointer w-fit mb-1">
                                            <input
                                                type="checkbox"
                                                checked={useDelimitedImages}
                                                onChange={(e) => setUseDelimitedImages(e.target.checked)}
                                                className="form-checkbox h-4 w-4 text-[var(--color-accent)] border-[var(--color-border)] rounded transition-colors cursor-pointer"
                                            />
                                            <span className="font-bold text-sm text-[var(--color-text-primary)]">
                                                Delimited Column for Images Mapping
                                            </span>
                                        </label>
                                        <p className="text-sm text-[var(--color-text-muted)] leading-relaxed max-w-3xl">
                                            Map all product images from a single CSV column separated by commas, instead of assigning 5 individual URL columns. Great for Shopify and WooCommerce exports.
                                        </p>
                                    </div>
                                )}

                                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(12, minmax(0, 1fr))', gap: '1.5rem 1.25rem' }}>
                                    {fields.map(({ key, label, required, span }) => {
                                        const isDelimited = ['brand_slug', 'categories', 'fuel_type', 'images'].includes(key);
                                        const colSpanNum = span || 12;

                                        return (
                                            <div key={key} style={{ gridColumn: `span ${colSpanNum} / span ${colSpanNum}`, display: 'flex', flexDirection: isDelimited ? 'row' : 'column', gap: isDelimited ? '1.5rem' : '0' }}>
                                                <div style={{ flex: 1 }}>
                                                    <label className="text-xs font-semibold text-[var(--color-text-secondary)] mb-1.5 block">
                                                        {label}{required && <span className="text-[var(--color-error)] ml-1">*</span>}
                                                    </label>
                                                    <select
                                                        value={fieldMap[key] || ''}
                                                        onChange={e => setFieldMap(prev => ({ ...prev, [key]: e.target.value }))}
                                                        className={`form-select text-sm transition-colors w-full h-10 ${fieldMap[key] ? 'border-[var(--color-success)]/60 bg-[var(--color-success)]/5' : ''}`}
                                                    >
                                                        <option value="">— ignore —</option>
                                                        {csvHeaders.map(h => (
                                                            <option key={h} value={h}>{h}</option>
                                                        ))}
                                                    </select>
                                                </div>
                                                {isDelimited && (
                                                    <div style={{ width: '80px', flexShrink: 0 }}>
                                                        <label className="text-xs font-semibold text-[var(--color-text-secondary)] mb-1.5 block">
                                                            Delimiter
                                                        </label>
                                                        <input
                                                            type="text"
                                                            value={delimiters[key] || ','}
                                                            onChange={e => setDelimiters(prev => ({ ...prev, [key]: e.target.value }))}
                                                            className="form-input text-sm w-full text-center h-10 px-2 border border-[var(--color-border)] rounded-md focus:border-[var(--color-accent)] focus:ring-1 focus:ring-[var(--color-accent)] outline-none"
                                                            title="Delimiter character"
                                                        />
                                                    </div>
                                                )}
                                            </div>
                                        )
                                    })}
                                </div>

                                {group === 'Core' && (
                                    <div className="mt-8 pt-6 border-t border-[var(--color-border)]/50">
                                        <div className="mb-2">
                                            <label className="flex items-center gap-2 cursor-pointer w-fit mb-1">
                                                <input
                                                    type="checkbox"
                                                    checked={showProductInfo}
                                                    onChange={(e) => setShowProductInfo(e.target.checked)}
                                                    className="form-checkbox h-4 w-4 text-[var(--color-accent)] border-[var(--color-border)] rounded transition-colors cursor-pointer"
                                                />
                                                <span className="font-bold text-sm text-[var(--color-text-primary)]">
                                                    Map Detailed Hearth Specifics &amp; Dimensions
                                                </span>
                                            </label>
                                            <p className="text-sm text-[var(--color-text-muted)] leading-relaxed max-w-3xl">
                                                Enable this to map granular physical dimensions and specific Hearth performance metrics (BTUs, efficiency, venting type) individually.
                                            </p>
                                        </div>
                                    </div>
                                )}
                            </div>
                        ))}
                    </div>

                    {/* Custom spec columns hint */}
                    <div className="mt-6 p-4 rounded-lg bg-[var(--color-bg-elevated)] border border-[var(--color-border)] text-sm">
                        <p className="font-semibold mb-1">💡 Dynamic Spec Columns</p>
                        <p className="text-[var(--color-text-muted)]">
                            Any column in your CSV can be imported as a product spec. In the Hearth Native template, prefix columns with <code>spec_</code> (e.g. <code>spec_heating_area</code>) and they'll automatically be stored as product specifications.
                        </p>
                    </div>
                </div>
            )}

            {/* ── FULLSCREEN MODAL (Preview, Import, Results) ── */}
            <Modal
                isOpen={showPreviewModal && step >= 3}
                onClose={() => {
                    if (step === 4) return; // Don't allow closing while importing
                    setShowPreviewModal(false);
                    if (step === 3) setStep(2);
                    if (step === 5) {
                        setStep(1); setFile(null); setTotalRows(0);
                    }
                }}
                size="excel"
                hideCloseButton={step === 4}
                title={
                    step === 3 ? "Excel Spreadsheet Preview" :
                        step === 4 ? "Importing Products..." :
                            "Import Complete"
                }
                subtitle={
                    step === 3 ? `Review mapped payload. Showing ${PREVIEW_PAGE_SIZE} rows per frame.` :
                        step === 4 ? `Processing ${importProgress} of ${totalRows} rows. Watch live updates below.` :
                            `Processed ${totalRows} rows with ${importResult?.successCount || 0} successes and ${importResult?.errorCount || 0} errors.`
                }
                footer={(
                    <div style={{ width: '100%', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                        {step === 3 ? (
                            <>
                                <span style={{ fontSize: '0.875rem', color: 'var(--color-text-muted)', fontWeight: 500 }}>
                                    Records <span style={{ color: 'var(--color-text-primary)' }}>{((previewPage - 1) * PREVIEW_PAGE_SIZE) + 1}</span> - <span style={{ color: 'var(--color-text-primary)' }}>{Math.min(previewPage * PREVIEW_PAGE_SIZE, totalRows)}</span> of <span style={{ color: 'var(--color-success)' }}>{totalRows}</span> Total
                                </span>

                                <div style={{ display: 'flex', alignItems: 'center', gap: '0.25rem' }}>
                                    <button
                                        disabled={previewPage === 1}
                                        onClick={() => setPreviewPage(1)}
                                        className="btn btn-secondary"
                                        style={{ padding: '0.25rem 0.75rem', fontWeight: 700, opacity: previewPage === 1 ? 0.5 : 1 }} title="First Page">«</button>
                                    <button
                                        disabled={previewPage === 1}
                                        onClick={() => setPreviewPage(p => p - 1)}
                                        className="btn btn-secondary" style={{ padding: '0.25rem 0.75rem', fontWeight: 700, opacity: previewPage === 1 ? 0.5 : 1 }} title="Previous Page">‹</button>
                                    <span style={{ padding: '0 0.75rem', color: 'var(--color-text-muted)', fontSize: '0.875rem', fontWeight: 500 }}>Page {previewPage}</span>
                                    <button
                                        disabled={previewPage * PREVIEW_PAGE_SIZE >= totalRows}
                                        onClick={() => setPreviewPage(p => p + 1)}
                                        className="btn btn-secondary" style={{ padding: '0.25rem 0.75rem', fontWeight: 700, opacity: previewPage * PREVIEW_PAGE_SIZE >= totalRows ? 0.5 : 1 }} title="Next Page">›</button>
                                </div>

                                <div style={{ display: 'flex', gap: '0.5rem', marginLeft: '1rem' }}>
                                    <button className="btn btn-secondary" onClick={() => { setShowPreviewModal(false); setStep(2); }}>Close Preview</button>
                                    <button className="btn btn-primary" style={{ backgroundColor: '#059669', borderColor: '#059669', fontWeight: 'bold', color: 'white' }} onClick={handleImport}>Start Import →</button>
                                </div>
                            </>
                        ) : step === 4 ? (
                            <div style={{ width: '100%', display: 'flex', justifyContent: 'flex-end' }}>
                                <button className="btn btn-primary" style={{ backgroundColor: 'var(--color-error)', borderColor: 'var(--color-error)' }} onClick={handleStopImport}>🛑 Stop Batch Import</button>
                            </div>
                        ) : (
                            <div style={{ width: '100%', display: 'flex', justifyContent: 'flex-end', gap: '0.5rem' }}>
                                <button className="btn btn-secondary" onClick={() => { setShowPreviewModal(false); setStep(1); setFile(null); setTotalRows(0); }}>Import New CSV</button>
                                <button className="btn btn-primary" onClick={() => router.push('/admin/products')}>View Catalog →</button>
                            </div>
                        )}
                    </div>
                )}
            >
                {step === 4 && (
                    <div style={{ height: '4px', width: '100%', backgroundColor: 'var(--color-bg-elevated)', overflow: 'hidden' }}>
                        <div style={{ height: '100%', backgroundColor: 'var(--color-accent)', width: `${Math.min(100, (importProgress / totalRows) * 100)}%`, transition: 'width 200ms ease-out' }}></div>
                    </div>
                )}

                <div style={{ backgroundColor: '#ffffff' }}>
                    {step === 3 && (
                        <table style={{ width: '100%', textAlign: 'left', fontSize: '0.875rem', whiteSpace: 'nowrap', borderCollapse: 'collapse' }}>
                            <thead style={{ backgroundColor: '#f9fafb', position: 'sticky', top: 0, zIndex: 10, boxShadow: '0 1px 2px rgba(0,0,0,0.05)' }}>
                                <tr>
                                    <th style={{ padding: '0.75rem 1rem', border: '1px solid #e5e7eb', color: '#111827', fontWeight: 700 }}>#</th>
                                    {Object.entries(fieldMap)
                                        .filter(([_, csvCol]) => csvCol)
                                        .map(([sysField, csvCol]) => {
                                            const isWide = ['description', 'short_description', 'name'].includes(sysField);
                                            return (
                                                <th key={sysField} style={{ padding: '0.75rem 1rem', border: '1px solid #e5e7eb', minWidth: isWide ? '300px' : '150px', color: '#111827', fontWeight: 700, backgroundColor: '#f9fafb' }}>
                                                    {sysField}
                                                    <div style={{ fontSize: '10px', color: '#6b7280', fontWeight: 'normal', textTransform: 'uppercase', marginTop: '0.25rem' }}>
                                                        [{csvCol}]
                                                    </div>
                                                </th>
                                            );
                                        })}
                                </tr>
                            </thead>
                            <tbody>
                                {allCsvData.slice((previewPage - 1) * PREVIEW_PAGE_SIZE, previewPage * PREVIEW_PAGE_SIZE).map((row, i) => {
                                    const globalIdx = (previewPage - 1) * PREVIEW_PAGE_SIZE + i + 1;
                                    return (
                                        <tr key={globalIdx} style={{ backgroundColor: i % 2 === 0 ? '#ffffff' : '#f9fafb', transition: 'background-color 150ms' }} onMouseOver={(e) => e.currentTarget.style.backgroundColor = '#f3f4f6'} onMouseOut={(e) => e.currentTarget.style.backgroundColor = i % 2 === 0 ? '#ffffff' : '#f9fafb'}>
                                            <td style={{ padding: '0.5rem 1rem', border: '1px solid #e5e7eb', color: '#6b7280', textAlign: 'center' }}>
                                                {globalIdx}
                                            </td>
                                            {Object.entries(fieldMap)
                                                .filter(([_, csvCol]) => csvCol)
                                                .map(([sysField, csvCol]) => {
                                                    const val = row[csvCol];
                                                    const isWide = ['description', 'short_description', 'name'].includes(sysField);
                                                    return (
                                                        <td key={sysField} style={{ padding: '0.5rem 1rem', border: '1px solid #e5e7eb', color: '#111827', maxWidth: isWide ? '300px' : '150px' }}>
                                                            {val ? (
                                                                <div style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }} title={String(val)}>{val}</div>
                                                            ) : (
                                                                <span style={{ color: "#d1d5db", fontStyle: "italic" }}>null</span>
                                                            )}
                                                        </td>
                                                    );
                                                })}
                                        </tr>
                                    );
                                })}
                            </tbody>
                        </table>
                    )}

                    {(step === 4 || step === 5) && (
                        <table style={{ width: '100%', textAlign: 'left', fontSize: '0.875rem', whiteSpace: 'nowrap', borderCollapse: 'collapse' }}>
                            <thead style={{ backgroundColor: '#f9fafb', position: 'sticky', top: 0, zIndex: 10, boxShadow: '0 1px 2px rgba(0,0,0,0.05)' }}>
                                <tr>
                                    <th style={{ padding: '0.75rem 1rem', border: '1px solid #e5e7eb', color: '#111827', fontWeight: 700, width: "5rem" }}>Row #</th>
                                    <th style={{ padding: '0.75rem 1rem', border: '1px solid #e5e7eb', color: '#111827', fontWeight: 700, width: "16rem" }}>Product Name</th>
                                    <th style={{ padding: '0.75rem 1rem', border: '1px solid #e5e7eb', color: '#111827', fontWeight: 700, width: "8rem", textAlign: "center" }}>Status</th>
                                    <th style={{ padding: '0.75rem 1rem', border: '1px solid #e5e7eb', color: '#111827', fontWeight: 700 }}>Execution Log</th>
                                </tr>
                            </thead>
                            <tbody>
                                {liveResults.length === 0 && (
                                    <tr>
                                        <td colSpan={4} style={{ padding: '4rem', textAlign: 'center', borderBottom: '1px solid #e5e7eb' }}>
                                            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '1rem', color: '#9ca3af' }}>
                                                <style>{`@keyframes spin { 100% { transform: rotate(360deg); } }`}</style>
                                                <div style={{ width: '2rem', height: '2rem', border: '4px solid #e5e7eb', borderTopColor: '#10b981', borderRadius: '50%', animation: 'spin 1s linear infinite' }}></div>
                                                <p style={{ fontWeight: 500, fontSize: '0.875rem' }}>Processing initial batch of requests...</p>
                                            </div>
                                        </td>
                                    </tr>
                                )}
                                {/* Reversing map to show latest logs at the top intuitively! */}
                                {liveResults.slice().reverse().map((r, revI) => (
                                    <tr key={`${r.rowIndex}-${revI}`} style={{ backgroundColor: revI % 2 === 0 ? '#ffffff' : '#f9fafb', transition: 'background-color 150ms' }} onMouseOver={(e) => e.currentTarget.style.backgroundColor = '#f3f4f6'} onMouseOut={(e) => e.currentTarget.style.backgroundColor = revI % 2 === 0 ? '#ffffff' : '#f9fafb'}>
                                        <td style={{ padding: '0.5rem 1rem', border: '1px solid #e5e7eb', color: '#6b7280', textAlign: 'center' }}>
                                            {r.rowIndex}
                                        </td>
                                        <td style={{ padding: '0.5rem 1rem', border: '1px solid #e5e7eb', color: '#111827', fontWeight: 600, maxWidth: '16rem' }}>
                                            <div style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }} title={r.name}>{r.name}</div>
                                        </td>
                                        <td style={{ padding: '0.5rem 1rem', border: '1px solid #e5e7eb', textAlign: "center" }}>
                                            <span style={{
                                                display: 'inline-flex', alignItems: 'center', padding: '0.125rem 0.5rem', borderRadius: '0.25rem', fontSize: '10px', fontWeight: 700, letterSpacing: '0.05em', textTransform: 'uppercase',
                                                backgroundColor: r.status === 'success' ? '#d1fae5' : r.status === 'error' ? '#ffe4e6' : '#fef3c7',
                                                color: r.status === 'success' ? '#047857' : r.status === 'error' ? '#be123c' : '#b45309'
                                            }}>
                                                {r.status}
                                            </span>
                                        </td>
                                        <td style={{ padding: '0.5rem 1rem', border: '1px solid #e5e7eb', color: r.status === 'error' ? '#e11d48' : '#4b5563', whiteSpace: 'normal', fontSize: '0.875rem' }}>
                                            {r.message || 'Processed successfully.'}
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    )}
                </div>
            </Modal>
        </div >
    );
}
