'use client';

import { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import ConfirmModal from '@/components/ConfirmModal';
import ProductViewModal from '@/components/ProductViewModal';

interface Product {
    id: string;
    name: string;
    modelNumber?: string | null;
    sku?: string | null;
    status: string;
    brand: { name: string; manufacturer: { name: string } };
    images: { url: string }[];
    categories: { id: string; name: string }[];
}

interface Props {
    products: Product[];
    brands?: { id: string; name: string }[];
    categories?: { id: string; name: string }[];
    total?: number;
}

export default function ProductsTableClient({ products, brands = [], categories = [], total = 0 }: Props) {
    const router = useRouter();
    const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
    const [allPagesSelected, setAllPagesSelected] = useState(false);
    const [isUpdating, setIsUpdating] = useState(false);
    const [confirmModal, setConfirmModal] = useState<{ isOpen: boolean; title: string; message: string; onConfirm: () => void } | null>(null);
    const [viewProductId, setViewProductId] = useState<string | null>(null);

    // ── Selection helpers ────────────────────────────────────────────────────

    const isPageFullySelected = products.length > 0 && selectedIds.size === products.length;

    const toggleAll = () => {
        if (isPageFullySelected) {
            setSelectedIds(new Set());
            setAllPagesSelected(false);
        } else {
            setSelectedIds(new Set(products.map(p => p.id)));
            setAllPagesSelected(false);
        }
    };

    const toggleItem = (id: string) => {
        const next = new Set(selectedIds);
        if (next.has(id)) {
            next.delete(id);
            setAllPagesSelected(false);
        } else {
            next.add(id);
        }
        setSelectedIds(next);
    };

    const selectedCount = allPagesSelected ? total : selectedIds.size;

    // ── Bulk operations ──────────────────────────────────────────────────────

    const runBulkDelete = async () => {
        setIsUpdating(true);
        try {
            let res: Response;
            if (allPagesSelected) {
                // Server will look up all products — just pass a sentinel
                res = await fetch('/api/products/bulk', {
                    method: 'DELETE',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ allPages: true }),
                });
            } else {
                res = await fetch('/api/products/bulk', {
                    method: 'DELETE',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ ids: Array.from(selectedIds) }),
                });
            }
            if (!res.ok) throw new Error('Failed to delete products');
            setSelectedIds(new Set());
            setAllPagesSelected(false);
            router.refresh();
        } catch (e: any) {
            alert(e.message);
        } finally {
            setIsUpdating(false);
        }
    };

    const handleBulkDelete = () => {
        setConfirmModal({
            isOpen: true,
            title: 'Confirm Bulk Delete',
            message: `Are you sure you want to delete ${selectedCount} product${selectedCount !== 1 ? 's' : ''}? This action cannot be undone.`,
            onConfirm: async () => {
                setConfirmModal(null);
                await runBulkDelete();
            },
        });
    };

    const handleBulkStatusChange = (value: string) => {
        if (!value) return;
        setConfirmModal({
            isOpen: true,
            title: 'Confirm Bulk Status Update',
            message: `Set status to "${value}" for ${selectedCount} product${selectedCount !== 1 ? 's' : ''}?`,
            onConfirm: async () => {
                setConfirmModal(null);
                setIsUpdating(true);
                try {
                    const body = allPagesSelected
                        ? { allPages: true, data: { status: value } }
                        : { ids: Array.from(selectedIds), data: { status: value } };
                    const res = await fetch('/api/products/bulk', {
                        method: 'PATCH',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify(body),
                    });
                    if (!res.ok) throw new Error('Failed to update status');
                    setSelectedIds(new Set());
                    setAllPagesSelected(false);
                    router.refresh();
                } catch (e: any) {
                    alert(e.message);
                } finally {
                    setIsUpdating(false);
                }
            },
        });
    };

    const handleBulkBrandChange = (brandId: string) => {
        if (!brandId) return;
        const brandName = brands.find(b => b.id === brandId)?.name ?? brandId;
        setConfirmModal({
            isOpen: true,
            title: 'Confirm Bulk Brand Update',
            message: `Reassign ${selectedCount} product${selectedCount !== 1 ? 's' : ''} to brand "${brandName}"?`,
            onConfirm: async () => {
                setConfirmModal(null);
                setIsUpdating(true);
                try {
                    const body = allPagesSelected
                        ? { allPages: true, data: { brandId } }
                        : { ids: Array.from(selectedIds), data: { brandId } };
                    const res = await fetch('/api/products/bulk', {
                        method: 'PATCH',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify(body),
                    });
                    if (!res.ok) throw new Error('Failed to update brand');
                    setSelectedIds(new Set());
                    setAllPagesSelected(false);
                    router.refresh();
                } catch (e: any) {
                    alert(e.message);
                } finally {
                    setIsUpdating(false);
                }
            },
        });
    };

    const handleBulkCategoryChange = (categoryId: string) => {
        if (!categoryId) return;
        const catName = categories.find(c => c.id === categoryId)?.name ?? categoryId;
        setConfirmModal({
            isOpen: true,
            title: 'Confirm Bulk Category Update',
            message: `Add category "${catName}" to ${selectedCount} product${selectedCount !== 1 ? 's' : ''}?`,
            onConfirm: async () => {
                setConfirmModal(null);
                setIsUpdating(true);
                try {
                    // Use categoryIds array for proper M2M handling
                    const body = allPagesSelected
                        ? { allPages: true, data: { categoryIds: [categoryId] } }
                        : { ids: Array.from(selectedIds), data: { categoryIds: [categoryId] } };
                    const res = await fetch('/api/products/bulk', {
                        method: 'PATCH',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify(body),
                    });
                    if (!res.ok) throw new Error('Failed to update category');
                    setSelectedIds(new Set());
                    setAllPagesSelected(false);
                    router.refresh();
                } catch (e: any) {
                    alert(e.message);
                } finally {
                    setIsUpdating(false);
                }
            },
        });
    };

    const handleBulkEnrich = async () => {
        const count = allPagesSelected ? total : selectedIds.size;
        if (count === 0) return;
        if (!confirm(`Start an enrichment job for ${count} product${count !== 1 ? 's' : ''}?\n\nThis will normalize names, match taxonomy, and generate proposed changes for review.`)) return;
        setIsUpdating(true);
        try {
            const res = await fetch('/api/enrichment', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    name: `Products enrichment — ${new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}`,
                    sourceType: 'MANUAL_LIST',
                    sourceFilter: {
                        productIds: allPagesSelected ? [] : Array.from(selectedIds),
                        ...(allPagesSelected ? { allPages: true } : {}),
                    },
                }),
            });
            const data = await res.json();
            if (!res.ok) throw new Error(data.error || 'Failed to start enrichment job');
            router.push(`/admin/enrichment/${data.id}`);
        } catch (e: any) {
            alert(e.message);
        } finally {
            setIsUpdating(false);
        }
    };

    // ── Render ───────────────────────────────────────────────────────────────

    return (
        <div className="card" style={{ padding: 0, overflow: 'hidden' }}>

            {/* ── Select-all-pages banner ── */}
            {isPageFullySelected && !allPagesSelected && total > products.length && (
                <div style={{
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    gap: 'var(--space-3)',
                    padding: 'var(--space-3) var(--space-4)',
                    background: 'color-mix(in srgb, var(--color-primary) 8%, transparent)',
                    borderBottom: '1px solid color-mix(in srgb, var(--color-primary) 20%, transparent)',
                    fontSize: 'var(--font-size-sm)',
                }}>
                    <span style={{ color: 'var(--color-text-secondary)' }}>
                        All <strong>{products.length}</strong> products on this page are selected.
                    </span>
                    <button
                        className="btn btn-sm btn-primary"
                        onClick={() => setAllPagesSelected(true)}
                        disabled={isUpdating}
                    >
                        Select all {total.toLocaleString()} products
                    </button>
                </div>
            )}

            {allPagesSelected && (
                <div style={{
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    gap: 'var(--space-3)',
                    padding: 'var(--space-3) var(--space-4)',
                    background: 'color-mix(in srgb, var(--color-primary) 12%, transparent)',
                    borderBottom: '1px solid color-mix(in srgb, var(--color-primary) 25%, transparent)',
                    fontSize: 'var(--font-size-sm)',
                }}>
                    <span style={{ color: 'var(--color-text-secondary)' }}>
                        All <strong style={{ color: 'var(--color-primary)' }}>{total.toLocaleString()}</strong> products are selected.
                    </span>
                    <button
                        className="btn btn-sm btn-ghost"
                        onClick={() => { setAllPagesSelected(false); setSelectedIds(new Set()); }}
                        disabled={isUpdating}
                    >
                        Clear selection
                    </button>
                </div>
            )}

            {/* ── Bulk action bar ── */}
            {(selectedIds.size > 0 || allPagesSelected) && (
                <div style={{
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    padding: 'var(--space-3) var(--space-4)',
                    background: 'var(--color-bg-elevated)',
                    borderBottom: '1px solid var(--color-border)',
                }}>
                    <span style={{ fontSize: 'var(--font-size-sm)', fontWeight: 600 }}>
                        {selectedCount.toLocaleString()} selected
                    </span>
                    <div style={{ display: 'flex', gap: 'var(--space-2)', alignItems: 'center' }}>
                        {/* Status */}
                        <select
                            className="form-select"
                            style={{ height: '32px', padding: '0 var(--space-3)', fontSize: 'var(--font-size-xs)' }}
                            onChange={e => { handleBulkStatusChange(e.target.value); e.target.value = ''; }}
                            defaultValue=""
                            disabled={isUpdating}
                        >
                            <option value="" disabled>Set Status…</option>
                            <option value="ACTIVE">Active</option>
                            <option value="DISCONTINUED">Discontinued</option>
                            <option value="COMING_SOON">Coming Soon</option>
                            <option value="DRAFT">Draft</option>
                        </select>

                        {/* Brand */}
                        <select
                            className="form-select"
                            style={{ height: '32px', padding: '0 var(--space-3)', fontSize: 'var(--font-size-xs)' }}
                            onChange={e => { handleBulkBrandChange(e.target.value); e.target.value = ''; }}
                            defaultValue=""
                            disabled={isUpdating}
                        >
                            <option value="" disabled>Set Brand…</option>
                            {brands.map(b => <option key={b.id} value={b.id}>{b.name}</option>)}
                        </select>

                        {/* Category (M2M — adds to existing categories) */}
                        <select
                            className="form-select"
                            style={{ height: '32px', padding: '0 var(--space-3)', fontSize: 'var(--font-size-xs)' }}
                            onChange={e => { handleBulkCategoryChange(e.target.value); e.target.value = ''; }}
                            defaultValue=""
                            disabled={isUpdating}
                        >
                            <option value="" disabled>Add Category…</option>
                            {categories.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                        </select>

                        <button
                            className="btn btn-sm btn-secondary"
                            onClick={handleBulkEnrich}
                            disabled={isUpdating}
                            style={{ gap: '4px' }}
                        >
                            🔬 Enrich Selected
                        </button>

                        <button
                            className="btn btn-sm btn-secondary"
                            onClick={handleBulkDelete}
                            disabled={isUpdating}
                            style={{ color: 'var(--color-error)', borderColor: 'var(--color-error)' }}
                        >
                            Delete Selected
                        </button>
                    </div>
                </div>
            )}

            {/* ── Table ── */}
            <table className="data-table">
                <thead>
                    <tr>
                        <th style={{ width: 40, textAlign: 'center' }}>
                            <input
                                type="checkbox"
                                onChange={toggleAll}
                                checked={isPageFullySelected}
                                style={{ width: 16, height: 16 }}
                            />
                        </th>
                        <th>Product</th>
                        <th>Brand</th>
                        <th>Categories</th>
                        <th>Status</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    {products.length === 0 ? (
                        <tr>
                            <td colSpan={6}>
                                <div className="empty-state">
                                    <h3>No products found</h3>
                                    <p>Try adjusting your filters or <Link href="/admin/products/new">add a product</Link>.</p>
                                </div>
                            </td>
                        </tr>
                    ) : (
                        products.map((product) => (
                            <tr
                                key={product.id}
                                style={{ background: selectedIds.has(product.id) || allPagesSelected ? 'var(--color-bg-card-hover)' : 'transparent' }}
                            >
                                <td style={{ textAlign: 'center' }}>
                                    <input
                                        type="checkbox"
                                        checked={selectedIds.has(product.id) || allPagesSelected}
                                        onChange={() => toggleItem(product.id)}
                                        style={{ width: 16, height: 16 }}
                                    />
                                </td>

                                {/* Product name + thumbnail */}
                                <td>
                                    <div style={{ display: 'flex', alignItems: 'center', gap: 'var(--space-3)' }}>
                                        {product.images[0] ? (
                                            <img
                                                src={product.images[0].url}
                                                alt={product.name}
                                                style={{
                                                    width: 40,
                                                    height: 40,
                                                    objectFit: 'cover',
                                                    borderRadius: 'var(--radius-md)',
                                                    border: '1px solid var(--color-border)',
                                                    flexShrink: 0,
                                                }}
                                            />
                                        ) : (
                                            <div style={{
                                                width: 40,
                                                height: 40,
                                                background: 'var(--color-bg)',
                                                borderRadius: 'var(--radius-md)',
                                                display: 'flex',
                                                alignItems: 'center',
                                                justifyContent: 'center',
                                                fontSize: '1.1rem',
                                                flexShrink: 0,
                                                border: '1px solid var(--color-border)',
                                            }}>🔥</div>
                                        )}
                                        <div style={{ minWidth: 0 }}>
                                            <Link
                                                href={`/admin/products/${product.id}/edit`}
                                                style={{ fontWeight: 600, color: 'var(--color-text-primary)', display: 'block', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', maxWidth: '380px' }}
                                            >
                                                {product.name}
                                            </Link>
                                            {(product.modelNumber || product.sku) && (
                                                <Link
                                                    href={`/admin/products/${product.id}/edit`}
                                                    style={{ fontSize: 'var(--font-size-xs)', color: 'var(--color-text-muted)', display: 'block', textDecoration: 'none' }}
                                                >
                                                    {product.modelNumber}{product.sku ? ` · ${product.sku}` : ''}
                                                </Link>
                                            )}
                                        </div>
                                    </div>
                                </td>

                                {/* Brand */}
                                <td>
                                    <div style={{ fontSize: 'var(--font-size-sm)', fontWeight: 500 }}>
                                        {product.brand.name}
                                    </div>
                                    <div style={{ fontSize: 'var(--font-size-xs)', color: 'var(--color-text-muted)' }}>
                                        {product.brand.manufacturer.name}
                                    </div>
                                </td>

                                {/* Categories — pill chips */}
                                <td>
                                    <div style={{ display: 'flex', flexWrap: 'wrap', gap: '4px' }}>
                                        {product.categories.length === 0 ? (
                                            <span style={{ fontSize: '11px', color: 'var(--color-text-muted)' }}>—</span>
                                        ) : (
                                            <>
                                                {product.categories.slice(0, 2).map(cat => (
                                                    <span
                                                        key={cat.id}
                                                        style={{
                                                            fontSize: '11px',
                                                            background: 'var(--color-bg-elevated)',
                                                            color: 'var(--color-text-secondary)',
                                                            border: '1px solid var(--color-border)',
                                                            borderRadius: '999px',
                                                            padding: '2px 8px',
                                                            whiteSpace: 'nowrap',
                                                        }}
                                                    >
                                                        {cat.name}
                                                    </span>
                                                ))}
                                                {product.categories.length > 2 && (
                                                    <span style={{ fontSize: '11px', color: 'var(--color-text-muted)' }}>
                                                        +{product.categories.length - 2}
                                                    </span>
                                                )}
                                            </>
                                        )}
                                    </div>
                                </td>

                                {/* Status */}
                                <td>
                                    <span className={`badge badge-${product.status === 'ACTIVE' ? 'active' : product.status === 'DISCONTINUED' ? 'danger' : 'warning'}`}>
                                        {product.status}
                                    </span>
                                </td>

                                {/* Actions */}
                                <td style={{ whiteSpace: 'nowrap' }}>
                                    <Link href={`/admin/products/${product.id}/edit`} className="btn btn-ghost btn-sm">
                                        Edit
                                    </Link>
                                    <button
                                        className="btn btn-ghost btn-sm"
                                        style={{ marginLeft: '4px' }}
                                        onClick={() => setViewProductId(product.id)}
                                    >
                                        View
                                    </button>
                                </td>
                            </tr>
                        ))
                    )}
                </tbody>
            </table>

            {confirmModal && (
                <ConfirmModal
                    isOpen={confirmModal.isOpen}
                    title={confirmModal.title}
                    message={confirmModal.message}
                    onConfirm={confirmModal.onConfirm}
                    onCancel={() => setConfirmModal(null)}
                />
            )}

            <ProductViewModal
                productId={viewProductId}
                onClose={() => setViewProductId(null)}
            />
        </div>
    );
}
