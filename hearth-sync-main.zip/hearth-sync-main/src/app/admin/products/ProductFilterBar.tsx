"use client";

import { useState } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import SearchableMultiSelect from '@/components/SearchableMultiSelect';
import Link from 'next/link';

interface Brand { id: string; name: string; }
interface Category { id: string; name: string; }

interface Props {
    brands: Brand[];
    categories: Category[];
    initialValues: {
        q?: string;
        status?: string;
        brand?: string;
        categoryIds: string[];
        limit: string;
    };
}

export default function ProductFilterBar({ brands, categories, initialValues }: Props) {
    const router = useRouter();
    const searchParams = useSearchParams();

    const [q, setQ] = useState(initialValues.q || '');
    const [status, setStatus] = useState(initialValues.status || '');
    const [brand, setBrand] = useState(initialValues.brand || '');
    const [categoryIds, setCategoryIds] = useState<string[]>(initialValues.categoryIds);
    const [limit, setLimit] = useState(initialValues.limit);

    const applyFilters = (overrides: Partial<{ q: string; status: string; brand: string; categoryIds: string[]; limit: string }> = {}) => {
        const params = new URLSearchParams();
        const effectiveQ = overrides.q !== undefined ? overrides.q : q;
        const effectiveStatus = overrides.status !== undefined ? overrides.status : status;
        const effectiveBrand = overrides.brand !== undefined ? overrides.brand : brand;
        const effectiveCategoryIds = overrides.categoryIds !== undefined ? overrides.categoryIds : categoryIds;
        const effectiveLimit = overrides.limit !== undefined ? overrides.limit : limit;

        if (effectiveQ) params.set('q', effectiveQ);
        if (effectiveStatus) params.set('status', effectiveStatus);
        if (effectiveBrand) params.set('brand', effectiveBrand);
        effectiveCategoryIds.forEach(id => params.append('category', id));
        params.set('limit', effectiveLimit);
        params.set('page', '1');

        router.push(`/admin/products?${params.toString()}`);
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        applyFilters();
    };

    const handleLimitChange = (newLimit: string) => {
        setLimit(newLimit);
        applyFilters({ limit: newLimit });
    };

    const handleStatusChange = (newStatus: string) => {
        setStatus(newStatus);
        applyFilters({ status: newStatus });
    };

    const handleBrandChange = (newBrand: string) => {
        setBrand(newBrand);
        applyFilters({ brand: newBrand });
    };

    const handleCategoryChange = (newIds: string[]) => {
        setCategoryIds(newIds);
        applyFilters({ categoryIds: newIds });
    };

    const handleClear = () => {
        setQ('');
        setStatus('');
        setBrand('');
        setCategoryIds([]);
        setLimit('25');
        router.push('/admin/products');
    };

    return (
        <form
            onSubmit={handleSubmit}
            style={{
                display: 'flex',
                gap: 'var(--space-3)',
                marginBottom: 'var(--space-6)',
                flexWrap: 'wrap',
                alignItems: 'flex-start',
            }}
        >
            <input
                type="text"
                className="form-input"
                placeholder="Search by name, model, or SKU..."
                value={q}
                onChange={e => setQ(e.target.value)}
                style={{ maxWidth: '280px', flex: '1 1 200px' }}
            />
            <select
                className="form-select"
                value={status}
                onChange={e => handleStatusChange(e.target.value)}
                style={{ maxWidth: '150px' }}
            >
                <option value="">All Status</option>
                <option value="ACTIVE">Active</option>
                <option value="DISCONTINUED">Discontinued</option>
                <option value="COMING_SOON">Coming Soon</option>
                <option value="DRAFT">Draft</option>
            </select>
            <select
                className="form-select"
                value={brand}
                onChange={e => handleBrandChange(e.target.value)}
                style={{ maxWidth: '180px' }}
            >
                <option value="">All Brands</option>
                {brands.map(b => <option key={b.id} value={b.id}>{b.name}</option>)}
            </select>

            <div style={{ minWidth: '220px', flex: '1 1 200px', maxWidth: '300px' }}>
                <SearchableMultiSelect
                    options={categories}
                    selected={categoryIds}
                    onChange={handleCategoryChange}
                    placeholder="All Categories"
                />
            </div>

            <select
                className="form-select"
                value={limit}
                onChange={e => handleLimitChange(e.target.value)}
                style={{ maxWidth: '120px' }}
            >
                <option value="10">10 / page</option>
                <option value="25">25 / page</option>
                <option value="50">50 / page</option>
                <option value="100">100 / page</option>
                <option value="250">250 / page</option>
                <option value="500">500 / page</option>
            </select>

            <button type="submit" className="btn btn-secondary">Filter</button>
            <button type="button" className="btn btn-ghost" onClick={handleClear}>Clear</button>
        </form>
    );
}
