import prisma from '@/lib/db';
import Link from 'next/link';
import AddProductClient from './AddProductClient';

export default async function NewProductPage() {
    const [brands, categories] = await Promise.all([
        prisma.brand.findMany({
            orderBy: { name: 'asc' },
            select: { id: true, name: true, manufacturer: { select: { name: true } } },
        }),
        prisma.productCategory.findMany({
            orderBy: [{ parentId: 'asc' }, { sortOrder: 'asc' }, { name: 'asc' }],
            select: { id: true, name: true, parentId: true },
        }),
    ]);

    return (
        <div style={{ maxWidth: '860px', margin: '0 auto', display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
            <div className="page-header pb-6 border-b border-[var(--color-border)]">
                <div>
                    <h2 className="page-title">Add Product</h2>
                    <p className="page-subtitle">Create a new product in the master catalog</p>
                </div>
                <Link href="/admin/products" className="btn btn-secondary text-sm">
                    ← Back to Products
                </Link>
            </div>
            <AddProductClient brands={brands} categories={categories} />
        </div>
    );
}
