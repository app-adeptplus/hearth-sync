"use client";

import { useState, useMemo } from 'react';
import { useRouter } from 'next/navigation';
import WysiwygEditor from '@/components/WysiwygEditor';
import SearchableMultiSelect from '@/components/SearchableMultiSelect';
import { buildCategoryOptions } from '@/lib/categoryUtils';

interface Brand {
    id: string;
    name: string;
    manufacturer: { name: string };
}

interface Category {
    id: string;
    name: string;
    parentId?: string | null;
}

function slugify(str: string) {
    return str
        .toLowerCase()
        .trim()
        .replace(/[^a-z0-9\s-]/g, '')
        .replace(/\s+/g, '-')
        .replace(/-+/g, '-');
}

export default function AddProductClient({
    brands,
    categories,
}: {
    brands: Brand[];
    categories: Category[];
}) {
    const router = useRouter();

    const [brandId, setBrandId] = useState('');
    const [name, setName] = useState('');
    const [modelNumber, setModelNumber] = useState('');
    const [sku, setSku] = useState('');
    const [status, setStatus] = useState('DRAFT');
    const [categoryIds, setCategoryIds] = useState<string[]>([]);
    const [shortDescription, setShortDescription] = useState('');
    const [description, setDescription] = useState('');

    const [isSaving, setIsSaving] = useState(false);
    const [error, setError] = useState<string | null>(null);

    // Hierarchically sorted categories for the picker
    const categoryOptions = useMemo(() => buildCategoryOptions(categories), [categories]);

    // Group brands by manufacturer for the select
    const grouped = brands.reduce<Record<string, Brand[]>>((acc, b) => {
        const key = b.manufacturer.name;
        if (!acc[key]) acc[key] = [];
        acc[key].push(b);
        return acc;
    }, {});

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setError(null);
        if (!brandId) { setError('Please select a brand.'); return; }
        if (!name.trim()) { setError('Product name is required.'); return; }

        setIsSaving(true);
        try {
            const res = await fetch('/api/products', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    brandId,
                    name: name.trim(),
                    slug: slugify(name),
                    modelNumber: modelNumber || undefined,
                    sku: sku || undefined,
                    status,
                    categories: categoryIds,
                    shortDescription: shortDescription || undefined,
                    description: description || undefined,
                }),
            });

            const data = await res.json();
            if (!res.ok) throw new Error(data.error || 'Failed to create product');

            // Redirect to the new product's edit page
            router.push(`/admin/products/${data.data.id}/edit`);
        } catch (err: any) {
            setError(err.message);
        } finally {
            setIsSaving(false);
        }
    };

    return (
        <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
            {error && (
                <div style={{
                    padding: 'var(--space-3) var(--space-4)',
                    background: 'color-mix(in srgb, var(--color-error) 10%, transparent)',
                    border: '1px solid color-mix(in srgb, var(--color-error) 30%, transparent)',
                    borderRadius: 'var(--radius-md)',
                    color: 'var(--color-error)',
                    fontSize: 'var(--font-size-sm)',
                }}>
                    {error}
                </div>
            )}

            <div className="card p-6" style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
                <h3 style={{ fontWeight: 600, fontSize: 'var(--font-size-md)', paddingBottom: 'var(--space-3)', borderBottom: '1px solid var(--color-border)', marginBottom: 0 }}>
                    Basic Info
                </h3>

                {/* Brand */}
                <div>
                    <label className="block text-sm font-semibold mb-2">
                        Brand <span style={{ color: 'var(--color-error)' }}>*</span>
                    </label>
                    <select
                        className="form-select w-full"
                        value={brandId}
                        onChange={e => setBrandId(e.target.value)}
                        required
                    >
                        <option value="">Select a brand…</option>
                        {Object.entries(grouped).sort(([a], [b]) => a.localeCompare(b)).map(([mfg, mfgBrands]) => (
                            <optgroup key={mfg} label={mfg}>
                                {mfgBrands.map(b => (
                                    <option key={b.id} value={b.id}>{b.name}</option>
                                ))}
                            </optgroup>
                        ))}
                    </select>
                </div>

                {/* Name */}
                <div>
                    <label className="block text-sm font-semibold mb-2">
                        Product Name <span style={{ color: 'var(--color-error)' }}>*</span>
                    </label>
                    <input
                        type="text"
                        className="form-input w-full"
                        value={name}
                        onChange={e => setName(e.target.value)}
                        placeholder="e.g. Escape 36 Gas Fireplace"
                        required
                    />
                    {name && (
                        <p style={{ fontSize: '11px', color: 'var(--color-text-muted)', marginTop: '4px' }}>
                            Slug: <code>{slugify(name)}</code>
                        </p>
                    )}
                </div>

                {/* Model + SKU + Status row */}
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: '1rem' }}>
                    <div>
                        <label className="block text-sm font-semibold mb-2">Model Number</label>
                        <input
                            type="text"
                            className="form-input w-full"
                            value={modelNumber}
                            onChange={e => setModelNumber(e.target.value)}
                            placeholder="e.g. ESS36-2"
                        />
                    </div>
                    <div>
                        <label className="block text-sm font-semibold mb-2">SKU</label>
                        <input
                            type="text"
                            className="form-input w-full"
                            value={sku}
                            onChange={e => setSku(e.target.value)}
                            placeholder="Unique SKU"
                        />
                    </div>
                    <div>
                        <label className="block text-sm font-semibold mb-2">Status</label>
                        <select className="form-select w-full" value={status} onChange={e => setStatus(e.target.value)}>
                            <option value="DRAFT">Draft</option>
                            <option value="ACTIVE">Active</option>
                            <option value="COMING_SOON">Coming Soon</option>
                            <option value="DISCONTINUED">Discontinued</option>
                        </select>
                    </div>
                </div>

                {/* Categories */}
                <div>
                    <label className="block text-sm font-semibold mb-2">Categories</label>
                    <SearchableMultiSelect
                        options={categoryOptions}
                        selected={categoryIds}
                        onChange={setCategoryIds}
                        placeholder="Select categories…"
                    />
                </div>
            </div>

            <div className="card p-6" style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
                <h3 style={{ fontWeight: 600, fontSize: 'var(--font-size-md)', paddingBottom: 'var(--space-3)', borderBottom: '1px solid var(--color-border)', marginBottom: 0 }}>
                    Descriptions
                </h3>
                <div>
                    <label className="block text-sm font-semibold mb-2">Short Description</label>
                    <WysiwygEditor value={shortDescription} onChange={setShortDescription} minHeight="100px" />
                </div>
                <div>
                    <label className="block text-sm font-semibold mb-2">Detailed Description</label>
                    <WysiwygEditor value={description} onChange={setDescription} minHeight="240px" />
                </div>
            </div>

            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 'var(--space-3)', paddingBottom: 'var(--space-8)' }}>
                <button
                    type="button"
                    onClick={() => router.push('/admin/products')}
                    className="btn btn-secondary"
                    disabled={isSaving}
                >
                    Cancel
                </button>
                <button type="submit" className="btn btn-primary" disabled={isSaving}>
                    {isSaving ? 'Creating…' : 'Create Product'}
                </button>
            </div>
        </form>
    );
}
