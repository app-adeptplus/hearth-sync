import prisma from '@/lib/db';
import Link from 'next/link';
import { notFound } from 'next/navigation';
import DOMPurify from 'isomorphic-dompurify';

export const dynamic = 'force-dynamic';

export default async function ProductDetailPage({ params }: { params: { id: string } }) {
    const product = await prisma.product.findUnique({
        where: { id: params.id },
        include: {
            brand: {
                include: { manufacturer: true }
            },
            images: { orderBy: { sortOrder: 'asc' } },
            specs: { orderBy: { sortOrder: 'asc' } },
            documents: true,
            categories: { orderBy: { name: 'asc' } },
            attributeValues: {
                include: { attribute: true },
                orderBy: { attribute: { sortOrder: 'asc' } },
            },
            optionGroups: {
                orderBy: { sortOrder: 'asc' },
                include: {
                    group: {
                        include: {
                            options: {
                                where: { isActive: true },
                                orderBy: [{ sortOrder: 'asc' }, { label: 'asc' }],
                            },
                        },
                    },
                },
            },
        },
    });

    if (!product) {
        notFound();
    }

    const primaryImage = product.images.find((img: any) => img.isPrimary) || product.images[0];
    const otherImages = product.images.filter((img: any) => img.id !== primaryImage?.id);

    return (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem', maxWidth: '72rem', margin: '0 auto' }}>
            <div className="page-header pb-6 border-b border-[var(--color-border)]">
                <div>
                    <h2 className="page-title">{product.name}</h2>
                    <p className="page-subtitle">
                        {product.brand.name} · {product.modelNumber || 'No Model Number'} · {product.sku || 'No SKU'}
                    </p>
                </div>
                <div style={{ display: 'flex', gap: 'var(--space-3)' }}>
                    <Link href="/admin/products" className="btn btn-secondary text-sm">
                        ← Back to Products
                    </Link>
                    <Link href={`/admin/products/${product.id}/edit`} className="btn btn-primary text-sm">
                        Edit Product
                    </Link>
                </div>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: 'minmax(0, 2fr) minmax(0, 1fr)', gap: '1.5rem', alignItems: 'start' }}>
                {/* Left Column */}
                <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>

                    {/* Description */}
                    <div className="card p-6">
                        <h3 className="font-semibold text-lg mb-4 pb-2 border-b border-[var(--color-border)]">Description</h3>
                        <div
                            className="wysiwyg-content"
                            style={{ color: 'var(--color-text-secondary)', fontSize: 'var(--font-size-sm)', whiteSpace: 'pre-wrap' }}
                            dangerouslySetInnerHTML={{
                                __html: DOMPurify.sanitize(product.description || product.shortDescription || '<span style="font-style: italic; color: var(--color-text-muted)">No description available.</span>')
                            }}
                        />
                    </div>

                    {/* Specifications */}
                    <div className="card p-6">
                        <h3 className="font-semibold text-lg mb-4 pb-2 border-b border-[var(--color-border)]">Specifications</h3>
                        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))', gap: '1rem' }}>
                            {product.ventingType && (
                                <div>
                                    <div style={{ fontSize: 'var(--font-size-xs)', color: 'var(--color-text-muted)' }}>Venting Type</div>
                                    <div style={{ fontWeight: 500 }}>{product.ventingType}</div>
                                </div>
                            )}
                            {product.btuInput && (
                                <div>
                                    <div style={{ fontSize: 'var(--font-size-xs)', color: 'var(--color-text-muted)' }}>BTU Input</div>
                                    <div style={{ fontWeight: 500 }}>{product.btuInput.toLocaleString()} BTU</div>
                                </div>
                            )}
                            {product.btuOutput && (
                                <div>
                                    <div style={{ fontSize: 'var(--font-size-xs)', color: 'var(--color-text-muted)' }}>BTU Output</div>
                                    <div style={{ fontWeight: 500 }}>{product.btuOutput.toLocaleString()} BTU</div>
                                </div>
                            )}
                            {product.efficiencyRating && (
                                <div>
                                    <div style={{ fontSize: 'var(--font-size-xs)', color: 'var(--color-text-muted)' }}>Efficiency</div>
                                    <div style={{ fontWeight: 500 }}>{product.efficiencyRating.toString()}%</div>
                                </div>
                            )}
                            {(product.width || product.height || product.depth) && (
                                <div>
                                    <div style={{ fontSize: 'var(--font-size-xs)', color: 'var(--color-text-muted)' }}>Dimensions (W × H × D)</div>
                                    <div style={{ fontWeight: 500 }}>
                                        {product.width?.toString() || '—'} × {product.height?.toString() || '—'} × {product.depth?.toString() || '—'} in
                                    </div>
                                </div>
                            )}
                            {product.weight && (
                                <div>
                                    <div style={{ fontSize: 'var(--font-size-xs)', color: 'var(--color-text-muted)' }}>Weight</div>
                                    <div style={{ fontWeight: 500 }}>{product.weight.toString()} lbs</div>
                                </div>
                            )}
                        </div>

                        {/* ProductSpec rows */}
                        {product.specs.length > 0 && (
                            <div style={{ marginTop: '1.5rem' }}>
                                <h4 className="font-semibold text-sm mb-3">Additional Specs</h4>
                                <table className="data-table">
                                    <tbody>
                                        {product.specs.map((spec: any) => (
                                            <tr key={spec.id}>
                                                <td style={{ width: '40%', color: 'var(--color-text-muted)', fontSize: 'var(--font-size-sm)' }}>{spec.name}</td>
                                                <td style={{ fontWeight: 500, fontSize: 'var(--font-size-sm)' }}>{spec.value}{spec.unit ? ` ${spec.unit}` : ''}</td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                            </div>
                        )}
                    </div>

                    {/* Attribute Values */}
                    {product.attributeValues.length > 0 && (
                        <div className="card p-6">
                            <h3 className="font-semibold text-lg mb-4 pb-2 border-b border-[var(--color-border)]">Attributes</h3>
                            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))', gap: '1rem' }}>
                                {product.attributeValues.map((av: any) => (
                                    <div key={av.id}>
                                        <div style={{ fontSize: 'var(--font-size-xs)', color: 'var(--color-text-muted)' }}>
                                            {av.attribute.name}
                                            {av.attribute.unit ? ` (${av.attribute.unit})` : ''}
                                        </div>
                                        <div style={{ fontWeight: 500 }}>
                                            {av.attribute.dataType === 'boolean'
                                                ? (av.value === 'true' ? 'Yes' : 'No')
                                                : av.value || '—'}
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </div>
                    )}

                    {/* Option Groups */}
                    {(product as any).optionGroups?.length > 0 && (
                        <div className="card p-6">
                            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem', paddingBottom: '0.5rem', borderBottom: '1px solid var(--color-border)' }}>
                                <h3 className="font-semibold text-lg">Configurable Options</h3>
                                <Link href={`/admin/products/${product.id}/edit`} style={{ fontSize: '12px', color: 'var(--color-primary)' }}>Edit</Link>
                            </div>
                            <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                                {(product as any).optionGroups.map((link: any) => {
                                    const g = link.group;
                                    return (
                                        <div key={link.id}>
                                            <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '6px' }}>
                                                <span style={{ fontWeight: 600, fontSize: '13px' }}>{g.name}</span>
                                                <span style={{ fontSize: '10px', background: 'var(--color-bg-elevated)', color: 'var(--color-text-muted)', border: '1px solid var(--color-border)', borderRadius: '8px', padding: '1px 7px' }}>
                                                    {g.inputType}
                                                </span>
                                                {(link.isRequired ?? g.isRequired) && (
                                                    <span style={{ fontSize: '10px', background: 'var(--color-warning)', color: 'white', borderRadius: '8px', padding: '1px 7px', fontWeight: 600 }}>Required</span>
                                                )}
                                            </div>
                                            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '4px', paddingLeft: '4px' }}>
                                                {g.options.map((opt: any) => (
                                                    <span key={opt.id} style={{
                                                        fontSize: '12px', padding: '3px 10px', borderRadius: '8px',
                                                        background: opt.isDefault ? 'var(--color-primary)' : 'var(--color-bg-elevated)',
                                                        color: opt.isDefault ? 'white' : 'var(--color-text-secondary)',
                                                        border: `1px solid ${opt.isDefault ? 'var(--color-primary)' : 'var(--color-border)'}`,
                                                    }}>
                                                        {opt.swatchColor && (
                                                            <span style={{ display: 'inline-block', width: '10px', height: '10px', borderRadius: '2px', background: opt.swatchColor, marginRight: '5px', verticalAlign: 'middle', border: '1px solid rgba(0,0,0,0.15)' }} />
                                                        )}
                                                        {opt.label}
                                                        {opt.priceAdjust && (
                                                            <span style={{ opacity: 0.75, marginLeft: '4px' }}>
                                                                ({Number(opt.priceAdjust) > 0 ? '+' : ''}${Number(opt.priceAdjust).toFixed(0)})
                                                            </span>
                                                        )}
                                                    </span>
                                                ))}
                                            </div>
                                        </div>
                                    );
                                })}
                            </div>
                        </div>
                    )}
                </div>

                {/* Right Column */}
                <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>

                    {/* Status & Price */}
                    <div className="card p-6">
                        <h3 className="font-semibold text-lg mb-4 pb-2 border-b border-[var(--color-border)]">Status</h3>
                        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '1rem' }}>
                            <span style={{ fontSize: 'var(--font-size-sm)', color: 'var(--color-text-muted)' }}>Current Status</span>
                            <span className={`badge badge-${product.status === 'ACTIVE' ? 'active' : product.status === 'DISCONTINUED' ? 'danger' : 'warning'}`}>
                                {product.status}
                            </span>
                        </div>
                        {product.priceMsrp && (
                            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.5rem' }}>
                                <span style={{ fontSize: 'var(--font-size-sm)', color: 'var(--color-text-muted)' }}>MSRP</span>
                                <span style={{ fontWeight: 600 }}>${Number(product.priceMsrp).toFixed(2)}</span>
                            </div>
                        )}
                        {product.priceMap && (
                            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                                <span style={{ fontSize: 'var(--font-size-sm)', color: 'var(--color-text-muted)' }}>MAP</span>
                                <span style={{ fontWeight: 600 }}>${Number(product.priceMap).toFixed(2)}</span>
                            </div>
                        )}
                    </div>

                    {/* Categories */}
                    {product.categories.length > 0 && (
                        <div className="card p-6">
                            <h3 className="font-semibold text-lg mb-4 pb-2 border-b border-[var(--color-border)]">Categories</h3>
                            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '6px' }}>
                                {product.categories.map((cat: any) => (
                                    <span
                                        key={cat.id}
                                        style={{
                                            fontSize: '12px',
                                            background: 'var(--color-bg-elevated)',
                                            color: 'var(--color-text-secondary)',
                                            border: '1px solid var(--color-border)',
                                            borderRadius: '999px',
                                            padding: '3px 10px',
                                        }}
                                    >
                                        {cat.name}
                                    </span>
                                ))}
                            </div>
                        </div>
                    )}

                    {/* Media */}
                    <div className="card p-6">
                        <h3 className="font-semibold text-lg mb-4 pb-2 border-b border-[var(--color-border)]">Media</h3>
                        {primaryImage ? (
                            <div style={{ marginBottom: '1rem' }}>
                                <img
                                    src={primaryImage.url}
                                    alt="Primary product image"
                                    style={{ width: '100%', height: 'auto', borderRadius: 'var(--radius-md)', border: '1px solid var(--color-border)' }}
                                />
                                {otherImages.length > 0 && (
                                    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '0.5rem', marginTop: '0.5rem' }}>
                                        {otherImages.map((img: any) => (
                                            <img
                                                key={img.id}
                                                src={img.url}
                                                alt="Additional product image"
                                                style={{ width: '100%', aspectRatio: '1/1', objectFit: 'cover', borderRadius: 'var(--radius-sm)', border: '1px solid var(--color-border)' }}
                                            />
                                        ))}
                                    </div>
                                )}
                            </div>
                        ) : (
                            <div style={{ padding: '2rem', textAlign: 'center', background: 'var(--color-bg-elevated)', borderRadius: 'var(--radius-md)', border: '1px dashed var(--color-border)', color: 'var(--color-text-muted)' }}>
                                No images available
                            </div>
                        )}
                    </div>

                    {/* Documents */}
                    {product.documents.length > 0 && (
                        <div className="card p-6">
                            <h3 className="font-semibold text-lg mb-4 pb-2 border-b border-[var(--color-border)]">Documents</h3>
                            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
                                {product.documents.map((doc: any) => (
                                    <a
                                        key={doc.id}
                                        href={doc.url}
                                        target="_blank"
                                        rel="noopener noreferrer"
                                        style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', padding: '0.5rem', borderRadius: 'var(--radius-md)', background: 'var(--color-bg-elevated)', border: '1px solid var(--color-border)', fontSize: 'var(--font-size-sm)', textDecoration: 'none', color: 'var(--color-text-primary)' }}
                                    >
                                        📄 {doc.type.replace('_', ' ')}
                                    </a>
                                ))}
                            </div>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
}
