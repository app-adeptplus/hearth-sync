"use client";

import { useState, useMemo } from 'react';
import { useRouter } from 'next/navigation';
import ConfirmModal from '@/components/ConfirmModal';
import Modal from '@/components/Modal';
import WysiwygEditor from '@/components/WysiwygEditor';
import ProductMediaManager from '@/components/ProductMediaManager';
import SearchableMultiSelect from '@/components/SearchableMultiSelect';
import ProductAttributeModal from '@/components/ProductAttributeModal';
import { buildCategoryOptions } from '@/lib/categoryUtils';

export default function EditProductClient({
    product,
    allCategories,
    allOptionGroups,
}: {
    product: any;
    allCategories: any[];
    allOptionGroups: any[];
}) {
    const router = useRouter();

    // ── Core fields ──────────────────────────────────────────────────────────
    const [name, setName] = useState(product.name || '');
    const [modelNumber, setModelNumber] = useState(product.modelNumber || '');
    const [sku, setSku] = useState(product.sku || '');
    const [status, setStatus] = useState(product.status || 'DRAFT');
    const [ventingType, setVentingType] = useState(product.ventingType || '');
    const [btuInput, setBtuInput] = useState(product.btuInput?.toString() || '');
    const [btuOutput, setBtuOutput] = useState(product.btuOutput?.toString() || '');
    const [efficiencyRating, setEfficiencyRating] = useState(product.efficiencyRating?.toString() || '');
    const [width, setWidth] = useState(product.width?.toString() || '');
    const [height, setHeight] = useState(product.height?.toString() || '');
    const [depth, setDepth] = useState(product.depth?.toString() || '');
    const [weight, setWeight] = useState(product.weight?.toString() || '');
    const [priceMsrp, setPriceMsrp] = useState(product.priceMsrp?.toString() || '');
    const [priceMap, setPriceMap] = useState(product.priceMap?.toString() || '');
    const [shortDescription, setShortDescription] = useState(product.shortDescription || '');
    const [description, setDescription] = useState(product.description || '');
    const [categoryIds, setCategoryIds] = useState<string[]>(product.categories?.map((c: any) => c.id) || []);

    // ── Category options — hierarchically sorted ─────────────────────────────
    const categoryOptions = useMemo(
        () => buildCategoryOptions(allCategories.map((c: any) => ({ id: c.id, name: c.name, parentId: c.parentId }))),
        [allCategories]
    );

    // ── Option Groups assignment state ────────────────────────────────────────
    const [assignedGroups, setAssignedGroups] = useState<any[]>(product.optionGroups ?? []);
    const [showGroupPicker, setShowGroupPicker] = useState(false);
    const [isAssigningGroup, setIsAssigningGroup] = useState(false);

    const assignedGroupIds = new Set(assignedGroups.map((l: any) => l.groupId ?? l.group?.id));

    const assignGroup = async (groupId: string) => {
        setIsAssigningGroup(true);
        try {
            const res = await fetch(`/api/products/${product.id}/option-groups`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ groupId, sortOrder: assignedGroups.length }),
            });
            if (!res.ok) { const d = await res.json(); throw new Error(d.error || 'Failed to assign'); }
            const { data } = await res.json();
            setAssignedGroups(prev => [...prev, data]);
            setShowGroupPicker(false);
        } catch (err: any) { alert(err.message); } finally { setIsAssigningGroup(false); }
    };

    const unassignGroup = async (groupId: string) => {
        try {
            const res = await fetch(`/api/products/${product.id}/option-groups`, {
                method: 'DELETE',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ groupId }),
            });
            if (!res.ok) { const d = await res.json(); throw new Error(d.error || 'Failed to remove'); }
            setAssignedGroups(prev => prev.filter((l: any) => (l.groupId ?? l.group?.id) !== groupId));
        } catch (err: any) { alert(err.message); }
    };

    // ── Save handlers ────────────────────────────────────────────────────────
    const [isSaving, setIsSaving] = useState(false);
    const [confirmModal, setConfirmModal] = useState<{
        isOpen: boolean; title: string; message: string; onConfirm: () => void;
    } | null>(null);

    const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
        e.preventDefault();
        setConfirmModal({
            isOpen: true,
            title: 'Confirm Update',
            message: `Save changes to ${product.name}?`,
            onConfirm: async () => {
                setConfirmModal(null);
                setIsSaving(true);
                try {
                    const res = await fetch(`/api/products/${product.id}`, {
                        method: 'PATCH',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({
                            name,
                            shortDescription,
                            description,
                            modelNumber,
                            sku,
                            status,
                            ventingType,
                            btuInput: btuInput ? Number(btuInput) : null,
                            btuOutput: btuOutput ? Number(btuOutput) : null,
                            efficiencyRating: efficiencyRating ? Number(efficiencyRating) : null,
                            width: width ? Number(width) : null,
                            height: height ? Number(height) : null,
                            depth: depth ? Number(depth) : null,
                            weight: weight ? Number(weight) : null,
                            priceMsrp: priceMsrp ? Number(priceMsrp) : null,
                            priceMap: priceMap ? Number(priceMap) : null,
                            categoryIds,
                        }),
                    });
                    if (!res.ok) throw new Error('Failed to update product');
                    router.refresh();
                } catch (error: any) {
                    alert(error.message);
                } finally {
                    setIsSaving(false);
                }
            }
        });
    };

    return (
        <>
            {/* ── Main product form ─────────────────────────────────────────── */}
            <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>

                {/* ── Basic Info ── */}
                <div className="card p-6" style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
                    <h3 style={{ fontWeight: 600, fontSize: 'var(--font-size-md)', paddingBottom: 'var(--space-3)', borderBottom: '1px solid var(--color-border)', marginBottom: 0 }}>
                        Basic Info
                    </h3>

                    <div>
                        <label className="block text-sm font-semibold mb-2">Product Name</label>
                        <input
                            type="text"
                            className="form-input w-full"
                            value={name}
                            onChange={e => setName(e.target.value)}
                            required
                        />
                    </div>

                    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: '1rem' }}>
                        <div>
                            <label className="block text-sm font-semibold mb-2">Model Number</label>
                            <input type="text" className="form-input w-full" value={modelNumber} onChange={e => setModelNumber(e.target.value)} />
                        </div>
                        <div>
                            <label className="block text-sm font-semibold mb-2">SKU</label>
                            <input type="text" className="form-input w-full" value={sku} onChange={e => setSku(e.target.value)} />
                        </div>
                        <div>
                            <label className="block text-sm font-semibold mb-2">Status</label>
                            <select className="form-select w-full" value={status} onChange={e => setStatus(e.target.value)}>
                                <option value="ACTIVE">Active</option>
                                <option value="DISCONTINUED">Discontinued</option>
                                <option value="COMING_SOON">Coming Soon</option>
                                <option value="DRAFT">Draft</option>
                            </select>
                        </div>
                    </div>

                    {/* Categories — hierarchically sorted */}
                    <div>
                        <label className="block text-sm font-semibold mb-2">Categories</label>
                        <SearchableMultiSelect
                            options={categoryOptions}
                            selected={categoryIds}
                            onChange={setCategoryIds}
                            placeholder="Select categories…"
                        />
                    </div>
                </div>

                {/* ── Specifications ── */}
                <div className="card p-6" style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
                    <h3 style={{ fontWeight: 600, fontSize: 'var(--font-size-md)', paddingBottom: 'var(--space-3)', borderBottom: '1px solid var(--color-border)', marginBottom: 0 }}>
                        Specifications
                    </h3>
                    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: '1rem' }}>
                        <div>
                            <label className="block text-sm font-semibold mb-2">Venting Type</label>
                            <input type="text" className="form-input w-full" value={ventingType} onChange={e => setVentingType(e.target.value)} placeholder="e.g. Direct Vent" />
                        </div>
                        <div>
                            <label className="block text-sm font-semibold mb-2">BTU Input</label>
                            <input type="number" className="form-input w-full" value={btuInput} onChange={e => setBtuInput(e.target.value)} />
                        </div>
                        <div>
                            <label className="block text-sm font-semibold mb-2">BTU Output</label>
                            <input type="number" className="form-input w-full" value={btuOutput} onChange={e => setBtuOutput(e.target.value)} />
                        </div>
                        <div>
                            <label className="block text-sm font-semibold mb-2">Efficiency (%)</label>
                            <input type="number" step="0.01" className="form-input w-full" value={efficiencyRating} onChange={e => setEfficiencyRating(e.target.value)} />
                        </div>
                    </div>
                    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(150px, 1fr))', gap: '1rem' }}>
                        <div>
                            <label className="block text-sm font-semibold mb-2">Width (in)</label>
                            <input type="number" step="0.01" className="form-input w-full" value={width} onChange={e => setWidth(e.target.value)} />
                        </div>
                        <div>
                            <label className="block text-sm font-semibold mb-2">Height (in)</label>
                            <input type="number" step="0.01" className="form-input w-full" value={height} onChange={e => setHeight(e.target.value)} />
                        </div>
                        <div>
                            <label className="block text-sm font-semibold mb-2">Depth (in)</label>
                            <input type="number" step="0.01" className="form-input w-full" value={depth} onChange={e => setDepth(e.target.value)} />
                        </div>
                        <div>
                            <label className="block text-sm font-semibold mb-2">Weight (lbs)</label>
                            <input type="number" step="0.01" className="form-input w-full" value={weight} onChange={e => setWeight(e.target.value)} />
                        </div>
                    </div>
                </div>

                {/* ── Pricing ── */}
                <div className="card p-6" style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
                    <h3 style={{ fontWeight: 600, fontSize: 'var(--font-size-md)', paddingBottom: 'var(--space-3)', borderBottom: '1px solid var(--color-border)', marginBottom: 0 }}>
                        Pricing
                    </h3>
                    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '1rem' }}>
                        <div>
                            <label className="block text-sm font-semibold mb-2">MSRP ($)</label>
                            <input type="number" step="0.01" className="form-input w-full" value={priceMsrp} onChange={e => setPriceMsrp(e.target.value)} />
                        </div>
                        <div>
                            <label className="block text-sm font-semibold mb-2">MAP ($)</label>
                            <input type="number" step="0.01" className="form-input w-full" value={priceMap} onChange={e => setPriceMap(e.target.value)} />
                        </div>
                    </div>
                </div>

                {/* ── Descriptions ── */}
                <div className="card p-6" style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
                    <h3 style={{ fontWeight: 600, fontSize: 'var(--font-size-md)', paddingBottom: 'var(--space-3)', borderBottom: '1px solid var(--color-border)', marginBottom: 0 }}>
                        Descriptions
                    </h3>
                    <div>
                        <label className="block text-sm font-semibold mb-2">Short Description</label>
                        <WysiwygEditor value={shortDescription} onChange={setShortDescription} minHeight="120px" />
                    </div>
                    <div>
                        <label className="block text-sm font-semibold mb-2">Detailed Description</label>
                        <WysiwygEditor value={description} onChange={setDescription} minHeight="300px" />
                    </div>
                </div>

                {/* ── Save / Cancel ── */}
                <div style={{ display: 'flex', gap: 'var(--space-3)', justifyContent: 'flex-end', paddingBottom: 'var(--space-4)' }}>
                    <button type="button" onClick={() => router.back()} className="btn btn-secondary" disabled={isSaving}>
                        Cancel
                    </button>
                    <button type="submit" className="btn btn-primary" disabled={isSaving}>
                        {isSaving ? 'Saving…' : 'Save Changes'}
                    </button>
                </div>

                {confirmModal && (
                    <ConfirmModal
                        isOpen={confirmModal.isOpen}
                        title={confirmModal.title}
                        message={confirmModal.message}
                        onConfirm={confirmModal.onConfirm}
                        onCancel={() => setConfirmModal(null)}
                    />
                )}
            </form>

            {/* ── Attributes — OUTSIDE the form so clicking never triggers submit ── */}
            <div className="card p-6" style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                <div style={{ paddingBottom: 'var(--space-3)', borderBottom: '1px solid var(--color-border)' }}>
                    <h3 style={{ fontWeight: 600, fontSize: 'var(--font-size-md)', marginBottom: '4px' }}>
                        Attributes
                    </h3>
                    <p style={{ fontSize: '12px', color: 'var(--color-text-muted)' }}>
                        Attribute values are saved independently from the main product fields.
                    </p>
                </div>
                <ProductAttributeModal productId={product.id} />
            </div>

            {/* ── Option Groups ── */}
            <div className="card p-6" style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', paddingBottom: 'var(--space-3)', borderBottom: '1px solid var(--color-border)' }}>
                    <div>
                        <h3 style={{ fontWeight: 600, fontSize: 'var(--font-size-md)', marginBottom: '4px' }}>Option Groups</h3>
                        <p style={{ fontSize: '12px', color: 'var(--color-text-muted)' }}>
                            Buyer-selectable choices (e.g. Finish, Fuel Type) assigned to this product.
                        </p>
                    </div>
                    <button type="button" className="btn btn-secondary btn-sm" onClick={() => setShowGroupPicker(true)}>
                        + Add Option Group
                    </button>
                </div>

                {assignedGroups.length === 0 ? (
                    <p style={{ fontSize: '13px', color: 'var(--color-text-muted)', fontStyle: 'italic' }}>No option groups assigned yet.</p>
                ) : (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
                        {assignedGroups.map((link: any) => {
                            const g = link.group;
                            const gId = link.groupId ?? g?.id;
                            return (
                                <div key={link.id ?? gId} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '10px 12px', background: 'var(--color-bg-elevated)', borderRadius: 'var(--radius-md)', border: '1px solid var(--color-border)' }}>
                                    <div>
                                        <span style={{ fontWeight: 500, fontSize: '13px' }}>{g?.name}</span>
                                        <span style={{ fontSize: '11px', color: 'var(--color-text-muted)', marginLeft: '8px' }}>{g?.inputType}</span>
                                        <div style={{ display: 'flex', gap: '4px', marginTop: '4px', flexWrap: 'wrap' }}>
                                            {g?.options?.map((opt: any) => (
                                                <span key={opt.id} style={{ fontSize: '11px', padding: '1px 7px', borderRadius: '6px', background: 'var(--color-bg-card)', border: '1px solid var(--color-border)', color: 'var(--color-text-secondary)' }}>
                                                    {opt.label}
                                                </span>
                                            ))}
                                        </div>
                                    </div>
                                    <button
                                        type="button"
                                        onClick={() => unassignGroup(gId)}
                                        style={{ color: 'var(--color-danger)', background: 'none', border: 'none', cursor: 'pointer', fontSize: '18px', lineHeight: 1, padding: '0 4px', flexShrink: 0 }}
                                        title="Remove group from this product"
                                    >✕</button>
                                </div>
                            );
                        })}
                    </div>
                )}
            </div>

            {/* ── Option Group Picker Modal ── */}
            <Modal
                isOpen={showGroupPicker}
                onClose={() => setShowGroupPicker(false)}
                title="Add Option Group"
                subtitle={`Assign a global option group to ${product.name}`}
                size="md"
                footer={
                    <div style={{ marginLeft: 'auto' }}>
                        <button type="button" className="btn btn-secondary" onClick={() => setShowGroupPicker(false)}>Cancel</button>
                    </div>
                }
            >
                <div style={{ padding: '1.5rem', display: 'flex', flexDirection: 'column', gap: '8px' }}>
                    <p style={{ fontSize: '12px', color: 'var(--color-text-muted)', marginBottom: '0.5rem' }}>
                        Click a group to assign it. Already-assigned groups are greyed out.
                    </p>
                    {allOptionGroups.length === 0 ? (
                        <p style={{ color: 'var(--color-text-muted)', fontStyle: 'italic', fontSize: '13px' }}>No option groups defined yet. <a href="/admin/option-groups" target="_blank" style={{ color: 'var(--color-primary)' }}>Create one →</a></p>
                    ) : allOptionGroups.map((g: any) => {
                        const isAssigned = assignedGroupIds.has(g.id);
                        return (
                            <button
                                key={g.id}
                                type="button"
                                disabled={isAssigned || isAssigningGroup}
                                onClick={() => assignGroup(g.id)}
                                style={{
                                    display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                                    padding: '10px 14px', borderRadius: 'var(--radius-md)',
                                    border: `1px solid ${isAssigned ? 'var(--color-border)' : 'var(--color-primary)'}`,
                                    background: isAssigned ? 'var(--color-bg-elevated)' : 'transparent',
                                    opacity: isAssigned ? 0.45 : 1,
                                    cursor: isAssigned ? 'not-allowed' : 'pointer',
                                    textAlign: 'left', width: '100%',
                                    transition: 'all 0.15s',
                                }}
                            >
                                <div>
                                    <span style={{ fontWeight: 500, fontSize: '13px', color: 'var(--color-text-primary)' }}>{g.name}</span>
                                    <span style={{ fontSize: '11px', color: 'var(--color-text-muted)', marginLeft: '8px' }}>{g.inputType}</span>
                                </div>
                                <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                                    <span style={{ fontSize: '11px', color: 'var(--color-text-muted)' }}>{g._count.options} option{g._count.options !== 1 ? 's' : ''}</span>
                                    {isAssigned && <span style={{ fontSize: '10px', background: 'var(--color-bg-elevated)', padding: '1px 6px', borderRadius: '6px', border: '1px solid var(--color-border)', color: 'var(--color-text-muted)' }}>Assigned</span>}
                                </div>
                            </button>
                        );
                    })}
                </div>
            </Modal>

            {/* ── Media ── */}
            <div style={{ marginTop: '2rem', paddingTop: '2rem', borderTop: '1px solid var(--color-border)' }}>
                <h3 style={{ fontSize: 'var(--font-size-xl)', fontWeight: 700, marginBottom: '1.5rem' }}>Manage Media &amp; Documents</h3>
                <ProductMediaManager product={product} />
            </div>
        </>
    );
}
