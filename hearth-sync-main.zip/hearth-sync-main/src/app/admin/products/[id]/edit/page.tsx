import prisma from '@/lib/db';
import { notFound } from 'next/navigation';
import Link from 'next/link';
import EditProductClient from './EditProductClient';

export default async function EditProductPage({ params }: { params: { id: string } }) {
    const [product, allOptionGroups] = await Promise.all([
        prisma.product.findUnique({
            where: { id: params.id },
            include: {
                images: { orderBy: { sortOrder: 'asc' } },
                documents: true,
                categories: {
                    include: {
                        attributeMappings: {
                            include: { attribute: true },
                            orderBy: { sortOrder: 'asc' },
                        },
                    },
                },
                attributeValues: { include: { attribute: true } },
                optionGroups: {
                    orderBy: { sortOrder: 'asc' },
                    include: {
                        group: {
                            include: {
                                options: {
                                    where: { isActive: true },
                                    orderBy: [{ sortOrder: 'asc' }, { label: 'asc' }],
                                },
                            },
                        },
                    },
                },
            },
        }),
        prisma.optionGroup.findMany({
            orderBy: [{ sortOrder: 'asc' }, { name: 'asc' }],
            include: { _count: { select: { options: true } } },
        }),
    ]);

    if (!product) notFound();

    const allCategories = await prisma.productCategory.findMany({
        orderBy: [{ parentId: 'asc' }, { sortOrder: 'asc' }, { name: 'asc' }],
        include: {
            attributeMappings: {
                include: { attribute: true },
                orderBy: { sortOrder: 'asc' },
            },
        },
    });

    return (
        <div style={{ margin: '0 auto', display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
            <div className="page-header pb-6 border-b border-[var(--color-border)]">
                <div>
                    <h2 className="page-title">Edit Product</h2>
                    <p className="page-subtitle">{product.name}</p>
                </div>
                <div style={{ display: 'flex', gap: 'var(--space-3)' }}>
                    <Link href="/admin/products" className="btn btn-secondary text-sm">
                        ← Back to Products
                    </Link>
                </div>
            </div>
            <EditProductClient product={product} allCategories={allCategories} allOptionGroups={allOptionGroups} />
        </div>
    );
}

