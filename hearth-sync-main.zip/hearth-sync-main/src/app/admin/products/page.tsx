import prisma from '@/lib/db';
import Link from 'next/link';
import ProductsTableClient from './products-table-client';
import ProductFilterBar from './ProductFilterBar';

async function getProducts(searchParams: Record<string, string | string[] | undefined>) {
    try {
        const pageStr = Array.isArray(searchParams.page) ? searchParams.page[0] : searchParams.page;
        const page = parseInt(pageStr || '1');
        const limitStr = Array.isArray(searchParams.limit) ? searchParams.limit[0] : searchParams.limit;
        const limit = parseInt(limitStr || '25');
        const skip = (page - 1) * limit;

        const where: Record<string, unknown> = {};
        const brand = Array.isArray(searchParams.brand) ? searchParams.brand[0] : searchParams.brand;
        const status = Array.isArray(searchParams.status) ? searchParams.status[0] : searchParams.status;
        const q = Array.isArray(searchParams.q) ? searchParams.q[0] : searchParams.q;

        if (brand) where.brandId = brand;
        if (status) where.status = status;
        if (searchParams.category) {
            const categories = Array.isArray(searchParams.category)
                ? searchParams.category
                : [searchParams.category as string];
            where.categories = { some: { id: { in: categories } } };
        }
        if (q) {
            where.OR = [
                { name: { contains: q, mode: 'insensitive' } },
                { modelNumber: { contains: q, mode: 'insensitive' } },
                { sku: { contains: q, mode: 'insensitive' } },
            ];
        }

        const [products, total, brands, categories] = await Promise.all([
            prisma.product.findMany({
                where,
                skip,
                take: limit,
                orderBy: { updatedAt: 'desc' },
                include: {
                    brand: { select: { name: true, manufacturer: { select: { name: true } } } },
                    images: { where: { isPrimary: true }, take: 1 },
                    categories: { select: { id: true, name: true } },
                },
            }),
            prisma.product.count({ where }),
            prisma.brand.findMany({ select: { id: true, name: true }, orderBy: { name: 'asc' } }),
            prisma.productCategory.findMany({ select: { id: true, name: true }, orderBy: { name: 'asc' } }),
        ]);

        return { products, total, page, limit, totalPages: Math.ceil(total / limit), brands, categories };
    } catch {
        return { products: [], total: 0, page: 1, limit: 25, totalPages: 0, brands: [], categories: [] };
    }
}

/** Build a URLSearchParams string from current params, overriding specific keys */
function buildUrl(base: Record<string, string | string[] | undefined>, overrides: Record<string, string>) {
    const p = new URLSearchParams();
    for (const [key, value] of Object.entries(base)) {
        if (Array.isArray(value)) value.forEach(v => p.append(key, v));
        else if (value) p.append(key, value);
    }
    for (const [key, value] of Object.entries(overrides)) {
        p.delete(key);
        p.set(key, value);
    }
    return p.toString();
}

export default async function ProductsPage({
    searchParams,
}: {
    searchParams: Record<string, string | string[] | undefined>;
}) {
    const { products, total, page, limit, totalPages, brands, categories } = await getProducts(searchParams);

    const selectedCategoryIds = searchParams.category
        ? (Array.isArray(searchParams.category) ? searchParams.category : [searchParams.category as string])
        : [];

    return (
        <>
            <div className="page-header">
                <div>
                    <h2 className="page-title">Products</h2>
                    <p className="page-subtitle">
                        {total.toLocaleString()} products in the master catalog
                    </p>
                </div>
                <div style={{ display: 'flex', gap: 'var(--space-3)' }}>
                    <Link href="/admin/products/import" className="btn btn-secondary text-sm">
                        Bulk Import
                    </Link>
                    <Link href="/admin/products/new" className="btn btn-primary text-sm">
                        + Add Product
                    </Link>
                </div>
            </div>

            {/* Client-side filter bar (handles SearchableMultiSelect onChange) */}
            <ProductFilterBar
                brands={brands}
                categories={categories}
                initialValues={{
                    q: Array.isArray(searchParams.q) ? searchParams.q[0] : searchParams.q,
                    status: Array.isArray(searchParams.status) ? searchParams.status[0] : searchParams.status,
                    brand: Array.isArray(searchParams.brand) ? searchParams.brand[0] : searchParams.brand,
                    categoryIds: selectedCategoryIds,
                    limit: limit.toString(),
                }}
            />

            {/* Products Table */}
            <ProductsTableClient products={products} brands={brands} categories={categories} total={total} />

            {/* Pagination */}
            {totalPages > 1 && (
                <div
                    style={{
                        display: 'flex',
                        justifyContent: 'center',
                        alignItems: 'center',
                        gap: 'var(--space-3)',
                        marginTop: 'var(--space-6)',
                        flexWrap: 'wrap',
                    }}
                >
                    {page > 1 && (
                        <Link
                            href={`/admin/products?${buildUrl(searchParams, { page: (page - 1).toString() })}`}
                            className="btn btn-secondary btn-sm"
                        >
                            ← Previous
                        </Link>
                    )}

                    <span style={{ padding: 'var(--space-2) var(--space-4)', fontSize: 'var(--font-size-sm)', color: 'var(--color-text-muted)' }}>
                        Page {page} of {totalPages}
                    </span>

                    {/* Jump-to-page */}
                    <form
                        action="/admin/products"
                        method="get"
                        style={{ display: 'flex', alignItems: 'center', gap: 'var(--space-2)' }}
                    >
                        {Object.entries(searchParams).map(([key, value]) => {
                            if (key === 'page') return null;
                            if (Array.isArray(value)) return value.map(v => <input key={`${key}-${v}`} type="hidden" name={key} value={v} />);
                            return value ? <input key={key} type="hidden" name={key} value={value} /> : null;
                        })}
                        <label style={{ fontSize: 'var(--font-size-sm)', color: 'var(--color-text-muted)' }}>Go to</label>
                        <input
                            type="number"
                            name="page"
                            min={1}
                            max={totalPages}
                            defaultValue={page}
                            className="form-input"
                            style={{ width: '70px', textAlign: 'center' }}
                        />
                        <button type="submit" className="btn btn-secondary btn-sm">Go</button>
                    </form>

                    {page < totalPages && (
                        <Link
                            href={`/admin/products?${buildUrl(searchParams, { page: (page + 1).toString() })}`}
                            className="btn btn-secondary btn-sm"
                        >
                            Next →
                        </Link>
                    )}
                </div>
            )}
        </>
    );
}
