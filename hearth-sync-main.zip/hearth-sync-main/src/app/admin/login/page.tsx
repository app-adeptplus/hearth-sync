'use client';

import { useState } from 'react';
import { createBrowserClient } from '@supabase/ssr';

export default function AdminLoginPage() {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [showPassword, setShowPassword] = useState(false);
    const [error, setError] = useState('');
    const [loading, setLoading] = useState(false);
    const [forgotMode, setForgotMode] = useState(false);
    const [forgotSent, setForgotSent] = useState(false);

    const getSupabase = () =>
        createBrowserClient(
            process.env.NEXT_PUBLIC_SUPABASE_URL!,
            process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
        );

    const handleLogin = async (e: React.FormEvent) => {
        e.preventDefault();
        setLoading(true);
        setError('');

        try {
            const supabase = getSupabase();
            const { data, error: signInError } = await supabase.auth.signInWithPassword({
                email,
                password,
            });

            if (signInError) {
                setError(signInError.message);
                setLoading(false);
                return;
            }

            // Verify the user has admin role
            // Check app_metadata first (secure/canonical), fall back to user_metadata for legacy admins
            const role =
                (data.user?.app_metadata?.portal_role as string | undefined) ??
                (data.user?.user_metadata?.portal_role as string | undefined);

            if (role && role !== 'admin') {
                await supabase.auth.signOut();
                setError('Access denied. This portal is for administrators only.');
                setLoading(false);
                return;
            }

            // Hard navigation so middleware picks up session cookies
            window.location.href = '/admin';
        } catch (err) {
            console.error('Login error:', err);
            setError(err instanceof Error ? err.message : 'An unexpected error occurred.');
            setLoading(false);
        }
    };

    const handleForgotPassword = async (e: React.FormEvent) => {
        e.preventDefault();
        setLoading(true);
        setError('');

        try {
            const supabase = getSupabase();
            const { error: resetError } = await supabase.auth.resetPasswordForEmail(email, {
                redirectTo: `${window.location.origin}/admin`,
            });

            if (resetError) {
                setError(resetError.message);
            } else {
                setForgotSent(true);
            }
        } catch (err) {
            console.error('Reset password error:', err);
            setError(err instanceof Error ? err.message : 'An unexpected error occurred.');
        } finally {
            setLoading(false);
        }
    };

    return (
        <div
            style={{
                minHeight: '100vh',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                background: 'radial-gradient(ellipse at top, #1a1a2e 0%, #0d1117 70%)',
                padding: '2rem',
            }}
        >
            <div
                style={{
                    width: '100%',
                    maxWidth: '420px',
                    background: 'var(--color-surface, #161b22)',
                    border: '1px solid var(--color-border, #30363d)',
                    borderRadius: '12px',
                    padding: '2.5rem',
                    boxShadow: '0 8px 32px rgba(0,0,0,0.4)',
                }}
            >
                {!forgotMode ? (
                    <>
                        {/* ── Sign In Form ── */}
                        <div style={{ textAlign: 'center', marginBottom: '2rem' }}>
                            <span style={{ fontSize: '2.5rem', display: 'block', marginBottom: '0.75rem' }}>
                                🔥
                            </span>
                            <h1
                                style={{
                                    fontSize: '1.75rem',
                                    fontWeight: 800,
                                    marginBottom: '0.25rem',
                                    background: 'linear-gradient(135deg, #e94560, #f4a261)',
                                    WebkitBackgroundClip: 'text',
                                    WebkitTextFillColor: 'transparent',
                                }}
                            >
                                HearthSync
                            </h1>
                            <p style={{ fontSize: '0.875rem', color: '#8b949e' }}>
                                Admin Dashboard Sign In
                            </p>
                        </div>

                        {error && (
                            <div
                                style={{
                                    padding: '0.75rem 1rem',
                                    background: 'rgba(239, 68, 68, 0.1)',
                                    border: '1px solid rgba(239, 68, 68, 0.3)',
                                    borderRadius: '8px',
                                    color: '#ef4444',
                                    fontSize: '0.875rem',
                                    marginBottom: '1.25rem',
                                }}
                            >
                                {error}
                            </div>
                        )}

                        <form
                            onSubmit={handleLogin}
                            style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}
                        >
                            <div>
                                <label
                                    htmlFor="admin-email"
                                    style={{
                                        display: 'block',
                                        fontSize: '0.875rem',
                                        fontWeight: 500,
                                        marginBottom: '0.5rem',
                                        color: '#c9d1d9',
                                    }}
                                >
                                    Email Address
                                </label>
                                <input
                                    id="admin-email"
                                    type="email"
                                    required
                                    placeholder="admin@example.com"
                                    value={email}
                                    onChange={(e) => setEmail(e.target.value)}
                                    style={{
                                        width: '100%',
                                        padding: '0.625rem 0.875rem',
                                        background: 'var(--color-background, #0d1117)',
                                        border: '1px solid var(--color-border, #30363d)',
                                        borderRadius: '8px',
                                        color: '#c9d1d9',
                                        fontSize: '0.875rem',
                                        outline: 'none',
                                        boxSizing: 'border-box',
                                    }}
                                />
                            </div>

                            <div>
                                <label
                                    htmlFor="admin-password"
                                    style={{
                                        display: 'block',
                                        fontSize: '0.875rem',
                                        fontWeight: 500,
                                        marginBottom: '0.5rem',
                                        color: '#c9d1d9',
                                    }}
                                >
                                    Password
                                </label>
                                <div style={{ position: 'relative' }}>
                                    <input
                                        id="admin-password"
                                        type={showPassword ? 'text' : 'password'}
                                        required
                                        placeholder="••••••••"
                                        value={password}
                                        onChange={(e) => setPassword(e.target.value)}
                                        style={{
                                            width: '100%',
                                            padding: '0.625rem 2.5rem 0.625rem 0.875rem',
                                            background: 'var(--color-background, #0d1117)',
                                            border: '1px solid var(--color-border, #30363d)',
                                            borderRadius: '8px',
                                            color: '#c9d1d9',
                                            fontSize: '0.875rem',
                                            outline: 'none',
                                            boxSizing: 'border-box',
                                        }}
                                    />
                                    <button
                                        type="button"
                                        onClick={() => setShowPassword(!showPassword)}
                                        tabIndex={-1}
                                        style={{
                                            position: 'absolute',
                                            right: '0.625rem',
                                            top: '50%',
                                            transform: 'translateY(-50%)',
                                            background: 'none',
                                            border: 'none',
                                            cursor: 'pointer',
                                            padding: '0.25rem',
                                            fontSize: '1.1rem',
                                            lineHeight: 1,
                                            color: '#8b949e',
                                            display: 'flex',
                                            alignItems: 'center',
                                        }}
                                        title={showPassword ? 'Hide password' : 'Show password'}
                                    >
                                        {showPassword ? '🙈' : '👁️'}
                                    </button>
                                </div>
                            </div>

                            <button
                                type="submit"
                                disabled={loading}
                                style={{
                                    width: '100%',
                                    padding: '0.75rem',
                                    background: loading
                                        ? 'rgba(233, 69, 96, 0.5)'
                                        : 'linear-gradient(135deg, #e94560, #c73e54)',
                                    border: 'none',
                                    borderRadius: '8px',
                                    color: '#ffffff',
                                    fontSize: '0.9375rem',
                                    fontWeight: 600,
                                    cursor: loading ? 'not-allowed' : 'pointer',
                                    transition: 'opacity 0.2s',
                                }}
                            >
                                {loading ? 'Signing in…' : 'Sign In'}
                            </button>
                        </form>

                        <div style={{ textAlign: 'center', marginTop: '1.25rem' }}>
                            <button
                                onClick={() => { setForgotMode(true); setError(''); }}
                                style={{
                                    background: 'none',
                                    border: 'none',
                                    color: '#58a6ff',
                                    cursor: 'pointer',
                                    fontSize: '0.8125rem',
                                }}
                            >
                                Forgot your password?
                            </button>
                        </div>

                        <p
                            style={{
                                textAlign: 'center',
                                marginTop: '1rem',
                                fontSize: '0.8125rem',
                                color: '#484f58',
                            }}
                        >
                            Contact an administrator if you need access.
                        </p>
                    </>
                ) : (
                    <>
                        {/* ── Forgot Password Form ── */}
                        <div style={{ textAlign: 'center', marginBottom: '2rem' }}>
                            <span style={{ fontSize: '2rem', display: 'block', marginBottom: '0.75rem' }}>
                                📧
                            </span>
                            <h1
                                style={{
                                    fontSize: '1.5rem',
                                    fontWeight: 700,
                                    marginBottom: '0.25rem',
                                    color: '#c9d1d9',
                                }}
                            >
                                Reset Password
                            </h1>
                            <p style={{ fontSize: '0.875rem', color: '#8b949e' }}>
                                {forgotSent
                                    ? 'Check your email for a reset link.'
                                    : "We'll send you a password reset link."}
                            </p>
                        </div>

                        {!forgotSent ? (
                            <>
                                {error && (
                                    <div
                                        style={{
                                            padding: '0.75rem 1rem',
                                            background: 'rgba(239, 68, 68, 0.1)',
                                            border: '1px solid rgba(239, 68, 68, 0.3)',
                                            borderRadius: '8px',
                                            color: '#ef4444',
                                            fontSize: '0.875rem',
                                            marginBottom: '1.25rem',
                                        }}
                                    >
                                        {error}
                                    </div>
                                )}

                                <form
                                    onSubmit={handleForgotPassword}
                                    style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}
                                >
                                    <div>
                                        <label
                                            htmlFor="forgot-email"
                                            style={{
                                                display: 'block',
                                                fontSize: '0.875rem',
                                                fontWeight: 500,
                                                marginBottom: '0.5rem',
                                                color: '#c9d1d9',
                                            }}
                                        >
                                            Email Address
                                        </label>
                                        <input
                                            id="forgot-email"
                                            type="email"
                                            required
                                            placeholder="admin@example.com"
                                            value={email}
                                            onChange={(e) => setEmail(e.target.value)}
                                            style={{
                                                width: '100%',
                                                padding: '0.625rem 0.875rem',
                                                background: 'var(--color-background, #0d1117)',
                                                border: '1px solid var(--color-border, #30363d)',
                                                borderRadius: '8px',
                                                color: '#c9d1d9',
                                                fontSize: '0.875rem',
                                                outline: 'none',
                                                boxSizing: 'border-box',
                                            }}
                                        />
                                    </div>

                                    <button
                                        type="submit"
                                        disabled={loading}
                                        style={{
                                            width: '100%',
                                            padding: '0.75rem',
                                            background: loading
                                                ? 'rgba(233, 69, 96, 0.5)'
                                                : 'linear-gradient(135deg, #e94560, #c73e54)',
                                            border: 'none',
                                            borderRadius: '8px',
                                            color: '#ffffff',
                                            fontSize: '0.9375rem',
                                            fontWeight: 600,
                                            cursor: loading ? 'not-allowed' : 'pointer',
                                            transition: 'opacity 0.2s',
                                        }}
                                    >
                                        {loading ? 'Sending…' : 'Send Reset Link'}
                                    </button>
                                </form>
                            </>
                        ) : (
                            <div
                                style={{
                                    textAlign: 'center',
                                    padding: '1.25rem',
                                    background: 'rgba(34, 197, 94, 0.1)',
                                    border: '1px solid rgba(34, 197, 94, 0.3)',
                                    borderRadius: '8px',
                                    color: '#22c55e',
                                    fontSize: '0.875rem',
                                }}
                            >
                                ✓ Reset link sent to {email}
                            </div>
                        )}

                        <div style={{ textAlign: 'center', marginTop: '1.25rem' }}>
                            <button
                                onClick={() => { setForgotMode(false); setForgotSent(false); setError(''); }}
                                style={{
                                    background: 'none',
                                    border: 'none',
                                    color: '#8b949e',
                                    cursor: 'pointer',
                                    fontSize: '0.8125rem',
                                }}
                            >
                                ← Back to sign in
                            </button>
                        </div>
                    </>
                )}
            </div>
        </div>
    );
}
