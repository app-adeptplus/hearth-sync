import { Suspense } from 'react';
import prisma from '@/lib/db';
import ProductAutomationClient from './ProductAutomationClient';

async function getAutomationData() {
    try {
        const [configs, dataPackages, brands, ftpAccounts, manufacturers] = await Promise.all([
            prisma.automationConfig.findMany({
                where: { status: { not: 'ARCHIVED' } },
                include: {
                    brand: { select: { id: true, name: true } },
                    _count: { select: { runs: true, artifacts: true } },
                },
                orderBy: { updatedAt: 'desc' },
            }),
            prisma.dataPackage.findMany({
                include: {
                    brand: { select: { id: true, name: true } },
                    automationRun: {
                        select: {
                            id: true,
                            config: { select: { id: true, name: true, sourceType: true } },
                        },
                    },
                    _count: { select: { items: true } },
                },
                orderBy: { createdAt: 'desc' },
            }),
            prisma.brand.findMany({
                select: { id: true, name: true, manufacturerId: true },
                orderBy: { name: 'asc' },
            }),
            prisma.manufacturerFtpAccount.findMany({
                include: {
                    manufacturer: { select: { id: true, name: true, slug: true } },
                    _count: { select: { uploadLogs: true } },
                },
                orderBy: { createdAt: 'desc' },
            }),
            prisma.manufacturer.findMany({
                select: { id: true, name: true, slug: true },
                orderBy: { name: 'asc' },
            }),
        ]);
        return { configs, dataPackages, brands, ftpAccounts, manufacturers };
    } catch {
        return { configs: [], dataPackages: [], brands: [], ftpAccounts: [], manufacturers: [] };
    }
}

export default async function ProductAutomationPage() {
    const { configs, dataPackages, brands, ftpAccounts, manufacturers } = await getAutomationData();

    return (
        <Suspense fallback={<div className="p-6">Loading...</div>}>
            <ProductAutomationClient
                configs={configs}
                dataPackages={dataPackages}
                brands={brands}
                ftpAccounts={ftpAccounts}
                manufacturers={manufacturers}
            />
        </Suspense>
    );
}
