'use client';

import { useRouter, useSearchParams } from 'next/navigation';
import Link from 'next/link';
import { useState } from 'react';

type TabType = 'SITE_SCRAPER' | 'API_AUTOMATION' | 'FTP_ERP' | 'DATA_PACKAGES';

interface ProductAutomationClientProps {
    configs: any[];
    dataPackages: any[];
    brands: any[];
    ftpAccounts: any[];
    manufacturers: any[];
}

const STATUS_COLORS: Record<string, string> = {
    DRAFT: 'badge-info',
    ACTIVE: 'badge-active',
    PAUSED: 'badge-inactive',
    FAILED: 'badge-error',
    ARCHIVED: 'badge-muted',
    PENDING_REVIEW: 'badge-info',
    ENRICHING: 'badge-warning',
    APPROVED: 'badge-active',
    REJECTED: 'badge-error',
    IMPORTED: 'badge-active',
};

const OCCURRENCE_LABELS: Record<string, string> = {
    MANUAL: 'Manual',
    HOURLY: 'Every Hour',
    DAILY: 'Daily',
    WEEKLY: 'Weekly',
    BIWEEKLY: 'Bi-Weekly',
    MONTHLY: 'Monthly',
};

export default function ProductAutomationClient({ configs, dataPackages, brands, ftpAccounts, manufacturers }: ProductAutomationClientProps) {
    const router = useRouter();
    const searchParams = useSearchParams();
    const activeTab: TabType = (searchParams.get('tab') as TabType) || 'SITE_SCRAPER';

    const setTab = (tab: TabType) => {
        router.push(`/admin/product-automation?tab=${tab}`);
    };

    const filteredConfigs = configs.filter(c => c.sourceType === activeTab);
    const totalConfigs = configs.length;
    const totalPackages = dataPackages.length;

    const [deletingId, setDeletingId] = useState<string | null>(null);
    const [creatingDrop, setCreatingDrop] = useState(false);
    const [dropManufacturerId, setDropManufacturerId] = useState('');
    const [dropBrandId, setDropBrandId] = useState('');
    const [dropLabel, setDropLabel] = useState('');
    const [dropNotes, setDropNotes] = useState('');
    const [dropWorking, setDropWorking] = useState(false);
    const [newCredentials, setNewCredentials] = useState<any>(null);

    // Test upload state
    const [testUploadOpen, setTestUploadOpen] = useState(true);
    const [testUploadAccountId, setTestUploadAccountId] = useState('');
    const [testUploadFile, setTestUploadFile] = useState<File | null>(null);
    const [testUploadWorking, setTestUploadWorking] = useState(false);
    const [testUploadResult, setTestUploadResult] = useState<any>(null);

    const handleArchive = async (id: string) => {
        if (!confirm('Archive this configuration? It will no longer run.')) return;
        setDeletingId(id);
        try {
            const res = await fetch(`/api/automation/configs/${id}`, { method: 'DELETE' });
            if (!res.ok) throw new Error('Failed to archive');
            router.refresh();
        } catch (err: any) {
            alert(err.message);
        } finally {
            setDeletingId(null);
        }
    };

    const handleRunNow = async (id: string) => {
        try {
            const res = await fetch('/api/automation/runs', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ configId: id }),
            });
            if (!res.ok) throw new Error('Failed to trigger run');
            alert('Automation run queued successfully!');
            router.refresh();
        } catch (err: any) {
            alert(err.message);
        }
    };

    const handleCreateDrop = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!dropManufacturerId || !dropBrandId || !dropLabel) return;
        setDropWorking(true);
        try {
            const res = await fetch('/api/automation/ftp-accounts', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ manufacturerId: dropManufacturerId, brandId: dropBrandId, label: dropLabel, notes: dropNotes }),
            });
            const data = await res.json();
            if (!res.ok) throw new Error(data.error || 'Failed to create drop zone');
            setNewCredentials(data);
            setCreatingDrop(false);
            setDropManufacturerId('');
            setDropBrandId('');
            setDropLabel('');
            setDropNotes('');
            router.refresh();
        } catch (err: any) {
            alert(err.message);
        } finally {
            setDropWorking(false);
        }
    };

    const handleDeactivateDrop = async (id: string) => {
        if (!confirm('Deactivate this FTP drop zone?')) return;
        try {
            const res = await fetch(`/api/automation/ftp-accounts/${id}`, { method: 'DELETE' });
            if (!res.ok) throw new Error('Failed to deactivate');
            router.refresh();
        } catch (err: any) {
            alert(err.message);
        }
    };

    const handleReactivateDrop = async (id: string) => {
        try {
            const res = await fetch(`/api/automation/ftp-accounts/${id}`, {
                method: 'PATCH',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ isActive: true }),
            });
            if (!res.ok) throw new Error('Failed to reactivate');
            router.refresh();
        } catch (err: any) {
            alert(err.message);
        }
    };

    const handleTestUpload = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!testUploadFile || !testUploadAccountId) return;
        setTestUploadWorking(true);
        setTestUploadResult(null);
        try {
            const fd = new FormData();
            fd.append('file', testUploadFile);
            fd.append('ftpAccountId', testUploadAccountId);
            const res = await fetch('/api/automation/ftp-accounts/test-upload', {
                method: 'POST',
                body: fd,
            });
            const data = await res.json();
            if (!res.ok) throw new Error(data.error || 'Upload failed');
            setTestUploadResult(data);
            setTestUploadFile(null);
            router.refresh();
        } catch (err: any) {
            alert(err.message);
        } finally {
            setTestUploadWorking(false);
        }
    };

    const formatDate = (d: string | null) => {
        if (!d) return '—';
        return new Date(d).toLocaleDateString('en-US', {
            month: 'short', day: 'numeric', year: 'numeric',
            hour: '2-digit', minute: '2-digit',
        });
    };

    return (
        <>
            <div className="page-header">
                <div>
                    <h2 className="page-title">Product Automation</h2>
                    <p className="page-subtitle">
                        {totalConfigs} configs · {totalPackages} data packages
                    </p>
                </div>
                <div style={{ display: 'flex', gap: 'var(--space-3)' }}>
                    {activeTab !== 'DATA_PACKAGES' ? (
                        <Link
                            href={`/admin/product-automation/new?type=${activeTab}`}
                            className="btn btn-primary"
                            style={{ textDecoration: 'none' }}
                        >
                            ➕ New Config
                        </Link>
                    ) : (
                        <Link
                            href="/admin/product-automation/packages/new"
                            className="btn btn-primary"
                            style={{ textDecoration: 'none' }}
                        >
                            ➕ New Package
                        </Link>
                    )}
                </div>
            </div>

            {/* Tabs */}
            <div style={{
                display: 'flex',
                gap: 'var(--space-2)',
                marginBottom: 'var(--space-6)',
                borderBottom: '1px solid var(--color-border)',
                paddingBottom: 'var(--space-3)',
                overflowX: 'auto',
            }}>
                <button
                    className={`btn ${activeTab === 'SITE_SCRAPER' ? 'btn-primary' : 'btn-ghost'}`}
                    onClick={() => setTab('SITE_SCRAPER')}
                >
                    🌐 Site Scrapers
                </button>
                <button
                    className={`btn ${activeTab === 'API_AUTOMATION' ? 'btn-primary' : 'btn-ghost'}`}
                    onClick={() => setTab('API_AUTOMATION')}
                >
                    🔌 API Automations
                </button>
                <button
                    className={`btn ${activeTab === 'FTP_ERP' ? 'btn-primary' : 'btn-ghost'}`}
                    onClick={() => setTab('FTP_ERP')}
                >
                    📁 FTP/ERP
                </button>
                <button
                    className={`btn ${activeTab === 'DATA_PACKAGES' ? 'btn-primary' : 'btn-ghost'}`}
                    onClick={() => setTab('DATA_PACKAGES')}
                >
                    📦 Data Packages
                </button>
            </div>

            {/* Config Tables — SITE_SCRAPER and API_AUTOMATION tabs */}
            {(activeTab === 'SITE_SCRAPER' || activeTab === 'API_AUTOMATION') && (
                <div id="automation-configs" className="card" style={{ marginBottom: 'var(--space-6)' }}>
                    <div className="card-header">
                        <h3 className="card-title">
                            {activeTab === 'SITE_SCRAPER' && '🌐 Site Scraper Configurations'}
                            {activeTab === 'API_AUTOMATION' && '🔌 API Automation Configurations'}
                        </h3>
                    </div>
                    {filteredConfigs.length === 0 ? (
                        <div className="empty-state" style={{ padding: 'var(--space-8) var(--space-6)' }}>
                            <div style={{ fontSize: '2.5rem', marginBottom: 'var(--space-3)' }}>
                                {activeTab === 'SITE_SCRAPER' && '🌐'}
                                {activeTab === 'API_AUTOMATION' && '🔌'}
                            </div>
                            <p style={{ fontWeight: 600, fontSize: '1.05rem', marginBottom: 'var(--space-2)' }}>
                                No {activeTab === 'SITE_SCRAPER' ? 'site scraper' : 'API automation'} configs yet.
                            </p>
                            <p style={{ color: 'var(--color-text-muted)', fontSize: '0.875rem' }}>
                                {activeTab === 'SITE_SCRAPER' && 'Add a site URL and let the AI automatically scrape product data from manufacturer websites.'}
                                {activeTab === 'API_AUTOMATION' && 'Connect to manufacturer APIs for automated product data streams.'}
                            </p>
                        </div>
                    ) : (
                        <div className="data-table" style={{ width: '100%', textAlign: 'left', borderCollapse: 'collapse' }}>
                            <table style={{ width: '100%' }}>
                                <thead>
                                    <tr style={{ borderBottom: '1px solid var(--color-border)' }}>
                                        <th style={{ padding: 'var(--space-2)' }}>Name</th>
                                        <th style={{ padding: 'var(--space-2)' }}>Brand</th>
                                        {activeTab === 'SITE_SCRAPER' && <th style={{ padding: 'var(--space-2)' }}>Site URL</th>}
                                        {activeTab === 'API_AUTOMATION' && <th style={{ padding: 'var(--space-2)' }}>Endpoint</th>}
                                        <th style={{ padding: 'var(--space-2)' }}>Status</th>
                                        <th style={{ padding: 'var(--space-2)' }}>Occurrence</th>
                                        <th style={{ padding: 'var(--space-2)' }}>Last Run</th>
                                        <th style={{ padding: 'var(--space-2)' }}>Artifacts</th>
                                        <th style={{ padding: 'var(--space-2)' }}>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {filteredConfigs.map((config: any) => (
                                        <tr key={config.id} style={{ borderBottom: '1px solid var(--color-border-light)' }}>
                                            <td style={{ padding: 'var(--space-3) var(--space-2)' }}>
                                                <div style={{ fontWeight: 600, color: 'var(--color-text-primary)' }}>
                                                    {config.name}
                                                </div>
                                                <div style={{ fontSize: '11px', color: 'var(--color-text-muted)', fontFamily: 'monospace' }}>
                                                    #{config.id.slice(0, 8)}
                                                </div>
                                            </td>
                                            <td style={{ padding: 'var(--space-3) var(--space-2)', fontWeight: 500 }}>
                                                {config.brand?.name || '—'}
                                            </td>
                                            {activeTab === 'SITE_SCRAPER' && (
                                                <td style={{ padding: 'var(--space-3) var(--space-2)', color: 'var(--color-text-muted)', fontSize: '13px', maxWidth: '200px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                                                    {config.siteUrl || '—'}
                                                </td>
                                            )}
                                            {activeTab === 'API_AUTOMATION' && (
                                                <td style={{ padding: 'var(--space-3) var(--space-2)', color: 'var(--color-text-muted)', fontSize: '13px', maxWidth: '200px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                                                    {config.apiEndpoint || '—'}
                                                </td>
                                            )}
                                            <td style={{ padding: 'var(--space-3) var(--space-2)' }}>
                                                <span className={`badge ${STATUS_COLORS[config.status] || ''}`}>
                                                    {config.status}
                                                </span>
                                            </td>
                                            <td style={{ padding: 'var(--space-3) var(--space-2)', fontSize: '13px' }}>
                                                {OCCURRENCE_LABELS[config.occurrence] || config.occurrence}
                                            </td>
                                            <td style={{ padding: 'var(--space-3) var(--space-2)', fontSize: '12px', color: 'var(--color-text-muted)' }}>
                                                {formatDate(config.lastRunAt)}
                                            </td>
                                            <td style={{ padding: 'var(--space-3) var(--space-2)' }}>
                                                <span style={{
                                                    display: 'inline-flex', alignItems: 'center', gap: '4px',
                                                    fontSize: '12px', color: 'var(--color-text-muted)',
                                                    background: 'var(--color-bg-elevated)', padding: '2px 8px',
                                                    borderRadius: '12px', border: '1px solid var(--color-border)',
                                                }}>
                                                    🧠 {config._count?.artifacts || 0}
                                                </span>
                                            </td>
                                            <td style={{ padding: 'var(--space-3) var(--space-2)' }}>
                                                <div style={{ display: 'flex', gap: 'var(--space-2)', alignItems: 'center' }}>
                                                    <Link
                                                        href={`/admin/product-automation/${config.id}`}
                                                        className="btn btn-sm btn-secondary"
                                                    >
                                                        Edit
                                                    </Link>
                                                    <button
                                                        className="btn btn-sm btn-ghost"
                                                        onClick={() => handleRunNow(config.id)}
                                                        title="Run Now"
                                                    >
                                                        ▶️
                                                    </button>
                                                    <button
                                                        className="btn btn-sm btn-ghost"
                                                        onClick={() => handleArchive(config.id)}
                                                        disabled={deletingId === config.id}
                                                        title="Archive"
                                                        style={{ color: 'var(--color-text-muted)' }}
                                                    >
                                                        🗄️
                                                    </button>
                                                </div>
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    )}
                </div>
            )}

            {/* FTP/ERP Tab — two-section layout (outbound configs + inbound drop zones) */}
            {activeTab === 'FTP_ERP' && (
                <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-6)' }}>

                    {/* ── Test Upload & Analyze Card ─────────────────────────── */}
                    <div id="test-upload" className="card" style={{ border: '1px dashed var(--color-border)' }}>
                        {/* Header — always visible, click to collapse */}
                        <div
                            className="card-header"
                            style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', cursor: 'pointer', userSelect: 'none' }}
                            onClick={() => { setTestUploadOpen(o => !o); setTestUploadResult(null); }}
                        >
                            <h3 className="card-title" style={{ margin: 0 }}>📂 Test Upload &amp; Analyze</h3>
                            <span style={{ fontSize: '0.75rem', color: 'var(--color-text-muted)' }}>
                                {testUploadOpen ? '▲ collapse' : '▼ expand'} — upload a sample file to inspect its structure
                            </span>
                        </div>

                        {testUploadOpen && (
                            <div style={{ padding: '1rem 1.5rem', borderTop: '1px solid var(--color-border)' }}>
                                {/* Form */}
                                {!testUploadResult && (
                                    <form onSubmit={handleTestUpload}>
                                        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem', marginBottom: '1rem' }}>
                                            <div>
                                                <label style={{ display: 'block', fontSize: '0.8rem', fontWeight: 600, marginBottom: '0.3rem' }}>Drop Zone</label>
                                                <select
                                                    className="form-select"
                                                    style={{ width: '100%' }}
                                                    value={testUploadAccountId}
                                                    onChange={e => setTestUploadAccountId(e.target.value)}
                                                    required
                                                >
                                                    <option value="">— Select a drop zone —</option>
                                                    {ftpAccounts.filter((a: any) => a.isActive).map((a: any) => (
                                                        <option key={a.id} value={a.id}>
                                                            {a.brand?.name || a.manufacturer?.name} — {a.label}
                                                        </option>
                                                    ))}
                                                </select>
                                            </div>
                                            <div>
                                                <label style={{ display: 'block', fontSize: '0.8rem', fontWeight: 600, marginBottom: '0.3rem' }}>File <span style={{ fontWeight: 400, color: 'var(--color-text-muted)' }}>(CSV, JSON, TXT)</span></label>
                                                <input
                                                    type="file"
                                                    accept=".csv,.json,.txt"
                                                    className="form-input"
                                                    style={{ width: '100%', padding: '0.35rem 0.6rem' }}
                                                    onChange={e => setTestUploadFile(e.target.files?.[0] || null)}
                                                    required
                                                />
                                            </div>
                                        </div>
                                        <button
                                            type="submit"
                                            className="btn btn-primary btn-sm"
                                            disabled={testUploadWorking || !testUploadAccountId || !testUploadFile}
                                        >
                                            {testUploadWorking ? '⏳ Analyzing…' : '🔍 Upload & Analyze'}
                                        </button>
                                        <p style={{ marginTop: '0.6rem', fontSize: '0.75rem', color: 'var(--color-text-muted)' }}>
                                            The file will be parsed, its structure inspected, and a <strong>PENDING_REVIEW</strong> Data Package will be created automatically.
                                        </p>
                                    </form>
                                )}

                                {/* Results panel */}
                                {testUploadResult && (
                                    <div>
                                        {/* Summary bar */}
                                        <div style={{
                                            display: 'flex', alignItems: 'center', gap: '1.5rem',
                                            background: 'var(--color-bg-elevated)', borderRadius: '8px',
                                            padding: '0.65rem 1rem', marginBottom: '1.25rem',
                                            fontSize: '0.85rem', flexWrap: 'wrap',
                                        }}>
                                            <span>📄 <strong>{testUploadResult.fileName}</strong></span>
                                            <span style={{ color: 'var(--color-text-muted)' }}>
                                                {(testUploadResult.fileSizeBytes / 1024).toFixed(1)} KB
                                            </span>
                                            <span>🏷️ {testUploadResult.brand?.name}</span>
                                            <span>📊 <strong>{testUploadResult.rowCount.toLocaleString()}</strong> rows · <strong>{testUploadResult.columns?.length}</strong> fields</span>
                                            <Link
                                                href={`/admin/product-automation/packages/${testUploadResult.dataPackageId}`}
                                                className="btn btn-sm btn-secondary"
                                                style={{ marginLeft: 'auto', textDecoration: 'none' }}
                                            >
                                                📦 Review Data Package →
                                            </Link>
                                        </div>

                                        {/* Column analysis */}
                                        <div style={{ marginBottom: '1.25rem' }}>
                                            <div style={{ fontSize: '0.8rem', fontWeight: 700, marginBottom: '0.4rem', color: 'var(--color-text-muted)', textTransform: 'uppercase', letterSpacing: '0.06em' }}>
                                                Field Structure ({testUploadResult.columns?.length} columns)
                                            </div>
                                            <div style={{ overflowX: 'auto' }}>
                                                <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '0.8rem' }}>
                                                    <thead>
                                                        <tr style={{ background: 'var(--color-bg-elevated)' }}>
                                                            <th style={{ padding: '0.35rem 0.75rem', textAlign: 'left', fontWeight: 600 }}>#</th>
                                                            <th style={{ padding: '0.35rem 0.75rem', textAlign: 'left', fontWeight: 600 }}>Field Name</th>
                                                            <th style={{ padding: '0.35rem 0.75rem', textAlign: 'left', fontWeight: 600 }}>Inferred Type</th>
                                                            <th style={{ padding: '0.35rem 0.75rem', textAlign: 'left', fontWeight: 600 }}>Example Value</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        {testUploadResult.columns?.map((col: any, i: number) => (
                                                            <tr key={col.name} style={{ borderBottom: '1px solid var(--color-border-light)' }}>
                                                                <td style={{ padding: '0.3rem 0.75rem', color: 'var(--color-text-muted)', fontFamily: 'monospace' }}>{i + 1}</td>
                                                                <td style={{ padding: '0.3rem 0.75rem', fontWeight: 600, fontFamily: 'monospace' }}>{col.name}</td>
                                                                <td style={{ padding: '0.3rem 0.75rem' }}>
                                                                    <span style={{
                                                                        fontSize: '0.72rem', fontWeight: 600, padding: '1px 7px', borderRadius: '9px',
                                                                        background: col.type === 'number' ? '#1e3a5f' : col.type === 'date' ? '#3b2670' : col.type === 'boolean' ? '#14532d' : '#374151',
                                                                        color: col.type === 'number' ? '#93c5fd' : col.type === 'date' ? '#c4b5fd' : col.type === 'boolean' ? '#86efac' : '#d1d5db',
                                                                    }}>
                                                                        {col.type}
                                                                    </span>
                                                                </td>
                                                                <td style={{ padding: '0.3rem 0.75rem', color: 'var(--color-text-muted)', fontFamily: 'monospace', fontSize: '0.78rem', maxWidth: '280px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                                                                    {col.example || '—'}
                                                                </td>
                                                            </tr>
                                                        ))}
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>

                                        {/* Sample rows */}
                                        {testUploadResult.sample?.length > 0 && (
                                            <div>
                                                <div style={{ fontSize: '0.8rem', fontWeight: 700, marginBottom: '0.4rem', color: 'var(--color-text-muted)', textTransform: 'uppercase', letterSpacing: '0.06em' }}>
                                                    Sample Data (first {testUploadResult.sample.length} rows)
                                                </div>
                                                <div style={{ overflowX: 'auto', fontSize: '0.75rem', fontFamily: 'monospace' }}>
                                                    <table style={{ borderCollapse: 'collapse', width: '100%' }}>
                                                        <thead>
                                                            <tr style={{ background: 'var(--color-bg-elevated)' }}>
                                                                {testUploadResult.columns?.slice(0, 8).map((col: any) => (
                                                                    <th key={col.name} style={{ padding: '0.3rem 0.6rem', textAlign: 'left', whiteSpace: 'nowrap', maxWidth: '180px', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                                                                        {col.name}
                                                                    </th>
                                                                ))}
                                                                {testUploadResult.columns?.length > 8 && <th style={{ padding: '0.3rem 0.6rem', color: 'var(--color-text-muted)' }}>+{testUploadResult.columns.length - 8} more…</th>}
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            {testUploadResult.sample.map((row: any, ri: number) => (
                                                                <tr key={ri} style={{ borderBottom: '1px solid var(--color-border-light)' }}>
                                                                    {testUploadResult.columns?.slice(0, 8).map((col: any) => (
                                                                        <td key={col.name} style={{ padding: '0.3rem 0.6rem', color: 'var(--color-text-muted)', maxWidth: '180px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                                                                            {row[col.name] ?? ''}
                                                                        </td>
                                                                    ))}
                                                                    {testUploadResult.columns?.length > 8 && <td />}
                                                                </tr>
                                                            ))}
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        )}

                                        <button
                                            className="btn btn-ghost btn-sm"
                                            style={{ marginTop: '1rem' }}
                                            onClick={() => { setTestUploadResult(null); setTestUploadFile(null); }}
                                        >
                                            ↩ Upload another file
                                        </button>
                                    </div>
                                )}
                            </div>
                        )}
                    </div>

                    {/* New credentials banner (shown once after creation) */}
                    {newCredentials && (() => {
                        const creds = newCredentials;
                        const credText = [
                            `Host:     ${creds.ftpHost}`,
                            `Port:     ${creds.ftpPort}`,
                            `User:     ${creds.ftpUser}`,
                            `Password: ${creds.ftpPasswordOnce}`,
                            `Path:     ${creds.ftpPath}`,
                        ].join('\n');
                        const handleCopyAll = () => {
                            navigator.clipboard.writeText(credText).then(() => {
                                const btn = document.getElementById('cred-copy-all-btn');
                                if (btn) { btn.textContent = '✓ Copied!'; setTimeout(() => { btn.textContent = '📋 Copy All'; }, 2000); }
                            });
                        };
                        return (
                            <div style={{
                                borderRadius: '10px',
                                border: '1px solid #22c55e',
                                overflow: 'hidden',
                            }}>
                                {/* Header bar */}
                                <div style={{
                                    background: '#14532d',
                                    padding: '0.75rem 1.25rem',
                                    display: 'flex',
                                    alignItems: 'center',
                                    justifyContent: 'space-between',
                                }}>
                                    <div style={{ color: '#86efac', fontWeight: 700, fontSize: '0.9rem' }}>
                                        ✅ Drop Zone Created — Save These Credentials Now
                                    </div>
                                    <span style={{ color: '#86efac', fontSize: '0.75rem', opacity: 0.8 }}>Password shown once only</span>
                                </div>
                                {/* Dark terminal body */}
                                <div style={{ background: '#0f172a', padding: '1rem 1.25rem' }}>
                                    <table style={{ width: '100%', borderCollapse: 'collapse', fontFamily: 'monospace', fontSize: '0.875rem' }}>
                                        <tbody>
                                            {([
                                                { label: 'Host', value: creds.ftpHost },
                                                { label: 'Port', value: String(creds.ftpPort) },
                                                { label: 'User', value: creds.ftpUser },
                                                { label: 'Password', value: creds.ftpPasswordOnce },
                                                { label: 'Path', value: creds.ftpPath },
                                            ] as { label: string; value: string }[]).map(({ label, value }) => (
                                                <tr key={label} style={{ borderBottom: '1px solid #1e293b' }}>
                                                    <td style={{ padding: '0.45rem 1rem 0.45rem 0', color: '#94a3b8', width: '80px', userSelect: 'none' }}>{label}</td>
                                                    <td style={{ padding: '0.45rem 0', color: '#f1f5f9', wordBreak: 'break-all' }}>{value}</td>
                                                </tr>
                                            ))}
                                        </tbody>
                                    </table>
                                </div>
                                {/* Footer actions */}
                                <div style={{
                                    background: '#020617',
                                    padding: '0.6rem 1.25rem',
                                    display: 'flex',
                                    gap: 'var(--space-3)',
                                    alignItems: 'center',
                                }}>
                                    <button
                                        id="cred-copy-all-btn"
                                        onClick={handleCopyAll}
                                        style={{
                                            background: '#1e3a5f',
                                            color: '#93c5fd',
                                            border: '1px solid #2563eb',
                                            borderRadius: '6px',
                                            padding: '0.3rem 0.85rem',
                                            fontSize: '0.8rem',
                                            fontWeight: 600,
                                            cursor: 'pointer',
                                        }}
                                    >
                                        📋 Copy All
                                    </button>
                                    <button
                                        onClick={() => setNewCredentials(null)}
                                        style={{
                                            background: 'transparent',
                                            color: '#64748b',
                                            border: '1px solid #1e293b',
                                            borderRadius: '6px',
                                            padding: '0.3rem 0.85rem',
                                            fontSize: '0.8rem',
                                            cursor: 'pointer',
                                        }}
                                    >
                                        Dismiss
                                    </button>
                                </div>
                            </div>
                        );
                    })()}

                    {/* Section 1: Outbound FTP Configs */}
                    <div id="outbound-ftp-configs" className="card">
                        <div className="card-header" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                            <h3 className="card-title">📤 Outbound FTP Configs</h3>
                            <Link href="/admin/product-automation/new?type=FTP_ERP" className="btn btn-sm btn-secondary" style={{ textDecoration: 'none' }}>➕ New Config</Link>
                        </div>
                        {filteredConfigs.length === 0 ? (
                            <div className="empty-state" style={{ padding: 'var(--space-6)' }}>
                                <p style={{ color: 'var(--color-text-muted)', fontSize: '0.875rem' }}>No outbound FTP configs yet. Add one to connect to a manufacturer&apos;s FTP server.</p>
                            </div>
                        ) : (
                            <div className="data-table">
                                <table style={{ width: '100%' }}>
                                    <thead>
                                        <tr style={{ borderBottom: '1px solid var(--color-border)' }}>
                                            <th style={{ padding: 'var(--space-2)' }}>Name</th>
                                            <th style={{ padding: 'var(--space-2)' }}>Brand</th>
                                            <th style={{ padding: 'var(--space-2)' }}>Host / Path</th>
                                            <th style={{ padding: 'var(--space-2)' }}>Status</th>
                                            <th style={{ padding: 'var(--space-2)' }}>Occurrence</th>
                                            <th style={{ padding: 'var(--space-2)' }}>Last Run</th>
                                            <th style={{ padding: 'var(--space-2)' }}>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {filteredConfigs.map((config: any) => (
                                            <tr key={config.id} style={{ borderBottom: '1px solid var(--color-border-light)' }}>
                                                <td style={{ padding: 'var(--space-3) var(--space-2)', fontWeight: 600 }}>{config.name}</td>
                                                <td style={{ padding: 'var(--space-3) var(--space-2)' }}>{config.brand?.name || '—'}</td>
                                                <td style={{ padding: 'var(--space-3) var(--space-2)', fontSize: '13px', color: 'var(--color-text-muted)' }}>
                                                    {config.ftpHost ? `${config.ftpHost}:${config.ftpPort || 21}${config.ftpPath || ''}` : '—'}
                                                </td>
                                                <td style={{ padding: 'var(--space-3) var(--space-2)' }}>
                                                    <span className={`badge ${STATUS_COLORS[config.status] || ''}`}>{config.status}</span>
                                                </td>
                                                <td style={{ padding: 'var(--space-3) var(--space-2)', fontSize: '13px' }}>{OCCURRENCE_LABELS[config.occurrence] || config.occurrence}</td>
                                                <td style={{ padding: 'var(--space-3) var(--space-2)', fontSize: '12px', color: 'var(--color-text-muted)' }}>{formatDate(config.lastRunAt)}</td>
                                                <td style={{ padding: 'var(--space-3) var(--space-2)' }}>
                                                    <div style={{ display: 'flex', gap: 'var(--space-2)' }}>
                                                        <Link href={`/admin/product-automation/${config.id}`} className="btn btn-sm btn-secondary">Edit</Link>
                                                        <button className="btn btn-sm btn-ghost" onClick={() => handleRunNow(config.id)} title="Run Now">▶️</button>
                                                        <button className="btn btn-sm btn-ghost" onClick={() => handleArchive(config.id)} disabled={deletingId === config.id} title="Archive" style={{ color: 'var(--color-text-muted)' }}>🗄️</button>
                                                    </div>
                                                </td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                            </div>
                        )}
                    </div>

                    {/* Section 2: Inbound FTP Drop Zones */}
                    <div id="inbound-ftp-accounts" className="card">
                        <div className="card-header" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                            <h3 className="card-title">📥 Inbound FTP Drop Zones</h3>
                            <button className="btn btn-sm btn-primary" onClick={() => setCreatingDrop(true)}>➕ New Drop Zone</button>
                        </div>

                        {/* Create Drop Zone form (inline) */}
                        {creatingDrop && (
                            <div style={{ padding: '1.25rem 1.5rem', borderBottom: '1px solid var(--color-border)', background: 'var(--color-bg-elevated)' }}>
                                <h4 style={{ fontWeight: 600, marginBottom: '1rem' }}>New Inbound FTP Drop Zone</h4>
                                <form onSubmit={handleCreateDrop} style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
                                        <div>
                                            <label style={{ display: 'block', fontSize: '0.8rem', fontWeight: 600, marginBottom: '0.35rem' }}>Manufacturer</label>
                                            <select className="form-select" style={{ width: '100%' }} value={dropManufacturerId} onChange={e => { setDropManufacturerId(e.target.value); setDropBrandId(''); }} required>
                                                <option value="">— Select Manufacturer —</option>
                                                {manufacturers.map((m: any) => (
                                                    <option key={m.id} value={m.id}>{m.name}</option>
                                                ))}
                                            </select>
                                        </div>
                                        <div>
                                            <label style={{ display: 'block', fontSize: '0.8rem', fontWeight: 600, marginBottom: '0.35rem' }}>Brand</label>
                                            <select className="form-select" style={{ width: '100%' }} value={dropBrandId} onChange={e => setDropBrandId(e.target.value)} required disabled={!dropManufacturerId}>
                                                <option value="">{dropManufacturerId ? '— Select Brand —' : '— Pick a manufacturer first —'}</option>
                                                {brands
                                                    .filter((b: any) => b.manufacturerId === dropManufacturerId)
                                                    .map((b: any) => (
                                                        <option key={b.id} value={b.id}>{b.name}</option>
                                                    ))}
                                            </select>
                                        </div>
                                    </div>
                                    <div>
                                        <label style={{ display: 'block', fontSize: '0.8rem', fontWeight: 600, marginBottom: '0.35rem' }}>Label</label>
                                        <input type="text" className="form-input" style={{ width: '100%' }} value={dropLabel} onChange={e => setDropLabel(e.target.value)} placeholder="e.g. Regency Primary FTP Drop" required />
                                    </div>
                                    <div>
                                        <label style={{ display: 'block', fontSize: '0.8rem', fontWeight: 600, marginBottom: '0.35rem' }}>Notes (optional)</label>
                                        <textarea className="form-input" style={{ width: '100%' }} rows={2} value={dropNotes} onChange={e => setDropNotes(e.target.value)} placeholder="Internal notes..." />
                                    </div>
                                    <p style={{ fontSize: '0.75rem', color: 'var(--color-text-muted)' }}>
                                        A unique FTP username, password, and local folder path will be auto-generated using the brand slug. The password is shown once after creation.
                                    </p>
                                    <div style={{ display: 'flex', gap: 'var(--space-3)' }}>
                                        <button type="submit" className="btn btn-primary btn-sm" disabled={dropWorking}>
                                            {dropWorking ? 'Creating...' : 'Create Drop Zone'}
                                        </button>
                                        <button type="button" className="btn btn-ghost btn-sm" onClick={() => setCreatingDrop(false)}>Cancel</button>
                                    </div>
                                </form>
                            </div>
                        )}

                        {ftpAccounts.length === 0 ? (
                            <div className="empty-state" style={{ padding: 'var(--space-6)' }}>
                                <div style={{ fontSize: '2rem', marginBottom: 'var(--space-2)' }}>📥</div>
                                <p style={{ fontWeight: 600, marginBottom: 'var(--space-1)' }}>No inbound drop zones yet.</p>
                                <p style={{ color: 'var(--color-text-muted)', fontSize: '0.875rem' }}>Provision a folder for a manufacturer so they can upload product data files directly.</p>
                            </div>
                        ) : (
                            <div className="data-table">
                                <table style={{ width: '100%' }}>
                                    <thead>
                                        <tr style={{ borderBottom: '1px solid var(--color-border)' }}>
                                            <th style={{ padding: 'var(--space-2)' }}>Manufacturer</th>
                                            <th style={{ padding: 'var(--space-2)' }}>Brand</th>
                                            <th style={{ padding: 'var(--space-2)' }}>Label</th>
                                            <th style={{ padding: 'var(--space-2)' }}>FTP User / Path</th>
                                            <th style={{ padding: 'var(--space-2)' }}>Status</th>
                                            <th style={{ padding: 'var(--space-2)' }}>Last Upload</th>
                                            <th style={{ padding: 'var(--space-2)' }}>Files</th>
                                            <th style={{ padding: 'var(--space-2)' }}>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {ftpAccounts.map((acct: any) => (
                                            <tr key={acct.id} style={{ borderBottom: '1px solid var(--color-border-light)' }}>
                                                <td style={{ padding: 'var(--space-3) var(--space-2)', fontWeight: 600 }}>{acct.manufacturer?.name || '—'}</td>
                                                <td style={{ padding: 'var(--space-3) var(--space-2)' }}>
                                                    <span style={{ fontWeight: 500 }}>{acct.brand?.name || '—'}</span>
                                                </td>
                                                <td style={{ padding: 'var(--space-3) var(--space-2)' }}>{acct.label}</td>
                                                <td style={{ padding: 'var(--space-3) var(--space-2)', fontFamily: 'monospace', fontSize: '12px', color: 'var(--color-text-muted)' }}>
                                                    <div>{acct.ftpUser}</div>
                                                    <div style={{ opacity: 0.7 }}>{acct.ftpPath}</div>
                                                </td>
                                                <td style={{ padding: 'var(--space-3) var(--space-2)' }}>
                                                    <span className={`badge ${acct.isActive ? 'badge-active' : 'badge-inactive'}`}>
                                                        {acct.isActive ? 'Active' : 'Inactive'}
                                                    </span>
                                                </td>
                                                <td style={{ padding: 'var(--space-3) var(--space-2)', fontSize: '12px', color: 'var(--color-text-muted)' }}>
                                                    {formatDate(acct.lastUploadAt)}
                                                </td>
                                                <td style={{ padding: 'var(--space-3) var(--space-2)' }}>
                                                    <span style={{ fontSize: '12px', fontWeight: 600 }}>{acct._count?.uploadLogs || 0}</span>
                                                </td>
                                                <td style={{ padding: 'var(--space-3) var(--space-2)' }}>
                                                    <div style={{ display: 'flex', gap: 'var(--space-2)' }}>
                                                        {acct.isActive ? (
                                                            <button className="btn btn-sm btn-ghost" onClick={() => handleDeactivateDrop(acct.id)} style={{ color: 'var(--color-text-muted)' }}>Deactivate</button>
                                                        ) : (
                                                            <button className="btn btn-sm btn-ghost" onClick={() => handleReactivateDrop(acct.id)}>Reactivate</button>
                                                        )}
                                                    </div>
                                                </td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                            </div>
                        )}
                    </div>
                </div>
            )}

            {/* Data Packages Tab */}
            {activeTab === 'DATA_PACKAGES' && (
                <div id="data-packages" className="card" style={{ marginBottom: 'var(--space-6)' }}>
                    <div className="card-header">
                        <h3 className="card-title">📦 Data Packages</h3>
                    </div>
                    {dataPackages.length === 0 ? (
                        <div className="empty-state" style={{ padding: 'var(--space-8) var(--space-6)' }}>
                            <div style={{ fontSize: '2.5rem', marginBottom: 'var(--space-3)' }}>📦</div>
                            <p style={{ fontWeight: 600, fontSize: '1.05rem', marginBottom: 'var(--space-2)' }}>
                                No data packages yet.
                            </p>
                            <p style={{ color: 'var(--color-text-muted)', fontSize: '0.875rem' }}>
                                Data packages are created when automations run. You can also create manual packages for review.
                            </p>
                        </div>
                    ) : (
                        <div className="data-table" style={{ width: '100%', textAlign: 'left', borderCollapse: 'collapse' }}>
                            <table style={{ width: '100%' }}>
                                <thead>
                                    <tr style={{ borderBottom: '1px solid var(--color-border)' }}>
                                        <th style={{ padding: 'var(--space-2)' }}>Name</th>
                                        <th style={{ padding: 'var(--space-2)' }}>Brand</th>
                                        <th style={{ padding: 'var(--space-2)' }}>Source</th>
                                        <th style={{ padding: 'var(--space-2)' }}>Items</th>
                                        <th style={{ padding: 'var(--space-2)' }}>Status</th>
                                        <th style={{ padding: 'var(--space-2)' }}>Created</th>
                                        <th style={{ padding: 'var(--space-2)' }}>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {dataPackages.map((pkg: any) => (
                                        <tr key={pkg.id} style={{ borderBottom: '1px solid var(--color-border-light)' }}>
                                            <td style={{ padding: 'var(--space-3) var(--space-2)' }}>
                                                <div style={{ fontWeight: 600, color: 'var(--color-text-primary)' }}>
                                                    {pkg.name}
                                                </div>
                                                <div style={{ fontSize: '11px', color: 'var(--color-text-muted)', fontFamily: 'monospace' }}>
                                                    #{pkg.id.slice(0, 8)}
                                                </div>
                                            </td>
                                            <td style={{ padding: 'var(--space-3) var(--space-2)', fontWeight: 500 }}>
                                                {pkg.brand?.name || '—'}
                                            </td>
                                            <td style={{ padding: 'var(--space-3) var(--space-2)', fontSize: '13px', color: 'var(--color-text-muted)' }}>
                                                {pkg.automationRun?.config?.name || 'Manual'}
                                            </td>
                                            <td style={{ padding: 'var(--space-3) var(--space-2)' }}>
                                                <span style={{
                                                    fontWeight: 600,
                                                    fontSize: '13px',
                                                    color: 'var(--color-text-primary)',
                                                }}>
                                                    {pkg._count?.items || 0}
                                                </span>
                                            </td>
                                            <td style={{ padding: 'var(--space-3) var(--space-2)' }}>
                                                <span className={`badge ${STATUS_COLORS[pkg.status] || ''}`}>
                                                    {pkg.status.replace('_', ' ')}
                                                </span>
                                            </td>
                                            <td style={{ padding: 'var(--space-3) var(--space-2)', fontSize: '12px', color: 'var(--color-text-muted)' }}>
                                                {formatDate(pkg.createdAt)}
                                            </td>
                                            <td style={{ padding: 'var(--space-3) var(--space-2)' }}>
                                                <Link
                                                    href={`/admin/product-automation/packages/${pkg.id}`}
                                                    className="btn btn-sm btn-secondary"
                                                >
                                                    Review
                                                </Link>
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    )}
                </div>
            )}
        </>
    );
}
