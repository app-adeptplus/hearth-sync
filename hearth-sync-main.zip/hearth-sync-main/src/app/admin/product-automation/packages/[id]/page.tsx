import prisma from '@/lib/db';
import DataPackageDetailClient from './DataPackageDetailClient';

interface PageProps {
    params: { id: string };
}

async function getPackageData(id: string) {
    try {
        const [pkg, brands, categories, attributes, optionGroups] = await Promise.all([
            prisma.dataPackage.findUnique({
                where: { id },
                include: {
                    brand: { select: { id: true, name: true } },
                    automationRun: {
                        select: {
                            id: true,
                            status: true,
                            config: { select: { id: true, name: true, sourceType: true } },
                        },
                    },
                    items: {
                        orderBy: { createdAt: 'desc' },
                    },
                },
            }),
            prisma.brand.findMany({
                select: { id: true, name: true },
                orderBy: { name: 'asc' },
            }),
            prisma.productCategory.findMany({
                select: { id: true, name: true, slug: true, parentId: true },
                orderBy: { name: 'asc' },
            }),
            prisma.productAttribute.findMany({
                select: { id: true, name: true },
                orderBy: { name: 'asc' },
            }),
            prisma.optionGroup.findMany({
                select: { id: true, name: true },
                orderBy: { name: 'asc' },
            }),
        ]);

        // If package has an enrichment job, load it with proposals and suggestions
        let enrichmentJob = null;
        const enrichedData = pkg?.enrichedData as any;
        if (enrichedData?.enrichmentJobId) {
            enrichmentJob = await prisma.enrichmentJob.findUnique({
                where: { id: enrichedData.enrichmentJobId },
                include: {
                    proposals: {
                        orderBy: { createdAt: 'asc' },
                    },
                    suggestions: {
                        orderBy: { createdAt: 'asc' },
                    },
                },
            });
        }

        return { pkg, brands, categories, attributes, optionGroups, enrichmentJob };
    } catch {
        return { pkg: null, brands: [], categories: [], attributes: [], optionGroups: [], enrichmentJob: null };
    }
}

export default async function DataPackageDetailPage({ params }: PageProps) {
    const { pkg, brands, categories, attributes, optionGroups, enrichmentJob } = await getPackageData(params.id);

    if (!pkg) {
        return (
            <div className="empty-state" style={{ padding: '4rem 2rem' }}>
                <p style={{ fontWeight: 600 }}>Data package not found.</p>
            </div>
        );
    }

    return (
        <DataPackageDetailClient
            pkg={pkg}
            brands={brands}
            categories={categories}
            attributes={attributes}
            optionGroups={optionGroups}
            enrichmentJob={enrichmentJob}
        />
    );
}
