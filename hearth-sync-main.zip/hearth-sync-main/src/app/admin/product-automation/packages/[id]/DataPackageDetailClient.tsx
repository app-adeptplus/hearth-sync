'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';

const STATUS_COLORS: Record<string, string> = {
    PENDING_REVIEW: 'badge-info',
    ENRICHING: 'badge-warning',
    APPROVED: 'badge-active',
    REJECTED: 'badge-error',
    IMPORTED: 'badge-active',
    pending: 'badge-info',
    approved: 'badge-active',
    rejected: 'badge-error',
};

const PROPOSAL_COLORS: Record<string, string> = {
    PENDING: 'badge-default',
    APPROVED: 'badge-active',
    REJECTED: 'badge-error',
    APPLIED: 'badge-active',
};

interface DataPackageDetailClientProps {
    pkg: any;
    brands: any[];
    categories: { id: string; name: string }[];
    attributes: { id: string; name: string }[];
    optionGroups: { id: string; name: string }[];
    enrichmentJob: any | null;
}

export default function DataPackageDetailClient({
    pkg,
    brands,
    categories,
    attributes,
    optionGroups,
    enrichmentJob,
}: DataPackageDetailClientProps) {
    const router = useRouter();
    const [selectedItems, setSelectedItems] = useState<Set<string>>(new Set());
    const [packageStatus, setPackageStatus] = useState(pkg.status);
    const [reviewNotes, setReviewNotes] = useState(pkg.reviewNotes || '');
    const [isSaving, setIsSaving] = useState(false);
    const [isImporting, setIsImporting] = useState(false);
    const [expandedItem, setExpandedItem] = useState<string | null>(null);
    const [itemStatuses, setItemStatuses] = useState<Record<string, string>>(
        Object.fromEntries(pkg.items?.map((i: any) => [i.id, i.status]) || [])
    );
    const [importResult, setImportResult] = useState<{ created: number; updated: number; errors: string[] } | null>(null);
    const [isEnriching, setIsEnriching] = useState(false);
    const [isAiEnriching, setIsAiEnriching] = useState(false);
    const [enrichResult, setEnrichResult] = useState<{ enrichedCount: number; skippedCount: number; normalizedCount?: number; errors: string[] } | null>(null);
    const [aiEnrichResult, setAiEnrichResult] = useState<{ jobId: string; enrichedCount: number; suggestionCount: number; errors: string[] } | null>(null);

    // Proposal & suggestion state
    const proposals = enrichmentJob?.proposals || [];
    const suggestions = enrichmentJob?.suggestions || [];
    const [proposalStatuses, setProposalStatuses] = useState<Record<string, string>>(
        Object.fromEntries(proposals.map((p: any) => [p.id, p.status]))
    );
    const [suggestionStatuses, setSuggestionStatuses] = useState<Record<string, string>>(
        Object.fromEntries(suggestions.map((s: any) => [s.id, s.status]))
    );
    const [reassignTarget, setReassignTarget] = useState<Record<string, string>>({});
    const [suggestionFilter, setSuggestionFilter] = useState<string>('ALL');

    const items = pkg.items || [];

    // Build lookup maps
    const categoryMap = Object.fromEntries(categories.map(c => [c.id, c.name]));
    const proposalByItem = Object.fromEntries(proposals.map((p: any) => [p.dataPackageItemId, p]));

    // Deduplicate suggestions by type+name
    const uniqueSuggestions = suggestions.reduce((acc: any, s: any) => {
        const key = `${s.type}::${s.suggestedName}`;
        if (!acc.map[key]) {
            acc.map[key] = s;
            acc.list.push(s);
            acc.counts[key] = 1;
        } else {
            acc.counts[key]++;
        }
        return acc;
    }, { map: {} as Record<string, any>, list: [] as any[], counts: {} as Record<string, number> });
    const dedupedSuggestions = uniqueSuggestions.list;
    const suggestionCounts = uniqueSuggestions.counts;
    const pendingDeduped = dedupedSuggestions.filter((s: any) => suggestionStatuses[s.id] === 'PENDING');

    // Per-type pending counts for filter tabs
    const pendingByType = pendingDeduped.reduce((acc: Record<string, number>, s: any) => {
        acc[s.type] = (acc[s.type] || 0) + 1;
        return acc;
    }, {} as Record<string, number>);
    const totalPending = pendingDeduped.length;

    // Filter suggestions by selected type
    const filteredSuggestions = suggestionFilter === 'ALL'
        ? dedupedSuggestions
        : dedupedSuggestions.filter((s: any) => s.type === suggestionFilter);

    const toggleSelect = (id: string) => {
        const next = new Set(selectedItems);
        if (next.has(id)) next.delete(id);
        else next.add(id);
        setSelectedItems(next);
    };

    const toggleAll = () => {
        if (selectedItems.size === items.length) {
            setSelectedItems(new Set());
        } else {
            setSelectedItems(new Set(items.map((i: any) => i.id)));
        }
    };

    const handleStatusUpdate = async (newStatus: string) => {
        setIsSaving(true);
        try {
            const res = await fetch(`/api/automation/data-packages/${pkg.id}`, {
                method: 'PATCH',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ status: newStatus, reviewNotes }),
            });
            if (!res.ok) throw new Error('Failed to update status');
            setPackageStatus(newStatus);
            router.refresh();
        } catch (err: any) {
            alert(err.message);
        } finally {
            setIsSaving(false);
        }
    };

    const handleApproveAll = async () => {
        if (!confirm(`Approve all ${items.filter((i: any) => itemStatuses[i.id] === 'pending').length} pending items?`)) return;
        setIsSaving(true);
        try {
            const res = await fetch(`/api/automation/data-packages/${pkg.id}`, {
                method: 'PATCH',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ action: 'approve-all' }),
            });
            if (!res.ok) throw new Error('Failed to approve items');
            const result = await res.json();
            const updated: Record<string, string> = { ...itemStatuses };
            for (const item of items) {
                if (updated[item.id] === 'pending') updated[item.id] = 'approved';
            }
            setItemStatuses(updated);
            setPackageStatus('APPROVED');
            alert(`✅ Approved ${result.approvedCount} items`);
        } catch (err: any) {
            alert(`Error: ${err.message}`);
        } finally {
            setIsSaving(false);
        }
    };

    const handleItemAction = async (itemIds: string[], action: 'approved' | 'rejected') => {
        setIsSaving(true);
        try {
            const updated = { ...itemStatuses };
            for (const id of itemIds) {
                const res = await fetch(`/api/automation/data-packages/${pkg.id}`, {
                    method: 'PATCH',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ itemId: id, itemStatus: action }),
                });
                if (res.ok) {
                    updated[id] = action;
                }
            }
            setItemStatuses(updated);
            setSelectedItems(new Set());
        } catch (err: any) {
            alert(`Error: ${err.message}`);
        } finally {
            setIsSaving(false);
        }
    };

    const handleImportToProducts = async () => {
        const approvedCount = items.filter((i: any) => itemStatuses[i.id] === 'approved').length;
        if (approvedCount === 0) {
            alert('No approved items to import. Approve items first.');
            return;
        }
        if (!confirm(`Import ${approvedCount} approved items into the Products database?\n\nThis will create new Product records for each item.`)) return;
        setIsImporting(true);
        setImportResult(null);
        try {
            const res = await fetch(`/api/automation/data-packages/${pkg.id}/import`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
            });
            if (!res.ok) {
                const errData = await res.json().catch(() => null);
                throw new Error(errData?.error || `Import failed: ${res.status}`);
            }
            const result = await res.json();
            setImportResult(result);
            setPackageStatus('IMPORTED');
            router.refresh();
        } catch (err: any) {
            alert(`Import error: ${err.message}`);
        } finally {
            setIsImporting(false);
        }
    };

    const handleNormalize = async () => {
        if (items.length === 0) {
            alert('No items in this package to normalize.');
            return;
        }
        if (!confirm(`Normalize ${items.length} items?\n\nThis will:\n• Format names as "${pkg.brand?.name || 'Brand'} - {Product Name}"\n• Generate model numbers and SKU hints\n• Fuzzy-match categories against your existing taxonomy\n\nNo LLM or scraping credits used.`)) return;
        setIsEnriching(true);
        setEnrichResult(null);
        try {
            const res = await fetch(`/api/automation/data-packages/${pkg.id}/enrich?phase=normalize`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
            });
            if (!res.ok) {
                const errData = await res.json().catch(() => null);
                throw new Error(errData?.error || `Normalization failed: ${res.status}`);
            }
            const result = await res.json();
            setEnrichResult(result);
            router.refresh();
        } catch (err: any) {
            alert(`Normalization error: ${err.message}`);
        } finally {
            setIsEnriching(false);
        }
    };

    const handleAiEnrich = async () => {
        if (items.length === 0) {
            alert('No items in this package to enrich.');
            return;
        }
        if (!confirm(`🔬 Enrich ${items.length} items with AI?\n\nThis will:\n• Call the LLM to analyze each item\n• Propose names, categories, attributes, and option groups\n• Create review proposals for your approval\n\nLLM tokens will be used.`)) return;
        setIsAiEnriching(true);
        setAiEnrichResult(null);
        try {
            const res = await fetch(`/api/automation/data-packages/${pkg.id}/enrich?phase=enrich`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
            });
            if (!res.ok) {
                const errData = await res.json().catch(() => null);
                throw new Error(errData?.error || `Enrichment failed: ${res.status}`);
            }
            const result = await res.json();
            setAiEnrichResult(result);
            router.refresh();
        } catch (err: any) {
            alert(`Enrichment error: ${err.message}`);
        } finally {
            setIsAiEnriching(false);
        }
    };

    // ─── Proposal & Suggestion Actions ────────────────────────────────────────

    const updateProposal = async (pid: string, status: string) => {
        if (!enrichmentJob) return;
        const res = await fetch(`/api/enrichment/${enrichmentJob.id}/proposals/${pid}`, {
            method: 'PATCH',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ status }),
        });
        if (res.ok) {
            setProposalStatuses(prev => ({ ...prev, [pid]: status }));

            // Also update item status when approving/rejecting a proposal
            const proposal = proposals.find((p: any) => p.id === pid);
            if (proposal?.dataPackageItemId) {
                if (status === 'APPROVED') {
                    setItemStatuses(prev => ({ ...prev, [proposal.dataPackageItemId]: 'approved' }));
                    // Also update the server-side item status
                    await fetch(`/api/automation/data-packages/${pkg.id}`, {
                        method: 'PATCH',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ itemId: proposal.dataPackageItemId, itemStatus: 'approved' }),
                    });
                } else if (status === 'REJECTED') {
                    setItemStatuses(prev => ({ ...prev, [proposal.dataPackageItemId]: 'rejected' }));
                    await fetch(`/api/automation/data-packages/${pkg.id}`, {
                        method: 'PATCH',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ itemId: proposal.dataPackageItemId, itemStatus: 'rejected' }),
                    });
                }
            }
        }
    };

    const approveAllProposals = async () => {
        const pending = proposals.filter((p: any) => proposalStatuses[p.id] === 'PENDING');
        for (const p of pending) {
            await updateProposal(p.id, 'APPROVED');
        }
    };

    const approveHighConfidence = async () => {
        const eligible = proposals.filter((p: any) => p.confidence >= 0.7 && proposalStatuses[p.id] === 'PENDING');
        for (const p of eligible) {
            await updateProposal(p.id, 'APPROVED');
        }
    };

    const resolveSuggestion = async (sid: string, action: string, resolvedId?: string) => {
        if (!enrichmentJob) return;
        const res = await fetch(`/api/enrichment/${enrichmentJob.id}/suggestions/${sid}`, {
            method: 'PATCH',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action, resolvedId }),
        });
        if (res.ok) {
            const actionToStatus: Record<string, string> = { approve: 'APPROVED', reassign: 'REASSIGNED', deny: 'DENIED' };
            setSuggestionStatuses(prev => ({ ...prev, [sid]: actionToStatus[action] || action.toUpperCase() }));
        }
    };

    const taxonomyOptions = (type: string) => {
        if (type === 'CATEGORY') return categories;
        if (type === 'ATTRIBUTE') return attributes;
        return optionGroups;
    };

    // ─── Helpers ──────────────────────────────────────────────────────────────

    const pendingCount = items.filter((i: any) => itemStatuses[i.id] === 'pending').length;
    const approvedCount = items.filter((i: any) => itemStatuses[i.id] === 'approved').length;
    const approvedProposals = Object.entries(proposalStatuses).filter(([, s]) => s === 'APPROVED').length;

    const formatDate = (d: string | null) => {
        if (!d) return '—';
        return new Date(d).toLocaleDateString('en-US', {
            month: 'short', day: 'numeric', year: 'numeric',
            hour: '2-digit', minute: '2-digit',
        });
    };

    const confidenceColor = (c: number) => {
        if (c >= 0.8) return '#22c55e';
        if (c >= 0.5) return '#f59e0b';
        return '#ef4444';
    };

    const resolveCategoryName = (id: string) => categoryMap[id] || id.slice(0, 8) + '…';

    const hasEnrichmentJob = !!enrichmentJob;

    return (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '2rem' }}>
            {/* Header */}
            <div className="page-header">
                <div>
                    <h2 className="page-title">📦 {pkg.name}</h2>
                    <p className="page-subtitle">
                        {items.length} items · {pkg.brand?.name || 'No brand'} · Source: {pkg.automationRun?.config?.name || 'Manual'}
                    </p>
                </div>
                <div style={{ display: 'flex', gap: 'var(--space-3)', alignItems: 'center' }}>
                    <span className={`badge ${STATUS_COLORS[packageStatus] || ''}`}>
                        {packageStatus.replace('_', ' ')}
                    </span>
                    {packageStatus !== 'IMPORTED' && approvedCount > 0 && (
                        <button
                            className="btn btn-primary"
                            onClick={handleImportToProducts}
                            disabled={isImporting}
                        >
                            {isImporting ? '⏳ Importing...' : `📥 Import ${approvedCount} Products`}
                        </button>
                    )}
                    {packageStatus !== 'IMPORTED' && !hasEnrichmentJob && (
                        <button
                            className="btn btn-primary"
                            onClick={handleAiEnrich}
                            disabled={isAiEnriching}
                            title="Enrich items with AI — calls the LLM to propose names, categories, attributes"
                            style={{ background: 'linear-gradient(135deg, #8b5cf6, #6366f1)' }}
                        >
                            {isAiEnriching ? '⏳ Enriching...' : '🔬 Enrich with AI'}
                        </button>
                    )}
                    {packageStatus !== 'IMPORTED' && (
                        <button
                            className="btn btn-secondary"
                            onClick={handleNormalize}
                            disabled={isEnriching}
                            title="Deterministic normalization — format names, generate SKUs, match categories. No LLM cost."
                        >
                            {isEnriching ? '⏳ Normalizing...' : '✨ Normalize Data'}
                        </button>
                    )}
                    <button
                        type="button"
                        className="btn btn-ghost"
                        onClick={() => router.push('/admin/product-automation?tab=DATA_PACKAGES')}
                    >
                        ← Back
                    </button>
                </div>
            </div>

            {/* Status & Notes */}
            <div className="card" style={{ padding: '2rem', display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
                <h3 style={{ fontSize: '1.15rem', fontWeight: 600, borderBottom: '1px solid var(--color-border)', paddingBottom: '0.75rem' }}>
                    Package Status & Notes
                </h3>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 2fr', gap: '2rem' }}>
                    <div>
                        <label style={{ display: 'block', fontSize: '0.875rem', fontWeight: 600, marginBottom: '0.5rem' }}>Status</label>
                        <div style={{ display: 'flex', gap: '0.5rem', flexWrap: 'wrap' }}>
                            {['PENDING_REVIEW', 'ENRICHING', 'APPROVED', 'REJECTED', 'IMPORTED'].map(s => (
                                <button
                                    key={s}
                                    type="button"
                                    className={`btn btn-sm ${packageStatus === s ? 'btn-primary' : 'btn-ghost'}`}
                                    onClick={() => handleStatusUpdate(s)}
                                    disabled={isSaving}
                                >
                                    {s.replace('_', ' ')}
                                </button>
                            ))}
                        </div>
                    </div>
                    <div>
                        <label style={{ display: 'block', fontSize: '0.875rem', fontWeight: 600, marginBottom: '0.5rem' }}>Review Notes</label>
                        <textarea
                            className="form-input"
                            style={{ width: '100%' }}
                            rows={3}
                            value={reviewNotes}
                            onChange={e => setReviewNotes(e.target.value)}
                            placeholder="Add review notes here..."
                        />
                    </div>
                </div>
            </div>

            {/* Import Result Banner */}
            {importResult && (
                <div className="card" style={{ padding: '1.25rem', background: 'var(--color-bg-elevated)', border: '1px solid var(--color-success, #22c55e)' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 'var(--space-3)' }}>
                        <span style={{ fontSize: '1.5rem' }}>🎉</span>
                        <div>
                            <div style={{ fontWeight: 600, color: 'var(--color-success, #22c55e)' }}>Import Complete</div>
                            <div style={{ fontSize: '0.875rem', color: 'var(--color-text-secondary)' }}>
                                Created: {importResult.created} · Updated: {importResult.updated}
                                {importResult.errors?.length > 0 && (
                                    <span style={{ color: 'var(--color-error, #ef4444)' }}> · {importResult.errors.length} errors</span>
                                )}
                            </div>
                            {importResult.errors?.length > 0 && (
                                <div style={{ marginTop: '0.5rem', fontSize: '0.8rem', color: 'var(--color-error, #ef4444)' }}>
                                    {importResult.errors.map((err: string, i: number) => <div key={i}>• {err}</div>)}
                                </div>
                            )}
                        </div>
                        <button className="btn btn-sm btn-primary" style={{ marginLeft: 'auto' }} onClick={() => router.push('/admin/products')}>
                            View Products →
                        </button>
                    </div>
                </div>
            )}

            {/* Normalize Result Banner */}
            {enrichResult && (
                <div className="card" style={{ padding: '1.25rem', background: 'var(--color-bg-elevated)', border: '1px solid var(--color-border)' }}>
                    <div style={{ display: 'flex', alignItems: 'flex-start', gap: 'var(--space-3)' }}>
                        <span style={{ fontSize: '1.5rem' }}>✨</span>
                        <div style={{ flex: 1 }}>
                            <div style={{ fontWeight: 600, marginBottom: '0.25rem' }}>Normalization Complete</div>
                            <div style={{ fontSize: '0.875rem', color: 'var(--color-text-secondary)' }}>
                                Normalized: <strong>{enrichResult.normalizedCount ?? enrichResult.enrichedCount ?? 0}</strong> items · No tokens used
                                {enrichResult.errors?.length > 0 && (
                                    <span style={{ color: 'var(--color-error, #ef4444)' }}> · {enrichResult.errors.length} errors</span>
                                )}
                            </div>
                            {enrichResult.errors?.length > 0 && (
                                <div style={{ marginTop: '0.5rem', fontSize: '0.8rem', color: 'var(--color-error, #ef4444)' }}>
                                    {enrichResult.errors.map((err: string, i: number) => <div key={i}>• {err}</div>)}
                                </div>
                            )}
                        </div>
                        <button className="btn btn-sm btn-ghost" onClick={() => setEnrichResult(null)}>✕</button>
                    </div>
                </div>
            )}

            {/* AI Enrichment Result Banner */}
            {aiEnrichResult && (
                <div className="card" style={{ padding: '1.25rem', background: 'var(--color-bg-elevated)', border: '1px solid #8b5cf6' }}>
                    <div style={{ display: 'flex', alignItems: 'flex-start', gap: 'var(--space-3)' }}>
                        <span style={{ fontSize: '1.5rem' }}>🔬</span>
                        <div style={{ flex: 1 }}>
                            <div style={{ fontWeight: 600, marginBottom: '0.25rem', color: '#8b5cf6' }}>AI Enrichment Complete</div>
                            <div style={{ fontSize: '0.875rem', color: 'var(--color-text-secondary)' }}>
                                Enriched: <strong>{aiEnrichResult.enrichedCount}</strong> items ·{' '}
                                <strong>{aiEnrichResult.suggestionCount}</strong> taxonomy suggestions
                                {aiEnrichResult.errors?.length > 0 && (
                                    <span style={{ color: 'var(--color-error, #ef4444)' }}> · {aiEnrichResult.errors.length} errors</span>
                                )}
                            </div>
                            {aiEnrichResult.errors?.length > 0 && (
                                <div style={{ marginTop: '0.5rem', fontSize: '0.8rem', color: 'var(--color-error, #ef4444)' }}>
                                    {aiEnrichResult.errors.map((err: string, i: number) => <div key={i}>• {err}</div>)}
                                </div>
                            )}
                        </div>
                        <a
                            href={`/admin/enrichment/${aiEnrichResult.jobId}`}
                            className="btn btn-sm btn-secondary"
                            style={{ flexShrink: 0 }}
                        >
                            View Enrichment Job →
                        </a>
                        <button className="btn btn-sm btn-ghost" onClick={() => setAiEnrichResult(null)}>✕</button>
                    </div>
                </div>
            )}

            {/* ── Taxonomy Suggestions ── */}
            {hasEnrichmentJob && dedupedSuggestions.length > 0 && (
                <div className="card" style={{ padding: '1.5rem' }}>
                    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '1rem' }}>
                        <h3 style={{ fontSize: '1rem', fontWeight: 600, margin: 0, display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                            ⚠️ Taxonomy Suggestions
                            <span style={{ fontSize: 'var(--font-size-xs)', color: 'var(--color-text-muted)', fontWeight: 400 }}>
                                {totalPending} pending · resolve before importing
                            </span>
                        </h3>
                        <div style={{ display: 'flex', gap: '0.5rem' }}>
                            <a href={`/admin/enrichment/${enrichmentJob.id}`} className="btn btn-sm btn-ghost" style={{ fontSize: '12px' }}>
                                View Full Job →
                            </a>
                            <button className="btn btn-sm btn-secondary"
                                onClick={() => pendingDeduped.forEach((s: any) => resolveSuggestion(s.id, 'approve'))}>
                                ✅ Approve All
                            </button>
                            <button className="btn btn-sm btn-ghost" style={{ color: 'var(--color-error)' }}
                                onClick={() => pendingDeduped.forEach((s: any) => resolveSuggestion(s.id, 'deny'))}>
                                ❌ Deny All
                            </button>
                        </div>
                    </div>
                    {/* Filter Tabs */}
                    <div style={{ display: 'flex', gap: '0.5rem', marginBottom: '1rem', borderBottom: '1px solid var(--color-border)', paddingBottom: '0.75rem' }}>
                        {[
                            { key: 'ALL', label: 'All', count: totalPending },
                            { key: 'CATEGORY', label: '📁 Categories', count: pendingByType['CATEGORY'] || 0 },
                            { key: 'ATTRIBUTE', label: '🏷️ Attributes', count: pendingByType['ATTRIBUTE'] || 0 },
                            { key: 'OPTION_GROUP', label: '⚙️ Option Groups', count: pendingByType['OPTION_GROUP'] || 0 },
                        ].map(tab => (
                            <button
                                key={tab.key}
                                className={`btn btn-sm ${suggestionFilter === tab.key ? 'btn-primary' : 'btn-ghost'}`}
                                onClick={() => setSuggestionFilter(tab.key)}
                                style={{ fontSize: '12px', display: 'flex', alignItems: 'center', gap: '4px' }}
                            >
                                {tab.label}
                                {tab.count > 0 && (
                                    <span style={{
                                        fontSize: '10px', padding: '1px 5px', borderRadius: '10px',
                                        background: suggestionFilter === tab.key ? 'rgba(255,255,255,0.2)' : 'var(--color-bg-elevated)',
                                        minWidth: '18px', textAlign: 'center',
                                    }}>
                                        {tab.count}
                                    </span>
                                )}
                            </button>
                        ))}
                    </div>
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
                        {filteredSuggestions.map((s: any) => {
                            const key = `${s.type}::${s.suggestedName}`;
                            const count = suggestionCounts[key] || 1;
                            const isPending = suggestionStatuses[s.id] === 'PENDING';
                            return (
                                <div key={s.id} style={{
                                    display: 'flex', alignItems: 'center', gap: 'var(--space-3)',
                                    padding: '0.5rem 0.75rem',
                                    background: 'var(--color-bg)',
                                    border: '1px solid var(--color-border)',
                                    borderRadius: 'var(--radius-md)',
                                    opacity: !isPending ? 0.45 : 1,
                                }}>
                                    <span className="badge badge-warning" style={{ fontSize: '10px', minWidth: 72, textAlign: 'center' }}>
                                        {s.type}
                                    </span>
                                    <div style={{ flex: 1, minWidth: 0 }}>
                                        <div style={{ fontWeight: 600, fontSize: 'var(--font-size-sm)' }}>
                                            {s.suggestedName}
                                            {count > 1 && (
                                                <span style={{ marginLeft: '6px', fontSize: '11px', color: 'var(--color-text-muted)', fontWeight: 400 }}>
                                                    ({count} products)
                                                </span>
                                            )}
                                        </div>
                                        {s.suggestedData?.reason && (
                                            <div style={{ fontSize: '11px', color: 'var(--color-text-muted)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                                                {s.suggestedData.reason}
                                            </div>
                                        )}
                                    </div>
                                    {isPending ? (
                                        <div style={{ display: 'flex', gap: '0.4rem', alignItems: 'center', flexShrink: 0 }}>
                                            <select
                                                className="form-select"
                                                style={{ height: '28px', fontSize: '11px', padding: '0 0.5rem', minWidth: '140px' }}
                                                value={reassignTarget[s.id] || ''}
                                                onChange={e => setReassignTarget(prev => ({ ...prev, [s.id]: e.target.value }))}
                                            >
                                                <option value="">↔ Reassign to…</option>
                                                {taxonomyOptions(s.type).map((t: any) => (
                                                    <option key={t.id} value={t.id}>{t.name}</option>
                                                ))}
                                            </select>
                                            {reassignTarget[s.id] && (
                                                <button className="btn btn-sm btn-secondary"
                                                    onClick={() => resolveSuggestion(s.id, 'reassign', reassignTarget[s.id])}>
                                                    Use
                                                </button>
                                            )}
                                            <button className="btn btn-sm btn-primary"
                                                onClick={() => resolveSuggestion(s.id, 'approve')}>✅</button>
                                            <button className="btn btn-sm btn-ghost" style={{ color: 'var(--color-error)' }}
                                                onClick={() => resolveSuggestion(s.id, 'deny')}>❌</button>
                                        </div>
                                    ) : (
                                        <span className={`badge ${suggestionStatuses[s.id] === 'APPROVED' ? 'badge-active' : suggestionStatuses[s.id] === 'DENIED' ? 'badge-error' : 'badge-info'}`}
                                            style={{ fontSize: '11px', flexShrink: 0 }}>
                                            {suggestionStatuses[s.id]}
                                        </span>
                                    )}
                                </div>
                            );
                        })}
                    </div>
                </div>
            )}

            {/* Proposal Batch Actions */}
            {hasEnrichmentJob && proposals.length > 0 && (
                <div className="card" style={{ padding: '1rem 1.5rem' }}>
                    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                        <span style={{ fontSize: '0.875rem', color: 'var(--color-text-muted)' }}>
                            🔬 {approvedProposals} of {proposals.length} proposals approved
                        </span>
                        <div style={{ display: 'flex', gap: '0.5rem' }}>
                            <button className="btn btn-sm btn-secondary" onClick={approveHighConfidence}>
                                ✅ Approve ≥70% Confidence
                            </button>
                            <button className="btn btn-sm btn-secondary" onClick={approveAllProposals}>
                                ✅ Approve All Proposals
                            </button>
                        </div>
                    </div>
                </div>
            )}

            {/* Bulk Actions */}
            {items.length > 0 && (
                <div style={{ display: 'flex', gap: 'var(--space-3)', alignItems: 'center', flexWrap: 'wrap' }}>
                    <span style={{ fontSize: '0.875rem', color: 'var(--color-text-muted)' }}>
                        {selectedItems.size} of {items.length} selected · {pendingCount} pending · {approvedCount} approved
                    </span>
                    <button className="btn btn-sm btn-secondary" onClick={toggleAll}>
                        {selectedItems.size === items.length ? 'Deselect All' : 'Select All'}
                    </button>
                    {pendingCount > 0 && (
                        <button className="btn btn-sm btn-primary" onClick={handleApproveAll} disabled={isSaving}>
                            ✅ Approve All ({pendingCount})
                        </button>
                    )}
                    {selectedItems.size > 0 && (
                        <>
                            <button className="btn btn-sm btn-primary" onClick={() => handleItemAction(Array.from(selectedItems), 'approved')} disabled={isSaving}>
                                ✅ Approve Selected
                            </button>
                            <button className="btn btn-sm btn-ghost" style={{ color: 'var(--color-error, #ef4444)' }} onClick={() => handleItemAction(Array.from(selectedItems), 'rejected')} disabled={isSaving}>
                                ❌ Reject Selected
                            </button>
                        </>
                    )}
                </div>
            )}

            {/* Items Table */}
            <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
                {items.length === 0 ? (
                    <div className="empty-state" style={{ padding: 'var(--space-8)' }}>
                        <div style={{ fontSize: '2rem', marginBottom: 'var(--space-3)' }}>📋</div>
                        <p style={{ fontWeight: 600 }}>No items in this package yet.</p>
                        <p style={{ color: 'var(--color-text-muted)', fontSize: '0.875rem' }}>
                            Items are added when an automation run processes data.
                        </p>
                    </div>
                ) : (
                    <div className="data-table" style={{ width: '100%' }}>
                        <table style={{ width: '100%' }}>
                            <thead>
                                <tr style={{ borderBottom: '1px solid var(--color-border)' }}>
                                    <th style={{ padding: 'var(--space-2)', width: '40px' }}>
                                        <input type="checkbox" checked={selectedItems.size === items.length} onChange={toggleAll} />
                                    </th>
                                    <th style={{ padding: 'var(--space-2)' }}>Name</th>
                                    <th style={{ padding: 'var(--space-2)' }}>SKU</th>
                                    <th style={{ padding: 'var(--space-2)' }}>Images</th>
                                    <th style={{ padding: 'var(--space-2)' }}>Categories</th>
                                    <th style={{ padding: 'var(--space-2)' }}>Confidence</th>
                                    <th style={{ padding: 'var(--space-2)' }}>Status</th>
                                    <th style={{ padding: 'var(--space-2)' }}>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                {items.map((item: any) => {
                                    const proposal = proposalByItem[item.id];
                                    const pStatus = proposal ? proposalStatuses[proposal.id] : null;
                                    const conf = proposal ? proposal.confidence : (item.confidence || 0);

                                    return (
                                        <>
                                            <tr key={item.id} style={{
                                                borderBottom: expandedItem === item.id ? 'none' : '1px solid var(--color-border-light)',
                                                background: pStatus === 'APPROVED'
                                                    ? 'color-mix(in srgb, var(--color-success, #22c55e) 6%, transparent)'
                                                    : pStatus === 'REJECTED'
                                                    ? 'color-mix(in srgb, var(--color-error) 5%, transparent)'
                                                    : 'transparent',
                                            }}>
                                                <td style={{ padding: 'var(--space-3) var(--space-2)' }}>
                                                    <input type="checkbox" checked={selectedItems.has(item.id)} onChange={() => toggleSelect(item.id)} />
                                                </td>
                                                <td style={{ padding: 'var(--space-3) var(--space-2)' }}>
                                                    <div style={{ fontWeight: 600, color: 'var(--color-text-primary)' }}>
                                                        {item.parsedName || 'Unnamed'}
                                                    </div>
                                                    {proposal && (
                                                        <div style={{ fontSize: '11px', color: '#8b5cf6', fontWeight: 500 }}>
                                                            → {proposal.proposedData?.name || '—'}
                                                        </div>
                                                    )}
                                                    {!proposal && item.parsedDescription && (
                                                        <div style={{ fontSize: '11px', color: 'var(--color-text-muted)', maxWidth: '250px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                                                            {item.parsedDescription}
                                                        </div>
                                                    )}
                                                </td>
                                                <td style={{ padding: 'var(--space-3) var(--space-2)', fontFamily: 'monospace', fontSize: '12px' }}>
                                                    {item.parsedSku || '—'}
                                                    {proposal?.proposedData?.modelNumber && proposal.proposedData.modelNumber !== item.parsedSku && (
                                                        <div style={{ color: '#8b5cf6', fontSize: '11px' }}>→ {proposal.proposedData.modelNumber}</div>
                                                    )}
                                                </td>
                                                <td style={{ padding: 'var(--space-3) var(--space-2)', fontSize: '13px' }}>
                                                    {item.parsedImages?.length || 0}
                                                </td>
                                                <td style={{ padding: 'var(--space-3) var(--space-2)' }}>
                                                    <div style={{ display: 'flex', gap: '4px', flexWrap: 'wrap' }}>
                                                        {proposal?.proposedData?.categoryIds?.length > 0 ? (
                                                            proposal.proposedData.categoryIds.slice(0, 3).map((cid: string, i: number) => (
                                                                <span key={i} style={{
                                                                    fontSize: '10px', padding: '2px 6px',
                                                                    borderRadius: '8px', background: 'color-mix(in srgb, #8b5cf6 12%, transparent)',
                                                                    border: '1px solid #8b5cf6', color: '#8b5cf6',
                                                                }}>
                                                                    {resolveCategoryName(cid)}
                                                                </span>
                                                            ))
                                                        ) : (
                                                            (item.parsedCategories || []).slice(0, 3).map((cat: string, i: number) => (
                                                                <span key={i} style={{
                                                                    fontSize: '10px', padding: '2px 6px',
                                                                    borderRadius: '8px', background: 'var(--color-bg-elevated)',
                                                                    border: '1px solid var(--color-border)', color: 'var(--color-text-muted)',
                                                                }}>
                                                                    {cat}
                                                                </span>
                                                            ))
                                                        )}
                                                    </div>
                                                </td>
                                                <td style={{ padding: 'var(--space-3) var(--space-2)' }}>
                                                    <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                                                        <div style={{
                                                            width: '40px', height: '6px', borderRadius: '3px',
                                                            background: 'var(--color-border)',
                                                            overflow: 'hidden',
                                                        }}>
                                                            <div style={{
                                                                width: `${conf * 100}%`,
                                                                height: '100%',
                                                                background: confidenceColor(conf),
                                                                borderRadius: '3px',
                                                            }} />
                                                        </div>
                                                        <span style={{ fontSize: '11px', color: 'var(--color-text-muted)' }}>
                                                            {Math.round(conf * 100)}%
                                                        </span>
                                                    </div>
                                                </td>
                                                <td style={{ padding: 'var(--space-3) var(--space-2)' }}>
                                                    <div style={{ display: 'flex', gap: '4px', alignItems: 'center' }}>
                                                        <span className={`badge ${STATUS_COLORS[itemStatuses[item.id] || item.status] || ''}`}>
                                                            {itemStatuses[item.id] || item.status}
                                                        </span>
                                                        {pStatus && (
                                                            <span className={`badge ${PROPOSAL_COLORS[pStatus] || 'badge-default'}`} style={{ fontSize: '10px' }}>
                                                                🔬 {pStatus}
                                                            </span>
                                                        )}
                                                    </div>
                                                </td>
                                                <td style={{ padding: 'var(--space-3) var(--space-2)' }}>
                                                    <div style={{ display: 'flex', gap: '0.25rem' }}>
                                                        {proposal && pStatus !== 'APPLIED' && (
                                                            <>
                                                                <button className="btn btn-sm btn-primary"
                                                                    onClick={() => updateProposal(proposal.id, pStatus === 'APPROVED' ? 'PENDING' : 'APPROVED')}>
                                                                    {pStatus === 'APPROVED' ? 'Undo' : '✅'}
                                                                </button>
                                                                {pStatus !== 'REJECTED' && (
                                                                    <button className="btn btn-sm btn-ghost"
                                                                        style={{ color: 'var(--color-error)' }}
                                                                        onClick={() => updateProposal(proposal.id, 'REJECTED')}>
                                                                        ❌
                                                                    </button>
                                                                )}
                                                            </>
                                                        )}
                                                        <button
                                                            className="btn btn-sm btn-ghost"
                                                            onClick={() => setExpandedItem(expandedItem === item.id ? null : item.id)}
                                                        >
                                                            {expandedItem === item.id ? '▲' : '▼'} Details
                                                        </button>
                                                    </div>
                                                </td>
                                            </tr>
                                            {expandedItem === item.id && (
                                                <tr key={`${item.id}-detail`} style={{ borderBottom: '1px solid var(--color-border-light)', background: 'var(--color-bg-elevated)' }}>
                                                    <td colSpan={8} style={{ padding: 'var(--space-4)' }}>
                                                        {proposal ? (
                                                            /* Proposal diff view */
                                                            <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                                                                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1.5rem' }}>
                                                                    <div>
                                                                        <div style={{ fontWeight: 600, marginBottom: '0.5rem', fontSize: '0.875rem', color: 'var(--color-text-muted)' }}>
                                                                            📥 Scraped (Original)
                                                                        </div>
                                                                        <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem', fontSize: '0.8rem' }}>
                                                                            <div><strong>Name:</strong> {item.parsedName || '—'}</div>
                                                                            <div><strong>SKU:</strong> <code>{item.parsedSku || '—'}</code></div>
                                                                            <div><strong>Categories:</strong> {(item.parsedCategories || []).join(', ') || '—'}</div>
                                                                            {item.parsedDescription && (
                                                                                <div><strong>Description:</strong> <span style={{ color: 'var(--color-text-secondary)' }}>{item.parsedDescription.slice(0, 200)}{item.parsedDescription.length > 200 ? '…' : ''}</span></div>
                                                                            )}
                                                                        </div>
                                                                    </div>
                                                                    <div>
                                                                        <div style={{ fontWeight: 600, marginBottom: '0.5rem', fontSize: '0.875rem', color: '#8b5cf6' }}>
                                                                            🔬 Proposed (Enriched)
                                                                        </div>
                                                                        <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem', fontSize: '0.8rem' }}>
                                                                            <div><strong>Name:</strong> {proposal.proposedData?.name || '—'}</div>
                                                                            <div><strong>Model:</strong> <code>{proposal.proposedData?.modelNumber || '—'}</code>{proposal.proposedData?.modelNumberIsGenerated && <span style={{ marginLeft: '4px', fontSize: '10px', color: 'var(--color-warning)' }}>auto-gen</span>}</div>
                                                                            <div><strong>SKU:</strong> <code>{proposal.proposedData?.sku || '—'}</code></div>
                                                                            <div>
                                                                                <strong>Categories:</strong>{' '}
                                                                                {(proposal.proposedData?.categoryIds || []).map((cid: string, i: number) => (
                                                                                    <span key={i} style={{
                                                                                        fontSize: '11px', padding: '1px 6px', marginRight: '4px',
                                                                                        borderRadius: '8px', background: 'color-mix(in srgb, #8b5cf6 12%, transparent)',
                                                                                        border: '1px solid #8b5cf6', color: '#8b5cf6',
                                                                                    }}>
                                                                                        {resolveCategoryName(cid)}
                                                                                    </span>
                                                                                ))}
                                                                                {(!proposal.proposedData?.categoryIds?.length) && '—'}
                                                                            </div>
                                                                            {proposal.proposedData?.attributeValues?.length > 0 && (
                                                                                <div>
                                                                                    <strong>Attributes:</strong>
                                                                                    <div style={{ marginTop: '4px', display: 'flex', gap: '4px', flexWrap: 'wrap' }}>
                                                                                        {proposal.proposedData.attributeValues.map((av: any, i: number) => (
                                                                                            <span key={i} style={{ fontSize: '10px', padding: '2px 6px', borderRadius: '6px', background: 'var(--color-bg)', border: '1px solid var(--color-border)' }}>
                                                                                                {av.attributeName}: {av.value}
                                                                                            </span>
                                                                                        ))}
                                                                                    </div>
                                                                                </div>
                                                                            )}
                                                                            {proposal.proposedData?.descriptionSummary && (
                                                                                <div><strong>Summary:</strong> <span style={{ color: 'var(--color-text-secondary)' }}>{proposal.proposedData.descriptionSummary}</span></div>
                                                                            )}
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                {proposal.notes && (
                                                                    <div style={{ fontSize: '12px', color: 'var(--color-text-muted)', padding: '0.5rem 0', borderTop: '1px solid var(--color-border)' }}>
                                                                        📝 {proposal.notes}
                                                                    </div>
                                                                )}
                                                            </div>
                                                        ) : (
                                                            /* Original detail view (no proposal) */
                                                            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1.5rem' }}>
                                                                <div>
                                                                    <h4 style={{ fontWeight: 600, marginBottom: '0.5rem', fontSize: '0.875rem' }}>Parsed Description</h4>
                                                                    <p style={{ fontSize: '0.8rem', color: 'var(--color-text-secondary)', lineHeight: 1.5 }}>
                                                                        {item.parsedDescription || 'No description'}
                                                                    </p>
                                                                </div>
                                                                <div>
                                                                    <h4 style={{ fontWeight: 600, marginBottom: '0.5rem', fontSize: '0.875rem' }}>Attributes</h4>
                                                                    {item.parsedAttributes ? (
                                                                        <pre style={{ fontSize: '0.75rem', background: 'var(--color-bg)', padding: '0.75rem', borderRadius: '6px', border: '1px solid var(--color-border)', overflow: 'auto', maxHeight: '150px' }}>
                                                                            {JSON.stringify(item.parsedAttributes, null, 2)}
                                                                        </pre>
                                                                    ) : <p style={{ fontSize: '0.8rem', color: 'var(--color-text-muted)' }}>None</p>}
                                                                </div>
                                                                <div>
                                                                    <h4 style={{ fontWeight: 600, marginBottom: '0.5rem', fontSize: '0.875rem' }}>Dimensions</h4>
                                                                    {item.parsedDimensions ? (
                                                                        <pre style={{ fontSize: '0.75rem', background: 'var(--color-bg)', padding: '0.75rem', borderRadius: '6px', border: '1px solid var(--color-border)', overflow: 'auto' }}>
                                                                            {JSON.stringify(item.parsedDimensions, null, 2)}
                                                                        </pre>
                                                                    ) : <p style={{ fontSize: '0.8rem', color: 'var(--color-text-muted)' }}>None</p>}
                                                                </div>
                                                                <div>
                                                                    <h4 style={{ fontWeight: 600, marginBottom: '0.5rem', fontSize: '0.875rem' }}>Images ({item.parsedImages?.length || 0})</h4>
                                                                    <div style={{ display: 'flex', gap: '4px', flexWrap: 'wrap' }}>
                                                                        {(item.parsedImages || []).map((url: string, i: number) => (
                                                                            <a key={i} href={url} target="_blank" rel="noopener noreferrer" style={{ fontSize: '11px', color: 'var(--color-primary)', textDecoration: 'underline' }}>
                                                                                Image {i + 1}
                                                                            </a>
                                                                        ))}
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        )}
                                                    </td>
                                                </tr>
                                            )}
                                        </>
                                    );
                                })}
                            </tbody>
                        </table>
                    </div>
                )}
            </div>
        </div>
    );
}
