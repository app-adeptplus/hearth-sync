'use client';

import { useState, useEffect } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';

const SOURCE_TYPE_LABELS: Record<string, string> = {
    SITE_SCRAPER: '🌐 Site Scraper',
    API_AUTOMATION: '🔌 API Automation',
    FTP_ERP: '📁 FTP/ERP Connection',
};

const DEFAULT_SITE_SCRAPER_PROMPT = `You are a product data extraction assistant for a hearth product catalog. For each product found on the page, extract the following fields:

1. **Product Name** — Full product name/title as displayed
2. **SKU / Model Number** — The manufacturer SKU, model number, or part number
3. **Images** — All product image URLs (full resolution when available)
4. **Product Description** — Full marketing description and product overview

Return structured JSON for each product. If a field is not available on the page, set it to null.`;

const STATUS_OPTIONS = ['DRAFT', 'ACTIVE', 'PAUSED'];
const OCCURRENCE_OPTIONS = [
    { value: 'MANUAL', label: 'Manual' },
    { value: 'HOURLY', label: 'Every Hour' },
    { value: 'DAILY', label: 'Daily' },
    { value: 'WEEKLY', label: 'Weekly' },
    { value: 'BIWEEKLY', label: 'Bi-Weekly' },
    { value: 'MONTHLY', label: 'Monthly' },
];

const AUTH_TYPES = [
    { value: 'none', label: 'None' },
    { value: 'api_key', label: 'API Key' },
    { value: 'bearer_token', label: 'Bearer Token' },
    { value: 'oauth2', label: 'OAuth 2.0' },
];

interface EditAutomationClientProps {
    config: any;
    brands: any[];
    isNew: boolean;
}

interface PromptTemplate { id: string; name: string; category: string; }
interface LlmConfig { id: string; displayName: string | null; provider: string; model: string; isDefault: boolean; }
interface McpServer { id: string; name: string; transportType: string; }

export default function EditAutomationClient({ config, brands, isNew }: EditAutomationClientProps) {
    const router = useRouter();
    const searchParams = useSearchParams();
    const defaultType = searchParams.get('type') || config?.sourceType || 'SITE_SCRAPER';

    // Form state
    const [name, setName] = useState(config?.name || '');
    const [brandId, setBrandId] = useState(config?.brandId || '');
    const [sourceType, setSourceType] = useState(defaultType);
    const [status, setStatus] = useState(config?.status || 'DRAFT');
    const [occurrence, setOccurrence] = useState(config?.occurrence || 'MANUAL');

    // Site Scraper
    const [siteUrl, setSiteUrl] = useState(config?.siteUrl || '');
    const [crawlDepth, setCrawlDepth] = useState(config?.crawlDepth || 'SHALLOW');

    // API Automation
    const [apiEndpoint, setApiEndpoint] = useState(config?.apiEndpoint || '');
    const [apiAuthType, setApiAuthType] = useState(config?.apiAuthType || 'none');
    const [apiCredentials, setApiCredentials] = useState(
        config?.apiCredentials ? JSON.stringify(config.apiCredentials, null, 2) : ''
    );

    // FTP/ERP
    const [ftpHost, setFtpHost] = useState(config?.ftpHost || '');
    const [ftpPort, setFtpPort] = useState(config?.ftpPort?.toString() || '21');
    const [ftpUser, setFtpUser] = useState(config?.ftpUser || '');
    const [ftpPassword, setFtpPassword] = useState(config?.ftpPassword || '');
    const [ftpPath, setFtpPath] = useState(config?.ftpPath || '');

    // AI
    const [llmInstructions, setLlmInstructions] = useState(config?.llmInstructions || '');
    const [llmModelOverride, setLlmModelOverride] = useState(config?.llmModelOverride || '');
    const [notes, setNotes] = useState(config?.notes || '');

    // Phase E — new AI selectors
    const [promptTemplateId, setPromptTemplateId] = useState<string>(config?.promptTemplateId || '');
    const [llmConfigOverrideId, setLlmConfigOverrideId] = useState<string>(config?.llmConfigOverrideId || '');
    const [mcpServerIds, setMcpServerIds] = useState<string[]>(
        config?.mcpServerLinks?.map((l: any) => l.mcpServer.id) ?? []
    );
    const [promptTemplates, setPromptTemplates] = useState<PromptTemplate[]>([]);
    const [llmConfigs, setLlmConfigs] = useState<LlmConfig[]>([]);
    const [mcpServers, setMcpServers] = useState<McpServer[]>([]);
    const [selectedTemplate, setSelectedTemplate] = useState<PromptTemplate | null>(
        config?.promptTemplate ?? null
    );

    // UI state
    const [isSaving, setIsSaving] = useState(false);
    const [saveStatus, setSaveStatus] = useState<'idle' | 'saved' | 'error'>('idle');
    const [saveError, setSaveError] = useState('');
    const [expandedRun, setExpandedRun] = useState<string | null>(null);

    // Load prompt templates, LLM configs, and MCP servers
    useEffect(() => {
        Promise.all([
            fetch('/api/automation/prompt-templates').then(r => r.json()),
            fetch('/api/automation/llm-settings').then(r => r.json()),
            fetch('/api/automation/mcp-servers').then(r => r.json()),
        ]).then(([templates, llmCfgs, mcpSrvs]) => {
            if (Array.isArray(templates)) setPromptTemplates(templates);
            if (Array.isArray(llmCfgs)) setLlmConfigs(llmCfgs);
            if (Array.isArray(mcpSrvs)) setMcpServers(mcpSrvs);
        }).catch(() => {/* non-critical, UI degrades gracefully */});
    }, []);

    const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
        e.preventDefault();
        setIsSaving(true);
        setSaveStatus('idle');
        setSaveError('');

        try {
            let parsedCredentials = null;
            if (apiCredentials.trim()) {
                try {
                    parsedCredentials = JSON.parse(apiCredentials);
                } catch {
                    throw new Error('Invalid JSON in API Credentials');
                }
            }

            const payload = {
                name, brandId: brandId || null, sourceType, status, occurrence,
                siteUrl: siteUrl || null,
                crawlDepth,
                apiEndpoint: apiEndpoint || null,
                apiAuthType: apiAuthType || null,
                apiCredentials: parsedCredentials,
                ftpHost: ftpHost || null,
                ftpPort: ftpPort || null,
                ftpUser: ftpUser || null,
                ftpPassword: ftpPassword || null,
                ftpPath: ftpPath || null,
                llmInstructions: llmInstructions || null,
                llmModelOverride: llmModelOverride || null,
                notes: notes || null,
                // Phase E fields
                promptTemplateId: promptTemplateId || null,
                llmConfigOverrideId: llmConfigOverrideId || null,
                mcpServerIds,
            };

            const url = isNew ? '/api/automation/configs' : `/api/automation/configs/${config.id}`;
            const method = isNew ? 'POST' : 'PATCH';

            const res = await fetch(url, {
                method,
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload),
            });

            if (!res.ok) {
                const data = await res.json();
                throw new Error(data.error || 'Failed to save');
            }

            setSaveStatus('saved');
            router.push(`/admin/product-automation?tab=${sourceType}`);
        } catch (error: any) {
            setSaveStatus('error');
            setSaveError(error.message);
        } finally {
            setIsSaving(false);
        }
    };

    const handleRunNow = async () => {
        try {
            const res = await fetch('/api/automation/runs', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ configId: config.id }),
            });
            if (!res.ok) throw new Error('Failed to trigger run');
            alert('Automation run queued successfully!');
            router.refresh();
        } catch (err: any) {
            alert(err.message);
        }
    };

    const formatDate = (d: string | null) => {
        if (!d) return '—';
        return new Date(d).toLocaleDateString('en-US', {
            month: 'short', day: 'numeric', year: 'numeric',
            hour: '2-digit', minute: '2-digit',
        });
    };

    return (
        <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '2rem' }}>
            {/* Header */}
            <div className="page-header">
                <div>
                    <h2 className="page-title">{isNew ? 'New Automation Config' : `Edit: ${config?.name}`}</h2>
                    <p className="page-subtitle">
                        {SOURCE_TYPE_LABELS[sourceType] || sourceType}
                    </p>
                </div>
                <div style={{ display: 'flex', gap: 'var(--space-3)' }}>
                    <button
                        type="button"
                        className="btn btn-ghost"
                        onClick={() => router.push(`/admin/product-automation?tab=${sourceType}`)}
                    >
                        ← Back
                    </button>
                </div>
            </div>

            {/* General Settings */}
            <div className="card" style={{ padding: '2rem', display: 'flex', flexDirection: 'column', gap: '2rem' }}>
                <h3 style={{ fontSize: '1.15rem', fontWeight: 600, borderBottom: '1px solid var(--color-border)', paddingBottom: '0.75rem' }}>
                    General Settings
                </h3>

                {isNew && (
                    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '2rem' }}>
                        <div>
                            <label style={{ display: 'block', fontSize: '0.875rem', fontWeight: 600, marginBottom: '0.5rem' }}>Source Type</label>
                            <select className="form-select" style={{ width: '100%' }} value={sourceType} onChange={e => setSourceType(e.target.value)}>
                                <option value="SITE_SCRAPER">🌐 Site Scraper</option>
                                <option value="API_AUTOMATION">🔌 API Automation</option>
                                <option value="FTP_ERP">📁 FTP/ERP Connection</option>
                            </select>
                        </div>
                    </div>
                )}

                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '2rem' }}>
                    <div>
                        <label style={{ display: 'block', fontSize: '0.875rem', fontWeight: 600, marginBottom: '0.5rem' }}>Name</label>
                        <input type="text" className="form-input" style={{ width: '100%' }} value={name} onChange={e => setName(e.target.value)} placeholder="e.g. Heat & Glo Product Scraper" required />
                    </div>
                    <div>
                        <label style={{ display: 'block', fontSize: '0.875rem', fontWeight: 600, marginBottom: '0.5rem' }}>Brand</label>
                        <select className="form-select" style={{ width: '100%' }} value={brandId} onChange={e => setBrandId(e.target.value)}>
                            <option value="">— No Brand —</option>
                            {brands.map((b: any) => (
                                <option key={b.id} value={b.id}>{b.name}</option>
                            ))}
                        </select>
                    </div>
                    <div>
                        <label style={{ display: 'block', fontSize: '0.875rem', fontWeight: 600, marginBottom: '0.5rem' }}>Status</label>
                        <select className="form-select" style={{ width: '100%' }} value={status} onChange={e => setStatus(e.target.value)}>
                            {STATUS_OPTIONS.map(s => (
                                <option key={s} value={s}>{s}</option>
                            ))}
                        </select>
                    </div>
                    <div>
                        <label style={{ display: 'block', fontSize: '0.875rem', fontWeight: 600, marginBottom: '0.5rem' }}>Occurrence</label>
                        <select className="form-select" style={{ width: '100%' }} value={occurrence} onChange={e => setOccurrence(e.target.value)}>
                            {OCCURRENCE_OPTIONS.map(o => (
                                <option key={o.value} value={o.value}>{o.label}</option>
                            ))}
                        </select>
                    </div>
                </div>
            </div>

            {/* Source-specific Settings */}
            <div className="card" style={{ padding: '2rem', display: 'flex', flexDirection: 'column', gap: '2rem' }}>
                <h3 style={{ fontSize: '1.15rem', fontWeight: 600, borderBottom: '1px solid var(--color-border)', paddingBottom: '0.75rem' }}>
                    {SOURCE_TYPE_LABELS[sourceType]} Settings
                </h3>

                {sourceType === 'SITE_SCRAPER' && (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
                        <div>
                            <label style={{ display: 'block', fontSize: '0.875rem', fontWeight: 600, marginBottom: '0.5rem' }}>Site URL</label>
                            <input type="url" className="form-input" style={{ width: '100%' }} value={siteUrl} onChange={e => setSiteUrl(e.target.value)} placeholder="https://www.manufacturer.com/products" />
                            <p style={{ fontSize: '0.75rem', color: 'var(--color-text-muted)', marginTop: '0.25rem' }}>
                                The AI will crawl this URL and automatically discover product pages, images, descriptions, and specifications.
                            </p>
                        </div>
                        <div>
                            <label style={{ display: 'block', fontSize: '0.875rem', fontWeight: 600, marginBottom: '0.5rem' }}>Crawl Depth</label>
                            <select className="form-select" style={{ width: '100%' }} value={crawlDepth} onChange={e => setCrawlDepth(e.target.value)}>
                                <option value="SHALLOW">Shallow — Listing page only (faster, less data)</option>
                                <option value="DEEP">Deep — Crawl individual product pages (more data, more tokens)</option>
                            </select>
                            <p style={{ fontSize: '0.75rem', color: 'var(--color-text-muted)', marginTop: '0.25rem' }}>
                                {crawlDepth === 'DEEP'
                                    ? '🔎 Deep mode: discovers product URLs via site map, then scrapes each page individually for full SKUs, specs, images, and descriptions.'
                                    : '⚡ Shallow mode: scrapes the listing page only. Faster but captures less detail per product.'}
                            </p>
                        </div>
                    </div>
                )}

                {sourceType === 'API_AUTOMATION' && (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
                        <div>
                            <label style={{ display: 'block', fontSize: '0.875rem', fontWeight: 600, marginBottom: '0.5rem' }}>API Endpoint</label>
                            <input type="url" className="form-input" style={{ width: '100%' }} value={apiEndpoint} onChange={e => setApiEndpoint(e.target.value)} placeholder="https://api.manufacturer.com/v1/products" />
                        </div>
                        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '2rem' }}>
                            <div>
                                <label style={{ display: 'block', fontSize: '0.875rem', fontWeight: 600, marginBottom: '0.5rem' }}>Auth Type</label>
                                <select className="form-select" style={{ width: '100%' }} value={apiAuthType} onChange={e => setApiAuthType(e.target.value)}>
                                    {AUTH_TYPES.map(a => (
                                        <option key={a.value} value={a.value}>{a.label}</option>
                                    ))}
                                </select>
                            </div>
                        </div>
                        {apiAuthType !== 'none' && (
                            <div>
                                <label style={{ display: 'block', fontSize: '0.875rem', fontWeight: 600, marginBottom: '0.5rem' }}>Credentials (JSON)</label>
                                <textarea className="form-input" style={{ width: '100%', fontFamily: 'monospace', fontSize: '0.8rem' }} rows={4} value={apiCredentials} onChange={e => setApiCredentials(e.target.value)} placeholder='{ "apiKey": "your-key-here" }' />
                            </div>
                        )}
                    </div>
                )}

                {sourceType === 'FTP_ERP' && (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
                        <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: '2rem' }}>
                            <div>
                                <label style={{ display: 'block', fontSize: '0.875rem', fontWeight: 600, marginBottom: '0.5rem' }}>FTP Host</label>
                                <input type="text" className="form-input" style={{ width: '100%' }} value={ftpHost} onChange={e => setFtpHost(e.target.value)} placeholder="ftp.manufacturer.com" />
                            </div>
                            <div>
                                <label style={{ display: 'block', fontSize: '0.875rem', fontWeight: 600, marginBottom: '0.5rem' }}>Port</label>
                                <input type="number" className="form-input" style={{ width: '100%' }} value={ftpPort} onChange={e => setFtpPort(e.target.value)} placeholder="21" />
                            </div>
                        </div>
                        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '2rem' }}>
                            <div>
                                <label style={{ display: 'block', fontSize: '0.875rem', fontWeight: 600, marginBottom: '0.5rem' }}>Username</label>
                                <input type="text" className="form-input" style={{ width: '100%' }} value={ftpUser} onChange={e => setFtpUser(e.target.value)} placeholder="ftp_user" />
                            </div>
                            <div>
                                <label style={{ display: 'block', fontSize: '0.875rem', fontWeight: 600, marginBottom: '0.5rem' }}>Password</label>
                                <input type="password" className="form-input" style={{ width: '100%' }} value={ftpPassword} onChange={e => setFtpPassword(e.target.value)} placeholder="••••••••" />
                            </div>
                        </div>
                        <div>
                            <label style={{ display: 'block', fontSize: '0.875rem', fontWeight: 600, marginBottom: '0.5rem' }}>Remote Path</label>
                            <input type="text" className="form-input" style={{ width: '100%' }} value={ftpPath} onChange={e => setFtpPath(e.target.value)} placeholder="/exports/products/" />
                        </div>
                    </div>
                )}
            </div>

            {/* AI Configuration */}
            <div className="card" style={{ padding: '2rem', display: 'flex', flexDirection: 'column', gap: '2rem' }}>
                <h3 style={{ fontSize: '1.15rem', fontWeight: 600, borderBottom: '1px solid var(--color-border)', paddingBottom: '0.75rem' }}>
                    🧠 AI Configuration
                </h3>

                {/* Prompt Template selector */}
                <div>
                    <label style={{ display: 'block', fontSize: '0.875rem', fontWeight: 600, marginBottom: '0.5rem' }}>
                        Prompt Template
                    </label>
                    <select
                        className="form-select"
                        style={{ width: '100%' }}
                        value={promptTemplateId}
                        onChange={e => {
                            setPromptTemplateId(e.target.value);
                            setSelectedTemplate(promptTemplates.find(t => t.id === e.target.value) ?? null);
                        }}
                    >
                        <option value="">— Use inline instructions below —</option>
                        {promptTemplates.map(t => (
                            <option key={t.id} value={t.id}>
                                {t.name} ({t.category.replace(/_/g, ' ')})
                            </option>
                        ))}
                    </select>
                    {selectedTemplate && (
                        <p style={{ fontSize: '0.75rem', color: 'var(--color-text-muted)', marginTop: '0.25rem' }}>
                            Using shared template. The instructions below will be appended as an addendum.
                        </p>
                    )}
                    {promptTemplates.length === 0 && (
                        <p style={{ fontSize: '0.75rem', color: 'var(--color-text-muted)', marginTop: '0.25rem' }}>
                            No templates yet. <a href="/admin/models" target="_blank" rel="noopener" style={{ color: 'var(--color-primary)' }}>Create one in System Services →</a>
                        </p>
                    )}
                </div>

                {/* Inline instructions (always visible — used as addendum when template is selected) */}
                <div>
                    <label style={{ display: 'block', fontSize: '0.875rem', fontWeight: 600, marginBottom: '0.5rem' }}>
                        {selectedTemplate ? 'Additional Instructions (appended to template)' : 'LLM Instructions'}
                    </label>
                    <textarea
                        className="form-input"
                        style={{ width: '100%' }}
                        rows={selectedTemplate ? 3 : 6}
                        value={llmInstructions}
                        onChange={e => setLlmInstructions(e.target.value)}
                        placeholder={
                            selectedTemplate
                                ? 'Optional: add config-specific overrides or extra instructions…'
                                : (sourceType === 'SITE_SCRAPER' ? DEFAULT_SITE_SCRAPER_PROMPT : 'Describe how the AI should process data from this source…')
                        }
                    />
                </div>

                {/* LLM Provider override */}
                <div>
                    <label style={{ display: 'block', fontSize: '0.875rem', fontWeight: 600, marginBottom: '0.5rem' }}>
                        LLM Provider Override
                    </label>
                    <select
                        className="form-select"
                        style={{ width: '100%' }}
                        value={llmConfigOverrideId}
                        onChange={e => setLlmConfigOverrideId(e.target.value)}
                    >
                        <option value="">
                            — Use default provider{llmConfigs.find(c => c.isDefault) ? ` (${llmConfigs.find(c => c.isDefault)!.displayName || llmConfigs.find(c => c.isDefault)!.provider})` : ''} —
                        </option>
                        {llmConfigs.filter(c => !c.isDefault).map(c => (
                            <option key={c.id} value={c.id}>
                                {c.displayName || c.provider} — {c.model}
                            </option>
                        ))}
                    </select>
                    {llmConfigs.length === 0 && (
                        <p style={{ fontSize: '0.75rem', color: 'var(--color-text-muted)', marginTop: '0.25rem' }}>
                            No LLM providers configured. <a href="/admin/models" target="_blank" rel="noopener" style={{ color: 'var(--color-primary)' }}>Add one in System Services →</a>
                        </p>
                    )}
                </div>

                {/* MCP Server links */}
                {mcpServers.length > 0 && (
                    <div>
                        <label style={{ display: 'block', fontSize: '0.875rem', fontWeight: 600, marginBottom: '0.5rem' }}>
                            MCP Tool Servers
                        </label>
                        <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
                            {mcpServers.map(srv => (
                                <label key={srv.id} style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', cursor: 'pointer', fontSize: '0.875rem' }}>
                                    <input
                                        type="checkbox"
                                        checked={mcpServerIds.includes(srv.id)}
                                        onChange={e => setMcpServerIds(
                                            e.target.checked
                                                ? [...mcpServerIds, srv.id]
                                                : mcpServerIds.filter(id => id !== srv.id)
                                        )}
                                    />
                                    {srv.name}
                                    <span style={{ fontSize: '0.7rem', color: 'var(--color-text-muted)', fontFamily: 'monospace' }}>
                                        {srv.transportType === 'SSE' ? 'SSE' : 'HTTP'}
                                    </span>
                                </label>
                            ))}
                        </div>
                    </div>
                )}
            </div>

            {/* Notes */}
            <div className="card" style={{ padding: '2rem', display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                <h3 style={{ fontSize: '1.15rem', fontWeight: 600, borderBottom: '1px solid var(--color-border)', paddingBottom: '0.75rem' }}>
                    Notes
                </h3>
                <div>
                    <textarea className="form-input" style={{ width: '100%' }} rows={3} value={notes} onChange={e => setNotes(e.target.value)} placeholder="Internal notes, exclusions, special handling..." />
                </div>
            </div>

            {/* Artifact History — edit mode only */}
            {!isNew && config?.artifacts?.length > 0 && (
                <div className="card" style={{ padding: '2rem', display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                    <h3 style={{ fontSize: '1.15rem', fontWeight: 600, borderBottom: '1px solid var(--color-border)', paddingBottom: '0.75rem' }}>
                        🧠 Learned Artifacts ({config.artifacts.length})
                    </h3>
                    <div className="data-table" style={{ width: '100%' }}>
                        <table style={{ width: '100%' }}>
                            <thead>
                                <tr style={{ borderBottom: '1px solid var(--color-border)' }}>
                                    <th style={{ padding: 'var(--space-2)' }}>Type</th>
                                    <th style={{ padding: 'var(--space-2)' }}>Version</th>
                                    <th style={{ padding: 'var(--space-2)' }}>Active</th>
                                    <th style={{ padding: 'var(--space-2)' }}>Created</th>
                                    <th style={{ padding: 'var(--space-2)' }}>Preview</th>
                                </tr>
                            </thead>
                            <tbody>
                                {config.artifacts.map((a: any) => (
                                    <tr key={a.id} style={{ borderBottom: '1px solid var(--color-border-light)' }}>
                                        <td style={{ padding: 'var(--space-3) var(--space-2)', fontWeight: 500 }}>{a.artifactType}</td>
                                        <td style={{ padding: 'var(--space-3) var(--space-2)' }}>v{a.version}</td>
                                        <td style={{ padding: 'var(--space-3) var(--space-2)' }}>
                                            <span className={`badge ${a.isActive ? 'badge-active' : 'badge-inactive'}`}>
                                                {a.isActive ? 'Active' : 'Inactive'}
                                            </span>
                                        </td>
                                        <td style={{ padding: 'var(--space-3) var(--space-2)', fontSize: '12px', color: 'var(--color-text-muted)' }}>
                                            {formatDate(a.createdAt)}
                                        </td>
                                        <td style={{ padding: 'var(--space-3) var(--space-2)', fontSize: '12px', color: 'var(--color-text-muted)', maxWidth: '200px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                                            {a.content?.substring(0, 80)}...
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </div>
            )}

            {/* Recent Runs — edit mode only */}
            {!isNew && config?.runs?.length > 0 && (
                <div className="card" style={{ padding: '2rem', display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                    <h3 style={{ fontSize: '1.15rem', fontWeight: 600, borderBottom: '1px solid var(--color-border)', paddingBottom: '0.75rem' }}>
                        🕒 Recent Runs ({config.runs.length})
                    </h3>
                    <div className="data-table" style={{ width: '100%' }}>
                        <table style={{ width: '100%' }}>
                            <thead>
                                <tr style={{ borderBottom: '1px solid var(--color-border)' }}>
                                    <th style={{ padding: 'var(--space-2)' }}>Status</th>
                                    <th style={{ padding: 'var(--space-2)' }}>Found</th>
                                    <th style={{ padding: 'var(--space-2)' }}>Added</th>
                                    <th style={{ padding: 'var(--space-2)' }}>Updated</th>
                                    <th style={{ padding: 'var(--space-2)' }}>Tokens</th>
                                    <th style={{ padding: 'var(--space-2)' }}>Started</th>
                                    <th style={{ padding: 'var(--space-2)' }}>Data Package</th>
                                    <th style={{ padding: 'var(--space-2)' }}>Details</th>
                                </tr>
                            </thead>
                            <tbody>
                                {config.runs.map((run: any) => (
                                    <>
                                    <tr key={run.id} style={{ borderBottom: expandedRun === run.id ? 'none' : '1px solid var(--color-border-light)' }}>
                                        <td style={{ padding: 'var(--space-3) var(--space-2)' }}>
                                            <span className={`badge ${run.status === 'COMPLETED' ? 'badge-active' : run.status === 'FAILED' ? 'badge-error' : run.status === 'RUNNING' ? 'badge-warning' : 'badge-info'}`}>
                                                {run.status}
                                            </span>
                                        </td>
                                        <td style={{ padding: 'var(--space-3) var(--space-2)' }}>{run.productsFound}</td>
                                        <td style={{ padding: 'var(--space-3) var(--space-2)' }}>{run.productsAdded}</td>
                                        <td style={{ padding: 'var(--space-3) var(--space-2)' }}>{run.productsUpdated}</td>
                                        <td style={{ padding: 'var(--space-3) var(--space-2)', fontSize: '12px' }}>{run.llmTokensUsed || '—'}</td>
                                        <td style={{ padding: 'var(--space-3) var(--space-2)', fontSize: '12px', color: 'var(--color-text-muted)' }}>
                                            {formatDate(run.startedAt || run.createdAt)}
                                        </td>
                                        <td style={{ padding: 'var(--space-3) var(--space-2)' }}>
                                            {run.dataPackage ? (
                                                <a href={`/admin/product-automation/packages/${run.dataPackage.id}`} className="btn btn-sm btn-secondary" style={{ textDecoration: 'none' }}>
                                                    📦 {run.dataPackage.name}
                                                </a>
                                            ) : '—'}
                                        </td>
                                        <td style={{ padding: 'var(--space-3) var(--space-2)' }}>
                                            <button
                                                type="button"
                                                className="btn btn-sm btn-ghost"
                                                onClick={() => setExpandedRun(expandedRun === run.id ? null : run.id)}
                                            >
                                                {expandedRun === run.id ? '▲' : '▼'}
                                            </button>
                                        </td>
                                    </tr>
                                    {expandedRun === run.id && (
                                        <tr key={`${run.id}-detail`} style={{ borderBottom: '1px solid var(--color-border-light)', background: run.status === 'FAILED' ? 'rgba(239, 68, 68, 0.05)' : 'var(--color-bg-elevated)' }}>
                                            <td colSpan={8} style={{ padding: 'var(--space-4)' }}>
                                                <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                                                    {/* Errors */}
                                                    {run.errors && Array.isArray(run.errors) && run.errors.length > 0 && (
                                                        <div>
                                                            <h4 style={{ fontWeight: 600, marginBottom: '0.5rem', fontSize: '0.875rem', color: 'var(--color-error, #ef4444)' }}>
                                                                ❌ Errors ({run.errors.length})
                                                            </h4>
                                                            <div style={{ fontSize: '0.8rem', color: 'var(--color-error, #ef4444)', background: 'rgba(239, 68, 68, 0.08)', padding: '0.75rem', borderRadius: '6px', border: '1px solid rgba(239, 68, 68, 0.2)' }}>
                                                                {run.errors.map((err: string, i: number) => (
                                                                    <div key={i} style={{ marginBottom: i < run.errors.length - 1 ? '0.5rem' : 0 }}>• {err}</div>
                                                                ))}
                                                            </div>
                                                        </div>
                                                    )}
                                                    {/* Run Details */}
                                                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem', fontSize: '0.8rem' }}>
                                                        <div>
                                                            <span style={{ fontWeight: 600, color: 'var(--color-text-secondary)' }}>Run ID:</span>{' '}
                                                            <code style={{ fontSize: '0.75rem' }}>{run.id}</code>
                                                        </div>
                                                        <div>
                                                            <span style={{ fontWeight: 600, color: 'var(--color-text-secondary)' }}>Duration:</span>{' '}
                                                            {run.startedAt && run.completedAt
                                                                ? `${Math.round((new Date(run.completedAt).getTime() - new Date(run.startedAt).getTime()) / 1000)}s`
                                                                : '—'}
                                                        </div>
                                                    </div>
                                                    {/* Raw Output (collapsible) */}
                                                    {run.rawOutput && (
                                                        <details>
                                                            <summary style={{ cursor: 'pointer', fontSize: '0.8rem', fontWeight: 600, color: 'var(--color-text-muted)' }}>
                                                                📄 Raw LLM Output ({run.rawOutput.length} chars)
                                                            </summary>
                                                            <pre style={{ fontSize: '0.7rem', background: 'var(--color-bg)', padding: '0.75rem', borderRadius: '6px', border: '1px solid var(--color-border)', overflow: 'auto', maxHeight: '300px', marginTop: '0.5rem', whiteSpace: 'pre-wrap', wordBreak: 'break-word' }}>
                                                                {run.rawOutput}
                                                            </pre>
                                                        </details>
                                                    )}
                                                </div>
                                            </td>
                                        </tr>
                                    )}
                                    </>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </div>
            )}

            {/* Action Bar */}
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', paddingTop: '1.5rem', marginBottom: '2rem', borderTop: '1px solid var(--color-border)' }}>
                {!isNew ? (
                    <button type="button" className="btn btn-secondary" onClick={handleRunNow} style={{ padding: '0 1.5rem' }}>
                        🤖 Run Automation Now
                    </button>
                ) : (
                    <div></div>
                )}
                <button type="submit" className="btn btn-primary" disabled={isSaving} style={{ padding: '0 2rem' }}>
                    {isSaving ? 'Saving...' : isNew ? 'Create Configuration' : 'Save Configuration'}
                </button>
            </div>

            {saveStatus === 'error' && (
                <div style={{
                    background: 'var(--color-error-bg, #fef2f2)',
                    border: '1px solid var(--color-error, #ef4444)',
                    borderRadius: '8px',
                    padding: '1rem 1.25rem',
                    color: 'var(--color-error, #dc2626)',
                    fontSize: '14px',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '0.5rem',
                }}>
                    ⚠️ {saveError}
                </div>
            )}
        </form>
    );
}
