import prisma from '@/lib/db';
import EditAutomationClient from './EditAutomationClient';

interface PageProps {
    params: { id: string };
}

async function getConfigData(id: string) {
    try {
        if (id === 'new') {
            const brands = await prisma.brand.findMany({
                select: { id: true, name: true },
                orderBy: { name: 'asc' },
            });
            return { config: null, brands, isNew: true };
        }

        const [config, brands] = await Promise.all([
            prisma.automationConfig.findUnique({
                where: { id },
                include: {
                    brand: { select: { id: true, name: true } },
                    artifacts: {
                        orderBy: { createdAt: 'desc' },
                        take: 20,
                    },
                    runs: {
                        orderBy: { createdAt: 'desc' },
                        take: 10,
                        include: {
                            dataPackage: { select: { id: true, name: true, status: true } },
                        },
                    },
                },
            }),
            prisma.brand.findMany({
                select: { id: true, name: true },
                orderBy: { name: 'asc' },
            }),
        ]);

        return { config, brands, isNew: false };
    } catch {
        return { config: null, brands: [], isNew: false };
    }
}

export default async function AutomationConfigPage({ params }: PageProps) {
    const { config, brands, isNew } = await getConfigData(params.id);

    return (
        <EditAutomationClient
            config={config}
            brands={brands}
            isNew={isNew}
        />
    );
}
