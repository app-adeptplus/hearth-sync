'use client';

import { useEffect, useState, useCallback } from 'react';
import Modal from '@/components/Modal';

type McpTransport = 'SSE' | 'STREAMABLE_HTTP';

interface McpServer {
    id: string;
    name: string;
    description: string | null;
    transportType: McpTransport;
    url: string;
    headers: any;
    authToken: string | null;
    isActive: boolean;
    lastConnectedAt: string | null;
    lastError: string | null;
    discoveredTools: any[] | null;
    toolsRefreshedAt: string | null;
    providerLinks: { llmConfig: { id: string; displayName: string | null; provider: string } }[];
}

interface LlmConfig {
    id: string;
    displayName: string | null;
    provider: string;
    model: string;
}

const TRANSPORT_LABELS: Record<McpTransport, string> = {
    SSE: 'Server-Sent Events (SSE)',
    STREAMABLE_HTTP: 'Streamable HTTP',
};

const emptyForm = {
    name: '', description: '', transportType: 'STREAMABLE_HTTP' as McpTransport,
    url: '', authToken: '', isActive: true, linkedLlmConfigIds: [] as string[],
};

export default function MCPServersTab() {
    const [servers, setServers] = useState<McpServer[]>([]);
    const [llmConfigs, setLlmConfigs] = useState<LlmConfig[]>([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);

    const [showModal, setShowModal] = useState(false);
    const [editingServer, setEditingServer] = useState<McpServer | null>(null);
    const [form, setForm] = useState(emptyForm);
    const [saving, setSaving] = useState(false);
    const [testing, setTesting] = useState<string | null>(null);

    const [showTools, setShowTools] = useState(false);
    const [toolsServer, setToolsServer] = useState<McpServer | null>(null);

    const loadData = useCallback(async () => {
        setLoading(true);
        try {
            const [srvRes, llmRes] = await Promise.all([
                fetch('/api/automation/mcp-servers'),
                fetch('/api/automation/llm-settings'),
            ]);
            const srvData = await srvRes.json();
            const llmData = await llmRes.json();
            setServers(Array.isArray(srvData) ? srvData : []);
            setLlmConfigs(Array.isArray(llmData) ? llmData : []);
            if (!Array.isArray(srvData) && srvData?.error) setError(`MCP Servers: ${srvData.error}`);
        } catch (e: any) {
            setError(e.message);
        } finally {
            setLoading(false);
        }
    }, []);

    useEffect(() => { loadData(); }, [loadData]);

    function openAdd() {
        setEditingServer(null);
        setForm(emptyForm);
        setShowModal(true);
    }

    function openEdit(s: McpServer) {
        setEditingServer(s);
        setForm({
            name: s.name,
            description: s.description || '',
            transportType: s.transportType,
            url: s.url,
            authToken: s.authToken || '',
            isActive: s.isActive,
            linkedLlmConfigIds: s.providerLinks.map(l => l.llmConfig.id),
        });
        setShowModal(true);
    }

    async function save() {
        setSaving(true);
        try {
            const body = { ...form, description: form.description || null };
            if (editingServer) {
                await fetch(`/api/automation/mcp-servers/${editingServer.id}`, {
                    method: 'PATCH', headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(body),
                });
            } else {
                await fetch('/api/automation/mcp-servers', {
                    method: 'POST', headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(body),
                });
            }
            setShowModal(false);
            loadData();
        } catch (e: any) {
            setError(e.message);
        } finally {
            setSaving(false);
        }
    }

    async function deleteServer(id: string) {
        if (!confirm('Delete this MCP server? This cannot be undone.')) return;
        await fetch(`/api/automation/mcp-servers/${id}`, { method: 'DELETE' });
        loadData();
    }

    async function testServer(id: string) {
        setTesting(id);
        try {
            const res = await fetch(`/api/automation/mcp-servers/${id}/test`, { method: 'POST' });
            const data = await res.json();
            alert(data.success
                ? `✅ Connected (${data.latencyMs}ms) — ${data.toolCount} tool(s) discovered`
                : `❌ Connection failed: ${data.error}`);
            loadData();
        } finally {
            setTesting(null);
        }
    }

    function openTools(s: McpServer) {
        setToolsServer(s);
        setShowTools(true);
    }

    if (loading) return <div className="loading-state">Loading MCP servers…</div>;

    return (
        <div>
            {error && <div className="alert alert-error">{error}</div>}

            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 'var(--space-4)' }}>
                <div>
                    <h2 style={{ margin: 0, fontSize: 'var(--font-size-lg)' }}>MCP Servers</h2>
                    <p style={{ margin: 0, color: 'var(--color-text-secondary)', fontSize: 'var(--font-size-sm)' }}>
                        Connect external Model Context Protocol tool servers (SSE and Streamable HTTP only)
                    </p>
                </div>
                <button className="btn btn-primary" onClick={openAdd}>+ Add Server</button>
            </div>

            <div className="alert alert-info" style={{ marginBottom: 'var(--space-4)', fontSize: 'var(--font-size-sm)' }}>
                <strong>Note:</strong> Only externally-hosted SSE and Streamable HTTP transports are supported. Local stdio servers are not supported in this deployment model.
            </div>

            {servers.length === 0 ? (
                <div className="empty-state">
                    <p>No MCP servers configured. Connect a Firecrawl MCP or custom tool server to extend model capabilities.</p>
                </div>
            ) : (
                <div className="data-table-wrapper">
                    <table className="data-table">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Transport</th>
                                <th>Status</th>
                                <th>Connection</th>
                                <th>Tools</th>
                                <th>Linked Providers</th>
                                <th>Last Connected</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            {servers.map(s => (
                                <tr key={s.id}>
                                    <td>
                                        <div style={{ fontWeight: 500 }}>{s.name}</div>
                                        {s.description && <div style={{ fontSize: 'var(--font-size-xs)', color: 'var(--color-text-muted)' }}>{s.description}</div>}
                                    </td>
                                    <td>
                                        <span className="badge badge-default">{s.transportType === 'SSE' ? 'SSE' : 'HTTP'}</span>
                                    </td>
                                    <td>
                                        <span className={`badge ${s.isActive ? 'badge-success' : 'badge-default'}`}>
                                            {s.isActive ? 'Active' : 'Inactive'}
                                        </span>
                                    </td>
                                    <td>
                                        {s.lastError ? (
                                            <span className="badge badge-error" title={s.lastError}>✗ Error</span>
                                        ) : s.lastConnectedAt ? (
                                            <span className="badge badge-success">✓ Connected</span>
                                        ) : (
                                            <span className="badge badge-default">Not tested</span>
                                        )}
                                    </td>
                                    <td>
                                        {s.discoveredTools ? (
                                            <button className="btn btn-sm btn-ghost" onClick={() => openTools(s)}>
                                                {s.discoveredTools.length} tools
                                            </button>
                                        ) : '—'}
                                    </td>
                                    <td>
                                        <div style={{ display: 'flex', gap: 'var(--space-1)', flexWrap: 'wrap' }}>
                                            {s.providerLinks.map(l => (
                                                <span key={l.llmConfig.id} className="badge badge-default" style={{ fontSize: '11px' }}>
                                                    {l.llmConfig.displayName || l.llmConfig.provider}
                                                </span>
                                            ))}
                                            {s.providerLinks.length === 0 && <span style={{ color: 'var(--color-text-muted)', fontSize: 'var(--font-size-xs)' }}>None</span>}
                                        </div>
                                    </td>
                                    <td style={{ fontSize: 'var(--font-size-sm)', color: 'var(--color-text-secondary)' }}>
                                        {s.lastConnectedAt ? new Date(s.lastConnectedAt).toLocaleDateString() : '—'}
                                    </td>
                                    <td>
                                        <div style={{ display: 'flex', gap: 'var(--space-2)' }}>
                                            <button className="btn btn-sm btn-ghost" onClick={() => testServer(s.id)} disabled={testing === s.id}>
                                                {testing === s.id ? '…' : 'Test'}
                                            </button>
                                            <button className="btn btn-sm btn-ghost" onClick={() => openEdit(s)}>Edit</button>
                                            <button className="btn btn-sm btn-ghost btn-danger" onClick={() => deleteServer(s.id)}>Delete</button>
                                        </div>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            )}

            {/* ── Add/Edit Modal ── */}
            <Modal
                isOpen={showModal}
                onClose={() => setShowModal(false)}
                title={editingServer ? 'Edit MCP Server' : 'Add MCP Server'}
                subtitle="Configure an external Model Context Protocol tool server connection."
                size="md"
                footer={
                    <>
                        <button className="btn btn-ghost" onClick={() => setShowModal(false)}>Cancel</button>
                        <button className="btn btn-primary" onClick={save} disabled={saving}>
                            {saving ? 'Saving…' : 'Save Server'}
                        </button>
                    </>
                }
            >
                <div style={{ padding: '1.5rem', display: 'flex', flexDirection: 'column', gap: 'var(--space-4)' }}>
                    <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: 'var(--space-3)' }}>
                        <div className="form-group">
                            <label className="form-label">Name</label>
                            <input className="form-input" placeholder='e.g. "Firecrawl MCP", "Web Search Tools"'
                                value={form.name}
                                onChange={e => setForm(f => ({ ...f, name: e.target.value }))} />
                        </div>
                        <div className="form-group">
                            <label className="form-label">Status</label>
                            <select className="form-select" value={form.isActive ? 'active' : 'inactive'}
                                onChange={e => setForm(f => ({ ...f, isActive: e.target.value === 'active' }))}>
                                <option value="active">Active</option>
                                <option value="inactive">Inactive</option>
                            </select>
                        </div>
                    </div>
                    <div className="form-group">
                        <label className="form-label">Description (optional)</label>
                        <input className="form-input" placeholder="What tools does this server provide?"
                            value={form.description}
                            onChange={e => setForm(f => ({ ...f, description: e.target.value }))} />
                    </div>
                    <div className="form-group">
                        <label className="form-label">Transport</label>
                        <select className="form-select" value={form.transportType}
                            onChange={e => setForm(f => ({ ...f, transportType: e.target.value as McpTransport }))}>
                            {Object.entries(TRANSPORT_LABELS).map(([k, v]) => (
                                <option key={k} value={k}>{v}</option>
                            ))}
                        </select>
                    </div>
                    <div className="form-group">
                        <label className="form-label">Endpoint URL</label>
                        <input className="form-input" placeholder="https://mcp.example.com/..."
                            value={form.url}
                            onChange={e => setForm(f => ({ ...f, url: e.target.value }))} />
                    </div>
                    <div className="form-group">
                        <label className="form-label">Auth Token (optional)</label>
                        <input className="form-input" type="password" placeholder="Bearer token"
                            value={form.authToken}
                            onChange={e => setForm(f => ({ ...f, authToken: e.target.value }))} />
                        <span className="form-hint">Stored encrypted (AES-256-GCM)</span>
                    </div>
                    <div className="form-group">
                        <label className="form-label">Link to LLM Providers</label>
                        <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-1)' }}>
                            {llmConfigs.map(cfg => (
                                <label key={cfg.id} style={{ display: 'flex', alignItems: 'center', gap: 'var(--space-2)', cursor: 'pointer' }}>
                                    <input type="checkbox"
                                        checked={form.linkedLlmConfigIds.includes(cfg.id)}
                                        onChange={e => setForm(f => ({
                                            ...f,
                                            linkedLlmConfigIds: e.target.checked
                                                ? [...f.linkedLlmConfigIds, cfg.id]
                                                : f.linkedLlmConfigIds.filter(id => id !== cfg.id),
                                        }))} />
                                    {cfg.displayName || cfg.provider} — <code style={{ fontSize: 'var(--font-size-xs)' }}>{cfg.model}</code>
                                </label>
                            ))}
                            {llmConfigs.length === 0 && <span className="form-hint">No LLM providers configured yet</span>}
                        </div>
                    </div>
                </div>
            </Modal>

            {/* ── Tools Discovery Modal ── */}
            <Modal
                isOpen={showTools && !!toolsServer}
                onClose={() => setShowTools(false)}
                title={toolsServer ? `${toolsServer.name} — Discovered Tools` : 'Discovered Tools'}
                subtitle={toolsServer?.toolsRefreshedAt ? `Last refreshed: ${new Date(toolsServer.toolsRefreshedAt).toLocaleString()}` : 'Run a test to discover tools.'}
                size="md"
                footer={
                    <>
                        <button className="btn btn-ghost" onClick={() => { setShowTools(false); if (toolsServer) testServer(toolsServer.id); }}>
                            Refresh Tools
                        </button>
                        <button className="btn btn-ghost" onClick={() => setShowTools(false)}>Close</button>
                    </>
                }
            >
                <div style={{ padding: '1.5rem' }}>
                    <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-3)' }}>
                        {(toolsServer?.discoveredTools || []).map((tool: any, i: number) => (
                            <div key={i} style={{ border: '1px solid var(--color-border)', borderRadius: 'var(--radius-md)', padding: 'var(--space-3)' }}>
                                <div style={{ fontWeight: 600, fontFamily: 'monospace', fontSize: 'var(--font-size-sm)' }}>{tool.name}</div>
                                {tool.description && <div style={{ color: 'var(--color-text-secondary)', fontSize: 'var(--font-size-sm)', marginTop: 'var(--space-1)' }}>{tool.description}</div>}
                            </div>
                        ))}
                        {(!toolsServer?.discoveredTools || toolsServer.discoveredTools.length === 0) && (
                            <p style={{ color: 'var(--color-text-secondary)' }}>No tools discovered. Run a connection test to refresh.</p>
                        )}
                    </div>
                </div>
            </Modal>
        </div>
    );
}
