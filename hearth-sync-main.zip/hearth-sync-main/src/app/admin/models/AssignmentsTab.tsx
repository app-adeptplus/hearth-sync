'use client';

import { useEffect, useState, useCallback } from 'react';
import Modal from '@/components/Modal';

type ServiceType = 'CHAT_BOT' | 'PRODUCT_AUTOMATION' | 'ENRICHMENT' | 'DEALER_SERVICE';
type ObjectEntity = 'PRODUCT' | 'CATEGORY' | 'ATTRIBUTE' | 'BRAND' | 'MANUFACTURER' | 'DATA_PACKAGE' | 'AUTOMATION_CONFIG' | 'AUDIT_LOG';

const SERVICE_TYPE_LABELS: Record<ServiceType, string> = {
    CHAT_BOT: 'Chat Bot',
    PRODUCT_AUTOMATION: 'Product Automation',
    ENRICHMENT: 'Enrichment',
    DEALER_SERVICE: 'Dealer Service',
};
const SERVICE_TYPE_COLORS: Record<ServiceType, string> = {
    CHAT_BOT: 'badge-primary',
    PRODUCT_AUTOMATION: 'badge-warning',
    ENRICHMENT: 'badge-success',
    DEALER_SERVICE: 'badge-info',
};
const ALL_ENTITIES: ObjectEntity[] = [
    'PRODUCT', 'CATEGORY', 'ATTRIBUTE', 'BRAND',
    'MANUFACTURER', 'DATA_PACKAGE', 'AUTOMATION_CONFIG', 'AUDIT_LOG',
];

interface Assignment {
    id: string;
    label: string;
    serviceType: ServiceType;
    serviceId: string | null;
    isActive: boolean;
    notes: string | null;
    promptTemplate: { id: string; name: string; category: string } | null;
    llmConfig: { id: string; displayName: string | null; provider: string; model: string };
    objectScopes: { entity: ObjectEntity; canRead: boolean; canWrite: boolean }[];
    mcpLinks: { mcpServer: { id: string; name: string } }[];
    createdAt: string;
}
interface LlmConfig { id: string; displayName: string | null; provider: string; model: string; }
interface PromptTemplate { id: string; name: string; category: string; }
interface McpServer { id: string; name: string; }

const emptyScopes = (): Record<ObjectEntity, { canRead: boolean; canWrite: boolean }> =>
    Object.fromEntries(ALL_ENTITIES.map(e => [e, { canRead: false, canWrite: false }])) as any;

const emptyForm = () => ({
    label: '', serviceType: 'CHAT_BOT' as ServiceType, serviceId: '',
    promptTemplateId: '', llmConfigId: '', notes: '', isActive: true,
    mcpServerIds: [] as string[],
    scopes: emptyScopes(),
});

export default function AssignmentsTab() {
    const [assignments, setAssignments] = useState<Assignment[]>([]);
    const [llmConfigs, setLlmConfigs] = useState<LlmConfig[]>([]);
    const [templates, setTemplates] = useState<PromptTemplate[]>([]);
    const [mcpServers, setMcpServers] = useState<McpServer[]>([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);

    const [showModal, setShowModal] = useState(false);
    const [editing, setEditing] = useState<Assignment | null>(null);
    const [form, setForm] = useState(emptyForm); // emptyForm is a factory fn — React calls it as lazy initializer
    const [saving, setSaving] = useState(false);
    const [modalError, setModalError] = useState<string | null>(null);

    const load = useCallback(async () => {
        setLoading(true);
        try {
            const [aRes, lRes, tRes, mRes] = await Promise.all([
                fetch('/api/assignments'),
                fetch('/api/automation/llm-settings'),
                fetch('/api/automation/prompt-templates'),
                fetch('/api/automation/mcp-servers'),
            ]);
            const [a, l, t, m] = await Promise.all([aRes.json(), lRes.json(), tRes.json(), mRes.json()]);
            setAssignments(Array.isArray(a) ? a : []);
            setLlmConfigs(Array.isArray(l) ? l : []);
            setTemplates(Array.isArray(t) ? t : []);
            setMcpServers(Array.isArray(m) ? m : []);
        } catch (e: any) { setError(e.message); }
        finally { setLoading(false); }
    }, []);

    useEffect(() => { load(); }, [load]);

    function openAdd() {
        setEditing(null);
        setForm(emptyForm());
        setModalError(null);
        setShowModal(true);
    }

    function openEdit(a: Assignment) {
        setEditing(a);
        const scopes = emptyScopes();
        a.objectScopes.forEach(s => { scopes[s.entity] = { canRead: s.canRead, canWrite: s.canWrite }; });
        setForm({
            label: a.label,
            serviceType: a.serviceType,
            serviceId: a.serviceId ?? '',
            promptTemplateId: a.promptTemplate?.id ?? '',
            llmConfigId: a.llmConfig.id,
            notes: a.notes ?? '',
            isActive: a.isActive,
            mcpServerIds: a.mcpLinks.map(l => l.mcpServer.id),
            scopes,
        });
        setModalError(null);
        setShowModal(true);
    }

    async function save() {
        setSaving(true);
        setModalError(null);
        try {
            const body = {
                label: form.label,
                serviceType: form.serviceType,
                serviceId: form.serviceId || null,
                promptTemplateId: form.promptTemplateId || null,
                llmConfigId: form.llmConfigId,
                notes: form.notes || null,
                isActive: form.isActive,
                mcpServerIds: form.mcpServerIds,
                objectScopes: ALL_ENTITIES
                    .filter(e => form.scopes[e].canRead || form.scopes[e].canWrite)
                    .map(e => ({ entity: e, ...form.scopes[e] })),
            };

            const url = editing ? `/api/assignments/${editing.id}` : '/api/assignments';
            const method = editing ? 'PATCH' : 'POST';
            const res = await fetch(url, { method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
            if (!res.ok) { const d = await res.json(); throw new Error(d.error || `Server error ${res.status}`); }
            setShowModal(false);
            load();
        } catch (e: any) { setModalError(e.message); }
        finally { setSaving(false); }
    }

    async function del(id: string) {
        if (!confirm('Delete this assignment? Services using it will fall back to the type-level default.')) return;
        await fetch(`/api/assignments/${id}`, { method: 'DELETE' });
        load();
    }

    function toggleScope(entity: ObjectEntity, field: 'canRead' | 'canWrite') {
        setForm(f => ({
            ...f,
            scopes: { ...f.scopes, [entity]: { ...f.scopes[entity], [field]: !f.scopes[entity][field] } },
        }));
    }

    if (loading) return <div className="loading-state">Loading assignments…</div>;

    // Group by service type for display
    const grouped = assignments.reduce((acc, a) => {
        if (!acc[a.serviceType]) acc[a.serviceType] = [];
        acc[a.serviceType].push(a);
        return acc;
    }, {} as Record<ServiceType, Assignment[]>);

    return (
        <div>
            {error && <div className="alert alert-error" style={{ marginBottom: 'var(--space-4)' }}>{error}</div>}

            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 'var(--space-4)' }}>
                <div>
                    <h2 style={{ margin: 0, fontSize: 'var(--font-size-lg)' }}>Prompt Assignments</h2>
                    <p style={{ margin: 0, color: 'var(--color-text-secondary)', fontSize: 'var(--font-size-sm)' }}>
                        Bind a Prompt Template + API Connection + MCP Tools + Object Access to each service slot
                    </p>
                </div>
                <button className="btn btn-primary" onClick={openAdd}>+ New Assignment</button>
            </div>

            <div className="alert alert-info" style={{ marginBottom: 'var(--space-4)', fontSize: 'var(--font-size-sm)' }}>
                <strong>Resolution order:</strong> a specific <code>serviceId</code> assignment wins over a type-level default (<code>serviceId = null</code>). If neither exists, the service falls back to inline instructions + the default LLM provider.
            </div>

            {assignments.length === 0 ? (
                <div className="empty-state">
                    <p>No assignments yet. Create your first assignment to wire a prompt, provider, and access scopes to a service slot.</p>
                </div>
            ) : (
                (Object.keys(SERVICE_TYPE_LABELS) as ServiceType[]).map(st => {
                    const group = grouped[st];
                    if (!group?.length) return null;
                    return (
                        <div key={st} style={{ marginBottom: 'var(--space-6)' }}>
                            <h3 style={{ fontSize: 'var(--font-size-base)', fontWeight: 600, marginBottom: 'var(--space-2)', color: 'var(--color-text-secondary)' }}>
                                {SERVICE_TYPE_LABELS[st]}
                            </h3>
                            <div className="data-table-wrapper">
                                <table className="data-table">
                                    <thead>
                                        <tr>
                                            <th>Label</th>
                                            <th>Service ID</th>
                                            <th>Status</th>
                                            <th>Prompt Template</th>
                                            <th>LLM Provider</th>
                                            <th>Object Access</th>
                                            <th>MCP Servers</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {group.map(a => (
                                            <tr key={a.id}>
                                                <td style={{ fontWeight: 500 }}>{a.label}</td>
                                                <td>
                                                    {a.serviceId
                                                        ? <code style={{ fontSize: '11px' }}>{a.serviceId}</code>
                                                        : <span style={{ color: 'var(--color-text-muted)', fontSize: 'var(--font-size-xs)' }}>type default</span>}
                                                </td>
                                                <td>
                                                    <span className={`badge ${a.isActive ? 'badge-success' : 'badge-default'}`}>
                                                        {a.isActive ? 'Active' : 'Inactive'}
                                                    </span>
                                                </td>
                                                <td>
                                                    {a.promptTemplate
                                                        ? <span>{a.promptTemplate.name}</span>
                                                        : <span style={{ color: 'var(--color-text-muted)', fontSize: 'var(--font-size-xs)' }}>Inline only</span>}
                                                </td>
                                                <td>
                                                    <div style={{ fontWeight: 500, fontSize: 'var(--font-size-sm)' }}>
                                                        {a.llmConfig.displayName || a.llmConfig.provider}
                                                    </div>
                                                    <div style={{ color: 'var(--color-text-muted)', fontSize: '11px' }}>{a.llmConfig.model}</div>
                                                </td>
                                                <td>
                                                    <div style={{ display: 'flex', gap: 'var(--space-1)', flexWrap: 'wrap' }}>
                                                        {a.objectScopes.filter(s => s.canRead || s.canWrite).map(s => (
                                                            <span key={s.entity} className="badge badge-default" style={{ fontSize: '10px' }} title={`R:${s.canRead} W:${s.canWrite}`}>
                                                                {s.entity.toLowerCase().replace('_', ' ')}
                                                                {s.canWrite ? ' ✎' : ' 👁'}
                                                            </span>
                                                        ))}
                                                        {a.objectScopes.length === 0 && <span style={{ color: 'var(--color-text-muted)', fontSize: '11px' }}>None</span>}
                                                    </div>
                                                </td>
                                                <td>
                                                    {a.mcpLinks.length > 0
                                                        ? a.mcpLinks.map(l => <span key={l.mcpServer.id} className="badge badge-default" style={{ fontSize: '11px', marginRight: 2 }}>{l.mcpServer.name}</span>)
                                                        : <span style={{ color: 'var(--color-text-muted)', fontSize: '11px' }}>None</span>}
                                                </td>
                                                <td>
                                                    <div style={{ display: 'flex', gap: 'var(--space-2)' }}>
                                                        <button className="btn btn-sm btn-ghost" onClick={() => openEdit(a)}>Edit</button>
                                                        <button className="btn btn-sm btn-ghost btn-danger" onClick={() => del(a.id)}>Delete</button>
                                                    </div>
                                                </td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    );
                })
            )}

            {/* ── Add/Edit Modal ── */}
            <Modal
                isOpen={showModal}
                onClose={() => setShowModal(false)}
                title={editing ? 'Edit Assignment' : 'New Prompt Assignment'}
                subtitle="Bind a prompt, provider, MCP tools, and object access scopes to a service slot."
                size="lg"
                footer={
                    <>
                        {modalError && (
                            <span style={{ color: 'var(--color-error)', fontSize: 'var(--font-size-sm)', flex: 1, textAlign: 'left' }}>
                                ⚠ {modalError}
                            </span>
                        )}
                        <button className="btn btn-ghost" onClick={() => setShowModal(false)}>Cancel</button>
                        <button className="btn btn-primary" onClick={save} disabled={saving || !form.label || !form.llmConfigId}>
                            {saving ? 'Saving…' : editing ? 'Save Changes' : 'Create Assignment'}
                        </button>
                    </>
                }
            >
                <div style={{ padding: '1.5rem', display: 'flex', flexDirection: 'column', gap: 'var(--space-4)' }}>
                    {/* Row 1: Label + Service Type + Status */}
                    <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr 1fr', gap: 'var(--space-3)' }}>
                        <div className="form-group">
                            <label className="form-label">Label</label>
                            <input className="form-input" placeholder='e.g. "Categorization Bot"'
                                value={form.label} onChange={e => setForm(f => ({ ...f, label: e.target.value }))} />
                        </div>
                        <div className="form-group">
                            <label className="form-label">Service Type</label>
                            <select className="form-select" value={form.serviceType}
                                onChange={e => setForm(f => ({ ...f, serviceType: e.target.value as ServiceType }))}>
                                {(Object.keys(SERVICE_TYPE_LABELS) as ServiceType[]).map(st => (
                                    <option key={st} value={st}>{SERVICE_TYPE_LABELS[st]}</option>
                                ))}
                            </select>
                        </div>
                        <div className="form-group">
                            <label className="form-label">Status</label>
                            <select className="form-select" value={form.isActive ? 'active' : 'inactive'}
                                onChange={e => setForm(f => ({ ...f, isActive: e.target.value === 'active' }))}>
                                <option value="active">Active</option>
                                <option value="inactive">Inactive</option>
                            </select>
                        </div>
                    </div>

                    {/* Row 2: Service ID */}
                    <div className="form-group">
                        <label className="form-label">Service ID <span style={{ fontWeight: 400, color: 'var(--color-text-muted)' }}>(optional — leave blank for type-level default)</span></label>
                        <input className="form-input" placeholder='e.g. "categorization", "spec_extractor", or an automationConfig.id'
                            value={form.serviceId} onChange={e => setForm(f => ({ ...f, serviceId: e.target.value }))} />
                        <span className="form-hint">Leave blank to make this the fallback for all {SERVICE_TYPE_LABELS[form.serviceType]} services.</span>
                    </div>

                    {/* Row 3: LLM Provider + Prompt Template */}
                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 'var(--space-3)' }}>
                        <div className="form-group">
                            <label className="form-label">LLM Provider <span style={{ color: 'var(--color-error)' }}>*</span></label>
                            <select className="form-select" value={form.llmConfigId}
                                onChange={e => setForm(f => ({ ...f, llmConfigId: e.target.value }))}>
                                <option value="">— Select provider —</option>
                                {llmConfigs.map(c => (
                                    <option key={c.id} value={c.id}>{c.displayName || c.provider} — {c.model}</option>
                                ))}
                            </select>
                        </div>
                        <div className="form-group">
                            <label className="form-label">Prompt Template <span style={{ fontWeight: 400, color: 'var(--color-text-muted)' }}>(optional)</span></label>
                            <select className="form-select" value={form.promptTemplateId}
                                onChange={e => setForm(f => ({ ...f, promptTemplateId: e.target.value }))}>
                                <option value="">— None (inline only) —</option>
                                {templates.map(t => (
                                    <option key={t.id} value={t.id}>{t.name} ({t.category.replace(/_/g, ' ')})</option>
                                ))}
                            </select>
                        </div>
                    </div>

                    {/* MCP Servers */}
                    {mcpServers.length > 0 && (
                        <div className="form-group">
                            <label className="form-label">Allowed MCP Servers</label>
                            <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-1)' }}>
                                {mcpServers.map(m => (
                                    <label key={m.id} style={{ display: 'flex', alignItems: 'center', gap: 'var(--space-2)', cursor: 'pointer', fontSize: 'var(--font-size-sm)' }}>
                                        <input type="checkbox"
                                            checked={form.mcpServerIds.includes(m.id)}
                                            onChange={e => setForm(f => ({
                                                ...f,
                                                mcpServerIds: e.target.checked
                                                    ? [...f.mcpServerIds, m.id]
                                                    : f.mcpServerIds.filter(id => id !== m.id),
                                            }))} />
                                        {m.name}
                                    </label>
                                ))}
                            </div>
                        </div>
                    )}

                    {/* Object Access Scopes */}
                    <div className="form-group">
                        <label className="form-label">Object Access Scopes</label>
                        <div style={{
                            border: '1px solid var(--color-border)', borderRadius: 'var(--radius-md)',
                            overflow: 'hidden',
                        }}>
                            <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                                <thead>
                                    <tr style={{ background: 'var(--color-surface-raised)', fontSize: 'var(--font-size-xs)', fontWeight: 600 }}>
                                        <th style={{ padding: '8px 12px', textAlign: 'left' }}>Entity</th>
                                        <th style={{ padding: '8px 12px', textAlign: 'center' }}>Read 👁</th>
                                        <th style={{ padding: '8px 12px', textAlign: 'center' }}>Write ✎</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {ALL_ENTITIES.map((entity, i) => (
                                        <tr key={entity} style={{ borderTop: i > 0 ? '1px solid var(--color-border)' : 'none' }}>
                                            <td style={{ padding: '8px 12px', fontSize: 'var(--font-size-sm)', fontWeight: 500, textTransform: 'capitalize' }}>
                                                {entity.toLowerCase().replace(/_/g, ' ')}
                                            </td>
                                            <td style={{ padding: '8px 12px', textAlign: 'center' }}>
                                                <input type="checkbox"
                                                    checked={form.scopes[entity].canRead}
                                                    onChange={() => toggleScope(entity, 'canRead')} />
                                            </td>
                                            <td style={{ padding: '8px 12px', textAlign: 'center' }}>
                                                <input type="checkbox"
                                                    checked={form.scopes[entity].canWrite}
                                                    onChange={() => toggleScope(entity, 'canWrite')} />
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                        <span className="form-hint">Only scopes with at least one box checked are saved. Unscoped entities are blocked by default.</span>
                    </div>

                    {/* Notes */}
                    <div className="form-group">
                        <label className="form-label">Notes <span style={{ fontWeight: 400, color: 'var(--color-text-muted)' }}>(optional)</span></label>
                        <input className="form-input" placeholder="What does this assignment do?"
                            value={form.notes} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))} />
                    </div>
                </div>
            </Modal>
        </div>
    );
}
