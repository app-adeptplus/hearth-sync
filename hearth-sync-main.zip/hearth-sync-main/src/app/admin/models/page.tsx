'use client';

import { useState } from 'react';
import APIConnectionsTab from './APIConnectionsTab';
import PromptTemplatesTab from './PromptTemplatesTab';
import MCPServersTab from './MCPServersTab';
import SystemSettingsTab from './SystemSettingsTab';
import AssignmentsTab from './AssignmentsTab';

const TABS = [
    { id: 'connections', label: 'API Connections', icon: '🔌' },
    { id: 'prompts', label: 'Prompt Templates', icon: '📝' },
    { id: 'mcp', label: 'MCP Servers', icon: '🔗' },
    { id: 'assignments', label: 'Assignments', icon: '🎯' },
    { id: 'settings', label: 'System Settings', icon: '⚙️' },
] as const;

type TabId = typeof TABS[number]['id'];

export default function ModelsPage() {
    const [activeTab, setActiveTab] = useState<TabId>('connections');

    return (
        <div>
            <div className="page-header">
                <div>
                    <h1>Models &amp; AI</h1>
                    <p className="page-subtitle">
                        Configure AI providers, prompt templates, MCP servers, and system settings
                    </p>
                </div>
            </div>

            {/* Tab navigation */}
            <div style={{ display: 'flex', gap: 'var(--space-2)', marginBottom: 'var(--space-6)' }}>
                {TABS.map(tab => (
                    <button
                        key={tab.id}
                        className={`btn ${activeTab === tab.id ? 'btn-primary' : 'btn-ghost'}`}
                        onClick={() => setActiveTab(tab.id)}
                    >
                        <span>{tab.icon}</span>
                        {tab.label}
                    </button>
                ))}
            </div>

            {/* Tab content */}
            {activeTab === 'connections' && <APIConnectionsTab />}
            {activeTab === 'prompts' && <PromptTemplatesTab />}
            {activeTab === 'mcp' && <MCPServersTab />}
            {activeTab === 'assignments' && <AssignmentsTab />}
            {activeTab === 'settings' && <SystemSettingsTab />}
        </div>
    );
}
