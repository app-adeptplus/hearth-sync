'use client';

import { useEffect, useState, useCallback } from 'react';
import Modal from '@/components/Modal';

type PromptCategory = 'SITE_SCRAPER' | 'API_AUTOMATION' | 'ENRICHMENT' | 'CATEGORIZATION' | 'GENERAL';

interface PromptTemplate {
    id: string;
    name: string;
    category: PromptCategory;
    systemPrompt: string;
    variables: any;
    tags: string[];
    version: number;
    isActive: boolean;
    updatedAt: string;
    _count?: { automationConfigs: number; versions: number };
}

interface PromptVersion {
    id: string;
    version: number;
    systemPrompt: string;
    changeNote: string | null;
    createdAt: string;
}

const CATEGORY_LABELS: Record<PromptCategory, string> = {
    SITE_SCRAPER: 'Site Scraper',
    API_AUTOMATION: 'API Automation',
    ENRICHMENT: 'Enrichment',
    CATEGORIZATION: 'Categorization',
    GENERAL: 'General',
};

const CATEGORY_COLORS: Record<PromptCategory, string> = {
    SITE_SCRAPER: 'badge-primary',
    API_AUTOMATION: 'badge-warning',
    ENRICHMENT: 'badge-success',
    CATEGORIZATION: 'badge-info',
    GENERAL: 'badge-default',
};

const emptyForm = {
    name: '', category: 'SITE_SCRAPER' as PromptCategory,
    systemPrompt: '', tags: '', changeNote: '', isActive: true,
};

const SAMPLE_VARS = {
    brand_name: 'Napoleon', brand_website: 'https://napoleon.com',
    product_type: 'Gas Fireplaces', category_context: 'High-efficiency hearth products',
    extraction_fields: 'BTU input, venting type, efficiency rating', custom_instructions: '',
};

export default function PromptTemplatesTab() {
    const [templates, setTemplates] = useState<PromptTemplate[]>([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);

    const [showEditor, setShowEditor] = useState(false);
    const [editingTemplate, setEditingTemplate] = useState<PromptTemplate | null>(null);
    const [form, setForm] = useState(emptyForm);
    const [saving, setSaving] = useState(false);

    const [showVersions, setShowVersions] = useState(false);
    const [versions, setVersions] = useState<PromptVersion[]>([]);
    const [versionsTemplateId, setVersionsTemplateId] = useState<string | null>(null);

    const [previewMode, setPreviewMode] = useState(false);
    const [previewOutput, setPreviewOutput] = useState('');

    const loadTemplates = useCallback(async () => {
        setLoading(true);
        try {
            const res = await fetch('/api/automation/prompt-templates');
            const data = await res.json();
            setTemplates(Array.isArray(data) ? data : []);
            if (!Array.isArray(data) && data?.error) setError(data.error);
        } catch (e: any) {
            setError(e.message);
        } finally {
            setLoading(false);
        }
    }, []);

    useEffect(() => { loadTemplates(); }, [loadTemplates]);

    function openAdd() {
        setEditingTemplate(null);
        setForm(emptyForm);
        setPreviewMode(false);
        setPreviewOutput('');
        setShowEditor(true);
    }

    function openEdit(t: PromptTemplate) {
        setEditingTemplate(t);
        setForm({
            name: t.name, category: t.category,
            systemPrompt: t.systemPrompt,
            tags: t.tags.join(', '),
            changeNote: '',
            isActive: t.isActive,
        });
        setPreviewMode(false);
        setPreviewOutput('');
        setShowEditor(true);
    }

    async function save() {
        setSaving(true);
        try {
            const body = {
                ...form,
                tags: form.tags.split(',').map(t => t.trim()).filter(Boolean),
            };
            if (editingTemplate) {
                await fetch(`/api/automation/prompt-templates/${editingTemplate.id}`, {
                    method: 'PATCH', headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(body),
                });
            } else {
                await fetch('/api/automation/prompt-templates', {
                    method: 'POST', headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(body),
                });
            }
            setShowEditor(false);
            loadTemplates();
        } catch (e: any) {
            setError(e.message);
        } finally {
            setSaving(false);
        }
    }

    async function archive(id: string) {
        if (!confirm('Archive this prompt template? It will no longer appear in selectors.')) return;
        await fetch(`/api/automation/prompt-templates/${id}`, { method: 'DELETE' });
        loadTemplates();
    }

    async function duplicate(t: PromptTemplate) {
        await fetch('/api/automation/prompt-templates', {
            method: 'POST', headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                name: `${t.name} (copy)`,
                category: t.category,
                systemPrompt: t.systemPrompt,
                tags: t.tags,
            }),
        });
        loadTemplates();
    }

    async function openVersions(t: PromptTemplate) {
        setVersionsTemplateId(t.id);
        const res = await fetch(`/api/automation/prompt-templates/${t.id}/versions`);
        setVersions(await res.json());
        setShowVersions(true);
    }

    async function revertToVersion(templateId: string, versionId: string) {
        if (!confirm('Revert to this version? The current version will be saved automatically.')) return;
        await fetch(`/api/automation/prompt-templates/${templateId}/revert/${versionId}`, { method: 'POST' });
        setShowVersions(false);
        loadTemplates();
    }

    function renderPreview() {
        let output = form.systemPrompt;
        Object.entries(SAMPLE_VARS).forEach(([key, val]) => {
            output = output.replace(new RegExp(`{{${key}}}`, 'g'), val);
            output = output.replace(
                new RegExp(`{{#if ${key}}}([\\s\\S]*?){{/if}}`, 'g'),
                val ? '$1' : ''
            );
        });
        output = output.replace(/{{#if [^}]+}}[\s\S]*?{{\/if}}/g, '');
        setPreviewOutput(output);
        setPreviewMode(true);
    }

    const tokenEstimate = Math.ceil(form.systemPrompt.length / 4);

    if (loading) return <div className="loading-state">Loading prompt templates…</div>;

    return (
        <div>
            {error && <div className="alert alert-error">{error}</div>}

            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 'var(--space-4)' }}>
                <div>
                    <h2 style={{ margin: 0, fontSize: 'var(--font-size-lg)' }}>Prompt Templates</h2>
                    <p style={{ margin: 0, color: 'var(--color-text-secondary)', fontSize: 'var(--font-size-sm)' }}>
                        Reusable Handlebars system prompts with variable injection and version history
                    </p>
                </div>
                <button className="btn btn-primary" onClick={openAdd}>+ New Template</button>
            </div>

            {templates.length === 0 ? (
                <div className="empty-state">
                    <p>No prompt templates yet. Create a template to share prompts across automation configs.</p>
                </div>
            ) : (
                <div className="data-table-wrapper">
                    <table className="data-table">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Category</th>
                                <th>Version</th>
                                <th>Status</th>
                                <th>Linked Configs</th>
                                <th>Tags</th>
                                <th>Last Modified</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            {templates.map(t => (
                                <tr key={t.id}>
                                    <td style={{ fontWeight: 500 }}>{t.name}</td>
                                    <td>
                                        <span className={`badge ${CATEGORY_COLORS[t.category]}`}>
                                            {CATEGORY_LABELS[t.category]}
                                        </span>
                                    </td>
                                    <td>v{t.version}</td>
                                    <td>
                                        <span className={`badge ${t.isActive ? 'badge-success' : 'badge-default'}`}>
                                            {t.isActive ? 'Active' : 'Archived'}
                                        </span>
                                    </td>
                                    <td>{t._count?.automationConfigs ?? 0}</td>
                                    <td>
                                        <div style={{ display: 'flex', gap: 'var(--space-1)', flexWrap: 'wrap' }}>
                                            {t.tags.map(tag => (
                                                <span key={tag} className="badge badge-default" style={{ fontSize: '11px' }}>{tag}</span>
                                            ))}
                                        </div>
                                    </td>
                                    <td style={{ color: 'var(--color-text-secondary)', fontSize: 'var(--font-size-sm)' }}>
                                        {new Date(t.updatedAt).toLocaleDateString()}
                                    </td>
                                    <td>
                                        <div style={{ display: 'flex', gap: 'var(--space-2)' }}>
                                            <button className="btn btn-sm btn-ghost" onClick={() => openEdit(t)}>Edit</button>
                                            <button className="btn btn-sm btn-ghost" onClick={() => duplicate(t)}>Duplicate</button>
                                            <button className="btn btn-sm btn-ghost" onClick={() => openVersions(t)}>History</button>
                                            <button className="btn btn-sm btn-ghost btn-danger" onClick={() => archive(t.id)}>Archive</button>
                                        </div>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            )}

            {/* ── Template Editor Modal ── */}
            <Modal
                isOpen={showEditor}
                onClose={() => setShowEditor(false)}
                title={editingTemplate ? 'Edit Template' : 'New Prompt Template'}
                subtitle="Handlebars system prompt with variable injection and automatic version tracking."
                size="lg"
                footer={
                    <>
                        <button className="btn btn-ghost" onClick={() => setShowEditor(false)}>Cancel</button>
                        <button className="btn btn-primary" onClick={save} disabled={saving}>
                            {saving ? 'Saving…' : editingTemplate ? 'Save Changes' : 'Create Template'}
                        </button>
                    </>
                }
            >
                <div style={{ padding: '1.5rem', display: 'flex', flexDirection: 'column', gap: 'var(--space-4)' }}>
                    <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr 1fr', gap: 'var(--space-3)' }}>
                        <div className="form-group">
                            <label className="form-label">Template Name</label>
                            <input className="form-input" placeholder='e.g. "Hearth Product Scraper"'
                                value={form.name}
                                onChange={e => setForm(f => ({ ...f, name: e.target.value }))} />
                        </div>
                        <div className="form-group">
                            <label className="form-label">Category</label>
                            <select className="form-select" value={form.category}
                                onChange={e => setForm(f => ({ ...f, category: e.target.value as PromptCategory }))}>
                                {Object.entries(CATEGORY_LABELS).map(([k, v]) => (
                                    <option key={k} value={k}>{v}</option>
                                ))}
                            </select>
                        </div>
                        <div className="form-group">
                            <label className="form-label">Status</label>
                            <select className="form-select" value={form.isActive ? 'active' : 'inactive'}
                                onChange={e => setForm(f => ({ ...f, isActive: e.target.value === 'active' }))}>
                                <option value="active">Active</option>
                                <option value="inactive">Archived</option>
                            </select>
                        </div>
                    </div>

                    <div className="form-group">
                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 'var(--space-2)' }}>
                            <label className="form-label" style={{ margin: 0 }}>System Prompt (Handlebars)</label>
                            <div style={{ display: 'flex', gap: 'var(--space-2)', alignItems: 'center' }}>
                                <span style={{ fontSize: 'var(--font-size-xs)', color: 'var(--color-text-muted)' }}>
                                    ~{tokenEstimate} tokens
                                </span>
                                <button className="btn btn-sm btn-ghost" onClick={renderPreview}>Preview</button>
                                {previewMode && <button className="btn btn-sm btn-ghost" onClick={() => setPreviewMode(false)}>Edit</button>}
                            </div>
                        </div>
                        {previewMode ? (
                            <div style={{
                                fontFamily: 'monospace', fontSize: 'var(--font-size-sm)',
                                background: 'var(--color-surface-raised)', padding: 'var(--space-3)',
                                borderRadius: 'var(--radius-md)', whiteSpace: 'pre-wrap', minHeight: '240px',
                                border: '1px solid var(--color-border)',
                            }}>
                                {previewOutput}
                            </div>
                        ) : (
                            <textarea
                                className="form-input"
                                style={{ fontFamily: 'monospace', fontSize: 'var(--font-size-sm)', minHeight: '240px', resize: 'vertical' }}
                                placeholder={`You are a product extraction assistant for {{brand_name}}...\n\n{{#if product_type}}\nFocus on: {{product_type}}\n{{/if}}`}
                                value={form.systemPrompt}
                                onChange={e => setForm(f => ({ ...f, systemPrompt: e.target.value }))}
                            />
                        )}
                        <span className="form-hint">
                            Available variables: <code>{'{{brand_name}}'}</code> <code>{'{{brand_website}}'}</code> <code>{'{{product_type}}'}</code> <code>{'{{category_context}}'}</code> <code>{'{{extraction_fields}}'}</code> <code>{'{{custom_instructions}}'}</code>
                        </span>
                    </div>

                    <div className="form-group">
                        <label className="form-label">Tags (comma-separated)</label>
                        <input className="form-input" placeholder="hearth, grill, outdoor, firecrawl"
                            value={form.tags}
                            onChange={e => setForm(f => ({ ...f, tags: e.target.value }))} />
                    </div>

                    {editingTemplate && (
                        <div className="form-group">
                            <label className="form-label">Change Note (optional)</label>
                            <input className="form-input" placeholder="What did you change and why?"
                                value={form.changeNote}
                                onChange={e => setForm(f => ({ ...f, changeNote: e.target.value }))} />
                        </div>
                    )}
                </div>
            </Modal>

            {/* ── Version History Modal ── */}
            <Modal
                isOpen={showVersions && !!versionsTemplateId}
                onClose={() => setShowVersions(false)}
                title="Version History"
                subtitle="Revert to a previous version. The current version is always saved automatically."
                size="md"
                footer={
                    <button className="btn btn-ghost" onClick={() => setShowVersions(false)}>Close</button>
                }
            >
                <div style={{ padding: '1.5rem' }}>
                    {versions.length === 0 ? (
                        <p style={{ color: 'var(--color-text-secondary)' }}>No saved versions yet. Versions are created automatically when you save edits.</p>
                    ) : (
                        <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-3)' }}>
                            {versions.map(v => (
                                <div key={v.id} style={{
                                    border: '1px solid var(--color-border)', borderRadius: 'var(--radius-md)',
                                    padding: 'var(--space-3)',
                                }}>
                                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                                        <div>
                                            <span style={{ fontWeight: 600 }}>v{v.version}</span>
                                            {v.changeNote && <span style={{ marginLeft: 'var(--space-2)', color: 'var(--color-text-secondary)', fontSize: 'var(--font-size-sm)' }}> — {v.changeNote}</span>}
                                            <div style={{ color: 'var(--color-text-muted)', fontSize: 'var(--font-size-xs)', marginTop: 'var(--space-1)' }}>
                                                {new Date(v.createdAt).toLocaleString()}
                                            </div>
                                        </div>
                                        <button className="btn btn-sm btn-ghost"
                                            onClick={() => revertToVersion(versionsTemplateId!, v.id)}>
                                            Revert to this
                                        </button>
                                    </div>
                                    <pre style={{
                                        marginTop: 'var(--space-2)', fontSize: '11px', fontFamily: 'monospace',
                                        background: 'var(--color-surface-raised)', padding: 'var(--space-2)',
                                        borderRadius: 'var(--radius-sm)', overflow: 'auto', maxHeight: '120px',
                                        whiteSpace: 'pre-wrap', color: 'var(--color-text-secondary)',
                                    }}>
                                        {v.systemPrompt.slice(0, 300)}{v.systemPrompt.length > 300 ? '…' : ''}
                                    </pre>
                                </div>
                            ))}
                        </div>
                    )}
                </div>
            </Modal>
        </div>
    );
}
