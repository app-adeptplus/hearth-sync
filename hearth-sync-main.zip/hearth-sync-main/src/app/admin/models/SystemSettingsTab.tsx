'use client';

import { useEffect, useState, useCallback } from 'react';

interface LlmConfig {
    id: string;
    displayName: string | null;
    provider: string;
    model: string;
    isDefault: boolean;
    isActive: boolean;
}

interface SystemSettingsData {
    defaultProvider: LlmConfig | null;
    allProviders: LlmConfig[];
    encryptionConfigured: boolean;
    envVarsDetected: Record<string, boolean>;
}

const ENV_VAR_LABELS: Record<string, string> = {
    OPENAI_API_KEY: 'OpenAI',
    ANTHROPIC_API_KEY: 'Anthropic',
    GOOGLE_GEMINI_API_KEY: 'Google Gemini',
    FIRECRAWL_API_KEY: 'Firecrawl',
    ENCRYPTION_SECRET: 'Encryption Key',
};

export default function SystemSettingsTab() {
    const [data, setData] = useState<SystemSettingsData | null>(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);

    // Rate limit buffer settings (stored in local state — future: save to a system settings table)
    const [softLimitPct, setSoftLimitPct] = useState(90);
    const [monthlyTokenBudgets, setMonthlyTokenBudgets] = useState<Record<string, string>>({});

    // Firecrawl defaults
    const [crawlMode, setCrawlMode] = useState('scrape');
    const [crawlFormats, setCrawlFormats] = useState({ markdown: true, html: false, screenshot: false });

    const [settingDefault, setSettingDefault] = useState<string | null>(null);

    const loadData = useCallback(async () => {
        setLoading(true);
        try {
            const res = await fetch('/api/automation/llm-settings');
            const providers: LlmConfig[] = await res.json();
            setData({
                defaultProvider: providers.find(p => p.isDefault) || null,
                allProviders: providers,
                encryptionConfigured: true, // We always set it now
                envVarsDetected: {
                    OPENAI_API_KEY: false,
                    ANTHROPIC_API_KEY: false,
                    GOOGLE_GEMINI_API_KEY: false,
                    FIRECRAWL_API_KEY: false,
                    ENCRYPTION_SECRET: true, // We set this
                },
            });
        } catch (e: any) {
            setError(e.message);
        } finally {
            setLoading(false);
        }
    }, []);

    useEffect(() => { loadData(); }, [loadData]);

    async function setAsDefault(id: string) {
        setSettingDefault(id);
        try {
            await fetch(`/api/automation/llm-settings/${id}`, {
                method: 'PATCH', headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ isDefault: true }),
            });
            loadData();
        } finally {
            setSettingDefault(null);
        }
    }

    if (loading) return <div className="loading-state">Loading system settings…</div>;
    if (!data) return null;

    const usageExamplePct = 73; // placeholder display

    return (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-8)' }}>
            {error && <div className="alert alert-error">{error}</div>}

            {/* ── Default Provider ── */}
            <section>
                <h2 style={{ fontSize: 'var(--font-size-lg)', marginBottom: 'var(--space-1)' }}>Default AI Provider</h2>
                <p style={{ color: 'var(--color-text-secondary)', fontSize: 'var(--font-size-sm)', marginBottom: 'var(--space-4)' }}>
                    The default provider is used for all automation runs unless a per-config override is set.
                </p>

                {data.defaultProvider ? (
                    <div className="card" style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: 'var(--space-4)' }}>
                        <div>
                            <div style={{ fontWeight: 600 }}>{data.defaultProvider.displayName || data.defaultProvider.provider}</div>
                            <div style={{ color: 'var(--color-text-secondary)', fontSize: 'var(--font-size-sm)' }}>
                                {data.defaultProvider.provider} — <code style={{ fontSize: '12px' }}>{data.defaultProvider.model}</code>
                            </div>
                        </div>
                        <span className="badge badge-primary">Default</span>
                    </div>
                ) : (
                    <div className="alert alert-warning">No default provider set. Go to API Connections → Set Default on a provider.</div>
                )}

                {data.allProviders.length > 1 && (
                    <div style={{ marginTop: 'var(--space-3)' }}>
                        <p style={{ fontSize: 'var(--font-size-sm)', color: 'var(--color-text-secondary)', marginBottom: 'var(--space-2)' }}>Change default:</p>
                        <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-2)' }}>
                            {data.allProviders.filter(p => !p.isDefault && p.isActive).map(p => (
                                <div key={p.id} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: 'var(--space-3)', border: '1px solid var(--color-border)', borderRadius: 'var(--radius-md)' }}>
                                    <div>
                                        <span style={{ fontWeight: 500 }}>{p.displayName || p.provider}</span>
                                        <span style={{ color: 'var(--color-text-muted)', fontSize: 'var(--font-size-xs)', marginLeft: 'var(--space-2)' }}>{p.model}</span>
                                    </div>
                                    <button className="btn btn-sm btn-ghost" disabled={settingDefault === p.id}
                                        onClick={() => setAsDefault(p.id)}>
                                        {settingDefault === p.id ? '…' : 'Set as Default'}
                                    </button>
                                </div>
                            ))}
                        </div>
                    </div>
                )}
            </section>

            {/* ── Rate Limit Buffer ── */}
            <section>
                <h2 style={{ fontSize: 'var(--font-size-lg)', marginBottom: 'var(--space-1)' }}>Rate Limit Buffer</h2>
                <p style={{ color: 'var(--color-text-secondary)', fontSize: 'var(--font-size-sm)', marginBottom: 'var(--space-4)' }}>
                    The app issues a warning when usage reaches the soft limit. Automation continues until the provider returns a hard 429 error.
                </p>

                <div className="card" style={{ padding: 'var(--space-4)', display: 'flex', flexDirection: 'column', gap: 'var(--space-4)' }}>
                    <div>
                        <label className="form-label">Warning Threshold: <strong>{softLimitPct}%</strong></label>
                        <input type="range" min="50" max="99" step="5" value={softLimitPct}
                            style={{ width: '100%', marginTop: 'var(--space-2)' }}
                            onChange={e => setSoftLimitPct(parseInt(e.target.value))} />
                        <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 'var(--font-size-xs)', color: 'var(--color-text-muted)' }}>
                            <span>50% (early warning)</span><span>99% (near limit)</span>
                        </div>
                    </div>

                    <div>
                        <label className="form-label" style={{ marginBottom: 'var(--space-2)', display: 'block' }}>
                            Monthly Token Budgets (per provider)
                        </label>
                        {data.allProviders.map(p => (
                            <div key={p.id} style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 'var(--space-3)', alignItems: 'center', marginBottom: 'var(--space-2)' }}>
                                <span style={{ fontSize: 'var(--font-size-sm)' }}>{p.displayName || p.provider}</span>
                                <input className="form-input"
                                    type="number" placeholder="e.g. 5000000" min="0"
                                    value={monthlyTokenBudgets[p.id] || ''}
                                    onChange={e => setMonthlyTokenBudgets(b => ({ ...b, [p.id]: e.target.value }))} />
                                <div style={{ width: '100%', background: 'var(--color-border)', borderRadius: '999px', height: '8px', overflow: 'hidden' }}>
                                    <div style={{
                                        height: '100%', borderRadius: '999px',
                                        background: usageExamplePct >= softLimitPct ? 'var(--color-error)' : usageExamplePct >= 75 ? 'var(--color-warning)' : 'var(--color-success)',
                                        width: `${usageExamplePct}%`, transition: 'width 0.3s ease',
                                    }} />
                                </div>
                            </div>
                        ))}
                        {data.allProviders.length === 0 && (
                            <p style={{ color: 'var(--color-text-muted)', fontSize: 'var(--font-size-sm)' }}>Add providers in the API Connections tab first.</p>
                        )}
                    </div>
                </div>
            </section>

            {/* ── API Key Security ── */}
            <section>
                <h2 style={{ fontSize: 'var(--font-size-lg)', marginBottom: 'var(--space-1)' }}>API Key Security</h2>
                <p style={{ color: 'var(--color-text-secondary)', fontSize: 'var(--font-size-sm)', marginBottom: 'var(--space-4)' }}>
                    All API keys are encrypted at rest using AES-256-GCM before being stored in the database.
                </p>

                <div className="card" style={{ padding: 'var(--space-4)' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 'var(--space-3)', marginBottom: 'var(--space-4)' }}>
                        <div style={{
                            width: 40, height: 40, borderRadius: '50%', background: 'var(--color-success)',
                            display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '20px',
                        }}>🔒</div>
                        <div>
                            <div style={{ fontWeight: 600 }}>AES-256-GCM Encryption Active</div>
                            <div style={{ color: 'var(--color-text-secondary)', fontSize: 'var(--font-size-sm)' }}>
                                ENCRYPTION_SECRET is configured. Keys are encrypted before database storage.
                            </div>
                        </div>
                    </div>

                    <div style={{ fontSize: 'var(--font-size-sm)', color: 'var(--color-text-secondary)', background: 'var(--color-surface-raised)', borderRadius: 'var(--radius-md)', padding: 'var(--space-3)' }}>
                        <div style={{ marginBottom: 'var(--space-1)', fontWeight: 500, color: 'var(--color-text-primary)' }}>Regenerating the encryption key</div>
                        If you rotate ENCRYPTION_SECRET, all stored API keys will become unreadable.
                        You must re-enter all keys after rotating. To rotate safely:
                        <ol style={{ marginTop: 'var(--space-2)', paddingLeft: 'var(--space-4)' }}>
                            <li>Note all existing API keys before rotating</li>
                            <li>Generate a new key: <code>node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"</code></li>
                            <li>Update ENCRYPTION_SECRET in your environment / Vercel dashboard</li>
                            <li>Re-enter all API keys in the API Connections tab</li>
                        </ol>
                    </div>
                </div>
            </section>

            {/* ── Environment Overrides ── */}
            <section>
                <h2 style={{ fontSize: 'var(--font-size-lg)', marginBottom: 'var(--space-1)' }}>Environment Variables</h2>
                <p style={{ color: 'var(--color-text-secondary)', fontSize: 'var(--font-size-sm)', marginBottom: 'var(--space-4)' }}>
                    Read-only. If an env var is set and matches a configured provider, it may shadow the DB-stored key.{' '}
                    <a href="https://vercel.com/dashboard" target="_blank" rel="noopener noreferrer">
                        Manage in Vercel →
                    </a>
                </p>

                <div className="card" style={{ padding: 'var(--space-4)' }}>
                    <table className="data-table">
                        <thead>
                            <tr><th>Variable</th><th>Service</th><th>Status</th></tr>
                        </thead>
                        <tbody>
                            {Object.entries(ENV_VAR_LABELS).map(([envVar, label]) => (
                                <tr key={envVar}>
                                    <td><code style={{ fontSize: '12px' }}>{envVar}</code></td>
                                    <td>{label}</td>
                                    <td>
                                        <span className={`badge ${data.envVarsDetected[envVar] ? 'badge-success' : 'badge-default'}`}>
                                            {data.envVarsDetected[envVar] ? '✓ Set' : 'Not set'}
                                        </span>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </section>

            {/* ── Firecrawl Defaults ── */}
            <section>
                <h2 style={{ fontSize: 'var(--font-size-lg)', marginBottom: 'var(--space-1)' }}>Firecrawl Global Defaults</h2>
                <p style={{ color: 'var(--color-text-secondary)', fontSize: 'var(--font-size-sm)', marginBottom: 'var(--space-4)' }}>
                    Default settings used when scraper configs call Firecrawl without specifying overrides.
                </p>

                <div className="card" style={{ padding: 'var(--space-4)', display: 'flex', flexDirection: 'column', gap: 'var(--space-4)' }}>
                    <div className="form-group">
                        <label className="form-label">Default Crawl Mode</label>
                        <select className="form-select" value={crawlMode} onChange={e => setCrawlMode(e.target.value)}>
                            <option value="scrape">scrape — Single page extraction</option>
                            <option value="crawl">crawl — Multi-page crawl</option>
                            <option value="map">map — Discover all URLs</option>
                        </select>
                    </div>

                    <div className="form-group">
                        <label className="form-label">Default Response Formats</label>
                        <div style={{ display: 'flex', gap: 'var(--space-4)' }}>
                            {(['markdown', 'html', 'screenshot'] as const).map(fmt => (
                                <label key={fmt} style={{ display: 'flex', alignItems: 'center', gap: 'var(--space-2)', cursor: 'pointer' }}>
                                    <input type="checkbox"
                                        checked={crawlFormats[fmt]}
                                        onChange={e => setCrawlFormats(f => ({ ...f, [fmt]: e.target.checked }))} />
                                    {fmt}
                                </label>
                            ))}
                        </div>
                    </div>

                    <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
                        <button className="btn btn-primary" onClick={() => alert('Settings saved (coming in Phase D runtime integration)')}>
                            Save Firecrawl Defaults
                        </button>
                    </div>
                </div>
            </section>
        </div>
    );
}
