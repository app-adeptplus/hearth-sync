'use client';

import { useEffect, useState, useCallback } from 'react';
import Modal from '@/components/Modal';

type LlmProvider = 'OPENAI' | 'ANTHROPIC' | 'GOOGLE_GEMINI' | 'AZURE_OPENAI' | 'CUSTOM';
type ExternalServiceType = 'FIRECRAWL' | 'DATA_ENRICHMENT' | 'WEBHOOK';

interface LlmConfig {
    id: string;
    displayName: string | null;
    provider: LlmProvider;
    model: string;
    apiKey: string;
    baseUrl: string | null;
    maxTokens: number;
    temperature: number;
    topP: number | null;
    isDefault: boolean;
    isActive: boolean;
    lastTestedAt: string | null;
    lastTestStatus: string | null;
}

interface ExternalService {
    id: string;
    displayName: string;
    serviceType: ExternalServiceType;
    apiKey: string;
    baseUrl: string | null;
    settings: any;
    isActive: boolean;
    lastTestedAt: string | null;
    lastTestStatus: string | null;
}

const PROVIDER_LABELS: Record<LlmProvider, string> = {
    OPENAI: 'OpenAI',
    ANTHROPIC: 'Anthropic',
    GOOGLE_GEMINI: 'Google Gemini',
    AZURE_OPENAI: 'Azure OpenAI',
    CUSTOM: 'Custom (OpenAI-compatible)',
};

const PROVIDER_MODEL_HINTS: Record<LlmProvider, string[]> = {
    OPENAI: ['gpt-5.4', 'gpt-5.4-mini', 'gpt-5.4-nano', 'gpt-4.1', 'gpt-4.1-mini', 'gpt-4.1-nano', 'gpt-4o', 'gpt-4o-mini', 'o3', 'o4-mini'],
    ANTHROPIC: ['claude-opus-4-6', 'claude-opus-4-5', 'claude-sonnet-4-5', 'claude-haiku-4-5'],
    GOOGLE_GEMINI: ['gemini-3.1-pro', 'gemini-3-flash', 'gemini-3.1-flash-lite', 'gemini-2.5-pro', 'gemini-2.5-flash', 'gemini-2.5-flash-lite', 'gemini-2.0-flash'],
    AZURE_OPENAI: ['gpt-4.1', 'gpt-4o', 'gpt-4'],
    CUSTOM: [],
};

const SERVICE_LABELS: Record<ExternalServiceType, string> = {
    FIRECRAWL: 'Firecrawl.dev',
    DATA_ENRICHMENT: 'Data Enrichment',
    WEBHOOK: 'Webhook',
};

const SERVICE_BASE_URLS: Record<ExternalServiceType, string> = {
    FIRECRAWL: 'https://api.firecrawl.dev',
    DATA_ENRICHMENT: '',
    WEBHOOK: '',
};

const emptyLlmForm = {
    displayName: '', provider: 'OPENAI' as LlmProvider, apiKey: '',
    model: 'gpt-4o', baseUrl: '', maxTokens: 4096, temperature: 0.3,
    topP: '', isDefault: false,
};

const emptyServiceForm = {
    displayName: '', serviceType: 'FIRECRAWL' as ExternalServiceType,
    apiKey: '', baseUrl: '', linkedLlmConfigIds: [] as string[],
};

export default function APIConnectionsTab() {
    const [llmConfigs, setLlmConfigs] = useState<LlmConfig[]>([]);
    const [externalServices, setExternalServices] = useState<ExternalService[]>([]);
    const [loading, setLoading] = useState(true);

    // LLM modal state
    const [showLlmModal, setShowLlmModal] = useState(false);
    const [editingLlm, setEditingLlm] = useState<LlmConfig | null>(null);
    const [llmForm, setLlmForm] = useState(emptyLlmForm);
    const [llmSaving, setLlmSaving] = useState(false);
    const [llmTesting, setLlmTesting] = useState<string | null>(null);

    // External service modal state
    const [showServiceModal, setShowServiceModal] = useState(false);
    const [editingService, setEditingService] = useState<ExternalService | null>(null);
    const [serviceForm, setServiceForm] = useState(emptyServiceForm);
    const [serviceSaving, setServiceSaving] = useState(false);
    const [serviceTesting, setServiceTesting] = useState<string | null>(null);

    const [error, setError] = useState<string | null>(null);

    const loadData = useCallback(async () => {
        setLoading(true);
        setError(null);
        try {
            const [llmRes, svcRes] = await Promise.all([
                fetch('/api/automation/llm-settings'),
                fetch('/api/automation/external-services'),
            ]);
            const llmData = await llmRes.json();
            const svcData = await svcRes.json();
            setLlmConfigs(Array.isArray(llmData) ? llmData : []);
            setExternalServices(Array.isArray(svcData) ? svcData : []);
            if (!Array.isArray(llmData) && llmData?.error) {
                setError(`LLM providers: ${llmData.error}`);
            } else if (!Array.isArray(svcData) && svcData?.error) {
                setError(`External services: ${svcData.error}`);
            }
        } catch (e: any) {
            setError(e.message);
        } finally {
            setLoading(false);
        }
    }, []);


    useEffect(() => { loadData(); }, [loadData]);

    // --- LLM Handlers ---
    function openAddLlm() {
        setEditingLlm(null);
        setLlmForm(emptyLlmForm);
        setShowLlmModal(true);
    }
    function openEditLlm(cfg: LlmConfig) {
        setEditingLlm(cfg);
        setLlmForm({
            displayName: cfg.displayName || '',
            provider: cfg.provider,
            apiKey: cfg.apiKey,
            model: cfg.model,
            baseUrl: cfg.baseUrl || '',
            maxTokens: cfg.maxTokens,
            temperature: cfg.temperature,
            topP: cfg.topP?.toString() || '',
            isDefault: cfg.isDefault,
        });
        setShowLlmModal(true);
    }
    async function saveLlm() {
        setLlmSaving(true);
        try {
            const body = {
                ...llmForm,
                topP: llmForm.topP ? parseFloat(llmForm.topP as any) : null,
            };
            if (editingLlm) {
                await fetch(`/api/automation/llm-settings/${editingLlm.id}`, {
                    method: 'PATCH', headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(body),
                });
            } else {
                await fetch('/api/automation/llm-settings', {
                    method: 'POST', headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(body),
                });
            }
            setShowLlmModal(false);
            loadData();
        } catch (e: any) {
            setError(e.message);
        } finally {
            setLlmSaving(false);
        }
    }
    async function deleteLlm(id: string) {
        if (!confirm('Delete this API connection? This cannot be undone.')) return;
        await fetch(`/api/automation/llm-settings/${id}`, { method: 'DELETE' });
        loadData();
    }
    async function testLlm(id: string) {
        setLlmTesting(id);
        try {
            const res = await fetch(`/api/automation/llm-settings/${id}/test`, { method: 'POST' });
            const data = await res.json();
            alert(data.success
                ? `✅ Connection successful (${data.latencyMs}ms)`
                : `❌ Test failed: ${data.error}`);
            loadData();
        } finally {
            setLlmTesting(null);
        }
    }
    async function setDefaultLlm(id: string) {
        await fetch(`/api/automation/llm-settings/${id}`, {
            method: 'PATCH', headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ isDefault: true }),
        });
        loadData();
    }
    async function toggleLlmActive(cfg: LlmConfig) {
        await fetch(`/api/automation/llm-settings/${cfg.id}`, {
            method: 'PATCH', headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ isActive: !cfg.isActive }),
        });
        loadData();
    }

    // --- External Service Handlers ---
    function openAddService() {
        setEditingService(null);
        setServiceForm(emptyServiceForm);
        setShowServiceModal(true);
    }
    function openEditService(svc: ExternalService) {
        setEditingService(svc);
        setServiceForm({
            displayName: svc.displayName,
            serviceType: svc.serviceType,
            apiKey: svc.apiKey,
            baseUrl: svc.baseUrl || '',
            linkedLlmConfigIds: [],
        });
        setShowServiceModal(true);
    }
    async function saveService() {
        setServiceSaving(true);
        try {
            const body = {
                ...serviceForm,
                baseUrl: serviceForm.baseUrl || SERVICE_BASE_URLS[serviceForm.serviceType] || null,
            };
            if (editingService) {
                await fetch(`/api/automation/external-services/${editingService.id}`, {
                    method: 'PATCH', headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(body),
                });
            } else {
                await fetch('/api/automation/external-services', {
                    method: 'POST', headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(body),
                });
            }
            setShowServiceModal(false);
            loadData();
        } catch (e: any) {
            setError(e.message);
        } finally {
            setServiceSaving(false);
        }
    }
    async function deleteService(id: string) {
        if (!confirm('Delete this service connection? This cannot be undone.')) return;
        await fetch(`/api/automation/external-services/${id}`, { method: 'DELETE' });
        loadData();
    }
    async function testService(id: string) {
        setServiceTesting(id);
        try {
            const res = await fetch(`/api/automation/external-services/${id}/test`, { method: 'POST' });
            const data = await res.json();
            alert(data.success
                ? `✅ Connection successful (${data.latencyMs}ms)`
                : `❌ Test failed: ${data.error}`);
            loadData();
        } finally {
            setServiceTesting(null);
        }
    }

    function testBadge(status: string | null, testedAt: string | null) {
        if (!testedAt) {
            return <span className="badge badge-default">Never tested</span>;
        }
        const ok = status === 'success';
        const ts = new Date(testedAt).toLocaleString(undefined, {
            month: 'short', day: 'numeric',
            hour: '2-digit', minute: '2-digit',
        });
        return (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '2px' }}>
                <span className={`badge ${ok ? 'badge-success' : 'badge-error'}`}>
                    {ok ? '✓ OK' : '✗ Failed'}
                </span>
                <span style={{ fontSize: '11px', color: 'var(--color-text-muted)' }}>{ts}</span>
            </div>
        );
    }

    if (loading) return <div className="loading-state">Loading API connections…</div>;

    return (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-8)' }}>
            {error && <div className="alert alert-error">{error}</div>}

            {/* ── LLM Providers ── */}
            <section>
                <div className="section-header" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 'var(--space-4)' }}>
                    <div>
                        <h2 style={{ margin: 0, fontSize: 'var(--font-size-lg)' }}>LLM Providers</h2>
                        <p style={{ margin: 0, color: 'var(--color-text-secondary)', fontSize: 'var(--font-size-sm)' }}>
                            OpenAI, Anthropic, Google Gemini, and custom model endpoints
                        </p>
                    </div>
                    <button className="btn btn-primary" onClick={openAddLlm}>+ Add Provider</button>
                </div>

                {llmConfigs.length === 0 ? (
                    <div className="empty-state">
                        <p>No LLM providers configured. Add one to start using AI features.</p>
                    </div>
                ) : (
                    <div className="data-table-wrapper">
                        <table className="data-table">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Provider</th>
                                    <th>Model</th>
                                    <th>Status</th>
                                    <th>Last Tested</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                {llmConfigs.map(cfg => (
                                    <tr key={cfg.id}>
                                        <td>
                                            <div style={{ display: 'flex', alignItems: 'center', gap: 'var(--space-2)' }}>
                                                {cfg.displayName || '(unnamed)'}
                                                {cfg.isDefault && <span className="badge badge-primary">Default</span>}
                                            </div>
                                        </td>
                                        <td><span className="badge badge-default">{PROVIDER_LABELS[cfg.provider]}</span></td>
                                        <td><code style={{ fontSize: 'var(--font-size-xs)' }}>{cfg.model}</code></td>
                                        <td>
                                            <span className={`badge ${cfg.isActive ? 'badge-success' : 'badge-default'}`}>
                                                {cfg.isActive ? 'Active' : 'Inactive'}
                                            </span>
                                        </td>
                                        <td>{testBadge(cfg.lastTestStatus, cfg.lastTestedAt)}</td>
                                        <td>
                                            <div style={{ display: 'flex', gap: 'var(--space-2)' }}>
                                                <button className="btn btn-sm btn-ghost" onClick={() => testLlm(cfg.id)} disabled={llmTesting === cfg.id}>
                                                    {llmTesting === cfg.id ? '…' : 'Test'}
                                                </button>
                                                {!cfg.isDefault && (
                                                    <button className="btn btn-sm btn-ghost" onClick={() => setDefaultLlm(cfg.id)}>Set Default</button>
                                                )}
                                                <button className="btn btn-sm btn-ghost" onClick={() => toggleLlmActive(cfg)}>
                                                    {cfg.isActive ? 'Disable' : 'Enable'}
                                                </button>
                                                <button className="btn btn-sm btn-ghost" onClick={() => openEditLlm(cfg)}>Edit</button>
                                                <button className="btn btn-sm btn-ghost btn-danger" onClick={() => deleteLlm(cfg.id)}>Delete</button>
                                            </div>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                )}
            </section>

            {/* ── External Services ── */}
            <section>
                <div className="section-header" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 'var(--space-4)' }}>
                    <div>
                        <h2 style={{ margin: 0, fontSize: 'var(--font-size-lg)' }}>External Services</h2>
                        <p style={{ margin: 0, color: 'var(--color-text-secondary)', fontSize: 'var(--font-size-sm)' }}>
                            Firecrawl.dev and other non-LLM service integrations
                        </p>
                    </div>
                    <button className="btn btn-primary" onClick={openAddService}>+ Add Service</button>
                </div>

                {externalServices.length === 0 ? (
                    <div className="empty-state">
                        <p>No external services configured. Connect Firecrawl.dev to enable web scraping.</p>
                    </div>
                ) : (
                    <div className="data-table-wrapper">
                        <table className="data-table">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Service</th>
                                    <th>Status</th>
                                    <th>Last Tested</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                {externalServices.map(svc => (
                                    <tr key={svc.id}>
                                        <td>{svc.displayName}</td>
                                        <td><span className="badge badge-default">{SERVICE_LABELS[svc.serviceType]}</span></td>
                                        <td>
                                            <span className={`badge ${svc.isActive ? 'badge-success' : 'badge-default'}`}>
                                                {svc.isActive ? 'Active' : 'Inactive'}
                                            </span>
                                        </td>
                                        <td>{testBadge(svc.lastTestStatus, svc.lastTestedAt)}</td>
                                        <td>
                                            <div style={{ display: 'flex', gap: 'var(--space-2)' }}>
                                                <button className="btn btn-sm btn-ghost" onClick={() => testService(svc.id)} disabled={serviceTesting === svc.id}>
                                                    {serviceTesting === svc.id ? '…' : 'Test'}
                                                </button>
                                                <button className="btn btn-sm btn-ghost" onClick={() => openEditService(svc)}>Edit</button>
                                                <button className="btn btn-sm btn-ghost btn-danger" onClick={() => deleteService(svc.id)}>Delete</button>
                                            </div>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                )}
            </section>

            {/* ── LLM Provider Modal ── */}
            <Modal
                isOpen={showLlmModal}
                onClose={() => setShowLlmModal(false)}
                title={editingLlm ? 'Edit LLM Provider' : 'Add LLM Provider'}
                subtitle="Configure an AI model API connection. Keys are stored encrypted."
                size="md"
                footer={
                    <>
                        <button className="btn btn-ghost" onClick={() => setShowLlmModal(false)}>Cancel</button>
                        <button className="btn btn-primary" onClick={saveLlm} disabled={llmSaving}>
                            {llmSaving ? 'Saving…' : 'Save Provider'}
                        </button>
                    </>
                }
            >
                <div style={{ padding: '1.5rem', display: 'flex', flexDirection: 'column', gap: 'var(--space-4)' }}>
                    <div className="form-group">
                        <label className="form-label">Display Name</label>
                        <input className="form-input" placeholder='e.g. "GPT-4o for Scraping"'
                            value={llmForm.displayName}
                            onChange={e => setLlmForm(f => ({ ...f, displayName: e.target.value }))} />
                    </div>
                    <div className="form-group">
                        <label className="form-label">Provider</label>
                        <select className="form-select" value={llmForm.provider}
                            onChange={e => setLlmForm(f => ({
                                ...f, provider: e.target.value as LlmProvider,
                                model: PROVIDER_MODEL_HINTS[e.target.value as LlmProvider]?.[0] || '',
                            }))}>
                            {Object.entries(PROVIDER_LABELS).map(([k, v]) => (
                                <option key={k} value={k}>{v}</option>
                            ))}
                        </select>
                    </div>
                    <div className="form-group">
                        <label className="form-label">API Key</label>
                        <input className="form-input" type="password" placeholder="sk-..." autoComplete="off"
                            value={llmForm.apiKey}
                            onChange={e => setLlmForm(f => ({ ...f, apiKey: e.target.value }))} />
                        <span className="form-hint">Stored encrypted (AES-256-GCM)</span>
                    </div>
                    <div className="form-group">
                        <label className="form-label">Model ID</label>
                        {PROVIDER_MODEL_HINTS[llmForm.provider]?.length > 0 ? (
                            <>
                                <select
                                    className="form-select"
                                    value={PROVIDER_MODEL_HINTS[llmForm.provider].includes(llmForm.model) ? llmForm.model : '__other__'}
                                    onChange={e => {
                                        if (e.target.value !== '__other__') {
                                            setLlmForm(f => ({ ...f, model: e.target.value }));
                                        } else {
                                            setLlmForm(f => ({ ...f, model: '' }));
                                        }
                                    }}
                                >
                                    {PROVIDER_MODEL_HINTS[llmForm.provider].map(m => (
                                        <option key={m} value={m}>{m}</option>
                                    ))}
                                    <option value="__other__">Other (enter manually)…</option>
                                </select>
                                {!PROVIDER_MODEL_HINTS[llmForm.provider].includes(llmForm.model) && (
                                    <input
                                        className="form-input"
                                        style={{ marginTop: 'var(--space-2)' }}
                                        placeholder="Enter model ID manually"
                                        value={llmForm.model}
                                        onChange={e => setLlmForm(f => ({ ...f, model: e.target.value }))}
                                        autoFocus
                                    />
                                )}
                            </>
                        ) : (
                            <input
                                className="form-input"
                                placeholder="e.g. my-custom-model-v1"
                                value={llmForm.model}
                                onChange={e => setLlmForm(f => ({ ...f, model: e.target.value }))}
                            />
                        )}
                    </div>
                    {(llmForm.provider === 'AZURE_OPENAI' || llmForm.provider === 'CUSTOM') && (
                        <div className="form-group">
                            <label className="form-label">Base URL</label>
                            <input className="form-input" placeholder="https://your-endpoint.openai.azure.com/..."
                                value={llmForm.baseUrl}
                                onChange={e => setLlmForm(f => ({ ...f, baseUrl: e.target.value }))} />
                        </div>
                    )}
                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 'var(--space-3)' }}>
                        <div className="form-group">
                            <label className="form-label">Temperature</label>
                            <input className="form-input" type="number" min="0" max="2" step="0.1"
                                value={llmForm.temperature}
                                onChange={e => setLlmForm(f => ({ ...f, temperature: parseFloat(e.target.value) }))} />
                        </div>
                        <div className="form-group">
                            <label className="form-label">Max Tokens</label>
                            <input className="form-input" type="number" min="256" max="128000"
                                value={llmForm.maxTokens}
                                onChange={e => setLlmForm(f => ({ ...f, maxTokens: parseInt(e.target.value) }))} />
                        </div>
                        <div className="form-group">
                            <label className="form-label">Top P</label>
                            <input className="form-input" type="number" min="0" max="1" step="0.05" placeholder="optional"
                                value={llmForm.topP}
                                onChange={e => setLlmForm(f => ({ ...f, topP: e.target.value }))} />
                        </div>
                    </div>
                    <div className="form-group">
                        <label style={{ display: 'flex', alignItems: 'center', gap: 'var(--space-2)', cursor: 'pointer' }}>
                            <input type="checkbox" checked={llmForm.isDefault}
                                onChange={e => setLlmForm(f => ({ ...f, isDefault: e.target.checked }))} />
                            Set as default provider
                        </label>
                    </div>
                </div>
            </Modal>

            {/* ── External Service Modal ── */}
            <Modal
                isOpen={showServiceModal}
                onClose={() => setShowServiceModal(false)}
                title={editingService ? 'Edit Service' : 'Add External Service'}
                subtitle="Connect Firecrawl.dev or other non-LLM service integrations."
                size="md"
                footer={
                    <>
                        <button className="btn btn-ghost" onClick={() => setShowServiceModal(false)}>Cancel</button>
                        <button className="btn btn-primary" onClick={saveService} disabled={serviceSaving}>
                            {serviceSaving ? 'Saving…' : 'Save Service'}
                        </button>
                    </>
                }
            >
                <div style={{ padding: '1.5rem', display: 'flex', flexDirection: 'column', gap: 'var(--space-4)' }}>
                    <div className="form-group">
                        <label className="form-label">Service Type</label>
                        <select className="form-select" value={serviceForm.serviceType}
                            onChange={e => setServiceForm(f => ({
                                ...f,
                                serviceType: e.target.value as ExternalServiceType,
                                baseUrl: SERVICE_BASE_URLS[e.target.value as ExternalServiceType],
                            }))}>
                            {Object.entries(SERVICE_LABELS).map(([k, v]) => (
                                <option key={k} value={k}>{v}</option>
                            ))}
                        </select>
                    </div>
                    <div className="form-group">
                        <label className="form-label">Display Name</label>
                        <input className="form-input" placeholder='e.g. "Firecrawl Production"'
                            value={serviceForm.displayName}
                            onChange={e => setServiceForm(f => ({ ...f, displayName: e.target.value }))} />
                    </div>
                    <div className="form-group">
                        <label className="form-label">API Key</label>
                        <input className="form-input" type="password" placeholder="fc-..." autoComplete="off"
                            value={serviceForm.apiKey}
                            onChange={e => setServiceForm(f => ({ ...f, apiKey: e.target.value }))} />
                        <span className="form-hint">Stored encrypted (AES-256-GCM)</span>
                    </div>
                    <div className="form-group">
                        <label className="form-label">Base URL (optional)</label>
                        <input className="form-input"
                            placeholder={SERVICE_BASE_URLS[serviceForm.serviceType] || 'https://...'}
                            value={serviceForm.baseUrl}
                            onChange={e => setServiceForm(f => ({ ...f, baseUrl: e.target.value }))} />
                        <span className="form-hint">Leave blank to use the default endpoint</span>
                    </div>
                    <div className="form-group">
                        <label className="form-label">Link to LLM Providers</label>
                        <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-1)' }}>
                            {llmConfigs.map(cfg => (
                                <label key={cfg.id} style={{ display: 'flex', alignItems: 'center', gap: 'var(--space-2)', cursor: 'pointer' }}>
                                    <input type="checkbox"
                                        checked={serviceForm.linkedLlmConfigIds.includes(cfg.id)}
                                        onChange={e => {
                                            setServiceForm(f => ({
                                                ...f,
                                                linkedLlmConfigIds: e.target.checked
                                                    ? [...f.linkedLlmConfigIds, cfg.id]
                                                    : f.linkedLlmConfigIds.filter(id => id !== cfg.id),
                                            }));
                                        }} />
                                    {cfg.displayName || cfg.provider} — <code style={{ fontSize: 'var(--font-size-xs)' }}>{cfg.model}</code>
                                </label>
                            ))}
                            {llmConfigs.length === 0 && (
                                <span className="form-hint">No LLM providers configured yet</span>
                            )}
                        </div>
                    </div>
                </div>
            </Modal>
        </div>
    );
}
