import prisma from '@/lib/db';
import Link from 'next/link';

async function getStats() {
    try {
        const [manufacturers, brands, products, activeProducts, scraperJobs] =
            await Promise.all([
                prisma.manufacturer.count(),
                prisma.brand.count(),
                prisma.product.count(),
                prisma.product.count({ where: { status: 'ACTIVE' } }),
                prisma.scraperJob.count({ where: { status: 'COMPLETED' } }),
            ]);

        const recentAudit = await prisma.auditLog.findMany({
            take: 10,
            orderBy: { createdAt: 'desc' },
            include: { product: { select: { name: true, brand: { select: { name: true } } } } },
        });

        return { manufacturers, brands, products, activeProducts, scraperJobs, recentAudit };
    } catch {
        // DB not connected yet — return defaults
        return {
            manufacturers: 0,
            brands: 0,
            products: 0,
            activeProducts: 0,
            scraperJobs: 0,
            recentAudit: [],
        };
    }
}

export default async function AdminDashboard() {
    const stats = await getStats();

    return (
        <>
            <div className="page-header">
                <div>
                    <h2 className="page-title">Dashboard</h2>
                    <p className="page-subtitle">
                        Master catalog overview and system health
                    </p>
                </div>
            </div>

            <div className="stats-grid">
                <div className="stat-card" style={{ '--stat-color': '#e94560' } as React.CSSProperties}>
                    <div className="stat-label">Manufacturers</div>
                    <div className="stat-value">{stats.manufacturers}</div>
                    <div className="stat-change">Parent companies tracked</div>
                </div>
                <div className="stat-card" style={{ '--stat-color': '#f4a261' } as React.CSSProperties}>
                    <div className="stat-label">Brands</div>
                    <div className="stat-value">{stats.brands}</div>
                    <div className="stat-change">Individual product lines</div>
                </div>
                <div className="stat-card" style={{ '--stat-color': '#06d6a0' } as React.CSSProperties}>
                    <div className="stat-label">Total Products</div>
                    <div className="stat-value">{stats.products}</div>
                    <div className="stat-change">{stats.activeProducts} active</div>
                </div>
                <div className="stat-card" style={{ '--stat-color': '#118ab2' } as React.CSSProperties}>
                    <div className="stat-label">Scrape Jobs</div>
                    <div className="stat-value">{stats.scraperJobs}</div>
                    <div className="stat-change">Completed runs</div>
                </div>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 'var(--space-6)' }}>
                {/* Recent Activity */}
                <div className="card">
                    <div className="card-header">
                        <h3 className="card-title">Recent Activity</h3>
                        <Link href="/admin/audit" className="btn btn-ghost btn-sm">
                            View All →
                        </Link>
                    </div>
                    {stats.recentAudit.length === 0 ? (
                        <div className="empty-state" style={{ padding: 'var(--space-8) 0' }}>
                            <p>No activity recorded yet. Run your first scraper job to populate the catalog.</p>
                        </div>
                    ) : (
                        <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-3)' }}>
                            {stats.recentAudit.map((log) => (
                                <div
                                    key={log.id}
                                    style={{
                                        display: 'flex',
                                        alignItems: 'center',
                                        justifyContent: 'space-between',
                                        padding: 'var(--space-3)',
                                        borderRadius: 'var(--radius-md)',
                                        background: 'var(--color-bg)',
                                    }}
                                >
                                    <div>
                                        <span className={`badge badge-${log.action === 'CREATED' ? 'active' : log.action === 'DELETED' ? 'danger' : 'info'}`}>
                                            {log.action}
                                        </span>
                                        <span style={{ marginLeft: 'var(--space-3)', fontSize: 'var(--font-size-sm)' }}>
                                            {log.product?.brand?.name} — {log.product?.name || log.entityType}
                                        </span>
                                    </div>
                                    <span style={{ fontSize: 'var(--font-size-xs)', color: 'var(--color-text-muted)' }}>
                                        {new Date(log.createdAt).toLocaleDateString()}
                                    </span>
                                </div>
                            ))}
                        </div>
                    )}
                </div>

                {/* Quick Actions */}
                <div className="card">
                    <div className="card-header">
                        <h3 className="card-title">Quick Actions</h3>
                    </div>
                    <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-3)' }}>
                        <Link
                            href="/admin/manufacturers"
                            className="btn btn-secondary"
                            style={{ justifyContent: 'flex-start' }}
                        >
                            🏭 Manage Manufacturers
                        </Link>
                        <Link
                            href="/admin/products"
                            className="btn btn-secondary"
                            style={{ justifyContent: 'flex-start' }}
                        >
                            🔥 Browse Products
                        </Link>
                        <Link
                            href="/admin/products/import"
                            className="btn btn-secondary"
                            style={{ justifyContent: 'flex-start' }}
                        >
                            📥 Bulk Import Products
                        </Link>
                        <Link
                            href="/admin/scraper"
                            className="btn btn-secondary"
                            style={{ justifyContent: 'flex-start' }}
                        >
                            🤖 Run Scraper Job
                        </Link>
                        <Link
                            href="/admin/categories"
                            className="btn btn-secondary"
                            style={{ justifyContent: 'flex-start' }}
                        >
                            📁 Manage Categories
                        </Link>
                    </div>
                </div>
            </div>
        </>
    );
}
