'use client';

import React, { useState } from 'react';
import Modal from '@/components/Modal';

export default function ModalTestPage() {
    const [openSize, setOpenSize] = useState<string | null>(null);
    const [previewPage, setPreviewPage] = useState(1);
    const PREVIEW_PAGE_SIZE = 50;
    const totalRows = 1000;

    const closeModal = () => setOpenSize(null);

    return (
        <div style={{ padding: '2rem' }}>
            <h1 style={{ fontSize: '1.875rem', fontWeight: 700, margin: '0 0 1.5rem' }}>Modal Component Testing</h1>

            <p style={{ color: 'var(--color-text-muted)', marginBottom: '2rem', maxWidth: '42rem', lineHeight: 1.6 }}>
                This page allows you to preview the new standard Modal system for HearthSync without needing to trigger a specific workflow. Try out the different sizes.
            </p>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem', maxWidth: '24rem' }}>
                <button className="btn btn-primary" onClick={() => setOpenSize('sm')}>Small Modal (sm)</button>
                <button className="btn btn-primary" onClick={() => setOpenSize('md')}>Medium Modal (md)</button>
                <button className="btn btn-primary" onClick={() => setOpenSize('lg')}>Large Modal (lg)</button>
                <button className="btn btn-primary" onClick={() => setOpenSize('xl')}>Extra Large Modal (xl)</button>
                <button className="btn btn-primary" onClick={() => setOpenSize('full')}>Full Screen Modal (full)</button>
                <button className="btn btn-primary" style={{ backgroundColor: '#059669', borderColor: '#059669', fontWeight: 'bold' }} onClick={() => setOpenSize('excel')}>
                    Giant Excel Modal (excel)
                </button>
            </div>

            {/* sm */}
            <Modal
                isOpen={openSize === 'sm'}
                onClose={closeModal}
                title="Small Confirmatory Modal"
                subtitle="Are you sure you want to do this thing?"
                size="sm"
                footer={(
                    <>
                        <button className="btn btn-secondary" onClick={closeModal}>Cancel</button>
                        <button className="btn btn-primary" style={{ backgroundColor: 'var(--color-error)', borderColor: 'var(--color-error)' }} onClick={closeModal}>Delete It</button>
                    </>
                )}
            >
                <div style={{ padding: '1.5rem', color: 'var(--color-text-secondary)', lineHeight: 1.5 }}>
                    This is a small modal often used for destructive actions or quick confirmations. It won't take up much space.
                </div>
            </Modal>

            {/* md */}
            <Modal
                isOpen={openSize === 'md'}
                onClose={closeModal}
                title="Medium Form Modal"
                subtitle="Fill out these details"
                size="md"
                footer={(
                    <>
                        <button className="btn btn-secondary" onClick={closeModal}>Cancel</button>
                        <button className="btn btn-primary" onClick={closeModal}>Save Changes</button>
                    </>
                )}
            >
                <div style={{ padding: '1.5rem', display: 'grid', gridTemplateColumns: '1fr', gap: '1rem' }}>
                    <label style={{ display: 'block' }}>
                        <span style={{ fontSize: '0.875rem', fontWeight: 600, marginBottom: '0.25rem', display: 'block' }}>First Name</span>
                        <input type="text" className="form-input" style={{ width: '100%' }} placeholder="John" />
                    </label>
                    <label style={{ display: 'block' }}>
                        <span style={{ fontSize: '0.875rem', fontWeight: 600, marginBottom: '0.25rem', display: 'block' }}>Last Name</span>
                        <input type="text" className="form-input" style={{ width: '100%' }} placeholder="Doe" />
                    </label>
                </div>
            </Modal>

            {/* lg */}
            <Modal
                isOpen={openSize === 'lg'}
                onClose={closeModal}
                title="Large Settings Panel"
                size="lg"
            >
                <div style={{ padding: '1.5rem', height: '400px', backgroundColor: 'var(--color-bg-card)' }}>
                    <p style={{ margin: '0 0 1rem', lineHeight: 1.5 }}>Plenty of room for tabs, big lists, or complex settings panels.</p>
                    <div style={{ width: '100%', height: 'calc(100% - 3rem)', backgroundColor: 'var(--color-border)', borderRadius: '4px', opacity: 0.2 }}></div>
                </div>
            </Modal>

            {/* xl */}
            <Modal
                isOpen={openSize === 'xl'}
                onClose={closeModal}
                title="Extra Large Modal"
                size="xl"
            >
                <div style={{ padding: '1.5rem', height: '600px', lineHeight: 1.5 }}>
                    This is commonly used for data-heavy views.
                </div>
            </Modal>

            {/* Full */}
            <Modal
                isOpen={openSize === 'full'}
                onClose={closeModal}
                title="Full Screen Override"
                subtitle="Almost fills the entire viewport"
                size="full"
                footer={<button className="btn btn-primary" onClick={closeModal}>Complete Workflow</button>}
            >
                <div style={{ padding: '1.5rem', height: '1200px', background: 'linear-gradient(to bottom, #f0fdf4, #eff6ff)', color: '#1f2937' }}>
                    <h2 style={{ fontSize: '1.5rem', fontWeight: 700, margin: '0 0 1rem' }}>Giant scrollable area inside</h2>
                    <p style={{ margin: 0 }}>This demonstrates how the body of the modal can scroll without scrolling the whole page.</p>
                </div>
            </Modal>

            {/* Excel */}
            <Modal
                isOpen={openSize === 'excel'}
                onClose={closeModal}
                title="Excel Spreadsheet Preview"
                subtitle="Maximized width to handle 30+ columns without wrapping"
                size="excel"
                footer={(
                    <div style={{ width: '100%', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                        <span style={{ fontSize: '0.875rem', color: 'var(--color-text-muted)', fontWeight: 500 }}>
                            Records <span style={{ color: 'var(--color-text-primary)' }}>{((previewPage - 1) * PREVIEW_PAGE_SIZE) + 1}</span> - <span style={{ color: 'var(--color-text-primary)' }}>{Math.min(previewPage * PREVIEW_PAGE_SIZE, totalRows)}</span> of <span style={{ color: 'var(--color-success)' }}>{totalRows}</span> Total
                        </span>

                        <div style={{ display: 'flex', alignItems: 'center', gap: '0.25rem' }}>
                            <button
                                disabled={previewPage === 1}
                                onClick={() => setPreviewPage(1)}
                                className="btn btn-secondary"
                                style={{ padding: '0.25rem 0.75rem', fontWeight: 700, opacity: previewPage === 1 ? 0.5 : 1 }} title="First Page">«</button>
                            <button
                                disabled={previewPage === 1}
                                onClick={() => setPreviewPage(p => p - 1)}
                                className="btn btn-secondary" style={{ padding: '0.25rem 0.75rem', fontWeight: 700, opacity: previewPage === 1 ? 0.5 : 1 }} title="Previous Page">‹</button>
                            <span style={{ padding: '0 0.75rem', color: 'var(--color-text-muted)', fontSize: '0.875rem', fontWeight: 500 }}>Page {previewPage}</span>
                            <button
                                disabled={previewPage * PREVIEW_PAGE_SIZE >= totalRows}
                                onClick={() => setPreviewPage(p => p + 1)}
                                className="btn btn-secondary" style={{ padding: '0.25rem 0.75rem', fontWeight: 700, opacity: previewPage * PREVIEW_PAGE_SIZE >= totalRows ? 0.5 : 1 }} title="Next Page">›</button>
                        </div>

                        <div style={{ display: 'flex', gap: '0.5rem', marginLeft: '1rem' }}>
                            <button className="btn btn-secondary" onClick={closeModal}>Close Preview</button>
                            <button className="btn btn-primary" style={{ backgroundColor: '#059669', borderColor: '#059669', fontWeight: 'bold', color: 'white' }} onClick={closeModal}>Start Import →</button>
                        </div>
                    </div>
                )}
            >
                <div>
                    <table style={{ width: '100%', textAlign: 'left', fontSize: '0.875rem', whiteSpace: 'nowrap', borderCollapse: 'collapse', backgroundColor: '#ffffff' }}>
                        <thead style={{ backgroundColor: '#f9fafb', position: 'sticky', top: 0, zIndex: 10, boxShadow: '0 1px 2px rgba(0,0,0,0.05)' }}>
                            <tr>
                                <th style={{ padding: '0.75rem 1rem', border: '1px solid #e5e7eb', color: '#111827', fontWeight: 700 }}>#</th>
                                {Array.from({ length: 25 }).map((_, i) => (
                                    <th key={i} style={{ padding: '0.75rem 1rem', border: '1px solid #e5e7eb', minWidth: '200px', color: '#111827', fontWeight: 700, backgroundColor: '#f9fafb' }}>
                                        Column {i + 1}
                                        <div style={{ fontSize: '10px', color: '#6b7280', fontWeight: 'normal', textTransform: 'uppercase', marginTop: '0.25rem' }}>db_col_{i + 1}</div>
                                    </th>
                                ))}
                            </tr>
                        </thead>
                        <tbody>
                            {Array.from({ length: 50 }).map((_, i) => {
                                const rIndex = ((previewPage - 1) * PREVIEW_PAGE_SIZE) + i;
                                return (
                                    <tr key={rIndex} style={{ backgroundColor: rIndex % 2 === 0 ? '#ffffff' : '#f9fafb', transition: 'background-color 150ms' }} onMouseOver={(e) => e.currentTarget.style.backgroundColor = '#f3f4f6'} onMouseOut={(e) => e.currentTarget.style.backgroundColor = rIndex % 2 === 0 ? '#ffffff' : '#f9fafb'}>
                                        <td style={{ padding: '0.5rem 1rem', border: '1px solid #e5e7eb', color: '#6b7280', textAlign: 'center' }}>{rIndex + 1}</td>
                                        {Array.from({ length: 25 }).map((_, cIndex) => (
                                            <td key={cIndex} style={{ padding: '0.5rem 1rem', border: '1px solid #e5e7eb', color: '#111827' }}>
                                                Data for Cell R{rIndex + 1}C{cIndex + 1}
                                            </td>
                                        ))}
                                    </tr>
                                )
                            })}
                        </tbody>
                    </table>
                </div>
            </Modal>

        </div>
    );
}
