'use client';

interface Props {
    dealerId: string;
    dealerSlug: string | null;
    companyName: string;
}

export default function LoginAsDealerButton({ dealerId, companyName }: Props) {
    // Opens the server-side impersonate route directly in a new tab.
    // The route creates a Supabase session server-side and redirects to the dealer catalog.
    const handleLogin = () => {
        window.open(`/api/admin/dealers/${dealerId}/impersonate`, '_blank');
    };

    return (
        <button
            onClick={handleLogin}
            title={`Log in to ${companyName}'s dealer portal`}
            style={{
                display: 'inline-flex',
                alignItems: 'center',
                gap: '6px',
                padding: '4px 10px',
                fontSize: 'var(--font-size-xs)',
                fontWeight: 500,
                border: '1px solid var(--color-border)',
                borderRadius: 'var(--radius-md)',
                background: 'var(--color-surface)',
                color: 'var(--color-text-secondary)',
                cursor: 'pointer',
                transition: 'background 0.15s, border-color 0.15s, color 0.15s',
                whiteSpace: 'nowrap',
            }}
            onMouseEnter={(e) => {
                (e.currentTarget as HTMLButtonElement).style.borderColor = 'var(--color-primary)';
                (e.currentTarget as HTMLButtonElement).style.color = 'var(--color-primary)';
            }}
            onMouseLeave={(e) => {
                (e.currentTarget as HTMLButtonElement).style.borderColor = 'var(--color-border)';
                (e.currentTarget as HTMLButtonElement).style.color = 'var(--color-text-secondary)';
            }}
        >
            <span style={{ fontSize: '0.75rem' }}>🔑</span>
            Login as Dealer
        </button>
    );
}
