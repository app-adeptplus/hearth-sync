'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import Modal from '@/components/Modal';

const TIERS = ['STARTER', 'PROFESSIONAL', 'ENTERPRISE'] as const;
type Tier = typeof TIERS[number];

function toSlug(s: string) {
    return s
        .toLowerCase()
        .replace(/[^a-z0-9\s-]/g, '')
        .trim()
        .replace(/\s+/g, '-')
        .replace(/-+/g, '-');
}

interface AddDealerModalProps {
    isOpen: boolean;
    onClose: () => void;
}

export default function AddDealerModal({ isOpen, onClose }: AddDealerModalProps) {
    const router = useRouter();
    const [form, setForm] = useState({
        companyName: '',
        contactName: '',
        email: '',
        phone: '',
        city: '',
        state: '',
        slug: '',
        ownerEmail: '',
        subscriptionTier: 'STARTER' as Tier,
    });
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState('');
    const [tempPassword, setTempPassword] = useState('');

    const update = (field: string, value: string) =>
        setForm((prev) => ({ ...prev, [field]: value }));

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setLoading(true);
        setError('');

        try {
            const res = await fetch('/api/admin/dealers', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(form),
            });
            const data = await res.json();
            if (!res.ok) throw new Error(data.error || 'Failed to create dealer');
            setTempPassword(data.tempPassword ?? '');
            setForm({ companyName: '', contactName: '', email: '', phone: '', city: '', state: '', slug: '', ownerEmail: '', subscriptionTier: 'STARTER' });
            router.refresh();
        } catch (err: any) {
            setError(err.message);
        } finally {
            setLoading(false);
        }
    };

    const handleClose = () => {
        setForm({ companyName: '', contactName: '', email: '', phone: '', city: '', state: '', slug: '', ownerEmail: '', subscriptionTier: 'STARTER' });
        setError('');
        setTempPassword('');
        onClose();
    };


    const field = (label: string, id: string, field: string, opts?: { type?: string; placeholder?: string; required?: boolean }) => (
        <div className="form-group">
            <label className="form-label" htmlFor={id}>
                {label}{opts?.required && <span style={{ color: 'var(--color-danger, #ef4444)' }}> *</span>}
            </label>
            <input
                id={id}
                type={opts?.type ?? 'text'}
                className="form-input"
                placeholder={opts?.placeholder ?? ''}
                value={(form as any)[field]}
                onChange={(e) => update(field, e.target.value)}
                required={opts?.required}
            />
        </div>
    );

    return (
        <Modal
            isOpen={isOpen}
            onClose={handleClose}
            title="Add Dealer"
            subtitle="Onboard a new dealer to the HearthSync Dealer Portal."
            size="md"
            footer={
                <>
                    <button className="btn btn-ghost" onClick={handleClose} disabled={loading}>
                        {tempPassword ? 'Done' : 'Cancel'}
                    </button>
                    {!tempPassword && (
                        <button className="btn btn-primary" onClick={handleSubmit as any} disabled={loading}>
                            {loading ? 'Creating…' : 'Create Dealer'}
                        </button>
                    )}
                </>
            }
        >
            <form onSubmit={handleSubmit} style={{ padding: '1.5rem', display: 'flex', flexDirection: 'column', gap: 'var(--space-4)' }}>
                {/* Temp password success state */}
                {tempPassword && (
                    <div style={{
                        padding: 'var(--space-4)',
                        background: 'rgba(34,197,94,0.1)',
                        border: '1px solid rgba(34,197,94,0.3)',
                        borderRadius: 'var(--radius-md)',
                        display: 'flex',
                        flexDirection: 'column',
                        gap: 'var(--space-2)',
                    }}>
                        <p style={{ fontWeight: 600, color: '#22c55e', fontSize: 'var(--font-size-sm)', margin: 0 }}>
                            ✓ Dealer created successfully
                        </p>
                        <p style={{ fontSize: 'var(--font-size-sm)', color: 'var(--color-text-muted)', margin: 0 }}>
                            Share this temporary password with the dealer owner — it will not be shown again.
                        </p>
                        <div
                            style={{
                                display: 'flex', alignItems: 'center', gap: 'var(--space-2)',
                                background: 'var(--color-surface)', border: '1px solid var(--color-border)',
                                borderRadius: 'var(--radius-sm)', padding: '0.5rem 0.75rem',
                                fontFamily: 'monospace', fontSize: '1rem', fontWeight: 700,
                                letterSpacing: '0.05em', color: 'var(--color-text)',
                                cursor: 'pointer', userSelect: 'all',
                            }}
                            title="Click to select"
                            onClick={(e) => {
                                const range = document.createRange();
                                range.selectNodeContents(e.currentTarget);
                                window.getSelection()?.removeAllRanges();
                                window.getSelection()?.addRange(range);
                            }}
                        >
                            {tempPassword}
                        </div>
                    </div>
                )}

                {error && (
                    <div style={{
                        padding: 'var(--space-3)',
                        background: 'rgba(239,68,68,0.1)',
                        border: '1px solid rgba(239,68,68,0.3)',
                        borderRadius: 'var(--radius-md)',
                        color: '#ef4444',
                        fontSize: 'var(--font-size-sm)',
                    }}>
                        ✗ {error}
                    </div>
                )}

                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 'var(--space-4)' }}>
                    {field('Company Name', 'dealer-company', 'companyName', { required: true, placeholder: 'Acme Hearth & Home' })}
                    {field('Contact Name', 'dealer-contact', 'contactName', { required: true, placeholder: 'Jane Smith' })}
                </div>

                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 'var(--space-4)' }}>
                    {field('Company Email', 'dealer-email', 'email', { required: true, type: 'email', placeholder: 'info@acmehearth.com' })}
                    {field('Phone', 'dealer-phone', 'phone', { placeholder: '(555) 000-0000' })}
                </div>

                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 'var(--space-4)' }}>
                    {field('Owner User Email', 'dealer-owner-email', 'ownerEmail', { required: true, type: 'email', placeholder: 'jane@acmehearth.com' })}
                    {field('City', 'dealer-city', 'city', { placeholder: 'Nashville' })}
                </div>

                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 'var(--space-4)' }}>
                    {field('State', 'dealer-state', 'state', { placeholder: 'TN' })}
                </div>

                {/* Slug */}
                <div className="form-group">
                    <label className="form-label" htmlFor="dealer-slug">
                        Portal Slug <span style={{ color: 'var(--color-text-muted)', fontWeight: 400 }}>(optional — auto-generated if blank)</span>
                    </label>
                    <div style={{ display: 'flex', gap: 'var(--space-2)', alignItems: 'center' }}>
                        <input
                            id="dealer-slug"
                            type="text"
                            className="form-input"
                            placeholder="e.g. acme-hearth"
                            value={form.slug}
                            onChange={(e) => update('slug', e.target.value.toLowerCase().replace(/[^a-z0-9-]/g, '-').replace(/-+/g, '-'))}
                            style={{ flex: 1 }}
                        />
                        <button
                            type="button"
                            className="btn btn-ghost"
                            style={{ whiteSpace: 'nowrap', padding: 'var(--space-2) var(--space-3)' }}
                            onClick={() => update('slug', toSlug(form.companyName))}
                            disabled={!form.companyName}
                        >
                            Auto-generate
                        </button>
                    </div>
                </div>

                <div className="form-group">
                    <label className="form-label" htmlFor="dealer-tier">Subscription Tier</label>
                    <select
                        id="dealer-tier"
                        className="form-select"
                        value={form.subscriptionTier}
                        onChange={(e) => update('subscriptionTier', e.target.value)}
                    >
                        {TIERS.map((t) => (
                            <option key={t} value={t}>{t.charAt(0) + t.slice(1).toLowerCase()}</option>
                        ))}
                    </select>
                </div>
            </form>
        </Modal>
    );
}
