import prisma from '@/lib/db';
import DealersPageClient from './DealersPageClient';

async function getDealers() {
    try {
        return await prisma.dealerAccount.findMany({
            orderBy: { createdAt: 'desc' },
            include: {
                _count: { select: { catalogSelections: true } },
            },
        });
    } catch (err) {
        console.error('[DealerAccountsPage] Failed to load dealers', err);
        return [];
    }
}

export default async function DealerAccountsPage() {
    const dealers = await getDealers();
    return <DealersPageClient dealers={dealers} />;
}
