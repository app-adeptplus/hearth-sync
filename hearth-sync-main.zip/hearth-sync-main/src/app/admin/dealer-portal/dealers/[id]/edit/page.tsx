import { notFound } from 'next/navigation';
import prisma from '@/lib/db';
import EditDealerClient from './EditDealerClient';

interface PageProps {
    params: {
        id: string;
    };
}

export default async function EditDealerPage({ params }: PageProps) {
    const dealer = await prisma.dealerAccount.findUnique({
        where: { id: params.id },
        include: { users: true },
    });

    if (!dealer) {
        notFound();
    }

    return <EditDealerClient dealer={dealer} />;
}
