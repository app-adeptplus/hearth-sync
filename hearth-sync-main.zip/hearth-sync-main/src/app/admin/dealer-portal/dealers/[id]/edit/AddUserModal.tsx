'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import Modal from '@/components/Modal';
import type { DealerUser } from '@prisma/client';

interface Props {
    dealerId: string;
    isOpen: boolean;
    onClose: () => void;
    user?: DealerUser | null;
}

export default function AddUserModal({ dealerId, isOpen, onClose, user }: Props) {
    const router = useRouter();
    const [email, setEmail] = useState(user?.email || '');
    const [role, setRole] = useState(user?.role || 'member');
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState('');
    const [tempPassword, setTempPassword] = useState('');

    // Reset when modal opens/closes with different user
    useState(() => {
        setEmail(user?.email || '');
        setRole(user?.role || 'member');
    });

    const handleClose = () => {
        setEmail('');
        setRole('member');
        setError('');
        setTempPassword('');
        onClose();
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setLoading(true);
        setError('');

        try {
            const url = user
                ? `/api/admin/dealers/${dealerId}/users/${user.id}`
                : `/api/admin/dealers/${dealerId}/users`;

            const res = await fetch(url, {
                method: user ? 'PUT' : 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ email, role }),
            });
            const data = await res.json();
            if (!res.ok) throw new Error(data.error || `Failed to ${user ? 'update' : 'add'} user`);

            if (!user && data.tempPassword) {
                // Show temp password before closing
                setTempPassword(data.tempPassword);
                router.refresh();
            } else {
                handleClose();
                router.refresh();
            }
        } catch (err: any) {
            setError(err.message);
        } finally {
            setLoading(false);
        }
    };

    return (
        <Modal
            isOpen={isOpen}
            onClose={handleClose}
            title={user ? "Edit Portal User" : "Add Portal User"}
            subtitle={user ? "Update access details for this user." : "Grant a user access to this dealer's portal."}
            size="md"
            footer={
                <>
                    <button className="btn btn-ghost" onClick={handleClose} disabled={loading}>
                        {tempPassword ? 'Done' : 'Cancel'}
                    </button>
                    {!tempPassword && (
                        <button className="btn btn-primary" onClick={handleSubmit as any} disabled={loading || !email}>
                            {loading ? 'Saving…' : (user ? 'Save Changes' : 'Add User')}
                        </button>
                    )}
                </>
            }
        >
            <form onSubmit={handleSubmit} style={{ padding: '1.5rem', display: 'flex', flexDirection: 'column', gap: 'var(--space-4)' }}>
                {/* Temp password success state */}
                {tempPassword && (
                    <div style={{
                        padding: 'var(--space-4)',
                        background: 'rgba(34,197,94,0.1)',
                        border: '1px solid rgba(34,197,94,0.3)',
                        borderRadius: 'var(--radius-md)',
                        display: 'flex', flexDirection: 'column', gap: 'var(--space-2)',
                    }}>
                        <p style={{ fontWeight: 600, color: '#22c55e', fontSize: 'var(--font-size-sm)', margin: 0 }}>
                            ✓ User added successfully
                        </p>
                        <p style={{ fontSize: 'var(--font-size-sm)', color: 'var(--color-text-muted)', margin: 0 }}>
                            Share this temporary password — it will not be shown again.
                        </p>
                        <div
                            style={{
                                background: 'var(--color-surface)', border: '1px solid var(--color-border)',
                                borderRadius: 'var(--radius-sm)', padding: '0.5rem 0.75rem',
                                fontFamily: 'monospace', fontSize: '1rem', fontWeight: 700,
                                letterSpacing: '0.05em', cursor: 'pointer', userSelect: 'all',
                            }}
                            title="Click to select"
                            onClick={(e) => {
                                const range = document.createRange();
                                range.selectNodeContents(e.currentTarget);
                                window.getSelection()?.removeAllRanges();
                                window.getSelection()?.addRange(range);
                            }}
                        >
                            {tempPassword}
                        </div>
                    </div>
                )}
                {error && (
                    <div style={{
                        padding: 'var(--space-3)',
                        background: 'rgba(239,68,68,0.1)',
                        border: '1px solid rgba(239,68,68,0.3)',
                        borderRadius: 'var(--radius-md)',
                        color: '#ef4444',
                        fontSize: 'var(--font-size-sm)',
                    }}>
                        ✗ {error}
                    </div>
                )}
                <div className="form-group">
                    <label className="form-label" htmlFor="user-email">
                        Email Address <span style={{ color: 'var(--color-danger, #ef4444)' }}>*</span>
                    </label>
                    <input
                        id="user-email"
                        type="email"
                        className="form-input"
                        placeholder="user@example.com"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        required
                    />
                </div>

                <div className="form-group">
                    <label className="form-label" htmlFor="user-role">Role</label>
                    <select
                        id="user-role"
                        className="form-select"
                        value={role}
                        onChange={(e) => setRole(e.target.value)}
                    >
                        <option value="owner">Owner</option>
                        <option value="admin">Admin</option>
                        <option value="member">Member</option>
                    </select>
                </div>
            </form>
        </Modal>
    );
}
