'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import type { DealerAccount, DealerUser } from '@prisma/client';
import AddUserModal from './AddUserModal';
import LoginAsDealerButton from '../../LoginAsDealerButton';

const TIERS = ['STARTER', 'PROFESSIONAL', 'ENTERPRISE'] as const;

function toSlug(s: string) {
    return s
        .toLowerCase()
        .replace(/[^a-z0-9\s-]/g, '')
        .trim()
        .replace(/\s+/g, '-')
        .replace(/-+/g, '-');
}

interface Props {
    dealer: DealerAccount & { users: DealerUser[] };
}

export default function EditDealerClient({ dealer }: Props) {
    const router = useRouter();
    const [form, setForm] = useState({
        companyName: dealer.companyName,
        contactName: dealer.contactName,
        phone: dealer.phone || '',
        city: dealer.city || '',
        state: dealer.state || '',
        slug: dealer.slug || '',
        subscriptionTier: dealer.subscriptionTier,
        subscriptionStatus: dealer.subscriptionStatus,
    });
    const [loading, setLoading] = useState(false);
    const [userLoading, setUserLoading] = useState(false);
    const [error, setError] = useState('');
    const [addUserOpen, setAddUserOpen] = useState(false);
    const [editingUser, setEditingUser] = useState<DealerUser | null>(null);

    const update = (field: string, value: string) => setForm(prev => ({ ...prev, [field]: value }));

    const handleSave = async (e: React.FormEvent) => {
        e.preventDefault();
        setLoading(true);
        setError('');

        try {
            const res = await fetch(`/api/admin/dealers/${dealer.id}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(form),
            });
            const data = await res.json();
            if (!res.ok) throw new Error(data.error || 'Failed to update dealer');
            router.refresh();
        } catch (err: any) {
            setError(err.message);
        } finally {
            setLoading(false);
        }
    };

    const handleRemoveUser = async (userId: string) => {
        if (!confirm('Are you sure you want to remove this user from the portal?')) return;
        setUserLoading(true);
        setError('');

        try {
            const res = await fetch(`/api/admin/dealers/${dealer.id}/users/${userId}`, {
                method: 'DELETE',
            });
            const data = await res.json();
            if (!res.ok) throw new Error(data.error || 'Failed to remove user');
            router.refresh();
        } catch (err: any) {
            setError(err.message);
        } finally {
            setUserLoading(false);
        }
    };

    const field = (label: string, id: string, name: keyof typeof form, required = false) => (
        <div className="form-group">
            <label className="form-label" htmlFor={id}>
                {label}{required && <span style={{ color: '#ef4444' }}> *</span>}
            </label>
            <input
                id={id}
                type="text"
                className="form-input"
                value={form[name]}
                onChange={(e) => update(name, e.target.value)}
                required={required}
            />
        </div>
    );

    return (
        <div style={{ maxWidth: '800px' }}>
            <div className="page-header" style={{ marginBottom: 'var(--space-6)' }}>
                <div>
                    <h2 className="page-title">Edit Dealer Account</h2>
                    <p className="page-subtitle">{dealer.companyName}</p>
                </div>
                <div style={{ display: 'flex', gap: 'var(--space-2)', alignItems: 'center' }}>
                    <LoginAsDealerButton
                        dealerId={dealer.id}
                        dealerSlug={(dealer as any).slug ?? null}
                        companyName={dealer.companyName}
                    />
                    <button className="btn btn-ghost" onClick={() => router.back()} disabled={loading}>
                        Cancel
                    </button>
                    <button className="btn btn-primary" onClick={handleSave} disabled={loading}>
                        {loading ? 'Saving…' : 'Save Changes'}
                    </button>
                </div>
            </div>

            {error && (
                <div style={{
                    padding: 'var(--space-3)',
                    background: 'rgba(239,68,68,0.1)',
                    border: '1px solid rgba(239,68,68,0.3)',
                    borderRadius: 'var(--radius-md)',
                    color: '#ef4444',
                    fontSize: 'var(--font-size-sm)',
                    marginBottom: 'var(--space-6)'
                }}>
                    ✗ {error}
                </div>
            )}

            <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-6)' }}>
                <div className="card" style={{ padding: 'var(--space-6)' }}>
                    <h3 style={{ fontSize: 'var(--font-size-lg)', fontWeight: 600, marginBottom: 'var(--space-4)' }}>General Information</h3>
                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 'var(--space-4)' }}>
                        {field('Company Name', 'dealer-company', 'companyName', true)}
                        {field('Contact Name', 'dealer-contact', 'contactName', true)}
                    </div>
                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 'var(--space-4)', marginTop: 'var(--space-4)' }}>
                        {field('Phone', 'dealer-phone', 'phone')}
                        {field('City', 'dealer-city', 'city')}
                    </div>
                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 'var(--space-4)', marginTop: 'var(--space-4)' }}>
                        {field('State', 'dealer-state', 'state')}

                        <div className="form-group">
                            <label className="form-label" htmlFor="dealer-tier">Subscription Tier</label>
                            <select
                                id="dealer-tier"
                                className="form-select"
                                value={form.subscriptionTier}
                                onChange={(e) => update('subscriptionTier', e.target.value)}
                            >
                                {TIERS.map((t) => (
                                    <option key={t} value={t}>{t.charAt(0) + t.slice(1).toLowerCase()}</option>
                                ))}
                            </select>
                        </div>
                    </div>
                    <div style={{ marginTop: 'var(--space-4)', maxWidth: '50%' }}>
                        <div className="form-group">
                            <label className="form-label" htmlFor="dealer-status">Status</label>
                            <select
                                id="dealer-status"
                                className="form-select"
                                value={form.subscriptionStatus}
                                onChange={(e) => update('subscriptionStatus', e.target.value)}
                            >
                                <option value="active">Active</option>
                                <option value="inactive">Inactive</option>
                                <option value="suspended">Suspended</option>
                            </select>
                        </div>
                    </div>

                    {/* Slug / Dealer Portal URL */}
                    <div style={{ marginTop: 'var(--space-4)', padding: 'var(--space-4)', background: 'rgba(var(--color-primary-rgb, 99,102,241), 0.05)', border: '1px solid rgba(var(--color-primary-rgb, 99,102,241), 0.15)', borderRadius: 'var(--radius-md)' }}>
                        <div className="form-group" style={{ marginBottom: 'var(--space-2)' }}>
                            <label className="form-label" htmlFor="dealer-slug">
                                Dealer Portal Slug <span style={{ color: 'var(--color-text-muted)', fontWeight: 400 }}>(optional)</span>
                            </label>
                            <div style={{ display: 'flex', gap: 'var(--space-2)', alignItems: 'center' }}>
                                <input
                                    id="dealer-slug"
                                    type="text"
                                    className="form-input"
                                    placeholder="e.g. acme-hearth"
                                    value={form.slug}
                                    onChange={(e) => update('slug', e.target.value.toLowerCase().replace(/[^a-z0-9-]/g, '-').replace(/-+/g, '-'))}
                                    style={{ flex: 1 }}
                                />
                                <button
                                    type="button"
                                    className="btn btn-ghost"
                                    style={{ whiteSpace: 'nowrap', padding: 'var(--space-2) var(--space-3)' }}
                                    onClick={() => update('slug', toSlug(form.companyName))}
                                >
                                    Auto-generate
                                </button>
                            </div>
                        </div>
                        {form.slug && (
                            <div style={{ fontSize: 'var(--font-size-xs)', color: 'var(--color-text-muted)', marginTop: 'var(--space-1)', display: 'flex', alignItems: 'center', gap: 'var(--space-2)' }}>
                                <span>🔗 Dealer portal URL:</span>
                                <a
                                    href={`/dealer/${form.slug}`}
                                    target="_blank"
                                    rel="noopener noreferrer"
                                    style={{ color: 'var(--color-primary)', fontFamily: 'monospace' }}
                                >
                                    /dealer/{form.slug}
                                </a>
                            </div>
                        )}
                    </div>
                </div>

                <div className="card" style={{ padding: 'var(--space-6)' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 'var(--space-4)' }}>
                        <div>
                            <h3 style={{ fontSize: 'var(--font-size-lg)', fontWeight: 600 }}>Portal Users</h3>
                            <p style={{ fontSize: 'var(--font-size-sm)', color: 'var(--color-text-muted)' }}>
                                Manage the users who have access to this dealer account portal.
                            </p>
                        </div>
                        <button className="btn btn-secondary" onClick={() => { setEditingUser(null); setAddUserOpen(true); }}>
                            + Add User
                        </button>
                    </div>

                    <table className="data-table" style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left' }}>
                        <thead>
                            <tr style={{ borderBottom: '1px solid var(--color-border)', color: 'var(--color-text-secondary)', fontSize: 'var(--font-size-sm)' }}>
                                <th style={{ paddingBottom: 'var(--space-2)' }}>Email Address</th>
                                <th style={{ paddingBottom: 'var(--space-2)' }}>Role</th>
                                <th style={{ paddingBottom: 'var(--space-2)' }}>Status</th>
                                <th style={{ paddingBottom: 'var(--space-2)', width: '60px' }}></th>
                            </tr>
                        </thead>
                        <tbody>
                            {dealer.users && dealer.users.length > 0 ? (
                                dealer.users.map(u => (
                                    <tr key={u.id} style={{ borderBottom: '1px solid var(--color-border-light)' }}>
                                        <td style={{ padding: 'var(--space-3) 0', fontWeight: 500 }}>{u.email}</td>
                                        <td style={{ padding: 'var(--space-3) 0', color: 'var(--color-text-secondary)' }}>
                                            {u.role.charAt(0).toUpperCase() + u.role.slice(1)}
                                        </td>
                                        <td style={{ padding: 'var(--space-3) 0' }}>
                                            {u.userId ? (
                                                <span className="badge badge-active">Registered</span>
                                            ) : (
                                                <span className="badge badge-warning">Invited</span>
                                            )}
                                        </td>
                                        <td style={{ padding: 'var(--space-3) 0', textAlign: 'right' }}>
                                            <button
                                                className="btn btn-ghost"
                                                style={{ color: 'var(--color-primary)', padding: 'var(--space-1) var(--space-2)', marginRight: 'var(--space-2)' }}
                                                onClick={() => { setEditingUser(u); setAddUserOpen(true); }}
                                                disabled={userLoading}
                                            >
                                                Edit
                                            </button>
                                            <button
                                                className="btn btn-ghost"
                                                style={{ color: '#ef4444', padding: 'var(--space-1) var(--space-2)' }}
                                                onClick={() => handleRemoveUser(u.id)}
                                                disabled={userLoading}
                                            >
                                                Remove
                                            </button>
                                        </td>
                                    </tr>
                                ))
                            ) : (
                                <tr>
                                    <td colSpan={4} style={{ padding: 'var(--space-4) 0', textAlign: 'center', color: 'var(--color-text-muted)' }}>
                                        No users have been configured for this dealer account.
                                    </td>
                                </tr>
                            )}
                        </tbody>
                    </table>
                </div>
            </div>

            <AddUserModal
                dealerId={dealer.id}
                isOpen={addUserOpen}
                user={editingUser}
                onClose={() => {
                    setAddUserOpen(false);
                    setEditingUser(null);
                }}
            />
        </div>
    );
}
