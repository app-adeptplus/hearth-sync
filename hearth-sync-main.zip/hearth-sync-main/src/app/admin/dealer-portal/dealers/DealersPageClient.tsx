'use client';

import { useState, useMemo } from 'react';
import Link from 'next/link';
import type { DealerAccount, SubscriptionTier } from '@prisma/client';
import AddDealerModal from './AddDealerModal';

type DealerWithCount = DealerAccount & { _count: { catalogSelections: number } };

interface Props {
    dealers: DealerWithCount[];
}

const TIER_BADGE: Record<SubscriptionTier, string> = {
    STARTER: 'badge-info',
    PROFESSIONAL: 'badge-warning',
    ENTERPRISE: 'badge-active',
};

function formatDate(d: Date | null) {
    if (!d) return '—';
    return new Date(d).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
}

export default function DealersPageClient({ dealers }: Props) {
    const [addOpen, setAddOpen] = useState(false);
    const [search, setSearch] = useState('');
    const [tier, setTier] = useState('');

    const filtered = useMemo(() => {
        return dealers.filter((d) => {
            const q = search.toLowerCase();
            const matchesSearch =
                !search ||
                d.companyName.toLowerCase().includes(q) ||
                d.contactName.toLowerCase().includes(q) ||
                d.email.toLowerCase().includes(q);
            const matchesTier = !tier || d.subscriptionTier === tier;
            return matchesSearch && matchesTier;
        });
    }, [dealers, search, tier]);

    return (
        <>
            <div className="page-header">
                <div>
                    <h2 className="page-title">Dealer Accounts</h2>
                    <p className="page-subtitle">
                        {dealers.length} dealer{dealers.length !== 1 ? 's' : ''} in the HearthSync Dealer Portal
                    </p>
                </div>
                <button className="btn btn-primary" onClick={() => setAddOpen(true)}>
                    + Add Dealer
                </button>
            </div>

            {/* Filters */}
            <div style={{ display: 'flex', gap: 'var(--space-3)', marginBottom: 'var(--space-6)', flexWrap: 'wrap' }}>
                <input
                    type="text"
                    className="form-input"
                    placeholder="Search by company, contact, or email…"
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                    style={{ maxWidth: '360px' }}
                />
                <select
                    className="form-select"
                    value={tier}
                    onChange={(e) => setTier(e.target.value)}
                    style={{ maxWidth: '180px' }}
                >
                    <option value="">All Tiers</option>
                    <option value="STARTER">Starter</option>
                    <option value="PROFESSIONAL">Professional</option>
                    <option value="ENTERPRISE">Enterprise</option>
                </select>
                {(search || tier) && (
                    <button className="btn btn-ghost" onClick={() => { setSearch(''); setTier(''); }} style={{ padding: 'var(--space-2) var(--space-3)' }}>
                        Clear
                    </button>
                )}
            </div>

            <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
                <table className="data-table">
                    <thead>
                        <tr>
                            <th scope="col">Company</th>
                            <th scope="col">Contact</th>
                            <th scope="col">Location</th>
                            <th scope="col">Tier</th>
                            <th scope="col">Status</th>
                            <th scope="col">Portal</th>
                            <th scope="col" style={{ width: '140px' }}></th>
                            <th scope="col">Catalog</th>
                            <th scope="col">Created</th>
                        </tr>
                    </thead>
                    <tbody>
                        {filtered.length === 0 ? (
                            <tr>
                                <td colSpan={7}>
                                    <div className="empty-state">
                                        <h3>{search || tier ? 'No dealers match your filters' : 'No dealers yet'}</h3>
                                        <p>
                                            {search || tier
                                                ? 'Try adjusting your search or tier filter.'
                                                : 'Click "+ Add Dealer" to onboard your first dealer.'}
                                        </p>
                                    </div>
                                </td>
                            </tr>
                        ) : (
                            filtered.map((dealer) => (
                                <tr key={dealer.id}>
                                    <td>
                                        <div style={{ fontWeight: 600 }}>
                                            <Link href={`/admin/dealer-portal/dealers/${dealer.id}/edit`} style={{ color: 'inherit', textDecoration: 'underline' }}>
                                                {dealer.companyName}
                                            </Link>
                                        </div>
                                        <div style={{ fontSize: 'var(--font-size-xs)', color: 'var(--color-text-muted)' }}>
                                            {dealer.email}
                                        </div>
                                    </td>
                                    <td style={{ color: 'var(--color-text-secondary)' }}>{dealer.contactName}</td>
                                    <td style={{ fontSize: 'var(--font-size-xs)', color: 'var(--color-text-muted)' }}>
                                        {[dealer.city, dealer.state].filter(Boolean).join(', ') || '—'}
                                    </td>
                                    <td>
                                        <span className={`badge ${TIER_BADGE[dealer.subscriptionTier]}`}>
                                            {dealer.subscriptionTier.charAt(0) + dealer.subscriptionTier.slice(1).toLowerCase()}
                                        </span>
                                    </td>
                                    <td>
                                        <span className={`badge ${dealer.subscriptionStatus === 'active' ? 'badge-active' : 'badge-inactive'}`}>
                                            {dealer.subscriptionStatus}
                                        </span>
                                    </td>
                                    <td style={{ fontSize: 'var(--font-size-xs)' }}>
                                        {dealer.slug ? (
                                            <a
                                                href={`/dealer/${dealer.slug}`}
                                                target="_blank"
                                                rel="noopener noreferrer"
                                                style={{ color: 'var(--color-primary)', fontFamily: 'monospace' }}
                                            >
                                                /{dealer.slug}
                                            </a>
                                        ) : (
                                            <span style={{ color: 'var(--color-text-muted)', fontStyle: 'italic' }}>no slug</span>
                                        )}
                                    </td>
                                    <td>
                                        {dealer.slug ? (
                                            <a
                                                href={`/dealer/${dealer.slug}/catalog`}
                                                target="_blank"
                                                rel="noopener noreferrer"
                                                className="btn btn-ghost"
                                                style={{ padding: 'var(--space-1) var(--space-3)', fontSize: 'var(--font-size-xs)' }}
                                            >
                                                View Portal ↗
                                            </a>
                                        ) : (
                                            <span style={{ color: 'var(--color-text-muted)', fontSize: 'var(--font-size-xs)', fontStyle: 'italic' }}>No slug set</span>
                                        )}
                                    </td>
                                    <td style={{ fontWeight: 500, color: 'var(--color-amber)' }}>
                                        {dealer._count.catalogSelections}
                                    </td>
                                    <td style={{ fontSize: 'var(--font-size-xs)', color: 'var(--color-text-muted)' }}>
                                        {formatDate(dealer.createdAt)}
                                    </td>
                                </tr>
                            ))
                        )}
                    </tbody>
                </table>
            </div>

            <AddDealerModal isOpen={addOpen} onClose={() => setAddOpen(false)} />
        </>
    );
}
