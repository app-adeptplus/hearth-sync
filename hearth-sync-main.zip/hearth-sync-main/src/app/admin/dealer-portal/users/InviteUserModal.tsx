'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import Modal from '@/components/Modal';

interface InviteUserModalProps {
    isOpen: boolean;
    onClose: () => void;
}

export default function InviteUserModal({ isOpen, onClose }: InviteUserModalProps) {
    const router = useRouter();
    const [name, setName] = useState('');
    const [email, setEmail] = useState('');
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState('');
    const [tempPassword, setTempPassword] = useState('');

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setLoading(true);
        setError('');
        setTempPassword('');

        try {
            const res = await fetch('/api/admin/users', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ name, email }),
            });
            const data = await res.json();
            if (!res.ok) throw new Error(data.error || 'Failed to create user');
            setTempPassword(data.tempPassword);
            setName('');
            setEmail('');
            router.refresh();
        } catch (err: any) {
            setError(err.message);
        } finally {
            setLoading(false);
        }
    };

    const handleClose = () => {
        setName('');
        setEmail('');
        setError('');
        setTempPassword('');
        onClose();
    };

    return (
        <Modal
            isOpen={isOpen}
            onClose={handleClose}
            title="Create Admin User"
            subtitle="Create a new user to grant access to the HearthSync Admin Dashboard."
            size="sm"
            footer={
                <>
                    <button className="btn btn-ghost" onClick={handleClose} disabled={loading}>
                        {tempPassword ? 'Done' : 'Cancel'}
                    </button>
                    {!tempPassword && (
                        <button
                            className="btn btn-primary"
                            onClick={handleSubmit as any}
                            disabled={loading || !email || !name}
                        >
                            {loading ? 'Creating…' : 'Create User'}
                        </button>
                    )}
                </>
            }
        >
            <form onSubmit={handleSubmit} style={{ padding: '1.5rem', display: 'flex', flexDirection: 'column', gap: 'var(--space-4)' }}>
                {/* Temp password success state */}
                {tempPassword && (
                    <div style={{
                        padding: 'var(--space-4)',
                        background: 'rgba(34,197,94,0.1)',
                        border: '1px solid rgba(34,197,94,0.3)',
                        borderRadius: 'var(--radius-md)',
                        display: 'flex',
                        flexDirection: 'column',
                        gap: 'var(--space-2)',
                    }}>
                        <p style={{ fontWeight: 600, color: '#22c55e', fontSize: 'var(--font-size-sm)', margin: 0 }}>
                            ✓ User created successfully
                        </p>
                        <p style={{ fontSize: 'var(--font-size-sm)', color: 'var(--color-text-muted)', margin: 0 }}>
                            Share this temporary password with the user — it will not be shown again.
                        </p>
                        <div
                            style={{
                                display: 'flex',
                                alignItems: 'center',
                                gap: 'var(--space-2)',
                                background: 'var(--color-surface)',
                                border: '1px solid var(--color-border)',
                                borderRadius: 'var(--radius-sm)',
                                padding: '0.5rem 0.75rem',
                                fontFamily: 'monospace',
                                fontSize: '1rem',
                                fontWeight: 700,
                                letterSpacing: '0.05em',
                                color: 'var(--color-text)',
                                cursor: 'pointer',
                                userSelect: 'all',
                            }}
                            title="Click to select"
                            onClick={(e) => {
                                const el = e.currentTarget;
                                const range = document.createRange();
                                range.selectNodeContents(el);
                                window.getSelection()?.removeAllRanges();
                                window.getSelection()?.addRange(range);
                            }}
                        >
                            {tempPassword}
                        </div>
                    </div>
                )}

                {/* Error banner */}
                {error && (
                    <div style={{
                        padding: 'var(--space-3)',
                        background: 'rgba(239,68,68,0.1)',
                        border: '1px solid rgba(239,68,68,0.3)',
                        borderRadius: 'var(--radius-md)',
                        color: '#ef4444',
                        fontSize: 'var(--font-size-sm)',
                    }}>
                        ✗ {error}
                    </div>
                )}

                {/* Input fields — hidden after success */}
                {!tempPassword && (
                    <>
                        <div className="form-group">
                            <label className="form-label" htmlFor="user-name">Full Name</label>
                            <input
                                id="user-name"
                                type="text"
                                className="form-input"
                                placeholder="John Doe"
                                value={name}
                                onChange={(e) => setName(e.target.value)}
                                required
                                autoFocus
                            />
                        </div>
                        <div className="form-group">
                            <label className="form-label" htmlFor="user-email">Email Address</label>
                            <input
                                id="user-email"
                                type="email"
                                className="form-input"
                                placeholder="user@example.com"
                                value={email}
                                onChange={(e) => setEmail(e.target.value)}
                                required
                            />
                        </div>
                        <p style={{ margin: 0, fontSize: 'var(--font-size-xs)', color: 'var(--color-text-muted)' }}>
                            A temporary password will be generated automatically. Share it with the user after creation.
                        </p>
                    </>
                )}
            </form>
        </Modal>
    );
}
