import { createServiceClient } from '@/lib/supabase';
import UsersPageClient from './UsersPageClient';

// Always fetch fresh from Supabase — never serve a cached user list
export const dynamic = 'force-dynamic';

async function getAdminUsers() {
    const supabase = createServiceClient();
    const allUsers = [];
    let page = 1;
    const perPage = 1000;

    try {
        while (true) {
            const { data, error } = await supabase.auth.admin.listUsers({ page, perPage });
            if (error) throw error;
            const users = data?.users ?? [];
            allUsers.push(...users);
            if (users.length < perPage) break;
            page++;
        }

        // Only surface users explicitly tagged as HearthSync admins in app_metadata.
        // app_metadata is writable only via the service role key — it is tamper-proof.
        // user_metadata is NOT checked here: it is user-editable and must not be trusted
        // for access control decisions.
        const adminUsers = allUsers.filter((u) => {
            // Cast to any: the Supabase User type does not fully expose app_metadata
            // but the field is present on the raw response from listUsers().
            const meta = (u as any).app_metadata ?? {};
            return meta.portal_role === 'admin';
        });

        return { users: adminUsers, error: null };

    } catch (err: any) {
        console.error('[UserAccountsPage] Failed to load users:', err?.message ?? err);
        return { users: [], error: err?.message ?? 'Failed to load users from Supabase' };
    }
}

export default async function UserAccountsPage() {
    const { users, error } = await getAdminUsers();
    return <UsersPageClient users={users} fetchError={error} />;
}

