'use client';

import { useState, useMemo } from 'react';
import type { User } from '@supabase/supabase-js';
import InviteUserModal from './InviteUserModal';
import EditUserModal from './EditUserModal';

interface Props {
    users: User[];
    fetchError?: string | null;
}

function StatusBadge({ user }: { user: User }) {
    if (!user.confirmed_at) return <span className="badge badge-warning">Pending</span>;
    if (user.banned_until) return <span className="badge badge-danger">Banned</span>;
    return <span className="badge badge-active">Active</span>;
}

function formatDate(iso?: string | null) {
    if (!iso) return '—';
    return new Date(iso).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
}

export default function UsersPageClient({ users: initialUsers, fetchError }: Props) {
    const [users, setUsers] = useState<User[]>(initialUsers);
    const [inviteOpen, setInviteOpen] = useState(false);
    const [editingUser, setEditingUser] = useState<User | null>(null);
    const [search, setSearch] = useState('');

    const filtered = useMemo(() => {
        if (!search.trim()) return users;
        const q = search.toLowerCase();
        return users.filter(
            (u) =>
                u.email?.toLowerCase().includes(q) ||
                (u.user_metadata?.full_name as string | undefined)?.toLowerCase().includes(q)
        );
    }, [users, search]);

    // Called when a user is successfully saved in the edit modal
    const handleUserSaved = (updated: User) => {
        setUsers(prev => prev.map(u => u.id === updated.id ? updated : u));
    };

    // Called when a user is deleted in the edit modal
    const handleUserDeleted = (id: string) => {
        setUsers(prev => prev.filter(u => u.id !== id));
    };

    return (
        <>
            {fetchError && (
                <div style={{ padding: '0.875rem 1rem', background: 'rgba(239,68,68,0.1)', border: '1px solid rgba(239,68,68,0.3)', borderRadius: '8px', color: '#ef4444', fontSize: 'var(--font-size-sm)', marginBottom: 'var(--space-5)', display: 'flex', gap: 'var(--space-2)', alignItems: 'center' }}>
                    <span>⚠️</span>
                    <span><strong>Failed to load users:</strong> {fetchError} — check that <code>SUPABASE_SERVICE_ROLE_KEY</code> is set in your environment.</span>
                </div>
            )}

            <div className="page-header">
                <div>
                    <h2 className="page-title">Admin Users</h2>
                    <p className="page-subtitle">
                        {users.length} user{users.length !== 1 ? 's' : ''} with access to the HearthSync Admin Dashboard
                    </p>
                </div>
                <button className="btn btn-primary" onClick={() => setInviteOpen(true)}>
                    + Create User
                </button>
            </div>

            {/* Search */}
            <div style={{ marginBottom: 'var(--space-6)', display: 'flex', gap: 'var(--space-3)' }}>
                <input
                    type="text"
                    className="form-input"
                    placeholder="Search by email or name…"
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                    style={{ maxWidth: '360px' }}
                />
                {search && (
                    <button className="btn btn-ghost" onClick={() => setSearch('')} style={{ padding: 'var(--space-2) var(--space-3)' }}>
                        Clear
                    </button>
                )}
            </div>

            <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
                <table className="data-table">
                    <thead>
                        <tr>
                            <th scope="col">Email</th>
                            <th scope="col">Name</th>
                            <th scope="col">Status</th>
                            <th scope="col">Last Sign In</th>
                            <th scope="col">Created</th>
                            <th scope="col" style={{ width: '80px' }}></th>
                        </tr>
                    </thead>
                    <tbody>
                        {filtered.length === 0 ? (
                            <tr>
                                <td colSpan={6}>
                                    <div className="empty-state">
                                        <h3>{search ? 'No users match your search' : 'No users yet'}</h3>
                                        <p>
                                            {search
                                                ? 'Try a different search term.'
                                                : 'Use the Create User button to grant someone access.'}
                                        </p>
                                    </div>
                                </td>
                            </tr>
                        ) : (
                            filtered.map((user) => {
                                const name = user.user_metadata?.full_name as string | undefined;
                                return (
                                    <tr key={user.id}>
                                        <td style={{ fontWeight: 500 }}>{user.email}</td>
                                        <td style={{ color: 'var(--color-text-secondary)' }}>
                                            {name || <span style={{ color: 'var(--color-text-muted)' }}>—</span>}
                                        </td>
                                        <td><StatusBadge user={user} /></td>
                                        <td style={{ fontSize: 'var(--font-size-xs)', color: 'var(--color-text-muted)' }}>
                                            {formatDate(user.last_sign_in_at)}
                                        </td>
                                        <td style={{ fontSize: 'var(--font-size-xs)', color: 'var(--color-text-muted)' }}>
                                            {formatDate(user.created_at)}
                                        </td>
                                        <td>
                                            <button
                                                className="btn btn-ghost"
                                                style={{ padding: 'var(--space-1) var(--space-3)', fontSize: 'var(--font-size-xs)' }}
                                                onClick={() => setEditingUser(user)}
                                            >
                                                Edit
                                            </button>
                                        </td>
                                    </tr>
                                );
                            })
                        )}
                    </tbody>
                </table>
            </div>

            <InviteUserModal isOpen={inviteOpen} onClose={() => setInviteOpen(false)} />
            <EditUserModal
                user={editingUser}
                onClose={() => setEditingUser(null)}
                onSaved={handleUserSaved}
                onDeleted={handleUserDeleted}
            />
        </>
    );
}
