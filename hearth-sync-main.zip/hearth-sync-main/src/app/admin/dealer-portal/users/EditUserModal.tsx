'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import type { User } from '@supabase/supabase-js';
import Modal from '@/components/Modal';

interface Props {
    user: User | null;
    onClose: () => void;
    onSaved: (updated: User) => void;
    onDeleted: (id: string) => void;
}

export default function EditUserModal({ user, onClose, onSaved, onDeleted }: Props) {
    const router = useRouter();
    const [name, setName] = useState('');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [confirmDelete, setConfirmDelete] = useState(false);
    const [isOrphaned, setIsOrphaned] = useState(false);
    const [loading, setLoading] = useState(false);
    const [deleteLoading, setDeleteLoading] = useState(false);
    const [error, setError] = useState('');
    const [success, setSuccess] = useState('');

    // Populate fields when user changes
    useEffect(() => {
        if (user) {
            setName((user.user_metadata?.full_name as string) ?? '');
            setEmail(user.email ?? '');
            setPassword('');
            setError('');
            setSuccess('');
            setConfirmDelete(false);
            setIsOrphaned(false);
        }
    }, [user]);

    const handleSave = async () => {
        if (!user) return;
        setLoading(true);
        setError('');
        setSuccess('');

        try {
            const payload: Record<string, string> = {};
            const trimmedName = name.trim();
            const trimmedEmail = email.trim().toLowerCase();
            const trimmedPw = password.trim();

            // Only send changed fields
            if (trimmedName !== (user.user_metadata?.full_name ?? '')) payload.name = trimmedName;
            if (trimmedEmail !== (user.email ?? '')) payload.email = trimmedEmail;
            if (trimmedPw) payload.password = trimmedPw;

            if (Object.keys(payload).length === 0) {
                setSuccess('No changes to save.');
                setLoading(false);
                return;
            }

            const res = await fetch(`/api/admin/users/${user.id}`, {
                method: 'PATCH',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload),
            });
            const data = await res.json();

            // Detect orphaned account (exists in list but not in Supabase Auth)
            if (res.status === 404 && data.isOrphaned) {
                setIsOrphaned(true);
                setLoading(false);
                return;
            }

            if (!res.ok) throw new Error(data.error || 'Failed to update user');

            setSuccess('User updated successfully.');
            setPassword('');
            onSaved(data.user);
            router.refresh();
        } catch (err: any) {
            setError(err.message);
        } finally {
            setLoading(false);
        }
    };

    const handleDelete = async () => {
        if (!user || !confirmDelete) return;
        setDeleteLoading(true);
        setError('');

        try {
            const res = await fetch(`/api/admin/users/${user.id}`, { method: 'DELETE' });
            const data = await res.json();
            if (!res.ok) throw new Error(data.error || 'Failed to delete user');

            onDeleted(user.id);
            router.refresh();
            onClose();
        } catch (err: any) {
            setError(err.message);
            setDeleteLoading(false);
        }
    };

    // For orphaned accounts: skip the confirmDelete gate — user already confirmed by
    // reaching the orphaned view and clicking "Remove from List".
    const handleRemoveOrphaned = async () => {
        if (!user) return;
        setDeleteLoading(true);
        setError('');

        try {
            const res = await fetch(`/api/admin/users/${user.id}`, { method: 'DELETE' });
            const data = await res.json();
            if (!res.ok) throw new Error(data.error || 'Failed to remove orphaned user');

            onDeleted(user.id);
            router.refresh();
            onClose();
        } catch (err: any) {
            setError(err.message);
            setDeleteLoading(false);
        }
    };

    const handleClose = () => {
        setConfirmDelete(false);
        setIsOrphaned(false);
        setError('');
        setSuccess('');
        onClose();
    };

    if (!user) return null;

    // Orphaned account view — no edit fields, just a removal prompt
    if (isOrphaned && user) {
        return (
            <Modal
                isOpen={!!user}
                onClose={handleClose}
                title="Orphaned Account Detected"
                subtitle={user.email}
                size="sm"
                footer={
                    <>
                        <button className="btn btn-ghost" onClick={handleClose} disabled={deleteLoading}>
                            Close
                        </button>
                        <button
                            className="btn btn-primary"
                            style={{ background: '#ef4444' }}
                            onClick={handleRemoveOrphaned}
                            disabled={deleteLoading}
                        >
                            {deleteLoading ? 'Removing…' : 'Remove from List'}
                        </button>
                    </>
                }
            >
                <div style={{ padding: '1.5rem', display: 'flex', flexDirection: 'column', gap: 'var(--space-4)' }}>
                    <div style={{ padding: 'var(--space-4)', background: 'rgba(245,158,11,0.08)', border: '1px solid rgba(245,158,11,0.3)', borderRadius: 'var(--radius-md)', display: 'flex', flexDirection: 'column', gap: 'var(--space-2)' }}>
                        <p style={{ fontWeight: 600, color: '#d97706', fontSize: 'var(--font-size-sm)', margin: 0 }}>⚠ Orphaned Account</p>
                        <p style={{ fontSize: 'var(--font-size-sm)', color: 'var(--color-text-secondary)', margin: 0 }}>
                            <strong>{user.email}</strong> appears in this list but no longer has an active Supabase Auth record.
                            It was likely deleted directly in Supabase or was never fully created.
                        </p>
                    </div>
                    <p style={{ fontSize: 'var(--font-size-sm)', color: 'var(--color-text-muted)', margin: 0 }}>
                        Click <strong>Remove from List</strong> to clean up this entry, then use <strong>+ Create User</strong> to
                        recreate the account properly if needed.
                    </p>
                    {error && (
                        <div style={{ padding: 'var(--space-3)', background: 'rgba(239,68,68,0.1)', border: '1px solid rgba(239,68,68,0.3)', borderRadius: 'var(--radius-md)', color: '#ef4444', fontSize: 'var(--font-size-sm)' }}>
                            ✗ {error}
                        </div>
                    )}
                </div>
            </Modal>
        );
    }

    return (
        <Modal
            isOpen={!!user}
            onClose={handleClose}
            title="Edit User Account"
            subtitle={`Editing ${user.email}`}
            size="sm"
            footer={
                <>
                    <button className="btn btn-ghost" onClick={handleClose} disabled={loading}>
                        Cancel
                    </button>
                    <button
                        className="btn btn-primary"
                        onClick={handleSave}
                        disabled={loading || deleteLoading}
                    >
                        {loading ? 'Saving…' : 'Save Changes'}
                    </button>
                </>
            }
        >
            <div style={{ padding: '1.5rem', display: 'flex', flexDirection: 'column', gap: 'var(--space-4)' }}>
                {/* Feedback */}
                {success && (
                    <div style={{ padding: 'var(--space-3)', background: 'rgba(34,197,94,0.1)', border: '1px solid rgba(34,197,94,0.3)', borderRadius: 'var(--radius-md)', color: '#22c55e', fontSize: 'var(--font-size-sm)' }}>
                        ✓ {success}
                    </div>
                )}
                {error && (
                    <div style={{ padding: 'var(--space-3)', background: 'rgba(239,68,68,0.1)', border: '1px solid rgba(239,68,68,0.3)', borderRadius: 'var(--radius-md)', color: '#ef4444', fontSize: 'var(--font-size-sm)' }}>
                        ✗ {error}
                    </div>
                )}

                {/* Full Name */}
                <div className="form-group">
                    <label className="form-label" htmlFor="edit-user-name">Full Name</label>
                    <input
                        id="edit-user-name"
                        type="text"
                        className="form-input"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        placeholder="Full name"
                        autoFocus
                    />
                </div>

                {/* Email */}
                <div className="form-group">
                    <label className="form-label" htmlFor="edit-user-email">Email Address</label>
                    <input
                        id="edit-user-email"
                        type="email"
                        className="form-input"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        placeholder="user@example.com"
                    />
                </div>

                {/* Password reset */}
                <div className="form-group">
                    <label className="form-label" htmlFor="edit-user-password">
                        New Password <span style={{ fontWeight: 400, color: 'var(--color-text-muted)' }}>(leave blank to keep current)</span>
                    </label>
                    <input
                        id="edit-user-password"
                        type="password"
                        className="form-input"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        placeholder="New password (optional)"
                        minLength={6}
                    />
                    {password && password.length < 6 && (
                        <p style={{ margin: '0.25rem 0 0', fontSize: 'var(--font-size-xs)', color: '#f59e0b' }}>
                            Password must be at least 6 characters.
                        </p>
                    )}
                </div>

                {/* Account info */}
                <div style={{ padding: 'var(--space-3)', background: 'var(--color-background)', borderRadius: 'var(--radius-md)', display: 'flex', flexDirection: 'column', gap: 'var(--space-2)', fontSize: 'var(--font-size-xs)', color: 'var(--color-text-muted)' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                        <span>User ID</span>
                        <span style={{ fontFamily: 'monospace', fontSize: '0.7rem' }}>{user.id.slice(0, 18)}…</span>
                    </div>
                    <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                        <span>Confirmed</span>
                        <span>{user.confirmed_at ? new Date(user.confirmed_at).toLocaleDateString() : 'Not confirmed'}</span>
                    </div>
                    <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                        <span>Last sign in</span>
                        <span>{user.last_sign_in_at ? new Date(user.last_sign_in_at).toLocaleDateString() : '—'}</span>
                    </div>
                </div>

                {/* Danger zone — delete */}
                <div style={{ borderTop: '1px solid var(--color-border)', paddingTop: 'var(--space-4)', marginTop: 'var(--space-2)' }}>
                    <p style={{ fontSize: 'var(--font-size-xs)', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.06em', color: '#ef4444', marginBottom: 'var(--space-2)' }}>
                        Danger Zone
                    </p>
                    {!confirmDelete ? (
                        <button
                            className="btn btn-ghost"
                            style={{ color: '#ef4444', border: '1px solid rgba(239,68,68,0.3)', width: '100%', justifyContent: 'center' }}
                            onClick={() => setConfirmDelete(true)}
                            disabled={loading}
                        >
                            🗑 Delete User Account
                        </button>
                    ) : (
                        <div style={{ background: 'rgba(239,68,68,0.07)', border: '1px solid rgba(239,68,68,0.25)', borderRadius: 'var(--radius-md)', padding: 'var(--space-3)', display: 'flex', flexDirection: 'column', gap: 'var(--space-2)' }}>
                            <p style={{ fontSize: 'var(--font-size-sm)', color: '#ef4444', fontWeight: 500 }}>
                                Permanently delete <strong>{user.email}</strong>? This cannot be undone.
                            </p>
                            <div style={{ display: 'flex', gap: 'var(--space-2)' }}>
                                <button
                                    className="btn btn-ghost"
                                    style={{ flex: 1 }}
                                    onClick={() => setConfirmDelete(false)}
                                    disabled={deleteLoading}
                                >
                                    Cancel
                                </button>
                                <button
                                    className="btn btn-primary"
                                    style={{ flex: 1, background: '#ef4444', justifyContent: 'center' }}
                                    onClick={handleDelete}
                                    disabled={deleteLoading}
                                >
                                    {deleteLoading ? 'Deleting…' : 'Yes, Delete'}
                                </button>
                            </div>
                        </div>
                    )}
                </div>
            </div>
        </Modal>
    );
}
