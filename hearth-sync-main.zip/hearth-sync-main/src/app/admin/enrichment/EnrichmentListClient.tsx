'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';

const STATUS_COLORS: Record<string, string> = {
    PENDING: 'badge-default',
    RUNNING: 'badge-warning',
    AWAITING_REVIEW: 'badge-info',
    APPLIED: 'badge-active',
    FAILED: 'badge-error',
};

interface Job {
    id: string;
    name: string;
    status: string;
    sourceType: string;
    totalProducts: number;
    processedCount: number;
    errorCount: number;
    createdAt: string;
    _count: { proposals: number; suggestions: number };
}

interface Brand { id: string; name: string; }

export default function EnrichmentListClient({ jobs, brands }: { jobs: Job[]; brands: Brand[] }) {
    const router = useRouter();
    const [showModal, setShowModal] = useState(false);
    const [isCreating, setIsCreating] = useState(false);
    const [form, setForm] = useState({
        name: '',
        sourceType: 'PRODUCT_QUERY',
        brandId: '',
    });
    const [error, setError] = useState<string | null>(null);

    const handleCreate = async () => {
        if (!form.name) { setError('Job name is required.'); return; }
        if (form.sourceType === 'PRODUCT_QUERY' && !form.brandId) { setError('Select a brand.'); return; }
        setIsCreating(true);
        setError(null);
        try {
            const res = await fetch('/api/enrichment', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    name: form.name,
                    sourceType: form.sourceType,
                    sourceFilter: form.brandId ? { brandId: form.brandId } : {},
                }),
            });
            const data = await res.json();
            if (!res.ok) throw new Error(data.error || 'Failed to create job');
            setShowModal(false);
            router.push(`/admin/enrichment/${data.id}`);
        } catch (e: any) {
            setError(e.message);
        } finally {
            setIsCreating(false);
        }
    };

    const formatDate = (d: string) => new Date(d).toLocaleDateString('en-US', {
        month: 'short', day: 'numeric', year: 'numeric', hour: '2-digit', minute: '2-digit',
    });

    return (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '2rem' }}>
            <div className="page-header">
                <div>
                    <h2 className="page-title">🔬 Enrichment Jobs</h2>
                    <p className="page-subtitle">
                        Normalize product data, match taxonomy, and review proposed changes before applying.
                    </p>
                </div>
                <button className="btn btn-primary" onClick={() => setShowModal(true)}>
                    + New Enrichment Run
                </button>
            </div>

            <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
                {jobs.length === 0 ? (
                    <div className="empty-state" style={{ padding: '3rem' }}>
                        <h3>No enrichment jobs yet</h3>
                        <p>Create a new job to start normalizing and enriching product data.</p>
                    </div>
                ) : (
                    <table className="data-table">
                        <thead>
                            <tr>
                                <th>Job Name</th>
                                <th>Source</th>
                                <th>Status</th>
                                <th>Progress</th>
                                <th>Proposals</th>
                                <th>Suggestions</th>
                                <th>Created</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            {jobs.map(job => (
                                <tr key={job.id} style={{ cursor: 'pointer' }} onClick={() => router.push(`/admin/enrichment/${job.id}`)}>
                                    <td style={{ fontWeight: 600 }}>{job.name}</td>
                                    <td>
                                        <span className="badge badge-default" style={{ fontSize: '11px' }}>
                                            {job.sourceType.replace('_', ' ')}
                                        </span>
                                    </td>
                                    <td>
                                        <span className={`badge ${STATUS_COLORS[job.status] || 'badge-default'}`}>
                                            {job.status.replace('_', ' ')}
                                        </span>
                                    </td>
                                    <td style={{ fontSize: 'var(--font-size-sm)', color: 'var(--color-text-secondary)' }}>
                                        {job.processedCount}/{job.totalProducts}
                                        {job.errorCount > 0 && (
                                            <span style={{ color: 'var(--color-error)', marginLeft: '0.5rem' }}>
                                                {job.errorCount} errors
                                            </span>
                                        )}
                                    </td>
                                    <td style={{ fontSize: 'var(--font-size-sm)' }}>{job._count.proposals}</td>
                                    <td style={{ fontSize: 'var(--font-size-sm)' }}>
                                        {job._count.suggestions > 0 ? (
                                            <span style={{ color: 'var(--color-warning)' }}>
                                                ⚠ {job._count.suggestions} pending
                                            </span>
                                        ) : '—'}
                                    </td>
                                    <td style={{ fontSize: 'var(--font-size-xs)', color: 'var(--color-text-muted)' }}>
                                        {formatDate(job.createdAt)}
                                    </td>
                                    <td>
                                        <button className="btn btn-ghost btn-sm">Review →</button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                )}
            </div>

            {/* New Job Modal */}
            {showModal && (
                <div style={{
                    position: 'fixed', inset: 0, zIndex: 1000,
                    background: 'rgba(0,0,0,0.6)',
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                }}>
                    <div className="card" style={{ width: '480px', padding: '2rem', display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
                        <h3 style={{ margin: 0 }}>New Enrichment Run</h3>

                        <div className="form-group">
                            <label className="form-label">Job Name <span style={{ color: 'var(--color-error)' }}>*</span></label>
                            <input
                                className="form-input"
                                placeholder='e.g. "Jackson Grills Brand Enrichment — Mar 2026"'
                                value={form.name}
                                onChange={e => setForm(f => ({ ...f, name: e.target.value }))}
                            />
                        </div>

                        <div className="form-group">
                            <label className="form-label">Source Type</label>
                            <select
                                className="form-select"
                                value={form.sourceType}
                                onChange={e => setForm(f => ({ ...f, sourceType: e.target.value }))}
                            >
                                <option value="PRODUCT_QUERY">All products in a brand</option>
                                <option value="MANUAL_LIST">Selected products (passed via API)</option>
                            </select>
                        </div>

                        {form.sourceType === 'PRODUCT_QUERY' && (
                            <div className="form-group">
                                <label className="form-label">Brand <span style={{ color: 'var(--color-error)' }}>*</span></label>
                                <select
                                    className="form-select"
                                    value={form.brandId}
                                    onChange={e => setForm(f => ({ ...f, brandId: e.target.value }))}
                                >
                                    <option value="">— Select a brand —</option>
                                    {brands.map(b => (
                                        <option key={b.id} value={b.id}>{b.name}</option>
                                    ))}
                                </select>
                            </div>
                        )}

                        {error && (
                            <div style={{ color: 'var(--color-error)', fontSize: 'var(--font-size-sm)' }}>⚠ {error}</div>
                        )}

                        <div style={{ display: 'flex', gap: '0.75rem', justifyContent: 'flex-end' }}>
                            <button className="btn btn-ghost" onClick={() => setShowModal(false)}>Cancel</button>
                            <button className="btn btn-primary" onClick={handleCreate} disabled={isCreating}>
                                {isCreating ? '⏳ Starting…' : 'Start Enrichment'}
                            </button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
}
