import prisma from '@/lib/db';
import EnrichmentListClient from './EnrichmentListClient';

export default async function EnrichmentPage() {
    const [jobs, brands] = await Promise.all([
        prisma.enrichmentJob.findMany({
            orderBy: { createdAt: 'desc' },
            include: {
                _count: { select: { proposals: true, suggestions: true } },
            },
        }),
        prisma.brand.findMany({
            orderBy: { name: 'asc' },
            select: { id: true, name: true },
        }),
    ]);

    return <EnrichmentListClient jobs={jobs as any} brands={brands} />;
}
