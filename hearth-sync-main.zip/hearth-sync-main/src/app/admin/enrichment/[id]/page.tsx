import prisma from '@/lib/db';
import { notFound } from 'next/navigation';
import EnrichmentDetailClient from './EnrichmentDetailClient';

export default async function EnrichmentDetailPage({
    params,
}: {
    params: { id: string };
}) {
    const [job, categories, attributes, optionGroups] = await Promise.all([
        prisma.enrichmentJob.findUnique({
            where: { id: params.id },
            include: {
                proposals: {
                    include: {
                        product: { select: { id: true, name: true, sku: true, modelNumber: true } },
                    },
                    orderBy: { createdAt: 'asc' },
                },
                suggestions: { orderBy: { createdAt: 'asc' } },
            },
        }),
        prisma.productCategory.findMany({ select: { id: true, name: true }, orderBy: { name: 'asc' } }),
        prisma.productAttribute.findMany({ select: { id: true, name: true }, orderBy: { name: 'asc' } }),
        prisma.optionGroup.findMany({ select: { id: true, name: true }, orderBy: { name: 'asc' } }),
    ]);

    if (!job) notFound();

    return <EnrichmentDetailClient job={job as any} categories={categories} attributes={attributes} optionGroups={optionGroups} />;
}
