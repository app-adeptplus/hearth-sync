'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';

const STATUS_COLORS: Record<string, string> = {
    PENDING: 'badge-default',
    RUNNING: 'badge-warning',
    AWAITING_REVIEW: 'badge-info',
    APPLIED: 'badge-active',
    FAILED: 'badge-error',
};

const PROPOSAL_COLORS: Record<string, string> = {
    PENDING: 'badge-default',
    APPROVED: 'badge-active',
    REJECTED: 'badge-error',
    APPLIED: 'badge-success',
};

interface Suggestion {
    id: string;
    type: string;
    status: string;
    suggestedName: string;
    suggestedData: any;
    resolvedId: string | null;
}

interface Proposal {
    id: string;
    status: string;
    confidence: number;
    notes: string | null;
    proposedData: any;
    originalData: any;
    product: { id: string; name: string; sku: string | null; modelNumber: string | null } | null;
}

interface Job {
    id: string;
    name: string;
    status: string;
    totalProducts: number;
    processedCount: number;
    errorCount: number;
    rawLog: string | null;
    proposals: Proposal[];
    suggestions: Suggestion[];
}

export default function EnrichmentDetailClient({
    job,
    categories,
    attributes,
    optionGroups,
}: {
    job: Job;
    categories: { id: string; name: string }[];
    attributes: { id: string; name: string }[];
    optionGroups: { id: string; name: string }[];
}) {
    const router = useRouter();
    const [proposalStatuses, setProposalStatuses] = useState<Record<string, string>>(
        Object.fromEntries(job.proposals.map(p => [p.id, p.status]))
    );
    const [suggestionStatuses, setSuggestionStatuses] = useState<Record<string, string>>(
        Object.fromEntries(job.suggestions.map(s => [s.id, s.status]))
    );
    const [isApplying, setIsApplying] = useState(false);
    const [applyResult, setApplyResult] = useState<any>(null);
    const [expandedProposal, setExpandedProposal] = useState<string | null>(null);
    const [showLog, setShowLog] = useState(false);
    const [reassignTarget, setReassignTarget] = useState<Record<string, string>>({});

    const pendingSuggestions = job.suggestions.filter(s => suggestionStatuses[s.id] === 'PENDING');
    const approvedProposals = Object.entries(proposalStatuses).filter(([, s]) => s === 'APPROVED').length;
    const progressPct = job.totalProducts > 0
        ? Math.round((job.processedCount / job.totalProducts) * 100)
        : 0;

    // Deduplicate suggestions by type+name — only show one row per unique suggestion
    const uniqueSuggestions = job.suggestions.reduce((acc, s) => {
        const key = `${s.type}::${s.suggestedName}`;
        if (!acc.map[key]) {
            acc.map[key] = s;
            acc.list.push(s);
            acc.counts[key] = 1;
        } else {
            acc.counts[key]++;
        }
        return acc;
    }, { map: {} as Record<string, Suggestion>, list: [] as Suggestion[], counts: {} as Record<string, number> });
    const dedupedSuggestions = uniqueSuggestions.list;
    const suggestionCounts = uniqueSuggestions.counts;
    const pendingDeduped = dedupedSuggestions.filter(s => suggestionStatuses[s.id] === 'PENDING');

    // Build category/attribute lookup maps for resolving IDs to names
    const categoryMap = Object.fromEntries(categories.map(c => [c.id, c.name]));
    const attributeMap = Object.fromEntries(attributes.map(a => [a.id, a.name]));

    const resolveName = (type: 'category' | 'attribute', id: string) =>
        type === 'category' ? (categoryMap[id] || id.slice(0, 8) + '…') : (attributeMap[id] || id.slice(0, 8) + '…');


    const updateProposal = async (pid: string, status: string) => {
        const res = await fetch(`/api/enrichment/${job.id}/proposals/${pid}`, {
            method: 'PATCH',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ status }),
        });
        if (res.ok) {
            setProposalStatuses(prev => ({ ...prev, [pid]: status }));
        }
    };

    const approveAll = async () => {
        const pending = job.proposals.filter(p => proposalStatuses[p.id] === 'PENDING');
        for (const p of pending) {
            await updateProposal(p.id, 'APPROVED');
        }
    };

    const approveHighConfidence = async () => {
        const eligible = job.proposals.filter(p => p.confidence >= 0.7 && proposalStatuses[p.id] === 'PENDING');
        for (const p of eligible) {
            await updateProposal(p.id, 'APPROVED');
        }
    };

    const resolveSuggestion = async (sid: string, action: string, resolvedId?: string) => {
        const res = await fetch(`/api/enrichment/${job.id}/suggestions/${sid}`, {
            method: 'PATCH',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action, resolvedId }),
        });
        if (res.ok) {
            const actionToStatus: Record<string, string> = { approve: 'APPROVED', reassign: 'REASSIGNED', deny: 'DENIED' };
            setSuggestionStatuses(prev => ({ ...prev, [sid]: actionToStatus[action] || action.toUpperCase() }));
        }
    };

    const handleApply = async () => {
        if (approvedProposals === 0) { alert('No approved proposals to apply.'); return; }
        if (!confirm(`Apply ${approvedProposals} approved proposals to the product database?`)) return;
        setIsApplying(true);
        try {
            const res = await fetch(`/api/enrichment/${job.id}/apply`, { method: 'POST' });
            const result = await res.json();
            if (!res.ok) throw new Error(result.error);
            setApplyResult(result);
            router.refresh();
        } catch (e: any) {
            alert(`Apply error: ${e.message}`);
        } finally {
            setIsApplying(false);
        }
    };

    const conf = (c: number) => `${Math.round(c * 100)}%`;
    const confColor = (c: number) => c >= 0.7 ? '#22c55e' : c >= 0.4 ? '#f59e0b' : '#ef4444';

    // Strip HTML tags and truncate long values for clean JSON display in the diff panel
    const sanitizeForDisplay = (obj: any): any => {
        if (typeof obj === 'string') {
            const stripped = obj.replace(/<[^>]+>/g, '').replace(/\s+/g, ' ').trim();
            return stripped.length > 300 ? stripped.slice(0, 300) + '…' : stripped;
        }
        if (Array.isArray(obj)) return obj.map(sanitizeForDisplay);
        if (obj && typeof obj === 'object') return Object.fromEntries(Object.entries(obj).map(([k, v]) => [k, sanitizeForDisplay(v)]));
        return obj;
    };

    const taxonomyOptions = (type: string) => {
        if (type === 'CATEGORY') return categories;
        if (type === 'ATTRIBUTE') return attributes;
        return optionGroups;
    };

    return (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
            {/* Header */}
            <div className="page-header">
                <div>
                    <h2 className="page-title">🔬 {job.name}</h2>
                    <p className="page-subtitle">
                        {job.proposals.length} proposals · {job.suggestions.length} taxonomy suggestions
                    </p>
                </div>
                <div style={{ display: 'flex', gap: 'var(--space-3)', alignItems: 'center' }}>
                    <span className={`badge ${STATUS_COLORS[job.status] || 'badge-default'}`}>
                        {job.status.replace('_', ' ')}
                    </span>
                    {approvedProposals > 0 && job.status !== 'APPLIED' && (
                        <button className="btn btn-primary" onClick={handleApply} disabled={isApplying}>
                            {isApplying ? '⏳ Applying…' : `✅ Apply ${approvedProposals} Proposals`}
                        </button>
                    )}
                    <button className="btn btn-ghost" onClick={() => router.push('/admin/enrichment')}>← Back</button>
                </div>
            </div>

            {/* Progress bar */}
            {job.status === 'RUNNING' && (
                <div className="card" style={{ padding: '1.25rem' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.5rem', fontSize: 'var(--font-size-sm)' }}>
                        <span>Processing products…</span>
                        <span>{job.processedCount}/{job.totalProducts} ({progressPct}%)</span>
                    </div>
                    <div style={{ height: '6px', background: 'var(--color-border)', borderRadius: '999px', overflow: 'hidden' }}>
                        <div style={{ height: '100%', width: `${progressPct}%`, background: 'var(--color-primary)', transition: 'width 0.3s' }} />
                    </div>
                </div>
            )}

            {/* Apply result */}
            {applyResult && (
                <div className="card" style={{ padding: '1.25rem', border: '1px solid var(--color-success, #22c55e)' }}>
                    <div style={{ fontWeight: 600, marginBottom: '0.5rem' }}>🎉 Applied Successfully</div>
                    <div style={{ fontSize: 'var(--font-size-sm)', color: 'var(--color-text-secondary)' }}>
                        {applyResult.applied} products updated · {applyResult.remaining} remaining
                        {applyResult.errors?.length > 0 && <span style={{ color: 'var(--color-error)' }}> · {applyResult.errors.length} errors</span>}
                    </div>
                    {applyResult.errors?.length > 0 && (
                        <div style={{ marginTop: '0.5rem', fontSize: '0.8rem', color: 'var(--color-error)' }}>
                            {applyResult.errors.map((e: string, i: number) => <div key={i}>• {e}</div>)}
                        </div>
                    )}
                </div>
            )}

            {/* ── Taxonomy Suggestions ── */}
            {pendingDeduped.length > 0 && (
                <div className="card" style={{ padding: '1.5rem' }}>
                    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '1rem' }}>
                        <h3 style={{ fontSize: '1rem', fontWeight: 600, margin: 0, display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                            ⚠️ Taxonomy Suggestions
                            <span style={{ fontSize: 'var(--font-size-xs)', color: 'var(--color-text-muted)', fontWeight: 400 }}>
                                {pendingDeduped.length} unique · resolve before applying
                            </span>
                        </h3>
                        <div style={{ display: 'flex', gap: '0.5rem' }}>
                            <button className="btn btn-sm btn-secondary"
                                onClick={() => pendingDeduped.forEach(s => resolveSuggestion(s.id, 'approve'))}>
                                ✅ Approve All
                            </button>
                            <button className="btn btn-sm btn-ghost" style={{ color: 'var(--color-error)' }}
                                onClick={() => pendingDeduped.forEach(s => resolveSuggestion(s.id, 'deny'))}>
                                ❌ Deny All
                            </button>
                        </div>
                    </div>
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
                        {dedupedSuggestions.map(s => {
                            const key = `${s.type}::${s.suggestedName}`;
                            const count = suggestionCounts[key] || 1;
                            const isPending = suggestionStatuses[s.id] === 'PENDING';
                            return (
                                <div key={s.id} style={{
                                    display: 'flex', alignItems: 'center', gap: 'var(--space-3)',
                                    padding: '0.5rem 0.75rem',
                                    background: 'var(--color-bg)',
                                    border: '1px solid var(--color-border)',
                                    borderRadius: 'var(--radius-md)',
                                    opacity: !isPending ? 0.45 : 1,
                                }}>
                                    <span className="badge badge-warning" style={{ fontSize: '10px', minWidth: 72, textAlign: 'center' }}>
                                        {s.type}
                                    </span>
                                    <div style={{ flex: 1, minWidth: 0 }}>
                                        <div style={{ fontWeight: 600, fontSize: 'var(--font-size-sm)' }}>
                                            {s.suggestedName}
                                            {count > 1 && (
                                                <span style={{ marginLeft: '6px', fontSize: '11px', color: 'var(--color-text-muted)', fontWeight: 400 }}>
                                                    ({count} products)
                                                </span>
                                            )}
                                        </div>
                                        {s.suggestedData?.reason && (
                                            <div style={{ fontSize: '11px', color: 'var(--color-text-muted)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                                                {s.suggestedData.reason}
                                            </div>
                                        )}
                                    </div>
                                    {isPending ? (
                                        <div style={{ display: 'flex', gap: '0.4rem', alignItems: 'center', flexShrink: 0 }}>
                                            <select
                                                className="form-select"
                                                style={{ height: '28px', fontSize: '11px', padding: '0 0.5rem', minWidth: '140px' }}
                                                value={reassignTarget[s.id] || ''}
                                                onChange={e => setReassignTarget(prev => ({ ...prev, [s.id]: e.target.value }))}
                                            >
                                                <option value="">↔ Reassign to…</option>
                                                {taxonomyOptions(s.type).map(t => (
                                                    <option key={t.id} value={t.id}>{t.name}</option>
                                                ))}
                                            </select>
                                            {reassignTarget[s.id] && (
                                                <button className="btn btn-sm btn-secondary"
                                                    onClick={() => resolveSuggestion(s.id, 'reassign', reassignTarget[s.id])}>
                                                    Use
                                                </button>
                                            )}
                                            <button className="btn btn-sm btn-primary"
                                                onClick={() => resolveSuggestion(s.id, 'approve')}>✅</button>
                                            <button className="btn btn-sm btn-ghost" style={{ color: 'var(--color-error)' }}
                                                onClick={() => resolveSuggestion(s.id, 'deny')}>❌</button>
                                        </div>
                                    ) : (
                                        <span className={`badge ${suggestionStatuses[s.id] === 'APPROVED' ? 'badge-active' : suggestionStatuses[s.id] === 'DENIED' ? 'badge-error' : 'badge-info'}`}
                                            style={{ fontSize: '11px', flexShrink: 0 }}>
                                            {suggestionStatuses[s.id]}
                                        </span>
                                    )}
                                </div>
                            );
                        })}
                    </div>
                </div>
            )}

            {/* ── Proposal Review Table ── */}
            <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '1rem 1.5rem', borderBottom: '1px solid var(--color-border)' }}>
                    <h3 style={{ margin: 0, fontSize: '1rem', fontWeight: 600 }}>
                        Product Proposals
                        <span style={{ marginLeft: '0.5rem', fontSize: 'var(--font-size-sm)', fontWeight: 400, color: 'var(--color-text-muted)' }}>
                            {approvedProposals} approved of {job.proposals.length}
                        </span>
                    </h3>
                    <div style={{ display: 'flex', gap: '0.5rem' }}>
                        <button className="btn btn-sm btn-secondary" onClick={approveHighConfidence}>
                            ✅ Approve ≥70% Confidence
                        </button>
                        <button className="btn btn-sm btn-secondary" onClick={approveAll}>
                            ✅ Approve All
                        </button>
                    </div>
                </div>

                {job.proposals.length === 0 ? (
                    <div className="empty-state" style={{ padding: '2rem' }}>
                        <p>{job.status === 'RUNNING' ? 'Processing…' : 'No proposals generated yet.'}</p>
                    </div>
                ) : (
                    <table className="data-table">
                        <thead>
                            <tr>
                                <th>Product</th>
                                <th>Proposed Name</th>
                                <th>SKU / Model</th>
                                <th>Categories</th>
                                <th>Confidence</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            {job.proposals.map(p => (
                                <>
                                    <tr key={p.id} style={{
                                        background: proposalStatuses[p.id] === 'APPROVED'
                                            ? 'color-mix(in srgb, var(--color-success, #22c55e) 6%, transparent)'
                                            : proposalStatuses[p.id] === 'REJECTED'
                                            ? 'color-mix(in srgb, var(--color-error) 5%, transparent)'
                                            : 'transparent'
                                    }}>
                                        <td style={{ fontSize: 'var(--font-size-sm)' }}>
                                            <div style={{ fontWeight: 500, maxWidth: '200px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                                                {p.product?.name || '—'}
                                            </div>
                                            <div style={{ fontSize: '11px', color: 'var(--color-text-muted)' }}>
                                                {p.product?.sku || p.product?.modelNumber || ''}
                                            </div>
                                        </td>
                                        <td style={{ fontSize: 'var(--font-size-sm)', fontWeight: 500, maxWidth: '220px' }}>
                                            {p.proposedData?.name || '—'}
                                        </td>
                                        <td style={{ fontSize: '12px', color: 'var(--color-text-secondary)' }}>
                                            <div>{p.proposedData?.sku || '—'}</div>
                                            <div style={{ color: 'var(--color-text-muted)' }}>{p.proposedData?.modelNumber || ''}</div>
                                        </td>
                                        <td>
                                            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '4px', maxWidth: '180px' }}>
                                                {(p.proposedData?.categoryIds || []).slice(0, 3).map((id: string, i: number) => (
                                                    <span key={i} style={{ fontSize: '11px', background: 'var(--color-bg-elevated)', border: '1px solid var(--color-border)', borderRadius: '999px', padding: '2px 6px' }}>
                                                        {resolveName('category', id)}
                                                    </span>
                                                ))}
                                                {(!p.proposedData?.categoryIds?.length) && <span style={{ fontSize: '11px', color: 'var(--color-text-muted)' }}>—</span>}
                                            </div>
                                        </td>
                                        <td>
                                            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                                                <div style={{ width: 50, height: 6, background: 'var(--color-border)', borderRadius: '999px', overflow: 'hidden' }}>
                                                    <div style={{ height: '100%', width: conf(p.confidence), background: confColor(p.confidence) }} />
                                                </div>
                                                <span style={{ fontSize: '12px', fontWeight: 600, color: confColor(p.confidence) }}>
                                                    {conf(p.confidence)}
                                                </span>
                                            </div>
                                        </td>
                                        <td>
                                            <span className={`badge ${PROPOSAL_COLORS[proposalStatuses[p.id]] || 'badge-default'}`} style={{ fontSize: '11px' }}>
                                                {proposalStatuses[p.id]}
                                            </span>
                                        </td>
                                        <td>
                                            <div style={{ display: 'flex', gap: '0.25rem' }}>
                                                {proposalStatuses[p.id] !== 'APPLIED' && <>
                                                    <button className="btn btn-sm btn-primary"
                                                        onClick={() => updateProposal(p.id, proposalStatuses[p.id] === 'APPROVED' ? 'PENDING' : 'APPROVED')}>
                                                        {proposalStatuses[p.id] === 'APPROVED' ? 'Undo' : '✅'}
                                                    </button>
                                                    {proposalStatuses[p.id] !== 'REJECTED' && (
                                                        <button className="btn btn-sm btn-ghost"
                                                            style={{ color: 'var(--color-error)' }}
                                                            onClick={() => updateProposal(p.id, 'REJECTED')}>
                                                            ❌
                                                        </button>
                                                    )}
                                                </>}
                                                <button className="btn btn-sm btn-ghost"
                                                    onClick={() => setExpandedProposal(expandedProposal === p.id ? null : p.id)}>
                                                    {expandedProposal === p.id ? '▲' : 'Details'}
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                    {expandedProposal === p.id && (
                                        <tr key={`${p.id}-detail`}>
                                            <td colSpan={7} style={{
                                                background: 'var(--color-bg)',
                                                padding: '1rem 1.5rem',
                                                maxWidth: 0,
                                                overflow: 'hidden',
                                            }}>
                                                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem', fontSize: 'var(--font-size-sm)', width: '100%', overflow: 'hidden' }}>
                                                    <div style={{ minWidth: 0 }}>
                                                        <div style={{ fontWeight: 600, marginBottom: '0.5rem' }}>Original</div>
                                                        <pre style={{ fontSize: '11px', background: 'var(--color-bg-elevated)', padding: '0.75rem', borderRadius: 'var(--radius-md)', overflowX: 'auto', overflowY: 'auto', maxHeight: '200px', wordBreak: 'break-word', whiteSpace: 'pre-wrap' }}>
                                                            {JSON.stringify(sanitizeForDisplay(p.originalData), null, 2)}
                                                        </pre>
                                                    </div>
                                                    <div style={{ minWidth: 0 }}>
                                                        <div style={{ fontWeight: 600, marginBottom: '0.5rem' }}>Proposed</div>
                                                        <pre style={{ fontSize: '11px', background: 'var(--color-bg-elevated)', padding: '0.75rem', borderRadius: 'var(--radius-md)', overflowX: 'auto', overflowY: 'auto', maxHeight: '200px', wordBreak: 'break-word', whiteSpace: 'pre-wrap' }}>
                                                            {JSON.stringify(sanitizeForDisplay(p.proposedData), null, 2)}
                                                        </pre>
                                                    </div>
                                                </div>
                                                {p.notes && (
                                                    <div style={{ marginTop: '0.5rem', fontSize: '12px', color: 'var(--color-text-muted)' }}>
                                                        📝 {p.notes}
                                                    </div>
                                                )}
                                            </td>
                                        </tr>
                                    )}
                                </>
                            ))}
                        </tbody>
                    </table>
                )}
            </div>

            {/* Raw log */}
            {job.rawLog && (
                <div className="card" style={{ padding: '1rem 1.5rem' }}>
                    <button className="btn btn-ghost btn-sm" onClick={() => setShowLog(v => !v)} style={{ marginBottom: '0.5rem' }}>
                        {showLog ? '▲ Hide' : '▼ Show'} Processing Log
                    </button>
                    {showLog && (
                        <pre style={{ fontSize: '11px', background: 'var(--color-bg)', padding: '0.75rem', borderRadius: 'var(--radius-md)', overflow: 'auto', maxHeight: '300px' }}>
                            {job.rawLog}
                        </pre>
                    )}
                </div>
            )}
        </div>
    );
}
