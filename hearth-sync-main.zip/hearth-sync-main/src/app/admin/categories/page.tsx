import prisma from '@/lib/db';
import Link from 'next/link';
import CategoriesClient from './CategoriesClient';
import AttributesClient from './AttributesClient';

export const dynamic = 'force-dynamic';

export default async function CategoriesPage({ searchParams }: { searchParams: { tab?: string } }) {
    const activeTab = searchParams.tab || 'categories';

    let content = null;

    if (activeTab === 'categories') {
        const categories = await prisma.productCategory.findMany({
            orderBy: [
                { parentId: 'asc' },
                { sortOrder: 'asc' },
                { name: 'asc' }
            ],
            include: {
                parent: true,
                _count: {
                    select: { products: true, children: true }
                }
            }
        });
        content = <CategoriesClient categories={categories} />;
    } else if (activeTab === 'attributes') {
        const [attributes, allCategories] = await Promise.all([
            prisma.productAttribute.findMany({
                orderBy: [{ sortOrder: 'asc' }, { name: 'asc' }],
                include: {
                    _count: {
                        select: { categoryMappings: true, productValues: true }
                    },
                    categoryMappings: {
                        include: {
                            category: {
                                select: { id: true, name: true, slug: true, parentId: true }
                            }
                        },
                        orderBy: { sortOrder: 'asc' }
                    },
                    childDependencies: {
                        include: {
                            childAttribute: {
                                select: { id: true, name: true, slug: true, dataType: true, options: true, unit: true }
                            }
                        },
                        orderBy: [{ triggerValue: 'asc' }, { sortOrder: 'asc' }]
                    }
                }
            }),
            prisma.productCategory.findMany({
                orderBy: [{ parentId: 'asc' }, { sortOrder: 'asc' }, { name: 'asc' }],
                select: { id: true, name: true, slug: true, parentId: true }
            })
        ]);
        content = <AttributesClient attributes={attributes} categories={allCategories} />;
    }

    const tabs = [
        { key: 'categories', label: 'Product Categories' },
        { key: 'attributes', label: 'Attributes' },
    ];

    return (
        <div className="space-y-6">
            <div className="page-header pb-6 border-b border-[var(--color-border)] mb-6 flex justify-between items-end">
                <div>
                    <h2 className="text-2xl font-bold">Taxonomy Engine</h2>
                    <p className="text-[var(--text-secondary)] mt-1">
                        Manage global hierarchies, variants, and product attributes
                    </p>
                </div>
            </div>

            <div style={{
                display: 'flex',
                gap: 'var(--space-2)',
                padding: 'var(--space-1)',
                background: 'var(--color-bg-elevated)',
                borderRadius: 'var(--radius-lg)',
                marginBottom: 'var(--space-8)',
                width: 'fit-content',
                border: '1px solid var(--color-border)'
            }}>
                {tabs.map(tab => (
                    <Link
                        key={tab.key}
                        href={`/admin/categories?tab=${tab.key}`}
                        style={{
                            padding: 'var(--space-2) var(--space-5)',
                            fontSize: 'var(--font-size-sm)',
                            fontWeight: 600,
                            borderRadius: 'var(--radius-md)',
                            transition: 'all var(--transition-base)',
                            background: activeTab === tab.key ? 'var(--color-primary)' : 'transparent',
                            color: activeTab === tab.key ? 'white' : 'var(--color-text-secondary)',
                            boxShadow: activeTab === tab.key ? 'var(--glass-shadow)' : 'none',
                        }}
                    >
                        {tab.label}
                    </Link>
                ))}
            </div>

            <div className="card" style={{ padding: '0', background: 'transparent', border: 'none', boxShadow: 'none' }}>
                {content}
            </div>
        </div>
    );
}
