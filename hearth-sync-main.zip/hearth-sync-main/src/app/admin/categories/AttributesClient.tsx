"use client";

import { useState, useMemo } from 'react';
import { useRouter } from 'next/navigation';
import Modal from '@/components/Modal';
import ConfirmDialog from '@/components/ui/ConfirmDialog';
import SearchableMultiSelect from '@/components/SearchableMultiSelect';
import { buildCategoryOptions } from '@/lib/categoryUtils';

const DATA_TYPES = [
    { value: 'text', label: 'Text' },
    { value: 'number', label: 'Number' },
    { value: 'boolean', label: 'Boolean (Yes/No)' },
    { value: 'select', label: 'Select (single choice)' },
    { value: 'multi_select', label: 'Multi-Select (multiple choices)' },
    { value: 'range', label: 'Range (min–max)' },
    { value: 'enum', label: 'Enum (strict predefined set)' },
];

const NEEDS_OPTIONS = ['select', 'multi_select', 'enum'];

type SystemFilter = 'all' | 'system' | 'user';

export default function AttributesClient({
    attributes,
    categories,
}: {
    attributes: any[];
    categories: any[];
}) {
    const router = useRouter();

    // ── Modal state ───────────────────────────────────────────────────────────
    const [editTarget, setEditTarget] = useState<any | null>(null); // null = closed, {} = new, attr = edit
    const [isModalOpen, setIsModalOpen] = useState(false);

    // ── Form state ────────────────────────────────────────────────────────────
    const [name, setName] = useState('');
    const [slug, setSlug] = useState('');
    const [description, setDescription] = useState('');
    const [unit, setUnit] = useState('');
    const [dataType, setDataType] = useState('text');
    const [options, setOptions] = useState('');
    const [industry, setIndustry] = useState('');
    const [isSystem, setIsSystem] = useState(false);
    const [sortOrder, setSortOrder] = useState('0');

    const [isSaving, setIsSaving] = useState(false);
    const [isDeleting, setIsDeleting] = useState(false);

    // ── Child Attribute Dependencies (edit modal) ─────────────────────────────
    const [editDeps, setEditDeps] = useState<any[]>([]);   // childDependencies for the open attr
    const [depTrigger, setDepTrigger] = useState('');      // selected trigger value for new rule
    const [depChildId, setDepChildId] = useState('');      // selected child attribute id for new rule
    const [isAddingDep, setIsAddingDep] = useState(false);

    // Confirm delete dialog
    const [confirmDelete, setConfirmDelete] = useState<{ id: string; name: string } | null>(null);

    // ── Filter state ──────────────────────────────────────────────────────────
    const [filterDataTypes, setFilterDataTypes] = useState<Set<string>>(new Set());
    const [filterCategories, setFilterCategories] = useState<Set<string>>(new Set());
    const [filterSystem, setFilterSystem] = useState<SystemFilter>('all');
    const [filterRelation, setFilterRelation] = useState<'parent' | 'child' | 'none' | null>(null);

    // ── Multi-select (bulk) state ─────────────────────────────────────────────
    const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
    const [isBulkDeleting, setIsBulkDeleting] = useState(false);
    const [bulkConfirm, setBulkConfirm] = useState(false);

    // ── Category Mapping Modal (standalone, separate from edit modal) ──────────
    const [catModalAttr, setCatModalAttr] = useState<any | null>(null);
    const [catModalIds, setCatModalIds] = useState<string[]>([]);
    const [catModalMappings, setCatModalMappings] = useState<any[]>([]);
    const [catModalSaving, setCatModalSaving] = useState(false);
    const [catModalError, setCatModalError] = useState<string | null>(null);
    const [catModalStatus, setCatModalStatus] = useState<'idle' | 'saved' | 'error'>('idle');

    const openCatModal = async (attr: any) => {
        setCatModalAttr(attr);
        setCatModalError(null);
        setCatModalStatus('idle');
        const mappings = attr.categoryMappings ?? [];
        setCatModalMappings(mappings);
        const ids = mappings.map((m: any) => m.categoryId ?? m.category?.id).filter(Boolean);
        setCatModalIds(ids);
    };

    const toggleCatModalFlag = async (
        categoryId: string,
        field: 'isRequired' | 'isFilterable',
        currentValue: boolean
    ) => {
        if (!catModalAttr) return;
        try {
            const res = await fetch(`/api/categories/${categoryId}/attributes`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ attributeId: catModalAttr.id, [field]: !currentValue }),
            });
            if (!res.ok) throw new Error('Failed to update flag');
            setCatModalMappings(prev => prev.map(m =>
                (m.categoryId ?? m.category?.id) === categoryId ? { ...m, [field]: !currentValue } : m
            ));
        } catch (e: any) {
            alert(e.message);
        }
    };

    /**
     * Toggle a single option value in the allowedOptions for a specific category mapping.
     * If all options would be allowed, saves null (= unrestricted) instead.
     */
    const toggleCatModalAllowedOption = async (categoryId: string, optionValue: string, allOptions: string[]) => {
        if (!catModalAttr) return;
        const mapping = catModalMappings.find(m => (m.categoryId ?? m.category?.id) === categoryId);
        if (!mapping) return;

        const currentAllowed: string[] = mapping.allowedOptions
            ? mapping.allowedOptions.split(',').map((s: string) => s.trim()).filter(Boolean)
            : allOptions; // null = all allowed

        const isCurrentlyAllowed = currentAllowed.includes(optionValue);
        let nextAllowed: string[];
        if (isCurrentlyAllowed) {
            nextAllowed = currentAllowed.filter(o => o !== optionValue);
        } else {
            nextAllowed = [...currentAllowed, optionValue];
        }

        // If every option is allowed, store null instead
        const newValue = nextAllowed.length === allOptions.length ? null : nextAllowed.join(', ');

        try {
            const res = await fetch(`/api/categories/${categoryId}/attributes`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ attributeId: catModalAttr.id, allowedOptions: newValue }),
            });
            if (!res.ok) throw new Error('Failed to update allowed options');
            setCatModalMappings(prev => prev.map(m =>
                (m.categoryId ?? m.category?.id) === categoryId ? { ...m, allowedOptions: newValue } : m
            ));
        } catch (e: any) {
            alert(e.message);
        }
    };

    const saveCatModal = async () => {
        if (!catModalAttr) return;
        setCatModalSaving(true);
        setCatModalError(null);
        try {
            const res = await fetch(`/api/attributes/${catModalAttr.id}/categories`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ categoryIds: catModalIds }),
            });
            const data = await res.json();
            if (!res.ok) throw new Error(data.error || 'Failed to save');
            // Refresh local mappings from response so flag toggles appear immediately
            setCatModalMappings(data.mappings ?? []);
            setCatModalStatus('saved');
            router.refresh();
        } catch (e: any) {
            setCatModalStatus('error');
            setCatModalError(e.message);
        } finally {
            setCatModalSaving(false);
        }
    };

    // ─────────────────────────────────────────────────────────────────────────

    const isAdding = isModalOpen && editTarget !== null && !editTarget.id;
    const editingId: string | null = isModalOpen && editTarget?.id ? editTarget.id : null;

    const openAddModal = () => {
        setEditTarget({});
        setName('');
        setSlug('');
        setDescription('');
        setUnit('');
        setDataType('text');
        setOptions('');
        setIndustry('');
        setIsSystem(false);
        setSortOrder('0');
        setIsModalOpen(true);
    };

    const openEditModal = (attr: any) => {
        setEditTarget(attr);
        setName(attr.name);
        setSlug(attr.slug || '');
        setDescription(attr.description || '');
        setUnit(attr.unit || '');
        setDataType(attr.dataType || 'text');
        setOptions(attr.options || '');
        setIndustry(attr.industry || '');
        setIsSystem(attr.isSystem || false);
        setSortOrder(attr.sortOrder?.toString() || '0');
        setEditDeps(attr.childDependencies || []);
        setDepTrigger('');
        setDepChildId('');
        setIsModalOpen(true);
    };

    const closeModal = () => {
        setIsModalOpen(false);
        setEditTarget(null);
    };

    const saveAttribute = async (e: React.FormEvent) => {
        e.preventDefault();
        setIsSaving(true);
        try {
            const payload = {
                name,
                ...(!isAdding && slug ? { slug: slug.trim() } : {}),
                description: description || null,
                unit: unit || null,
                dataType,
                options: NEEDS_OPTIONS.includes(dataType) ? (options || null) : null,
                industry: industry || null,
                isSystem,
                sortOrder: parseInt(sortOrder) || 0,
            };

            const url = isAdding ? '/api/attributes' : `/api/attributes/${editingId}`;
            const method = isAdding ? 'POST' : 'PATCH';

            const res = await fetch(url, {
                method,
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload),
            });

            if (!res.ok) {
                const data = await res.json();
                throw new Error(data.error || 'Failed to save attribute');
            }
            router.refresh();
            closeModal();
        } catch (error: any) {
            alert(error.message);
        } finally {
            setIsSaving(false);
        }
    };

    const handleDelete = (id: string) => {
        const attr = attributes.find(a => a.id === id);
        if (!attr) return;
        setConfirmDelete({ id, name: attr.name });
    };

    const executeDelete = async () => {
        if (!confirmDelete) return;
        const { id } = confirmDelete;
        setConfirmDelete(null);
        setIsDeleting(true);
        try {
            const res = await fetch(`/api/attributes/${id}`, { method: 'DELETE' });
            const data = await res.json();
            if (!res.ok) throw new Error(data.error || 'Failed to delete attribute');
            router.refresh();
            if (editingId === id) closeModal();
        } catch (error: any) {
            alert(error.message);
        } finally {
            setIsDeleting(false);
        }
    };

    const addDep = async () => {
        if (!editingId || !depTrigger || !depChildId) return;
        setIsAddingDep(true);
        try {
            const res = await fetch(`/api/attributes/${editingId}/dependencies`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ triggerValue: depTrigger, childAttributeId: depChildId }),
            });
            const data = await res.json();
            if (!res.ok) throw new Error(data.error || 'Failed to add dependency');
            setEditDeps(prev => [...prev, data.dependency]);
            setDepChildId(''); // reset child, keep trigger so user can add more
        } catch (e: any) {
            alert(e.message);
        } finally {
            setIsAddingDep(false);
        }
    };

    const removeDep = async (depId: string) => {
        if (!editingId) return;
        try {
            const res = await fetch(`/api/attributes/${editingId}/dependencies`, {
                method: 'DELETE',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ dependencyId: depId }),
            });
            if (!res.ok) throw new Error('Failed to remove dependency');
            setEditDeps(prev => prev.filter(d => d.id !== depId));
        } catch (e: any) {
            alert(e.message);
        }
    };

    const sortedCategoryOptions = useMemo(
        () => buildCategoryOptions(categories.map((c: any) => ({ id: c.id, name: c.name, parentId: c.parentId }))),
        [categories]
    );

    // ── Filter logic ──────────────────────────────────────────────────────────

    const toggleFilterDataType = (value: string) => {
        setFilterDataTypes(prev => {
            const next = new Set(prev);
            next.has(value) ? next.delete(value) : next.add(value);
            return next;
        });
    };

    const toggleFilterCategory = (id: string) => {
        setFilterCategories(prev => {
            const next = new Set(prev);
            next.has(id) ? next.delete(id) : next.add(id);
            return next;
        });
    };

    const filteredAttributes = useMemo(() => {
        return attributes.filter(attr => {
            // Data type filter
            if (filterDataTypes.size > 0 && !filterDataTypes.has(attr.dataType)) return false;
            // System filter
            if (filterSystem === 'system' && !attr.isSystem) return false;
            if (filterSystem === 'user' && attr.isSystem) return false;
            // Category filter (OR logic)
            if (filterCategories.size > 0) {
                const mappedCatIds = new Set(
                    (attr.categoryMappings || []).map((m: any) => m.categoryId || m.category?.id)
                );
                const hasMatch = Array.from(filterCategories).some(id => mappedCatIds.has(id));
                if (!hasMatch) return false;
            }
            // Relation filter
            if (filterRelation !== null) {
                const isParent = (attr.childDependencies?.length ?? 0) > 0;
                const isChild  = (attr.parentDependencies?.length ?? 0) > 0;
                if (filterRelation === 'parent' && !isParent) return false;
                if (filterRelation === 'child'  && !isChild)  return false;
                if (filterRelation === 'none'   && (isParent || isChild)) return false;
            }
            return true;
        });
    }, [attributes, filterDataTypes, filterSystem, filterCategories, filterRelation]);

    // ── Bulk-select helpers ───────────────────────────────────────────────────

    const isSelectable = (attr: any) => !attr.isSystem;
    const selectableAttrs = filteredAttributes.filter(isSelectable);
    const allSelectableSelected =
        selectableAttrs.length > 0 &&
        selectableAttrs.every(a => selectedIds.has(a.id));

    const toggleSelectAll = () => {
        if (allSelectableSelected) {
            setSelectedIds(new Set());
        } else {
            setSelectedIds(new Set(selectableAttrs.map(a => a.id)));
        }
    };

    const toggleSelect = (id: string) => {
        setSelectedIds(prev => {
            const next = new Set(prev);
            next.has(id) ? next.delete(id) : next.add(id);
            return next;
        });
    };

    const executeBulkDelete = async () => {
        setBulkConfirm(false);
        setIsBulkDeleting(true);
        try {
            const res = await fetch('/api/attributes/bulk-delete', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ ids: Array.from(selectedIds) }),
            });
            const data = await res.json();
            if (!res.ok) throw new Error(data.error || 'Bulk delete failed');
            setSelectedIds(new Set());
            if (editingId && selectedIds.has(editingId)) closeModal();
            router.refresh();
            if (data.skipped?.length) {
                alert(`Deleted ${data.deleted}. Skipped ${data.skipped.length} system attribute(s).`);
            }
        } catch (error: any) {
            alert(error.message);
        } finally {
            setIsBulkDeleting(false);
        }
    };

    const hasActiveFilters = filterDataTypes.size > 0 || filterCategories.size > 0 || filterSystem !== 'all' || filterRelation !== null;

    // ─────────────────────────────────────────────────────────────────────────

    return (
        <>
            <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
                {/* Card header */}
                <div style={{ padding: 'var(--space-4)', borderBottom: '1px solid var(--color-border)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <div>
                        <h3 className="card-title text-lg font-semibold">Attributes</h3>
                        <p style={{ fontSize: '12px', color: 'var(--color-text-muted)', marginTop: '2px' }}>
                            Product attributes mapped to categories. Defines what data each product type can have.
                        </p>
                    </div>
                    <button className="btn btn-primary btn-sm" onClick={openAddModal}>+ New Attribute</button>
                </div>

                {/* ── Filter toolbar ─────────────────────────────────────────── */}
                <div style={{
                    padding: 'var(--space-3) var(--space-4)',
                    borderBottom: '1px solid var(--color-border)',
                    background: 'var(--color-bg-elevated)',
                    display: 'flex',
                    flexDirection: 'column',
                    gap: 'var(--space-2)',
                }}>
                    {/* Data Type pills */}
                    <div style={{ display: 'flex', alignItems: 'center', gap: '8px', flexWrap: 'wrap' }}>
                        <span style={{ fontSize: '11px', fontWeight: 600, color: 'var(--color-text-muted)', minWidth: '72px' }}>Data Type</span>
                        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '6px' }}>
                            {DATA_TYPES.map(dt => {
                                const active = filterDataTypes.has(dt.value);
                                return (
                                    <button
                                        key={dt.value}
                                        onClick={() => toggleFilterDataType(dt.value)}
                                        style={{
                                            fontSize: '11px',
                                            padding: '3px 10px',
                                            borderRadius: '12px',
                                            border: '1px solid',
                                            cursor: 'pointer',
                                            transition: 'all 0.15s',
                                            background: active ? 'var(--color-primary)' : 'var(--color-bg-card)',
                                            color: active ? 'white' : 'var(--color-text-secondary)',
                                            borderColor: active ? 'var(--color-primary)' : 'var(--color-border)',
                                            fontWeight: active ? 600 : 400,
                                        }}
                                    >
                                        {dt.label}
                                    </button>
                                );
                            })}
                        </div>
                    </div>

                    {/* Category filter — SearchableMultiSelect */}
                    {categories.length > 0 && (
                        <div style={{ display: 'flex', alignItems: 'flex-start', gap: '8px' }}>
                            <span style={{ fontSize: '11px', fontWeight: 600, color: 'var(--color-text-muted)', minWidth: '72px', paddingTop: '7px' }}>Category</span>
                            <div style={{ flex: 1, maxWidth: '600px' }}>
                                <SearchableMultiSelect
                                    options={sortedCategoryOptions}
                                    selected={Array.from(filterCategories)}
                                    onChange={(ids) => setFilterCategories(new Set(ids))}
                                    placeholder="Filter by category…"
                                />
                            </div>
                        </div>
                    )}

                    {/* Relation chips */}
                    <div style={{ display: 'flex', alignItems: 'center', gap: '8px', flexWrap: 'wrap' }}>
                        <span style={{ fontSize: '11px', fontWeight: 600, color: 'var(--color-text-muted)', minWidth: '72px' }}>Relation</span>
                        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '6px' }}>
                            {([
                                { value: 'parent', label: 'Is Parent' },
                                { value: 'child',  label: 'Is Child' },
                                { value: 'none',   label: 'No Relation' },
                            ] as const).map(({ value, label }) => {
                                const active = filterRelation === value;
                                return (
                                    <button
                                        key={value}
                                        onClick={() => setFilterRelation(active ? null : value)}
                                        style={{
                                            fontSize: '11px',
                                            padding: '3px 10px',
                                            borderRadius: '12px',
                                            border: '1px solid',
                                            cursor: 'pointer',
                                            transition: 'all 0.15s',
                                            background: active ? 'var(--color-primary)' : 'var(--color-bg-card)',
                                            color: active ? 'white' : 'var(--color-text-secondary)',
                                            borderColor: active ? 'var(--color-primary)' : 'var(--color-border)',
                                            fontWeight: active ? 600 : 400,
                                        }}
                                    >
                                        {label}
                                    </button>
                                );
                            })}
                        </div>
                    </div>

                    {/* System toggle + clear */}
                    <div style={{ display: 'flex', alignItems: 'center', gap: '8px', flexWrap: 'wrap' }}>
                        <span style={{ fontSize: '11px', fontWeight: 600, color: 'var(--color-text-muted)', minWidth: '72px' }}>System</span>
                        <div style={{ display: 'flex', gap: 0, border: '1px solid var(--color-border)', borderRadius: 'var(--radius-md)', overflow: 'hidden' }}>
                            {(['all', 'user', 'system'] as SystemFilter[]).map((val, i) => {
                                const label = val === 'all' ? 'All' : val === 'user' ? 'User-defined' : 'System only';
                                const active = filterSystem === val;
                                return (
                                    <button
                                        key={val}
                                        onClick={() => setFilterSystem(val)}
                                        style={{
                                            fontSize: '11px',
                                            padding: '3px 12px',
                                            border: 'none',
                                            borderLeft: i > 0 ? '1px solid var(--color-border)' : 'none',
                                            cursor: 'pointer',
                                            background: active ? 'var(--color-primary)' : 'var(--color-bg-card)',
                                            color: active ? 'white' : 'var(--color-text-secondary)',
                                            fontWeight: active ? 600 : 400,
                                            transition: 'all 0.15s',
                                        }}
                                    >
                                        {label}
                                    </button>
                                );
                            })}
                        </div>
                        {hasActiveFilters && (
                            <button
                                onClick={() => {
                                    setFilterDataTypes(new Set());
                                    setFilterCategories(new Set());
                                    setFilterSystem('all');
                                    setFilterRelation(null);
                                }}
                                style={{ fontSize: '11px', color: 'var(--color-text-muted)', background: 'none', border: 'none', cursor: 'pointer', textDecoration: 'underline', padding: '0 4px' }}
                            >
                                Clear filters
                            </button>
                        )}
                        {hasActiveFilters && (
                            <span style={{ fontSize: '11px', color: 'var(--color-text-muted)' }}>
                                Showing {filteredAttributes.length} of {attributes.length}
                            </span>
                        )}
                    </div>
                </div>

                {/* Table */}
                <table className="data-table">
                    <thead>
                        <tr>
                            <th style={{ width: '36px', paddingLeft: 'var(--space-4)' }}>
                                <input
                                    type="checkbox"
                                    checked={allSelectableSelected}
                                    onChange={toggleSelectAll}
                                    title="Select all non-system attributes"
                                    style={{ cursor: 'pointer' }}
                                />
                            </th>
                            <th>Name</th>
                            <th>Data Type</th>
                            <th>Unit</th>
                            <th style={{ textAlign: 'center' }}>Sort</th>
                            <th style={{ textAlign: 'center' }}>Categories</th>
                            <th style={{ textAlign: 'center' }}>Products</th>
                            <th style={{ textAlign: 'right' }}>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {filteredAttributes.map((attr) => (
                            <tr key={attr.id} style={{
                                backgroundColor: selectedIds.has(attr.id)
                                    ? 'var(--color-bg-card-hover)'
                                    : 'transparent'
                            }}>
                                <td style={{ paddingLeft: 'var(--space-4)', width: '36px' }}>
                                    <input
                                        type="checkbox"
                                        checked={selectedIds.has(attr.id)}
                                        onChange={() => toggleSelect(attr.id)}
                                        disabled={!isSelectable(attr)}
                                        title={attr.isSystem ? 'System attributes cannot be deleted' : undefined}
                                        style={{ cursor: isSelectable(attr) ? 'pointer' : 'not-allowed', opacity: isSelectable(attr) ? 1 : 0.35 }}
                                    />
                                </td>
                                <td style={{ fontWeight: 500, paddingLeft: 'var(--space-4)' }}>
                                    <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                                        {attr.name}
                                        {attr.isSystem && (
                                            <span style={{ fontSize: '9px', background: 'var(--color-primary)', color: 'white', padding: '1px 6px', borderRadius: '8px', fontWeight: 600 }}>
                                                SYS
                                            </span>
                                        )}
                                    </div>
                                    {attr.description && (
                                        <div style={{ fontSize: '11px', color: 'var(--color-text-muted)', marginTop: '2px' }}>{attr.description}</div>
                                    )}
                                </td>
                                <td>
                                    <span style={{ fontSize: '11px', background: 'var(--color-bg-elevated)', padding: '2px 8px', borderRadius: '10px', color: 'var(--color-text-secondary)', border: '1px solid var(--color-border)' }}>
                                        {DATA_TYPES.find(d => d.value === attr.dataType)?.label ?? attr.dataType}
                                    </span>
                                </td>
                                <td style={{ color: 'var(--color-text-secondary)', fontSize: '13px' }}>{attr.unit || '—'}</td>
                                <td style={{ textAlign: 'center', color: 'var(--color-text-muted)', fontSize: '12px', fontVariantNumeric: 'tabular-nums' }}>
                                    {attr.sortOrder ?? 0}
                                </td>
                                <td
                                    style={{ maxWidth: 260, cursor: 'pointer' }}
                                    title="Click to edit category assignments"
                                    onClick={() => openCatModal(attr)}
                                >
                                    <div style={{ display: 'flex', flexWrap: 'wrap', gap: '4px' }}>
                                        {(attr.categoryMappings?.length ?? 0) === 0 ? (
                                            <span style={{
                                                fontSize: '11px',
                                                color: 'var(--color-primary)',
                                                opacity: 0.7,
                                                textDecoration: 'underline',
                                                textDecorationStyle: 'dashed',
                                            }}>Add categories…</span>
                                        ) : (
                                            attr.categoryMappings.map((m: any) => (
                                                <span key={m.id} style={{
                                                    fontSize: '11px',
                                                    background: 'var(--color-bg-elevated)',
                                                    color: 'var(--color-text-secondary)',
                                                    border: '1px solid var(--color-border)',
                                                    borderRadius: '999px',
                                                    padding: '2px 7px',
                                                    whiteSpace: 'nowrap',
                                                    transition: 'border-color 0.15s',
                                                }}>
                                                    {m.category?.name ?? '?'}
                                                </span>
                                            ))
                                        )}
                                    </div>
                                </td>
                                <td style={{ textAlign: 'center' }}>
                                    <span style={{ fontSize: '12px', background: 'var(--color-bg-elevated)', padding: '2px 8px', borderRadius: '12px', color: 'var(--color-text-secondary)' }}>
                                        {attr._count?.productValues ?? 0}
                                    </span>
                                </td>
                                <td style={{ textAlign: 'right', whiteSpace: 'nowrap' }}>
                                    <button className="btn btn-sm btn-ghost" onClick={() => openEditModal(attr)}>Edit</button>
                                    <button
                                        className="btn btn-sm btn-ghost"
                                        style={{ color: 'var(--color-danger)', marginLeft: '4px' }}
                                        onClick={() => handleDelete(attr.id)}
                                        disabled={isDeleting || attr.isSystem}
                                        title={attr.isSystem ? 'System attribute' : 'Delete'}
                                    >
                                        ✕
                                    </button>
                                </td>
                            </tr>
                        ))}
                        {filteredAttributes.length === 0 && (
                            <tr>
                                <td colSpan={7} style={{ padding: '2rem', textAlign: 'center', color: 'var(--color-text-muted)' }}>
                                    {hasActiveFilters
                                        ? 'No attributes match the current filters.'
                                        : 'No attributes yet. Click "+ New Attribute" to define industry-specific product attributes.'}
                                </td>
                            </tr>
                        )}
                    </tbody>
                </table>

                {/* Bulk action toolbar */}
                {selectedIds.size > 0 && (
                    <div style={{
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'space-between',
                        padding: 'var(--space-3) var(--space-4)',
                        borderTop: '1px solid var(--color-border)',
                        background: 'var(--color-bg-elevated)',
                    }}>
                        <span style={{ fontSize: '13px', color: 'var(--color-text-secondary)' }}>
                            <strong style={{ color: 'var(--color-text-primary)' }}>{selectedIds.size}</strong> selected
                        </span>
                        <div style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
                            <button className="btn btn-sm btn-secondary" onClick={() => setSelectedIds(new Set())}>Clear</button>
                            <button
                                className="btn btn-sm"
                                style={{ background: 'var(--color-danger)', color: 'white' }}
                                onClick={() => setBulkConfirm(true)}
                                disabled={isBulkDeleting}
                            >
                                {isBulkDeleting ? 'Deleting...' : `Delete ${selectedIds.size}`}
                            </button>
                        </div>
                    </div>
                )}
            </div>

            {/* ── Attribute Edit/Add Modal ───────────────────────────────────── */}
            <Modal
                isOpen={isModalOpen}
                onClose={closeModal}
                title={isAdding ? 'New Attribute' : `Edit Attribute`}
                subtitle={isAdding ? 'Define a new product attribute' : editTarget?.name}
                size="lg"
                footer={
                    <div style={{ display: 'flex', justifyContent: 'space-between', width: '100%' }}>
                        {editingId ? (
                            <button
                                type="button"
                                className="btn btn-ghost"
                                style={{ color: 'var(--color-danger)' }}
                                onClick={() => handleDelete(editingId)}
                                disabled={isDeleting || isSystem}
                            >
                                {isDeleting ? '...' : 'Delete'}
                            </button>
                        ) : <div />}
                        <div style={{ display: 'flex', gap: '0.5rem' }}>
                            <button type="button" className="btn btn-secondary" onClick={closeModal}>Cancel</button>
                            <button
                                type="button"
                                className="btn btn-primary"
                                onClick={(e) => saveAttribute(e as any)}
                                disabled={isSaving}
                            >
                                {isSaving ? 'Saving...' : 'Save'}
                            </button>
                        </div>
                    </div>
                }
            >
                <form onSubmit={saveAttribute} style={{ padding: '1.5rem', display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                    <div>
                        <label className="block text-sm font-semibold mb-1">Name *</label>
                        <input type="text" className="form-input w-full" value={name} onChange={e => setName(e.target.value)} required placeholder="e.g. BTU Input" />
                    </div>

                    {editingId && (
                        <div>
                            <label className="block text-sm font-semibold mb-1">Slug</label>
                            <input
                                type="text"
                                className="form-input w-full"
                                value={slug}
                                onChange={e => setSlug(e.target.value.toLowerCase().replace(/\s+/g, '-').replace(/[^\w-]/g, ''))}
                                placeholder="e.g. btu-input"
                                style={{ fontFamily: 'monospace', fontSize: '13px' }}
                            />
                            <p style={{ fontSize: '11px', color: 'var(--color-text-muted)', marginTop: '4px' }}>Used by importers and APIs. Auto-generated on creation.</p>
                        </div>
                    )}

                    <div>
                        <label className="block text-sm font-semibold mb-1">Description</label>
                        <textarea className="form-input w-full" rows={2} value={description} onChange={e => setDescription(e.target.value)} placeholder="Brief explanation of this attribute..." style={{ resize: 'vertical' }} />
                    </div>

                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
                        <div>
                            <label className="block text-sm font-semibold mb-1">Data Type</label>
                            <select className="form-select w-full" value={dataType} onChange={e => setDataType(e.target.value)}>
                                {DATA_TYPES.map(dt => (
                                    <option key={dt.value} value={dt.value}>{dt.label}</option>
                                ))}
                            </select>
                        </div>
                        <div>
                            <label className="block text-sm font-semibold mb-1">Unit</label>
                            <input type="text" className="form-input w-full" value={unit} onChange={e => setUnit(e.target.value)} placeholder="e.g. BTU, sq ft, inches" />
                        </div>
                    </div>

                    {NEEDS_OPTIONS.includes(dataType) && (
                        <div>
                            <label className="block text-sm font-semibold mb-1">Options</label>
                            <input type="text" className="form-input w-full" value={options} onChange={e => setOptions(e.target.value)} placeholder="Option A, Option B, Option C" />
                            <p style={{ fontSize: '11px', color: 'var(--color-text-muted)', marginTop: '4px' }}>Comma-separated list of allowed values.</p>
                        </div>
                    )}

                    <div>
                        <label className="block text-sm font-semibold mb-1">Industry Hint</label>
                        <input type="text" className="form-input w-full" value={industry} onChange={e => setIndustry(e.target.value)} placeholder="e.g. hearth, outdoor-kitchen, grills" />
                        <p style={{ fontSize: '11px', color: 'var(--color-text-muted)', marginTop: '4px' }}>Which industry this attribute is most relevant to.</p>
                    </div>

                    <div style={{ display: 'flex', gap: '1rem' }}>
                        <div style={{ flex: 1 }}>
                            <label className="block text-sm font-semibold mb-1">Sort Order</label>
                            <input type="number" className="form-input w-full" value={sortOrder} onChange={e => setSortOrder(e.target.value)} />
                        </div>
                        <div style={{ flex: 1, display: 'flex', alignItems: 'flex-end', paddingBottom: '2px' }}>
                            <label style={{ display: 'flex', alignItems: 'center', gap: '6px', cursor: 'pointer', fontSize: '13px' }}>
                                <input type="checkbox" checked={isSystem} onChange={e => setIsSystem(e.target.checked)} />
                                System Attribute
                            </label>
                        </div>
                    </div>

                    {/* ── Child Attributes (Dependencies) ─────────────── */}
                    {editingId && NEEDS_OPTIONS.includes(dataType) && (
                        <div style={{ borderTop: '1px solid var(--color-border)', paddingTop: 'var(--space-3)', marginTop: 'var(--space-1)' }}>
                            <h4 className="text-sm font-semibold" style={{ marginBottom: '4px' }}>Child Attributes</h4>
                            <p style={{ fontSize: '11px', color: 'var(--color-text-muted)', marginBottom: 'var(--space-3)' }}>
                                Define sub-attributes that appear when this attribute{' '}
                                {(dataType === 'multi_select' || dataType === 'enum') ? 'contains a matching value' : 'equals a specific value'}.
                                Example: Fuel Type = &ldquo;Gas&rdquo; &rarr; also show &ldquo;Gas Type&rdquo; (Natural Gas / Liquid Propane).
                            </p>

                            {/* Existing dependencies grouped by trigger value */}
                            {editDeps.length > 0 && (() => {
                                const grouped: Record<string, any[]> = {};
                                editDeps.forEach(d => {
                                    if (!grouped[d.triggerValue]) grouped[d.triggerValue] = [];
                                    grouped[d.triggerValue].push(d);
                                });
                                return (
                                    <div style={{ display: 'flex', flexDirection: 'column', gap: '8px', marginBottom: 'var(--space-3)' }}>
                                        {Object.entries(grouped).map(([trigger, deps]) => (
                                            <div key={trigger} style={{
                                                padding: '8px 12px',
                                                background: 'var(--color-bg-elevated)',
                                                borderRadius: 'var(--radius-md)',
                                                border: '1px solid var(--color-border)',
                                            }}>
                                                <p style={{ fontSize: '11px', fontWeight: 600, color: 'var(--color-text-muted)', marginBottom: '6px' }}>
                                                    When{' '}<span style={{ color: 'var(--color-primary)', fontStyle: 'italic' }}>"{trigger}"</span>{' '}{(dataType === 'multi_select' || dataType === 'enum') ? 'contains a match' : 'is selected'}, also show:
                                                </p>
                                                <div style={{ display: 'flex', flexWrap: 'wrap', gap: '4px' }}>
                                                    {deps.map((dep: any) => (
                                                        <span key={dep.id} style={{
                                                            display: 'inline-flex', alignItems: 'center', gap: '4px',
                                                            fontSize: '12px', padding: '2px 8px', borderRadius: '8px',
                                                            background: 'var(--color-bg-card)', border: '1px solid var(--color-border)',
                                                        }}>
                                                            {dep.childAttribute?.name ?? dep.childAttributeId}
                                                            <button
                                                                type="button"
                                                                onClick={() => removeDep(dep.id)}
                                                                style={{ color: 'var(--color-danger)', background: 'none', border: 'none', cursor: 'pointer', fontSize: '13px', lineHeight: 1, padding: '0 1px' }}
                                                            >✕</button>
                                                        </span>
                                                    ))}
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                );
                            })()}

                            {/* Add new dependency rule */}
                            <div style={{ display: 'flex', gap: '8px', alignItems: 'flex-end', flexWrap: 'wrap' }}>
                                <div style={{ flex: '0 0 160px' }}>
                                    <label style={{ fontSize: '11px', fontWeight: 600, color: 'var(--color-text-muted)', display: 'block', marginBottom: '3px' }}>
                                        {(dataType === 'multi_select' || dataType === 'enum') ? 'When value contains' : 'When value is selected'}
                                    </label>
                                    <select
                                        className="form-input"
                                        value={depTrigger}
                                        onChange={e => setDepTrigger(e.target.value)}
                                        style={{ fontSize: '12px', padding: '4px 8px' }}
                                    >
                                        <option value="">— pick value —</option>
                                        {options.split(',').map(o => o.trim()).filter(Boolean).map(opt => (
                                            <option key={opt} value={opt}>{opt}</option>
                                        ))}
                                    </select>
                                </div>
                                <div style={{ flex: 1, minWidth: '180px' }}>
                                    <label style={{ fontSize: '11px', fontWeight: 600, color: 'var(--color-text-muted)', display: 'block', marginBottom: '3px' }}>Also show attribute</label>
                                    <select
                                        className="form-input"
                                        value={depChildId}
                                        onChange={e => setDepChildId(e.target.value)}
                                        style={{ fontSize: '12px', padding: '4px 8px' }}
                                    >
                                        <option value="">— pick attribute —</option>
                                        {attributes
                                            .filter(a => a.id !== editingId)
                                            .map(a => (
                                                <option key={a.id} value={a.id}>{a.name}</option>
                                            ))}
                                    </select>
                                </div>
                                <button
                                    type="button"
                                    className="btn btn-secondary btn-sm"
                                    onClick={addDep}
                                    disabled={!depTrigger || !depChildId || isAddingDep}
                                    style={{ flexShrink: 0 }}
                                >
                                    {isAddingDep ? 'Adding…' : '+ Add Rule'}
                                </button>
                            </div>
                        </div>
                    )}

                    {/* Hidden submit handler */}
                    <button type="submit" style={{ display: 'none' }} />
                </form>
            </Modal>

            {/* Delete confirmation dialog */}
            <ConfirmDialog
                isOpen={!!confirmDelete}
                title="Delete Attribute"
                message={(() => {
                    const attr = attributes.find(a => a.id === confirmDelete?.id);
                    const count = attr?._count?.productValues ?? 0;
                    return count > 0
                        ? `Delete "${confirmDelete?.name}"? This attribute has ${count} product value${count === 1 ? '' : 's'} that will also be removed.`
                        : `Are you sure you want to delete "${confirmDelete?.name}"? This action cannot be undone.`;
                })()}
                confirmLabel="Delete"
                variant="danger"
                onConfirm={executeDelete}
                onCancel={() => setConfirmDelete(null)}
                isLoading={isDeleting}
            />

            {/* Bulk delete confirmation */}
            <ConfirmDialog
                isOpen={bulkConfirm}
                title="Delete Selected Attributes"
                message={`Delete ${selectedIds.size} selected attribute${selectedIds.size === 1 ? '' : 's'}? Their category mappings and any product values will also be removed. This cannot be undone.`}
                confirmLabel={`Delete ${selectedIds.size}`}
                variant="danger"
                onConfirm={executeBulkDelete}
                onCancel={() => setBulkConfirm(false)}
                isLoading={isBulkDeleting}
            />
            {/* ── Category Mapping Modal ──────────────────────────────────────── */}
            <Modal
                isOpen={!!catModalAttr}
                onClose={() => { if (!catModalSaving) { setCatModalAttr(null); setCatModalStatus('idle'); } }}
                title={`Category Mappings — ${catModalAttr?.name ?? ''}`}
                subtitle="Select which product categories this attribute applies to"
                size="md"
                footer={
                    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', width: '100%' }}>
                        {catModalStatus === 'saved' && (
                            <span style={{ color: 'var(--color-success)', fontWeight: 600, fontSize: 'var(--font-size-sm)' }}>✓ Saved</span>
                        )}
                        {catModalStatus === 'error' && catModalError && (
                            <span style={{ color: 'var(--color-error)', fontSize: 'var(--font-size-sm)' }}>✕ {catModalError}</span>
                        )}
                        {catModalStatus === 'idle' && <span />}
                        <div style={{ display: 'flex', gap: '0.75rem' }}>
                            <button type="button" className="btn btn-secondary" onClick={() => setCatModalAttr(null)} disabled={catModalSaving}>
                                Cancel
                            </button>
                            <button type="button" className="btn btn-primary" onClick={saveCatModal} disabled={catModalSaving}>
                                {catModalSaving ? 'Saving…' : 'Save Mappings'}
                            </button>
                        </div>
                    </div>
                }
            >
                <div style={{ padding: '1.5rem', display: 'flex', flexDirection: 'column', gap: '1.25rem', minHeight: '420px' }}>
                    <div>
                        <p style={{ fontSize: '12px', color: 'var(--color-text-muted)', marginBottom: '0.75rem' }}>
                            Add or remove category assignments. Products in assigned categories will show this attribute field on their edit page.
                        </p>
                        <SearchableMultiSelect
                            options={sortedCategoryOptions}
                            selected={catModalIds}
                            onChange={setCatModalIds}
                            placeholder="Search and select categories…"
                        />
                    </div>

                    {/* Existing mapping rows with Required/Filterable toggles */}
                    {catModalMappings.length > 0 && (
                        <div style={{ borderTop: '1px solid var(--color-border)', paddingTop: '1rem' }}>
                            <h5 style={{ fontSize: '11px', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.06em', color: 'var(--color-text-muted)', marginBottom: '0.75rem' }}>
                                Mapping Options
                            </h5>
                            <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                                {catModalMappings
                                    .filter(m => catModalIds.includes(m.categoryId ?? m.category?.id))
                                    .map(mapping => {
                                        const catId = mapping.categoryId ?? mapping.category?.id;
                                        // Parse parent attribute's full option list
                                        const allOptions = catModalAttr?.options
                                            ? catModalAttr.options.split(',').map((s: string) => s.trim()).filter(Boolean)
                                            : [];
                                        const allowedSet = new Set<string>(
                                            mapping.allowedOptions
                                                ? mapping.allowedOptions.split(',').map((s: string) => s.trim()).filter(Boolean)
                                                : allOptions
                                        );
                                        const hasOptionFilter = NEEDS_OPTIONS.includes(catModalAttr?.dataType ?? '') && allOptions.length > 0;
                                        return (
                                            <div key={mapping.id ?? catId} style={{
                                                padding: '10px 12px',
                                                background: 'var(--color-bg-elevated)',
                                                borderRadius: 'var(--radius-md)',
                                                border: '1px solid var(--color-border)',
                                                fontSize: '13px',
                                            }}>
                                                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: hasOptionFilter ? '8px' : 0 }}>
                                                    <span style={{ fontWeight: 500, color: 'var(--color-text-primary)' }}>
                                                        {mapping.category?.name ?? 'Unknown'}
                                                    </span>
                                                    <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                                                        <button
                                                            type="button"
                                                            onClick={() => toggleCatModalFlag(catId, 'isRequired', mapping.isRequired)}
                                                            style={{
                                                                fontSize: '11px', padding: '2px 8px', borderRadius: '8px',
                                                                border: '1px solid', cursor: 'pointer',
                                                                background: mapping.isRequired ? 'var(--color-warning)' : 'transparent',
                                                                color: mapping.isRequired ? 'white' : 'var(--color-text-muted)',
                                                                borderColor: mapping.isRequired ? 'var(--color-warning)' : 'var(--color-border)',
                                                                fontWeight: mapping.isRequired ? 600 : 400,
                                                                transition: 'all 0.15s',
                                                            }}
                                                        >
                                                            {mapping.isRequired ? 'Required' : 'Optional'}
                                                        </button>
                                                        <button
                                                            type="button"
                                                            onClick={() => toggleCatModalFlag(catId, 'isFilterable', mapping.isFilterable)}
                                                            style={{
                                                                fontSize: '11px', padding: '2px 8px', borderRadius: '8px',
                                                                border: '1px solid', cursor: 'pointer',
                                                                background: mapping.isFilterable ? 'var(--color-primary)' : 'transparent',
                                                                color: mapping.isFilterable ? 'white' : 'var(--color-text-muted)',
                                                                borderColor: mapping.isFilterable ? 'var(--color-primary)' : 'var(--color-border)',
                                                                fontWeight: mapping.isFilterable ? 600 : 400,
                                                                transition: 'all 0.15s',
                                                            }}
                                                        >
                                                            Filterable
                                                        </button>
                                                    </div>
                                                </div>
                                                {/* Allowed Options chips — only for select/enum/multi_select */}
                                                {hasOptionFilter && (
                                                    <div>
                                                        <p style={{ fontSize: '10px', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.05em', color: 'var(--color-text-muted)', marginBottom: '5px' }}>
                                                            Allowed Options for this Category
                                                        </p>
                                                        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '4px' }}>
                                                            {allOptions.map((opt: string) => {
                                                                const active = allowedSet.has(opt);
                                                                return (
                                                                    <button
                                                                        key={opt}
                                                                        type="button"
                                                                        onClick={() => toggleCatModalAllowedOption(catId, opt, allOptions)}
                                                                        style={{
                                                                            fontSize: '11px', padding: '2px 8px', borderRadius: '8px',
                                                                            border: '1px solid', cursor: 'pointer',
                                                                            background: active ? 'var(--color-bg-card)' : 'transparent',
                                                                            color: active ? 'var(--color-text-primary)' : 'var(--color-text-muted)',
                                                                            borderColor: active ? 'var(--color-primary)' : 'var(--color-border)',
                                                                            fontWeight: active ? 500 : 400,
                                                                            opacity: active ? 1 : 0.5,
                                                                            transition: 'all 0.15s',
                                                                            textDecoration: active ? 'none' : 'line-through',
                                                                        }}
                                                                    >
                                                                        {opt}
                                                                    </button>
                                                                );
                                                            })}
                                                        </div>
                                                        {mapping.allowedOptions && (
                                                            <p style={{ fontSize: '10px', color: 'var(--color-text-muted)', marginTop: '4px' }}>
                                                                {allowedSet.size} of {allOptions.length} options allowed
                                                            </p>
                                                        )}
                                                    </div>
                                                )}
                                            </div>
                                        );
                                    })
                                }
                            </div>
                            <p style={{ fontSize: '11px', color: 'var(--color-text-muted)', marginTop: '0.5rem' }}>
                                Flag changes apply immediately. New categories get defaults (Optional, Filterable) after Save.
                            </p>
                        </div>
                    )}
                </div>
            </Modal>
        </>
    );
}
