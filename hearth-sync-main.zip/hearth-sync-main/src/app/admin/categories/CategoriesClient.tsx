"use client";

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import Modal from '@/components/Modal';
import ConfirmDialog from '@/components/ui/ConfirmDialog';

type BulkAction = 'delete' | 'move-parent';

export default function CategoriesClient({ categories }: { categories: any[] }) {
    const router = useRouter();

    // ── Modal state ───────────────────────────────────────────────────────────
    const [editTarget, setEditTarget] = useState<any | null>(null);
    const [isModalOpen, setIsModalOpen] = useState(false);

    // ── Form state ────────────────────────────────────────────────────────────
    const [name, setName] = useState('');
    const [slug, setSlug] = useState('');
    const [parentId, setParentId] = useState('');
    const [sortOrder, setSortOrder] = useState('0');
    const [categoryResearch, setCategoryResearch] = useState('');
    const [likeTerms, setLikeTerms] = useState('');
    const [isSaving, setIsSaving] = useState(false);
    const [isDeleting, setIsDeleting] = useState(false);

    // ── Multi-select state ────────────────────────────────────────────────────
    const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
    const [bulkAction, setBulkAction] = useState<BulkAction>('delete');
    const [isBulkWorking, setIsBulkWorking] = useState(false);

    // ── Bulk action modals ────────────────────────────────────────────────────
    const [bulkDeleteModalOpen, setBulkDeleteModalOpen] = useState(false);
    const [bulkMoveModalOpen, setBulkMoveModalOpen] = useState(false);
    const [bulkMoveParentId, setBulkMoveParentId] = useState('');

    // ── Single-item delete dialogs ────────────────────────────────────────────
    const [deleteDialog, setDeleteDialog] = useState<{
        id: string; name: string; productCount: number; show: boolean;
    } | null>(null);
    const [moveTargetId, setMoveTargetId] = useState('');
    const [confirmDialog, setConfirmDialog] = useState<{
        show: boolean; id: string; name: string;
    } | null>(null);

    // ─────────────────────────────────────────────────────────────────────────

    const parentOptions = categories.filter(c => !c.parentId);
    const isAdding = isModalOpen && editTarget !== null && !editTarget.id;
    const editingId: string | null = isModalOpen && editTarget?.id ? editTarget.id : null;

    const openAddModal = () => {
        setEditTarget({});
        setName(''); setSlug(''); setParentId(''); setSortOrder('0');
        setCategoryResearch(''); setLikeTerms('');
        setIsModalOpen(true);
    };

    const openEditModal = (cat: any) => {
        setEditTarget(cat);
        setName(cat.name); setSlug(cat.slug || '');
        setParentId(cat.parentId || '');
        setSortOrder(cat.sortOrder?.toString() || '0');
        setCategoryResearch(cat.categoryResearch || '');
        setLikeTerms(cat.likeTerms || '');
        setIsModalOpen(true);
    };

    const closeModal = () => {
        setIsModalOpen(false);
        setEditTarget(null);
    };

    const saveCategory = async (e: React.FormEvent) => {
        e.preventDefault();
        setIsSaving(true);
        try {
            const payload = {
                name,
                ...(!isAdding && slug ? { slug: slug.trim() } : {}),
                parentId: parentId || null,
                sortOrder: parseInt(sortOrder) || 0,
                categoryResearch: categoryResearch || null,
                likeTerms: likeTerms || null,
            };
            const res = isAdding
                ? await fetch('/api/categories', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) })
                : await fetch(`/api/categories/${editingId}`, { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
            if (!res.ok) { const d = await res.json(); throw new Error(d.error || 'Failed to save'); }
            router.refresh(); closeModal();
        } catch (err: any) { alert(err.message); } finally { setIsSaving(false); }
    };

    const handleDelete = async (id: string) => {
        const cat = categories.find(c => c.id === id);
        if (!cat) return;
        setIsDeleting(true);
        try {
            const res = await fetch(`/api/categories/${id}`, { method: 'DELETE' });
            const data = await res.json();
            if (res.ok) { router.refresh(); if (editingId === id) closeModal(); return; }
            if (data.code === 'HAS_CHILDREN') { setConfirmDialog({ show: true, id: '', name: data.error }); return; }
            if (data.code === 'HAS_PRODUCTS') {
                setDeleteDialog({ id, name: cat.name, productCount: data.productCount, show: true });
                setMoveTargetId(''); return;
            }
            throw new Error(data.error || 'Failed to delete category');
        } catch (err: any) { setConfirmDialog({ show: true, id: '', name: err.message }); }
        finally { setIsDeleting(false); }
    };

    const initiateDelete = (id: string) => {
        const cat = categories.find(c => c.id === id);
        if (cat) setConfirmDialog({ show: true, id, name: cat.name });
    };

    const executeConfirmedDelete = async () => {
        if (!confirmDialog?.id) { setConfirmDialog(null); return; }
        await handleDelete(confirmDialog.id); setConfirmDialog(null);
    };

    const confirmDeleteWithProducts = async (action: 'move' | 'disconnect') => {
        if (!deleteDialog) return;
        setIsDeleting(true);
        try {
            let url = `/api/categories/${deleteDialog.id}?force=true`;
            if (action === 'move' && moveTargetId) url += `&moveTo=${moveTargetId}`;
            const res = await fetch(url, { method: 'DELETE' });
            const data = await res.json();
            if (!res.ok) throw new Error(data.error || 'Failed to delete');
            router.refresh(); if (editingId === deleteDialog.id) closeModal(); setDeleteDialog(null);
        } catch (err: any) { alert(err.message); } finally { setIsDeleting(false); }
    };

    // ── Multi-select ──────────────────────────────────────────────────────────
    const allSelected = categories.length > 0 && categories.every(c => selectedIds.has(c.id));
    const toggleSelectAll = () =>
        setSelectedIds(allSelected ? new Set() : new Set(categories.map(c => c.id)));
    const toggleSelect = (id: string) => {
        setSelectedIds(prev => {
            const next = new Set(prev);
            next.has(id) ? next.delete(id) : next.add(id);
            return next;
        });
    };

    const handleBulkApply = () => {
        if (bulkAction === 'delete') setBulkDeleteModalOpen(true);
        else if (bulkAction === 'move-parent') { setBulkMoveParentId(''); setBulkMoveModalOpen(true); }
    };

    const executeBulkDelete = async () => {
        setBulkDeleteModalOpen(false);
        setIsBulkWorking(true);
        try {
            const res = await fetch('/api/categories/bulk-delete', {
                method: 'POST', headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ ids: Array.from(selectedIds) }),
            });
            const data = await res.json();
            if (!res.ok) throw new Error(data.error || 'Bulk delete failed');
            if (editingId && selectedIds.has(editingId)) closeModal();
            setSelectedIds(new Set());
            router.refresh();
            if (data.skipped?.length) alert(`Deleted ${data.deleted}. Skipped ${data.skipped.length} (had sub-categories).`);
        } catch (err: any) { alert(err.message); } finally { setIsBulkWorking(false); }
    };

    const executeBulkMove = async () => {
        if (!bulkMoveParentId) return;
        setBulkMoveModalOpen(false);
        setIsBulkWorking(true);
        try {
            const res = await fetch('/api/categories/bulk-move-parent', {
                method: 'POST', headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ ids: Array.from(selectedIds), parentId: bulkMoveParentId }),
            });
            const data = await res.json();
            if (!res.ok) throw new Error(data.error || 'Bulk move failed');
            setSelectedIds(new Set());
            router.refresh();
        } catch (err: any) { alert(err.message); } finally { setIsBulkWorking(false); }
    };

    // ─────────────────────────────────────────────────────────────────────────

    const likeTermBadges = (terms: string) =>
        terms?.split(',').map(t => t.trim()).filter(Boolean) ?? [];

    const parents = categories.filter(c => !c.parentId);
    const childrenOf = (pid: string) => categories.filter(c => c.parentId === pid);
    const sortedCategories: { cat: any; isParent: boolean; siblingCount: number; index: number }[] = [];
    for (const parent of parents) {
        const kids = childrenOf(parent.id);
        sortedCategories.push({ cat: parent, isParent: true, siblingCount: 0, index: 0 });
        kids.forEach((child, idx) =>
            sortedCategories.push({ cat: child, isParent: false, siblingCount: kids.length, index: idx })
        );
    }
    categories
        .filter(c => c.parentId && !parents.find((p: any) => p.id === c.parentId))
        .forEach(c => sortedCategories.push({ cat: c, isParent: false, siblingCount: 1, index: 0 }));

    const BulkToolbar = ({ position }: { position: 'top' | 'bottom' }) => {
        if (selectedIds.size === 0) return null;
        const borderStyle = position === 'top'
            ? { borderBottom: '1px solid var(--color-border)' }
            : { borderTop: '1px solid var(--color-border)' };
        return (
            <div style={{
                display: 'flex', alignItems: 'center', gap: '10px',
                padding: 'var(--space-3) var(--space-4)',
                background: 'var(--color-bg-elevated)',
                ...borderStyle,
            }}>
                <span style={{ fontSize: '13px', color: 'var(--color-text-secondary)', minWidth: 'max-content' }}>
                    <strong style={{ color: 'var(--color-text-primary)' }}>{selectedIds.size}</strong> selected
                </span>
                <select
                    className="form-select"
                    value={bulkAction}
                    onChange={e => setBulkAction(e.target.value as BulkAction)}
                    style={{ fontSize: '13px', padding: '4px 10px', height: '32px' }}
                >
                    <option value="delete">Delete</option>
                    <option value="move-parent">Move to Parent</option>
                </select>
                <button
                    className="btn btn-sm btn-primary"
                    onClick={handleBulkApply}
                    disabled={isBulkWorking}
                    style={{ minWidth: '64px' }}
                >
                    {isBulkWorking ? '…' : 'Apply'}
                </button>
                <button className="btn btn-sm btn-secondary" onClick={() => setSelectedIds(new Set())} disabled={isBulkWorking}>
                    Clear
                </button>
            </div>
        );
    };

    const selectedMoveParent = parentOptions.find(p => p.id === bulkMoveParentId);

    /** Export sub-categories only as a CSV download */
    const exportSubcategoriesCsv = () => {
        const subCats = categories.filter(c => c.parentId);
        const header = ['Parent Category', 'Sub-Category', 'Slug', 'Like Terms', 'Product Count'];

        const escape = (val: string | null | undefined) => {
            const s = (val ?? '').toString();
            // Wrap in quotes if contains comma, quote, or newline
            return /[,"\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
        };

        const rows = subCats.map(c => {
            const parent = categories.find(p => p.id === c.parentId);
            return [
                escape(parent?.name),
                escape(c.name),
                escape(c.slug),
                escape(c.likeTerms ?? c.like_terms),
                String(c._count?.products ?? 0),
            ].join(',');
        });

        const csv = [header.join(','), ...rows].join('\n');
        const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
        const url  = URL.createObjectURL(blob);
        const a    = document.createElement('a');
        a.href     = url;
        a.download = `sub-categories-${new Date().toISOString().slice(0, 10)}.csv`;
        a.click();
        URL.revokeObjectURL(url);
    };

    return (
        <>
            <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
                {/* Card header */}
                <div style={{ padding: 'var(--space-4)', borderBottom: '1px solid var(--color-border)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <h3 className="card-title text-lg font-semibold">Hierarchy</h3>
                    <div style={{ display: 'flex', gap: '8px' }}>
                        <button className="btn btn-secondary btn-sm" onClick={exportSubcategoriesCsv}>↓ Export CSV</button>
                        <button className="btn btn-primary btn-sm" onClick={openAddModal}>+ New Category</button>
                    </div>
                </div>

                <BulkToolbar position="top" />

                <table className="data-table">
                    <thead>
                        <tr>
                            <th style={{ width: '36px', paddingLeft: 'var(--space-4)' }}>
                                <input type="checkbox" checked={allSelected} onChange={toggleSelectAll} title="Select all" style={{ cursor: 'pointer' }} />
                            </th>
                            <th style={{ width: '35%' }}>Name</th>
                            <th>Slug</th>
                            <th style={{ textAlign: 'center' }}>Children</th>
                            <th>Like Terms</th>
                            <th style={{ textAlign: 'center' }}>Products</th>
                            <th style={{ textAlign: 'right' }}>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {sortedCategories.map(({ cat, isParent, siblingCount, index }) => (
                            <tr key={cat.id} style={{
                                backgroundColor: selectedIds.has(cat.id)
                                    ? 'var(--color-bg-card-hover)' : 'transparent',
                            }}>
                                <td style={{ paddingLeft: 'var(--space-4)', width: '36px' }}>
                                    <input type="checkbox" checked={selectedIds.has(cat.id)} onChange={() => toggleSelect(cat.id)} style={{ cursor: 'pointer' }} />
                                </td>
                                <td style={{ fontWeight: isParent ? 600 : 400, paddingLeft: isParent ? 'var(--space-4)' : '2.5rem', position: 'relative' }}>
                                    {!isParent && <span style={{ position: 'absolute', left: '1rem', top: 0, bottom: index === siblingCount - 1 ? '50%' : 0, width: '1px', background: 'var(--color-border)' }} />}
                                    {!isParent && <span style={{ position: 'absolute', left: '1rem', top: '50%', width: '0.75rem', height: '1px', background: 'var(--color-border)' }} />}
                                    {isParent
                                        ? <span style={{ color: 'var(--color-text-primary)' }}>{cat.name}</span>
                                        : <span style={{ color: 'var(--color-text-secondary)' }}>{cat.name}</span>
                                    }
                                    {isParent && cat._count?.children > 0 && (
                                        <span style={{ marginLeft: '0.5rem', fontSize: '11px', background: 'var(--color-bg-elevated)', color: 'var(--color-text-secondary)', border: '1px solid var(--color-border)', padding: '1px 8px', borderRadius: '12px', fontWeight: 500 }}>
                                            {cat._count.children}
                                        </span>
                                    )}
                                </td>
                                <td style={{ fontFamily: 'monospace', fontSize: '11px', color: 'var(--color-text-secondary)' }}>{cat.slug}</td>
                                <td style={{ textAlign: 'center', color: 'var(--color-text-muted)', fontSize: '12px' }}>
                                    {isParent
                                        ? <span>{cat._count?.children ?? 0} sub</span>
                                        : <span style={{ fontSize: '10px', background: 'var(--color-bg-elevated)', padding: '1px 6px', borderRadius: '8px', border: '1px solid var(--color-border)' }}>child</span>
                                    }
                                </td>
                                <td>
                                    <div style={{ display: 'flex', flexWrap: 'wrap', gap: '4px' }}>
                                        {likeTermBadges(cat.likeTerms).slice(0, 3).map((term: string) => (
                                            <span key={term} style={{ fontSize: '10px', background: 'var(--color-bg-elevated)', padding: '2px 6px', borderRadius: '10px', color: 'var(--color-text-secondary)', border: '1px solid var(--color-border)' }}>{term}</span>
                                        ))}
                                        {likeTermBadges(cat.likeTerms).length > 3 && (
                                            <span style={{ fontSize: '10px', color: 'var(--color-text-muted)' }}>+{likeTermBadges(cat.likeTerms).length - 3}</span>
                                        )}
                                    </div>
                                </td>
                                <td style={{ textAlign: 'center' }}>
                                    <span style={{ fontSize: '12px', background: 'var(--color-bg-elevated)', padding: '2px 8px', borderRadius: '12px', color: 'var(--color-text-secondary)' }}>
                                        {cat._count.products}
                                    </span>
                                </td>
                                <td style={{ textAlign: 'right', whiteSpace: 'nowrap' }}>
                                    <button className="btn btn-sm btn-ghost" onClick={() => openEditModal(cat)}>Edit</button>
                                    <button className="btn btn-sm btn-ghost" style={{ color: 'var(--color-danger)', marginLeft: '4px' }} onClick={() => initiateDelete(cat.id)} disabled={isDeleting} title="Delete">✕</button>
                                </td>
                            </tr>
                        ))}
                        {categories.length === 0 && (
                            <tr><td colSpan={7} style={{ padding: '2rem', textAlign: 'center', color: 'var(--color-text-muted)' }}>No categories found.</td></tr>
                        )}
                    </tbody>
                </table>

                <BulkToolbar position="bottom" />
            </div>

            {/* ── Category Edit / Add Modal ──────────────────────────────────── */}
            <Modal
                isOpen={isModalOpen}
                onClose={closeModal}
                title={isAdding ? 'Add Category' : 'Edit Category'}
                subtitle={isAdding ? 'Create a new product category' : editTarget?.name}
                size="md"
                footer={
                    <div style={{ display: 'flex', justifyContent: 'space-between', width: '100%' }}>
                        {editingId ? (
                            <button
                                type="button"
                                className="btn btn-ghost"
                                style={{ color: 'var(--color-danger)' }}
                                onClick={() => initiateDelete(editingId)}
                                disabled={isDeleting}
                            >
                                {isDeleting ? '...' : 'Delete'}
                            </button>
                        ) : <div />}
                        <div style={{ display: 'flex', gap: '0.5rem' }}>
                            <button type="button" className="btn btn-secondary" onClick={closeModal}>Cancel</button>
                            <button
                                type="button"
                                className="btn btn-primary"
                                onClick={(e) => saveCategory(e as any)}
                                disabled={isSaving}
                            >
                                {isSaving ? 'Saving...' : 'Save'}
                            </button>
                        </div>
                    </div>
                }
            >
                <form onSubmit={saveCategory} style={{ padding: '1.5rem', display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                    <div>
                        <label className="block text-sm font-semibold mb-1">Name</label>
                        <input type="text" className="form-input w-full" value={name} onChange={e => setName(e.target.value)} required />
                    </div>

                    {editingId && (
                        <div>
                            <label className="block text-sm font-semibold mb-1">Slug</label>
                            <input
                                type="text"
                                className="form-input w-full"
                                value={slug}
                                onChange={e => setSlug(e.target.value.toLowerCase().replace(/\s+/g, '-').replace(/[^\w-]/g, ''))}
                                placeholder="e.g. fire-pits"
                                style={{ fontFamily: 'monospace', fontSize: '13px' }}
                            />
                            <p style={{ fontSize: '11px', color: 'var(--color-text-muted)', marginTop: '4px' }}>Used in URLs and API queries. Auto-generated on creation.</p>
                        </div>
                    )}

                    <div>
                        <label className="block text-sm font-semibold mb-1">Parent Category</label>
                        <select className="form-select w-full" value={parentId} onChange={e => setParentId(e.target.value)}>
                            <option value="">None (Top Level)</option>
                            {parentOptions.filter(c => c.id !== editingId).map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                        </select>
                        <p style={{ fontSize: '11px', color: 'var(--color-text-muted)', marginTop: '4px' }}>Sub-categories cannot have further children.</p>
                    </div>

                    <div>
                        <label className="block text-sm font-semibold mb-1">Like Terms</label>
                        <input type="text" className="form-input w-full" value={likeTerms} onChange={e => setLikeTerms(e.target.value)} placeholder="e.g. Hearth Accessory, Fireplace Accessory" />
                        <p style={{ fontSize: '11px', color: 'var(--color-text-muted)', marginTop: '4px' }}>Comma-separated synonyms.</p>
                    </div>

                    <div>
                        <label className="block text-sm font-semibold mb-1">Category Research</label>
                        <textarea className="form-input w-full" rows={5} value={categoryResearch} onChange={e => setCategoryResearch(e.target.value)} placeholder="LLM-generated notes..." style={{ resize: 'vertical', fontFamily: 'inherit' }} />
                        <p style={{ fontSize: '11px', color: 'var(--color-text-muted)', marginTop: '4px' }}>Used by AI systems.</p>
                    </div>

                    <div>
                        <label className="block text-sm font-semibold mb-1">Sort Order</label>
                        <input type="number" className="form-input w-full" value={sortOrder} onChange={e => setSortOrder(e.target.value)} />
                    </div>

                    <button type="submit" style={{ display: 'none' }} />
                </form>
            </Modal>

            {/* ── Single-item delete (has products) ────────────────────────── */}
            {deleteDialog?.show && (
                <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.5)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 1000 }}>
                    <div className="card" style={{ width: '480px', maxWidth: '90vw', padding: 'var(--space-6)' }}>
                        <h3 className="font-semibold text-lg" style={{ marginBottom: 'var(--space-3)' }}>Delete "{deleteDialog.name}"?</h3>
                        <p style={{ color: 'var(--color-text-secondary)', marginBottom: 'var(--space-4)', lineHeight: 1.5 }}>
                            This category has <strong>{deleteDialog.productCount}</strong> product{deleteDialog.productCount === 1 ? '' : 's'}. Choose how to handle them:
                        </p>
                        <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-3)', marginBottom: 'var(--space-5)' }}>
                            <div style={{ border: '1px solid var(--color-border)', borderRadius: 'var(--radius-md)', padding: 'var(--space-3)' }}>
                                <div style={{ fontWeight: 600, fontSize: '14px', marginBottom: 'var(--space-2)' }}>Move products to another category</div>
                                <select className="form-select w-full" value={moveTargetId} onChange={e => setMoveTargetId(e.target.value)} style={{ marginBottom: 'var(--space-2)' }}>
                                    <option value="">Select a category...</option>
                                    {categories.filter(c => c.id !== deleteDialog.id).map(c => <option key={c.id} value={c.id}>{c.parentId ? '  └ ' : ''}{c.name}</option>)}
                                </select>
                                <button className="btn btn-primary btn-sm w-full" disabled={!moveTargetId || isDeleting} onClick={() => confirmDeleteWithProducts('move')}>
                                    {isDeleting ? 'Processing...' : 'Move Products & Delete Category'}
                                </button>
                            </div>
                            <div style={{ border: '1px solid var(--color-border)', borderRadius: 'var(--radius-md)', padding: 'var(--space-3)' }}>
                                <div style={{ fontWeight: 600, fontSize: '14px', marginBottom: 'var(--space-2)' }}>Remove association only</div>
                                <p style={{ fontSize: '12px', color: 'var(--color-text-muted)', marginBottom: 'var(--space-2)' }}>Products remain but won't be linked to any category.</p>
                                <button className="btn btn-sm w-full" style={{ background: 'var(--color-danger)', color: 'white' }} disabled={isDeleting} onClick={() => confirmDeleteWithProducts('disconnect')}>
                                    {isDeleting ? 'Processing...' : 'Disconnect Products & Delete Category'}
                                </button>
                            </div>
                        </div>
                        <button className="btn btn-secondary w-full" onClick={() => setDeleteDialog(null)} disabled={isDeleting}>Cancel</button>
                    </div>
                </div>
            )}

            {/* Single-item confirm delete */}
            <ConfirmDialog
                isOpen={!!(confirmDialog?.show && confirmDialog.id)}
                title="Delete Category"
                message={`Are you sure you want to delete "${confirmDialog?.name}"? This action cannot be undone.`}
                confirmLabel="Delete" variant="danger"
                onConfirm={executeConfirmedDelete} onCancel={() => setConfirmDialog(null)} isLoading={isDeleting}
            />
            {confirmDialog?.show && !confirmDialog.id && (
                <ConfirmDialog isOpen title="Cannot Delete" message={confirmDialog.name}
                    confirmLabel="OK" cancelLabel="" variant="warning"
                    onConfirm={() => setConfirmDialog(null)} onCancel={() => setConfirmDialog(null)}
                />
            )}

            {/* ── Bulk Delete Modal ─────────────────────────────────────────── */}
            <Modal
                isOpen={bulkDeleteModalOpen}
                onClose={() => setBulkDeleteModalOpen(false)}
                title="Delete Selected Categories"
                subtitle={`${selectedIds.size} categor${selectedIds.size === 1 ? 'y' : 'ies'} will be permanently deleted`}
                size="sm"
                footer={
                    <>
                        <button className="btn btn-secondary" onClick={() => setBulkDeleteModalOpen(false)}>Cancel</button>
                        <button
                            className="btn"
                            style={{ background: 'var(--color-danger)', color: 'white' }}
                            onClick={executeBulkDelete}
                            disabled={isBulkWorking}
                        >
                            {isBulkWorking ? 'Deleting…' : `Delete ${selectedIds.size}`}
                        </button>
                    </>
                }
            >
                <div style={{ padding: '1.5rem' }}>
                    <p style={{ color: 'var(--color-text-secondary)', lineHeight: 1.6, marginBottom: '1rem' }}>
                        This will permanently delete the selected categories. Any products in these categories will be disconnected.
                        Categories that have sub-categories will be skipped automatically.
                    </p>
                    <p style={{ fontSize: '13px', color: 'var(--color-text-muted)' }}>This action cannot be undone.</p>
                </div>
            </Modal>

            {/* ── Bulk Move Parent Modal ────────────────────────────────────── */}
            <Modal
                isOpen={bulkMoveModalOpen}
                onClose={() => setBulkMoveModalOpen(false)}
                title="Move to Parent Category"
                subtitle={`Reassign parent for ${selectedIds.size} selected categor${selectedIds.size === 1 ? 'y' : 'ies'}`}
                size="sm"
                footer={
                    <>
                        <button className="btn btn-secondary" onClick={() => setBulkMoveModalOpen(false)}>Cancel</button>
                        <button
                            className="btn btn-primary"
                            onClick={executeBulkMove}
                            disabled={!bulkMoveParentId || isBulkWorking}
                        >
                            {isBulkWorking ? 'Moving…' : `Move ${selectedIds.size}`}
                        </button>
                    </>
                }
            >
                <div style={{ padding: '1.5rem', display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                    <p style={{ color: 'var(--color-text-secondary)', lineHeight: 1.6 }}>
                        Choose a top-level category to move the selected items under.
                    </p>
                    <div>
                        <label className="block text-sm font-semibold mb-1">New Parent Category</label>
                        <select
                            className="form-select w-full"
                            value={bulkMoveParentId}
                            onChange={e => setBulkMoveParentId(e.target.value)}
                        >
                            <option value="">Select a parent…</option>
                            {parentOptions.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                        </select>
                    </div>
                    {selectedMoveParent && (
                        <p style={{ fontSize: '13px', color: 'var(--color-text-muted)' }}>
                            The selected {selectedIds.size} categor{selectedIds.size === 1 ? 'y' : 'ies'} will become sub-categories of <strong style={{ color: 'var(--color-text-primary)' }}>{selectedMoveParent.name}</strong>.
                        </p>
                    )}
                </div>
            </Modal>
        </>
    );
}
