"use client";

import { useState } from 'react';
import { useRouter } from 'next/navigation';

export default function SimpleTaxonomyClient({
    items,
    title,
    apiUrlBase
}: {
    items: any[],
    title: string,
    apiUrlBase: string
}) {
    const router = useRouter();

    const [editingId, setEditingId] = useState<string | null>(null);
    const [isAdding, setIsAdding] = useState(false);

    const [name, setName] = useState('');

    const [isSaving, setIsSaving] = useState(false);
    const [isDeleting, setIsDeleting] = useState(false);

    const openForm = (item?: any) => {
        if (item) {
            setEditingId(item.id);
            setIsAdding(false);
            setName(item.name);
        } else {
            setEditingId(null);
            setIsAdding(true);
            setName('');
        }
    };

    const cancelForm = () => {
        setEditingId(null);
        setIsAdding(false);
    };

    const saveItem = async (e: React.FormEvent) => {
        e.preventDefault();
        setIsSaving(true);
        try {
            const payload = { name };

            let res;
            if (isAdding) {
                res = await fetch(apiUrlBase, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(payload)
                });
            } else {
                res = await fetch(`${apiUrlBase}/${editingId}`, {
                    method: 'PATCH',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(payload)
                });
            }
            if (!res.ok) {
                const data = await res.json();
                throw new Error(data.error || 'Failed to save item');
            }
            router.refresh();
            cancelForm();
        } catch (error: any) {
            alert(error.message);
        } finally {
            setIsSaving(false);
        }
    };

    const handleDelete = async (id: string) => {
        if (!confirm('Are you sure you want to delete this item? Products might be orphaned.')) return;
        setIsDeleting(true);
        try {
            const res = await fetch(`${apiUrlBase}/${id}`, {
                method: 'DELETE',
            });
            if (!res.ok) throw new Error('Failed to delete item');
            router.refresh();
            if (editingId === id) cancelForm();
        } catch (error: any) {
            alert(error.message);
        } finally {
            setIsDeleting(false);
        }
    };

    return (
        <div style={{ display: 'grid', gridTemplateColumns: 'minmax(0, 2fr) minmax(0, 1fr)', gap: '1.5rem', alignItems: 'start' }}>
            <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
                <div style={{ padding: 'var(--space-4)', borderBottom: '1px solid var(--color-border)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <h3 className="card-title text-lg font-semibold">{title}</h3>
                    <button className="btn btn-primary btn-sm" onClick={() => openForm()}>+ New {title}</button>
                </div>
                <table className="data-table">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Slug</th>
                            <th>Products</th>
                            <th style={{ textAlign: 'right' }}>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {items.map((item) => (
                            <tr key={item.id} style={{ backgroundColor: editingId === item.id ? 'var(--color-bg-card-hover)' : 'transparent' }}>
                                <td style={{ fontWeight: 500, paddingLeft: 'var(--space-4)' }}>
                                    {item.name}
                                </td>
                                <td style={{ fontFamily: 'monospace', fontSize: '11px', color: 'var(--color-text-secondary)' }}>
                                    {item.slug}
                                </td>
                                <td>
                                    <span style={{ fontSize: '12px', background: 'var(--color-bg-elevated)', padding: '2px 8px', borderRadius: '12px', color: 'var(--color-text-secondary)' }}>
                                        {item._count?.products || 0}
                                    </span>
                                </td>
                                <td style={{ textAlign: 'right' }}>
                                    <button className="btn btn-sm btn-ghost" onClick={() => openForm(item)}>Edit</button>
                                </td>
                            </tr>
                        ))}
                        {items.length === 0 && (
                            <tr>
                                <td colSpan={4} style={{ padding: '2rem', textAlign: 'center', color: 'var(--color-text-muted)' }}>
                                    No {title.toLowerCase()} found.
                                </td>
                            </tr>
                        )}
                    </tbody>
                </table>
            </div>

            {/* Right side form */}
            <div className="card p-6" style={{ position: 'sticky', top: '100px' }}>
                {!isAdding && !editingId ? (
                    <div style={{ textAlign: 'center', color: 'var(--color-text-muted)', padding: '2rem 0' }}>
                        Select a {title.toLowerCase()} to edit or click "New {title}"
                    </div>
                ) : (
                    <form onSubmit={saveItem} style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                        <h3 className="font-semibold text-lg pb-2 border-b border-[var(--color-border)]">
                            {isAdding ? `Add ${title}` : `Edit ${title}`}
                        </h3>

                        <div>
                            <label className="block text-sm font-semibold mb-1">Name</label>
                            <input type="text" className="form-input w-full" value={name} onChange={e => setName(e.target.value)} required />
                        </div>

                        <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: '1rem' }}>
                            {editingId ? (
                                <button type="button" className="btn btn-ghost text-[var(--color-danger)]" onClick={() => handleDelete(editingId)} disabled={isDeleting}>
                                    {isDeleting ? '...' : 'Delete'}
                                </button>
                            ) : (
                                <div></div>
                            )}
                            <div style={{ display: 'flex', gap: '0.5rem' }}>
                                <button type="button" className="btn btn-secondary" onClick={cancelForm}>Cancel</button>
                                <button type="submit" className="btn btn-primary" disabled={isSaving}>
                                    {isSaving ? 'Saving...' : 'Save'}
                                </button>
                            </div>
                        </div>
                    </form>
                )}
            </div>
        </div>
    );
}
