"use client";

import { useState } from 'react';

export default function ExportManufacturersModal() {
    const [open, setOpen] = useState(false);
    const [mode, setMode] = useState<'manufacturers' | 'all'>('manufacturers');
    const [loading, setLoading] = useState(false);

    const handleExport = async () => {
        setLoading(true);
        try {
            const res = await fetch(`/api/manufacturers/export?mode=${mode}`);
            if (!res.ok) throw new Error('Export failed');
            const blob = await res.blob();
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = mode === 'all' ? 'manufacturers-all.csv' : 'manufacturers.csv';
            a.click();
            URL.revokeObjectURL(url);
            setOpen(false);
        } catch (err: any) {
            alert(err.message);
        } finally {
            setLoading(false);
        }
    };

    return (
        <>
            <button
                className="btn btn-secondary"
                onClick={() => setOpen(true)}
            >
                Export ↓
            </button>

            {open && (
                <div
                    style={{
                        position: 'fixed', inset: 0, zIndex: 50,
                        background: 'rgba(0,0,0,0.5)',
                        display: 'flex', alignItems: 'center', justifyContent: 'center',
                    }}
                    onClick={() => setOpen(false)}
                >
                    <div
                        className="card"
                        style={{ width: '360px', padding: '1.5rem', display: 'flex', flexDirection: 'column', gap: '1.25rem' }}
                        onClick={e => e.stopPropagation()}
                    >
                        <h3 style={{ fontWeight: 700, fontSize: 'var(--font-size-lg)' }}>Export Manufacturers</h3>

                        <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
                            <label style={{ display: 'flex', alignItems: 'flex-start', gap: '0.75rem', cursor: 'pointer' }}>
                                <input
                                    type="radio"
                                    name="export-mode"
                                    value="manufacturers"
                                    checked={mode === 'manufacturers'}
                                    onChange={() => setMode('manufacturers')}
                                    style={{ marginTop: '3px' }}
                                />
                                <div>
                                    <div style={{ fontWeight: 600 }}>Manufacturers only</div>
                                    <div style={{ fontSize: 'var(--font-size-xs)', color: 'var(--color-text-muted)' }}>
                                        One row per manufacturer — name, prefix, website, country, status
                                    </div>
                                </div>
                            </label>
                            <label style={{ display: 'flex', alignItems: 'flex-start', gap: '0.75rem', cursor: 'pointer' }}>
                                <input
                                    type="radio"
                                    name="export-mode"
                                    value="all"
                                    checked={mode === 'all'}
                                    onChange={() => setMode('all')}
                                    style={{ marginTop: '3px' }}
                                />
                                <div>
                                    <div style={{ fontWeight: 600 }}>All (manufacturers + brands)</div>
                                    <div style={{ fontSize: 'var(--font-size-xs)', color: 'var(--color-text-muted)' }}>
                                        One row per brand with parent manufacturer columns repeated
                                    </div>
                                </div>
                            </label>
                        </div>

                        <div style={{ display: 'flex', gap: '0.75rem', justifyContent: 'flex-end', borderTop: '1px solid var(--color-border)', paddingTop: '1rem' }}>
                            <button className="btn btn-ghost" onClick={() => setOpen(false)} disabled={loading}>
                                Cancel
                            </button>
                            <button className="btn btn-primary" onClick={handleExport} disabled={loading}>
                                {loading ? 'Exporting...' : 'Export CSV'}
                            </button>
                        </div>
                    </div>
                </div>
            )}
        </>
    );
}
