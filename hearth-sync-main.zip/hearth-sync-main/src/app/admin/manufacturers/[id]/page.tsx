import prisma from '@/lib/db';
import Link from 'next/link';
import { notFound } from 'next/navigation';

async function getManufacturer(id: string) {
    try {
        const manufacturer = await prisma.manufacturer.findUnique({
            where: { id },
            include: {
                brands: {
                    include: {
                        _count: { select: { products: true } },
                        scraperConfigs: { select: { id: true, isActive: true, lastSyncAt: true } },
                    },
                },
                integrations: true,
            },
        });
        return manufacturer;
    } catch {
        return null;
    }
}

export default async function ManufacturerDetailPage({
    params,
}: {
    params: { id: string };
}) {
    const manufacturer = await getManufacturer(params.id);
    if (!manufacturer) return notFound();

    const integration = manufacturer.integrations[0];

    return (
        <>
            <div className="page-header">
                <div>
                    <Link
                        href="/admin/manufacturers"
                        style={{
                            fontSize: 'var(--font-size-sm)',
                            color: 'var(--color-text-muted)',
                            marginBottom: 'var(--space-2)',
                            display: 'block',
                        }}
                    >
                        ← Back to Manufacturers
                    </Link>
                    <h2 className="page-title">{manufacturer.name}</h2>
                    <p className="page-subtitle">
                        {manufacturer.website || 'No website recorded'}
                    </p>
                </div>
                <div style={{ display: 'flex', gap: 'var(--space-3)' }}>
                    <Link href={`/admin/manufacturers/${manufacturer.id}/edit`} className="btn btn-secondary">Edit</Link>
                    <button className="btn btn-primary">🤖 Run Scraper</button>
                </div>
            </div>

            {/* Integration Details */}
            <div
                style={{
                    display: 'grid',
                    gridTemplateColumns: '1fr 1fr',
                    gap: 'var(--space-6)',
                    marginBottom: 'var(--space-8)',
                }}
            >
                <div className="card">
                    <h3
                        className="card-title"
                        style={{ marginBottom: 'var(--space-4)' }}
                    >
                        Integration Details
                    </h3>
                    <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-4)' }}>
                        <div>
                            <span
                                style={{
                                    fontSize: 'var(--font-size-xs)',
                                    color: 'var(--color-text-muted)',
                                    textTransform: 'uppercase',
                                }}
                            >
                                Method
                            </span>
                            <div>
                                <span className="badge badge-info">
                                    {integration?.integrationMethod || 'Not set'}
                                </span>
                            </div>
                        </div>
                        <div>
                            <span
                                style={{
                                    fontSize: 'var(--font-size-xs)',
                                    color: 'var(--color-text-muted)',
                                    textTransform: 'uppercase',
                                }}
                            >
                                Status
                            </span>
                            <div>
                                <span className="badge badge-active">
                                    {integration?.status || 'WISHLIST'}
                                </span>
                            </div>
                        </div>
                        <div>
                            <span
                                style={{
                                    fontSize: 'var(--font-size-xs)',
                                    color: 'var(--color-text-muted)',
                                    textTransform: 'uppercase',
                                }}
                            >
                                Partnership
                            </span>
                            <div style={{ fontSize: 'var(--font-size-sm)' }}>
                                {integration?.partnershipStatus || 'None'}
                            </div>
                        </div>
                        <div>
                            <span
                                style={{
                                    fontSize: 'var(--font-size-xs)',
                                    color: 'var(--color-text-muted)',
                                    textTransform: 'uppercase',
                                }}
                            >
                                Assigned Engineer
                            </span>
                            <div style={{ fontSize: 'var(--font-size-sm)' }}>
                                {integration?.assignedEngineer || 'Unassigned'}
                            </div>
                        </div>
                    </div>
                </div>

                <div className="card">
                    <h3
                        className="card-title"
                        style={{ marginBottom: 'var(--space-4)' }}
                    >
                        Developer Notes
                    </h3>
                    <div
                        style={{
                            fontSize: 'var(--font-size-sm)',
                            color: 'var(--color-text-secondary)',
                            whiteSpace: 'pre-wrap',
                            lineHeight: 1.7,
                        }}
                    >
                        {integration?.devNotes || 'No developer notes yet.'}
                    </div>
                </div>
            </div>

            {/* Brands Table */}
            <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
                <div
                    style={{
                        padding: 'var(--space-6)',
                        borderBottom: '1px solid var(--color-border)',
                        display: 'flex',
                        justifyContent: 'space-between',
                        alignItems: 'center',
                    }}
                >
                    <h3 className="card-title">
                        Brands ({manufacturer.brands.length})
                    </h3>
                </div>
                <table className="data-table">
                    <thead>
                        <tr>
                            <th>Brand</th>
                            <th>Products</th>
                            <th>Scraper</th>
                            <th>Last Sync</th>
                            <th>Active</th>
                        </tr>
                    </thead>
                    <tbody>
                        {manufacturer.brands.map((brand: any) => {
                            const config = brand.scraperConfigs[0];
                            return (
                                <tr key={brand.id}>
                                    <td style={{ fontWeight: 600 }}>{brand.name}</td>
                                    <td>{brand._count.products}</td>
                                    <td>
                                        <span
                                            className={`badge ${config ? 'badge-active' : 'badge-inactive'}`}
                                        >
                                            {config ? 'Configured' : 'None'}
                                        </span>
                                    </td>
                                    <td
                                        style={{
                                            fontSize: 'var(--font-size-xs)',
                                            color: 'var(--color-text-muted)',
                                        }}
                                    >
                                        {config?.lastSyncAt
                                            ? new Date(config.lastSyncAt).toLocaleDateString()
                                            : '—'}
                                    </td>
                                    <td>
                                        <span
                                            className={`badge ${brand.isActive ? 'badge-active' : 'badge-inactive'}`}
                                        >
                                            {brand.isActive ? 'Active' : 'Inactive'}
                                        </span>
                                    </td>
                                </tr>
                            );
                        })}
                    </tbody>
                </table>
            </div>
        </>
    );
}
