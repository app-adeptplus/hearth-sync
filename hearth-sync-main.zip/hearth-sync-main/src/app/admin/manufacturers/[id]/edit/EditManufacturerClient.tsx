"use client";

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import Modal from '@/components/Modal';

export default function EditManufacturerClient({ manufacturer }: { manufacturer: any }) {
    const router = useRouter();
    const [isSaving, setIsSaving] = useState(false);
    const [confirmingDelete, setConfirmingDelete] = useState(false);

    // All other manufacturers for migration dropdowns
    const [allManufacturers, setAllManufacturers] = useState<{ id: string; name: string }[]>([]);
    useEffect(() => {
        fetch('/api/manufacturers')
            .then(r => r.json())
            .then(d => setAllManufacturers(
                (d.data || []).filter((m: any) => m.id !== manufacturer.id)
            ))
            .catch(() => {});
    }, [manufacturer.id]);

    // Migration state — manufacturer level (only when brands.length === 1)
    const [migrateManufacturerOpen, setMigrateManufacturerOpen] = useState(false);
    const [migrateMfrTarget, setMigrateMfrTarget] = useState('');

    // Migration state — brand level (only when brands.length > 1)
    const [migrateBrandTarget, setMigrateBrandTarget] = useState<{ id: string; name: string } | null>(null);
    const [migrateBrandTargetMfr, setMigrateBrandTargetMfr] = useState('');

    // Manufacturer State
    const [name, setName] = useState(manufacturer.name || '');
    const [prefix, setPrefix] = useState(manufacturer.prefix || '');
    const [website, setWebsite] = useState(manufacturer.website || '');
    const [country, setCountry] = useState(manufacturer.country || 'US');
    const [description, setDescription] = useState(manufacturer.description || '');
    const [logoUrl, setLogoUrl] = useState(manufacturer.logoUrl || '');

    // Upload state
    const [isUploading, setIsUploading] = useState(false);

    const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>, setUrl: (url: string) => void) => {
        if (!e.target.files || e.target.files.length === 0) return;
        const file = e.target.files[0];
        setIsUploading(true);

        const formData = new FormData();
        formData.append('file', file);
        formData.append('folder', 'logos');

        try {
            const res = await fetch('/api/upload', {
                method: 'POST',
                body: formData,
            });
            if (!res.ok) throw new Error('Upload failed');
            const data = await res.json();
            setUrl(data.url);
        } catch (error: any) {
            alert(error.message);
        } finally {
            setIsUploading(false);
            e.target.value = ''; // Reset
        }
    };

    const handleDelete = async () => {
        setIsSaving(true);
        try {
            const res = await fetch(`/api/manufacturers/${manufacturer.id}`, { method: 'DELETE' });
            if (!res.ok) throw new Error('Failed to delete manufacturer');
            router.push('/admin/manufacturers');
        } catch (error: any) {
            alert(error.message);
            setIsSaving(false);
            setConfirmingDelete(false);
        }
    };

    const handleSaveManufacturer = async (e: React.FormEvent) => {
        e.preventDefault();
        setIsSaving(true);
        try {
            const res = await fetch(`/api/manufacturers/${manufacturer.id}`, {
                method: 'PATCH',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ name, prefix, website, country, description, logoUrl })
            });
            if (!res.ok) throw new Error('Failed to update manufacturer');
            router.refresh();
            alert('Manufacturer updated successfully!');
        } catch (error: any) {
            alert(error.message);
        } finally {
            setIsSaving(false);
        }
    };

    // Brand Management
    const [editingBrandId, setEditingBrandId] = useState<string | null>(null);
    const [isAddingBrand, setIsAddingBrand] = useState(false);
    const [confirmingDeleteBrandId, setConfirmingDeleteBrandId] = useState<string | null>(null);

    // Temporary brand state
    const [bName, setBName] = useState('');
    const [bWebsite, setBWebsite] = useState('');
    const [bBrandSku, setBBrandSku] = useState('');
    const [bLogoUrl, setBLogoUrl] = useState('');
    const [bIsActive, setBIsActive] = useState(true);

    const openBrandForm = (brand?: any) => {
        if (brand) {
            setEditingBrandId(brand.id);
            setIsAddingBrand(false);
            setBName(brand.name);
            setBWebsite(brand.website || '');
            setBBrandSku(brand.brandSku || '');
            setBLogoUrl(brand.logoUrl || '');
            setBIsActive(brand.isActive !== undefined ? brand.isActive : true);
        } else {
            setEditingBrandId(null);
            setIsAddingBrand(true);
            setBName('');
            setBWebsite('');
            setBBrandSku('');
            setBLogoUrl('');
            setBIsActive(true);
        }
    };

    const cancelBrandForm = () => {
        setEditingBrandId(null);
        setIsAddingBrand(false);
    };

    const saveBrand = async (e: React.FormEvent) => {
        e.preventDefault();
        setIsSaving(true);
        try {
            const payload = {
                name: bName,
                website: bWebsite,
                brandSku: bBrandSku,
                logoUrl: bLogoUrl,
                isActive: bIsActive,
                manufacturerId: manufacturer.id
            };

            let res;
            if (isAddingBrand) {
                res = await fetch('/api/brands', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(payload)
                });
            } else {
                res = await fetch(`/api/brands/${editingBrandId}`, {
                    method: 'PATCH',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(payload)
                });
            }
            if (!res.ok) throw new Error('Failed to save brand');
            router.refresh();
            cancelBrandForm();
        } catch (error: any) {
            alert(error.message);
        } finally {
            setIsSaving(false);
        }
    };

    const deleteBrand = async (brandId: string) => {
        setIsSaving(true);
        try {
            const res = await fetch(`/api/brands/${brandId}`, { method: 'DELETE' });
            if (!res.ok) throw new Error('Failed to delete brand');
            setConfirmingDeleteBrandId(null);
            router.refresh();
        } catch (error: any) {
            alert(error.message);
        } finally {
            setIsSaving(false);
        }
    };

    // "Convert to Sub-Brand": moves the single brand to the target manufacturer,
    // which also deletes this manufacturer (now empty).
    const handleMigrateManufacturer = async () => {
        if (!migrateMfrTarget) return;
        const singleBrand = manufacturer.brands[0];
        setIsSaving(true);
        try {
            const res = await fetch(`/api/brands/${singleBrand.id}`, {
                method: 'PATCH',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    manufacturerId: migrateMfrTarget,
                    deleteManufacturerIfEmpty: true,
                }),
            });
            if (!res.ok) throw new Error('Migration failed');
            setMigrateManufacturerOpen(false);
            router.push('/admin/manufacturers');
        } catch (error: any) {
            alert(error.message);
        } finally {
            setIsSaving(false);
        }
    };

    // "Move to Mfr": reassigns a single brand to another manufacturer.
    const handleMigrateBrand = async () => {
        if (!migrateBrandTarget || !migrateBrandTargetMfr) return;
        setIsSaving(true);
        try {
            const res = await fetch(`/api/brands/${migrateBrandTarget.id}`, {
                method: 'PATCH',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ manufacturerId: migrateBrandTargetMfr }),
            });
            if (!res.ok) throw new Error('Brand migration failed');
            setMigrateBrandTarget(null);
            setMigrateBrandTargetMfr('');
            router.refresh();
        } catch (error: any) {
            alert(error.message);
        } finally {
            setIsSaving(false);
        }
    };

    return (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '2rem' }}>
            {/* Manufacturer Details Form */}
            <form onSubmit={handleSaveManufacturer} className="card p-6" style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
                <h3 className="font-semibold text-lg pb-2 border-b border-[var(--color-border)]">Manufacturer Info</h3>

                <div style={{ display: 'flex', gap: '1.5rem', alignItems: 'flex-start' }}>
                    <div style={{ width: '150px', flexShrink: 0 }}>
                        <div style={{ width: '150px', height: '150px', border: '1px dashed var(--color-border)', borderRadius: 'var(--radius-md)', display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'var(--color-bg-elevated)', overflow: 'hidden', position: 'relative' }}>
                            {logoUrl ? (
                                <img src={logoUrl} alt="Logo" style={{ width: '100%', height: '100%', objectFit: 'contain', padding: '0.5rem' }} />
                            ) : (
                                <span style={{ color: 'var(--color-text-muted)', fontSize: '13px' }}>No Logo</span>
                            )}
                        </div>
                        <label className="btn btn-secondary btn-sm" style={{ marginTop: '0.5rem', width: '100%', textAlign: 'center', cursor: 'pointer' }}>
                            {isUploading ? 'Uploading...' : 'Upload Logo'}
                            <input type="file" accept="image/*" style={{ display: 'none' }} onChange={(e) => handleFileUpload(e, setLogoUrl)} disabled={isUploading} />
                        </label>
                        {logoUrl && (
                            <button type="button" className="btn btn-ghost btn-sm w-full mt-1 text-[var(--color-danger)]" onClick={() => setLogoUrl('')}>Remove</button>
                        )}
                    </div>

                    <div style={{ flex: 1, display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1.5rem' }}>
                        <div style={{ gridColumn: '1 / -1', display: 'grid', gridTemplateColumns: '2fr 1fr', gap: '1.5rem' }}>
                            <div>
                                <label className="block text-sm font-semibold mb-2">Company Name</label>
                                <input type="text" className="form-input w-full" value={name} onChange={e => setName(e.target.value)} required />
                            </div>
                            <div>
                                <label className="block text-sm font-semibold mb-2">Prefix</label>
                                <input type="text" className="form-input w-full" value={prefix} onChange={e => setPrefix(e.target.value)} placeholder="e.g. HGL" maxLength={10} />
                            </div>
                        </div>
                        <div>
                            <label className="block text-sm font-semibold mb-2">Website</label>
                            <input type="url" className="form-input w-full" value={website} onChange={e => setWebsite(e.target.value)} />
                        </div>
                        <div>
                            <label className="block text-sm font-semibold mb-2">Country</label>
                            <select className="form-select w-full" value={country} onChange={e => setCountry(e.target.value)}>
                                <option value="US">United States</option>
                                <option value="CA">Canada</option>
                                <option value="EU">Europe</option>
                                <option value="OTHER">Other</option>
                            </select>
                        </div>
                        <div style={{ gridColumn: '1 / -1' }}>
                            <label className="block text-sm font-semibold mb-2">Description</label>
                            <textarea className="form-textarea w-full" rows={3} value={description} onChange={e => setDescription(e.target.value)}></textarea>
                        </div>
                    </div>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', paddingTop: '1rem', borderTop: '1px solid var(--color-border)' }}>
                    {confirmingDelete ? (
                        <div style={{ display: 'flex', alignItems: 'center', gap: 'var(--space-3)' }}>
                            <span style={{ fontSize: 'var(--font-size-sm)', color: 'var(--color-danger)' }}>
                                Delete all brands &amp; products too?
                            </span>
                            <button
                                type="button"
                                className="btn btn-ghost btn-sm"
                                onClick={() => setConfirmingDelete(false)}
                                disabled={isSaving}
                            >
                                Cancel
                            </button>
                            <button
                                type="button"
                                className="btn btn-sm"
                                style={{ background: 'var(--color-danger)', color: '#fff', border: 'none' }}
                                onClick={handleDelete}
                                disabled={isSaving}
                            >
                                {isSaving ? 'Deleting...' : 'Yes, Delete'}
                            </button>
                        </div>
                    ) : (
                        <div style={{ display: 'flex', gap: 'var(--space-3)' }}>
                            <button
                                type="button"
                                className="btn btn-ghost btn-sm"
                                style={{ color: 'var(--color-danger)' }}
                                onClick={() => setConfirmingDelete(true)}
                                disabled={isSaving}
                            >
                                Delete Manufacturer
                            </button>
                            {manufacturer.brands.length === 1 && (
                                <button
                                    type="button"
                                    className="btn btn-ghost btn-sm"
                                    style={{ color: 'var(--color-text-muted)' }}
                                    onClick={() => { setMigrateMfrTarget(''); setMigrateManufacturerOpen(true); }}
                                    disabled={isSaving}
                                >
                                    Convert to Sub-Brand →
                                </button>
                            )}
                        </div>
                    )}
                    <button type="submit" className="btn btn-primary" disabled={isSaving}>
                        {isSaving ? 'Saving...' : 'Save Manufacturer Data'}
                    </button>
                </div>
            </form>

            {/* Migrate Manufacturer Modal — only reachable when brands.length === 1 */}
            <Modal
                isOpen={migrateManufacturerOpen}
                onClose={() => setMigrateManufacturerOpen(false)}
                title="Convert to Sub-Brand"
                subtitle={`Move "${manufacturer.name}" under another manufacturer as a brand.`}
                size="sm"
                footer={
                    <>
                        <button className="btn btn-secondary" onClick={() => setMigrateManufacturerOpen(false)} disabled={isSaving}>
                            Cancel
                        </button>
                        <button
                            className="btn btn-primary"
                            onClick={handleMigrateManufacturer}
                            disabled={isSaving || !migrateMfrTarget}
                        >
                            {isSaving ? 'Migrating…' : 'Confirm Migration'}
                        </button>
                    </>
                }
            >
                <div style={{ padding: '1.5rem', display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                    <p style={{ fontSize: 'var(--font-size-sm)', color: 'var(--color-text-secondary)', lineHeight: 1.5 }}>
                        The brand <strong>{manufacturer.brands[0]?.name}</strong> and all its products will be moved to the selected manufacturer.
                        This manufacturer record will be deleted. <strong style={{ color: 'var(--color-danger)' }}>This cannot be undone.</strong>
                    </p>
                    <label style={{ display: 'block' }}>
                        <span style={{ fontSize: 'var(--font-size-sm)', fontWeight: 600, display: 'block', marginBottom: '0.25rem' }}>
                            Move under which manufacturer?
                        </span>
                        <select
                            className="form-select w-full"
                            value={migrateMfrTarget}
                            onChange={e => setMigrateMfrTarget(e.target.value)}
                        >
                            <option value="">— Select manufacturer —</option>
                            {allManufacturers.map(m => (
                                <option key={m.id} value={m.id}>{m.name}</option>
                            ))}
                        </select>
                    </label>
                </div>
            </Modal>

            {/* Migrate Brand Modal — only reachable when brands.length > 1 */}
            <Modal
                isOpen={!!migrateBrandTarget}
                onClose={() => { setMigrateBrandTarget(null); setMigrateBrandTargetMfr(''); }}
                title="Move Brand to Another Manufacturer"
                subtitle={migrateBrandTarget ? `Reassign "${migrateBrandTarget.name}" to a different manufacturer.` : ''}
                size="sm"
                footer={
                    <>
                        <button className="btn btn-secondary" onClick={() => { setMigrateBrandTarget(null); setMigrateBrandTargetMfr(''); }} disabled={isSaving}>
                            Cancel
                        </button>
                        <button
                            className="btn btn-primary"
                            onClick={handleMigrateBrand}
                            disabled={isSaving || !migrateBrandTargetMfr}
                        >
                            {isSaving ? 'Moving…' : 'Move Brand'}
                        </button>
                    </>
                }
            >
                <div style={{ padding: '1.5rem', display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                    <p style={{ fontSize: 'var(--font-size-sm)', color: 'var(--color-text-secondary)', lineHeight: 1.5 }}>
                        All products under <strong>{migrateBrandTarget?.name}</strong> will follow this brand to its new manufacturer.
                    </p>
                    <label style={{ display: 'block' }}>
                        <span style={{ fontSize: 'var(--font-size-sm)', fontWeight: 600, display: 'block', marginBottom: '0.25rem' }}>
                            Move to which manufacturer?
                        </span>
                        <select
                            className="form-select w-full"
                            value={migrateBrandTargetMfr}
                            onChange={e => setMigrateBrandTargetMfr(e.target.value)}
                        >
                            <option value="">— Select manufacturer —</option>
                            {allManufacturers.map(m => (
                                <option key={m.id} value={m.id}>{m.name}</option>
                            ))}
                        </select>
                    </label>
                </div>
            </Modal>


            {/* Brands Management Section */}
            <div className="card p-6">
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem', paddingBottom: '0.5rem', borderBottom: '1px solid var(--color-border)' }}>
                    <h3 className="font-semibold text-lg">Brands ({manufacturer.brands.length})</h3>
                    <button className="btn btn-secondary btn-sm" onClick={() => openBrandForm()}>+ Add Brand</button>
                </div>

                {isAddingBrand || editingBrandId ? (
                    <form onSubmit={saveBrand} style={{ background: 'var(--color-bg-elevated)', border: '1px solid var(--color-border)', borderRadius: 'var(--radius-md)', padding: '1.5rem', marginBottom: '1.5rem' }}>
                        <h4 className="font-semibold mb-4">{isAddingBrand ? 'Add New Brand' : 'Edit Brand'}</h4>

                        <div style={{ display: 'flex', gap: '1.5rem', alignItems: 'flex-start' }}>
                            <div style={{ width: '100px', flexShrink: 0 }}>
                                <div style={{ width: '100px', height: '100px', border: '1px dashed var(--color-border)', borderRadius: 'var(--radius-sm)', display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'var(--color-bg)', overflow: 'hidden' }}>
                                    {bLogoUrl ? (
                                        <img src={bLogoUrl} alt="Logo" style={{ width: '100%', height: '100%', objectFit: 'contain', padding: '0.25rem' }} />
                                    ) : (
                                        <span style={{ color: 'var(--color-text-muted)', fontSize: '11px' }}>No Logo</span>
                                    )}
                                </div>
                                <label className="btn btn-secondary btn-sm" style={{ marginTop: '0.5rem', width: '100%', textAlign: 'center', cursor: 'pointer', padding: '0.2rem', fontSize: '11px' }}>
                                    {isUploading ? '...' : 'Upload Logo'}
                                    <input type="file" accept="image/*" style={{ display: 'none' }} onChange={(e) => handleFileUpload(e, setBLogoUrl)} disabled={isUploading} />
                                </label>
                                {bLogoUrl && (
                                    <button type="button" className="btn btn-ghost btn-sm w-full text-[var(--color-danger)]" style={{ fontSize: '11px', padding: 0 }} onClick={() => setBLogoUrl('')}>Remove</button>
                                )}
                            </div>

                            <div style={{ flex: 1, display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
                                <div>
                                    <label className="block text-xs font-semibold mb-1">Brand Name *</label>
                                    <input type="text" className="form-input w-full" style={{ padding: '0.4rem' }} value={bName} onChange={e => setBName(e.target.value)} required />
                                </div>
                                <div>
                                    <label className="block text-xs font-semibold mb-1">SKU Prefix</label>
                                    <input type="text" className="form-input w-full" style={{ padding: '0.4rem' }} value={bBrandSku} onChange={e => setBBrandSku(e.target.value)} placeholder="e.g. HGL" />
                                </div>
                                <div>
                                    <label className="block text-xs font-semibold mb-1">Website</label>
                                    <input type="url" className="form-input w-full" style={{ padding: '0.4rem' }} value={bWebsite} onChange={e => setBWebsite(e.target.value)} placeholder="https://" />
                                </div>
                                <div>
                                    <label className="block text-xs font-semibold mb-1">Status</label>
                                    <select className="form-select w-full" style={{ padding: '0.4rem' }} value={bIsActive ? 'true' : 'false'} onChange={e => setBIsActive(e.target.value === 'true')}>
                                        <option value="true">Active</option>
                                        <option value="false">Inactive</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div style={{ display: 'flex', gap: '0.5rem', justifyContent: 'flex-end', marginTop: '1.5rem' }}>
                            <button type="button" className="btn btn-ghost" onClick={cancelBrandForm}>Cancel</button>
                            <button type="submit" className="btn btn-primary" disabled={isSaving}>{isSaving ? 'Saving...' : 'Save Brand'}</button>
                        </div>
                    </form>
                ) : null}

                {manufacturer.brands.length > 0 ? (
                    <table className="data-table">
                        <thead>
                            <tr>
                                <th>Logo</th>
                                <th>Brand Name</th>
                                <th>SKU</th>
                                <th>Website</th>
                                <th>Products</th>
                                <th>Status</th>
                                <th style={{ textAlign: 'right' }}>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            {manufacturer.brands.map((brand: any) => (
                                <tr key={brand.id}>
                                    <td style={{ width: '60px' }}>
                                        {brand.logoUrl ? (
                                            <img src={brand.logoUrl} alt="Logo" style={{ width: '40px', height: '40px', objectFit: 'contain', background: 'white', borderRadius: '4px' }} />
                                        ) : (
                                            <div style={{ width: '40px', height: '40px', background: 'var(--color-bg-elevated)', borderRadius: '4px', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '10px', color: 'var(--color-text-muted)' }}>None</div>
                                        )}
                                    </td>
                                    <td className="font-semibold">{brand.name}</td>
                                    <td>{brand.brandSku || '—'}</td>
                                    <td>{brand.website || '—'}</td>
                                    <td style={{ fontWeight: 600, color: 'var(--color-amber)' }}>
                                        <Link
                                            href={`/admin/products?brand=${brand.id}`}
                                            target="_blank"
                                            rel="noopener noreferrer"
                                            style={{ color: 'var(--color-amber)', textDecoration: 'none' }}
                                            title="View products for this brand"
                                        >
                                            {brand._count?.products ?? '—'}
                                        </Link>
                                    </td>
                                    <td>
                                        <span className={`badge ${brand.isActive ? 'badge-active' : 'badge-inactive'}`}>
                                            {brand.isActive ? 'Active' : 'Inactive'}
                                        </span>
                                    </td>
                                    <td style={{ textAlign: 'right' }}>
                                        {confirmingDeleteBrandId === brand.id ? (
                                            <span style={{ display: 'inline-flex', alignItems: 'center', gap: '0.5rem' }}>
                                                <span style={{ fontSize: 'var(--font-size-xs)', color: 'var(--color-danger)' }}>Delete brand?</span>
                                                <button
                                                    className="btn btn-sm btn-ghost"
                                                    onClick={() => setConfirmingDeleteBrandId(null)}
                                                    disabled={isSaving}
                                                >
                                                    Cancel
                                                </button>
                                                <button
                                                    className="btn btn-sm"
                                                    style={{ background: 'var(--color-danger)', color: '#fff', border: 'none' }}
                                                    onClick={() => deleteBrand(brand.id)}
                                                    disabled={isSaving}
                                                >
                                                    {isSaving ? '…' : 'Confirm'}
                                                </button>
                                            </span>
                                        ) : (
                                            <span style={{ display: 'inline-flex', gap: '0.5rem' }}>
                                                <button className="btn btn-sm btn-ghost" onClick={() => openBrandForm(brand)}>Edit</button>
                                                {manufacturer.brands.length > 1 && (
                                                    <button
                                                        className="btn btn-sm btn-ghost"
                                                        style={{ color: 'var(--color-text-muted)' }}
                                                        onClick={() => { setMigrateBrandTargetMfr(''); setMigrateBrandTarget({ id: brand.id, name: brand.name }); }}
                                                    >
                                                        Move
                                                    </button>
                                                )}
                                                <button
                                                    className="btn btn-sm btn-ghost"
                                                    style={{ color: 'var(--color-danger)' }}
                                                    onClick={() => setConfirmingDeleteBrandId(brand.id)}
                                                >
                                                    Delete
                                                </button>
                                            </span>
                                        )}
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                ) : (
                    <div style={{ padding: '2rem', textAlign: 'center', color: 'var(--color-text-muted)' }}>
                        No brands created for this manufacturer yet.
                    </div>
                )}
            </div>
        </div>
    );
}
