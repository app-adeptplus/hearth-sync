import prisma from '@/lib/db';
import { notFound } from 'next/navigation';
import Link from 'next/link';
import EditManufacturerClient from './EditManufacturerClient';

export const dynamic = 'force-dynamic';

export default async function EditManufacturerPage({ params }: { params: { id: string } }) {
    const manufacturer = await prisma.manufacturer.findUnique({
        where: { id: params.id },
        include: {
            brands: {
                orderBy: { name: 'asc' },
                include: {
                    _count: { select: { products: true } },
                },
            },
        }
    });

    if (!manufacturer) {
        notFound();
    }

    return (
        <div className="max-w-4xl mx-auto app-content" style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem', margin: '0 auto' }}>
            <div className="page-header pb-6 border-b border-[var(--color-border)]">
                <div>
                    <h2 className="page-title">Edit {manufacturer.name}</h2>
                    <p className="page-subtitle">Update global settings and manage child brands</p>
                </div>
                <div style={{ display: 'flex', gap: 'var(--space-3)' }}>
                    <Link href={`/admin/manufacturers/${manufacturer.id}`} className="btn btn-ghost text-sm">
                        Go to view →
                    </Link>
                    <Link href="/admin/manufacturers" className="btn btn-secondary text-sm">
                        ← Manufacturers
                    </Link>
                </div>
            </div>

            <EditManufacturerClient manufacturer={manufacturer} />
        </div>
    );
}
