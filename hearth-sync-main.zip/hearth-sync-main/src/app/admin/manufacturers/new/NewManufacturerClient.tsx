"use client";

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';

interface PendingBrand {
    key: string; // local-only temp key
    name: string;
    website: string;
    brandSku: string;
    logoUrl: string;
    isActive: boolean;
}

export default function NewManufacturerClient() {
    const router = useRouter();
    const [isSaving, setIsSaving] = useState(false);

    // ── Manufacturer fields ──────────────────────────────────────
    const [name, setName] = useState('');
    const [prefix, setPrefix] = useState('');
    const [website, setWebsite] = useState('');
    const [country, setCountry] = useState('US');
    const [description, setDescription] = useState('');
    const [logoUrl, setLogoUrl] = useState('');
    const [status, setStatus] = useState('WISHLIST');
    const [devNotes, setDevNotes] = useState('');

    // ── Upload state ─────────────────────────────────────────────
    const [isUploading, setIsUploading] = useState(false);

    const handleFileUpload = async (
        e: React.ChangeEvent<HTMLInputElement>,
        setUrl: (url: string) => void
    ) => {
        if (!e.target.files || e.target.files.length === 0) return;
        const file = e.target.files[0];
        setIsUploading(true);
        const formData = new FormData();
        formData.append('file', file);
        formData.append('folder', 'logos');
        try {
            const res = await fetch('/api/upload', { method: 'POST', body: formData });
            if (!res.ok) throw new Error('Upload failed');
            const data = await res.json();
            setUrl(data.url);
        } catch (error: any) {
            alert(error.message);
        } finally {
            setIsUploading(false);
            e.target.value = '';
        }
    };

    // ── Pending brands (local, not yet saved) ────────────────────
    const [pendingBrands, setPendingBrands] = useState<PendingBrand[]>([]);
    const [editingKey, setEditingKey] = useState<string | null>(null);
    const [isAddingBrand, setIsAddingBrand] = useState(false);

    // Brand form fields
    const [bName, setBName] = useState('');
    const [bWebsite, setBWebsite] = useState('');
    const [bBrandSku, setBBrandSku] = useState('');
    const [bLogoUrl, setBLogoUrl] = useState('');
    const [bIsActive, setBIsActive] = useState(true);

    const openAddBrand = () => {
        setEditingKey(null);
        setIsAddingBrand(true);
        // Pre-fill from manufacturer fields as a convenience
        setBName(name);
        setBWebsite(website);
        setBBrandSku(prefix);
        setBLogoUrl(logoUrl);
        setBIsActive(true);
    };

    const openEditBrand = (brand: PendingBrand) => {
        setEditingKey(brand.key);
        setIsAddingBrand(false);
        setBName(brand.name);
        setBWebsite(brand.website);
        setBBrandSku(brand.brandSku);
        setBLogoUrl(brand.logoUrl);
        setBIsActive(brand.isActive);
    };

    const cancelBrandForm = () => {
        setEditingKey(null);
        setIsAddingBrand(false);
    };

    const savePendingBrand = (e: React.FormEvent) => {
        e.preventDefault();
        if (isAddingBrand) {
            setPendingBrands(prev => [
                ...prev,
                {
                    key: `brand-${Date.now()}`,
                    name: bName,
                    website: bWebsite,
                    brandSku: bBrandSku,
                    logoUrl: bLogoUrl,
                    isActive: bIsActive,
                },
            ]);
        } else if (editingKey) {
            setPendingBrands(prev =>
                prev.map(b =>
                    b.key === editingKey
                        ? { ...b, name: bName, website: bWebsite, brandSku: bBrandSku, logoUrl: bLogoUrl, isActive: bIsActive }
                        : b
                )
            );
        }
        cancelBrandForm();
    };

    const removePendingBrand = (key: string) => {
        setPendingBrands(prev => prev.filter(b => b.key !== key));
    };

    // ── Submit ───────────────────────────────────────────────────
    const handleSave = async (e: React.FormEvent) => {
        e.preventDefault();
        setIsSaving(true);
        try {
            // 1. Create the manufacturer
            const mfrRes = await fetch('/api/manufacturers', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ name, prefix, website, country, description, logoUrl, devNotes, status }),
            });
            if (!mfrRes.ok) {
                const data = await mfrRes.json();
                throw new Error(data.error || 'Failed to create manufacturer');
            }
            const { data: manufacturer } = await mfrRes.json();

            // 2. Determine which brands to create
            const brandsToCreate =
                pendingBrands.length > 0
                    ? pendingBrands
                    : [
                          // Auto-create one brand mirroring the manufacturer
                          {
                              key: 'auto',
                              name,
                              website,
                              brandSku: prefix,
                              logoUrl,
                              isActive: true,
                          },
                      ];

            // 3. Create each brand
            for (const brand of brandsToCreate) {
                const brandRes = await fetch('/api/brands', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        name: brand.name,
                        website: brand.website || null,
                        brandSku: brand.brandSku || null,
                        logoUrl: brand.logoUrl || null,
                        isActive: brand.isActive,
                        manufacturerId: manufacturer.id,
                    }),
                });
                if (!brandRes.ok) {
                    const data = await brandRes.json();
                    throw new Error(data.error || `Failed to create brand "${brand.name}"`);
                }
            }

            router.push('/admin/manufacturers');
            router.refresh();
        } catch (err: any) {
            alert(err.message);
        } finally {
            setIsSaving(false);
        }
    };

    return (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '2rem' }}>

            {/* ── Page header ───────────────────────────────── */}
            <div className="page-header pb-6 border-b border-[var(--color-border)]">
                <div>
                    <h2 className="page-title">Add Manufacturer</h2>
                    <p className="page-subtitle">Create a new parent company with brands and integration tracker</p>
                </div>
                <Link href="/admin/manufacturers" className="btn btn-ghost text-sm">
                    ← Manufacturers
                </Link>
            </div>

            {/* ── Manufacturer Info form ─────────────────────── */}
            <form onSubmit={handleSave} id="new-manufacturer-form" className="card p-6" style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
                <h3 className="font-semibold text-lg pb-2 border-b border-[var(--color-border)]">Manufacturer Info</h3>

                <div style={{ display: 'flex', gap: '1.5rem', alignItems: 'flex-start' }}>
                    {/* Logo upload */}
                    <div style={{ width: '150px', flexShrink: 0 }}>
                        <div style={{ width: '150px', height: '150px', border: '1px dashed var(--color-border)', borderRadius: 'var(--radius-md)', display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'var(--color-bg-elevated)', overflow: 'hidden' }}>
                            {logoUrl ? (
                                <img src={logoUrl} alt="Logo" style={{ width: '100%', height: '100%', objectFit: 'contain', padding: '0.5rem' }} />
                            ) : (
                                <span style={{ color: 'var(--color-text-muted)', fontSize: '13px' }}>No Logo</span>
                            )}
                        </div>
                        <label className="btn btn-secondary btn-sm" style={{ marginTop: '0.5rem', width: '100%', textAlign: 'center', cursor: 'pointer' }}>
                            {isUploading ? 'Uploading...' : 'Upload Logo'}
                            <input type="file" accept="image/*" style={{ display: 'none' }} onChange={e => handleFileUpload(e, setLogoUrl)} disabled={isUploading} />
                        </label>
                        {logoUrl && (
                            <button type="button" className="btn btn-ghost btn-sm w-full mt-1 text-[var(--color-danger)]" onClick={() => setLogoUrl('')}>Remove</button>
                        )}
                    </div>

                    {/* Fields grid */}
                    <div style={{ flex: 1, display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1.5rem' }}>
                        {/* Name + Prefix row */}
                        <div style={{ gridColumn: '1 / -1', display: 'grid', gridTemplateColumns: '2fr 1fr', gap: '1.5rem' }}>
                            <div>
                                <label className="block text-sm font-semibold mb-2">Company Name *</label>
                                <input type="text" className="form-input w-full" value={name} onChange={e => setName(e.target.value)} placeholder="e.g. Hearth & Home Technologies" required />
                            </div>
                            <div>
                                <label className="block text-sm font-semibold mb-2">Prefix</label>
                                <input type="text" className="form-input w-full" value={prefix} onChange={e => setPrefix(e.target.value)} placeholder="e.g. HGL" maxLength={10} />
                            </div>
                        </div>

                        <div>
                            <label className="block text-sm font-semibold mb-2">Website</label>
                            <input type="url" className="form-input w-full" value={website} onChange={e => setWebsite(e.target.value)} placeholder="https://" />
                        </div>
                        <div>
                            <label className="block text-sm font-semibold mb-2">Country</label>
                            <select className="form-select w-full" value={country} onChange={e => setCountry(e.target.value)}>
                                <option value="US">United States</option>
                                <option value="CA">Canada</option>
                                <option value="EU">Europe</option>
                                <option value="OTHER">Other</option>
                            </select>
                        </div>

                        <div>
                            <label className="block text-sm font-semibold mb-2">Integration Status</label>
                            <select className="form-select w-full" value={status} onChange={e => setStatus(e.target.value)}>
                                <option value="WISHLIST">Wishlist</option>
                                <option value="IN_PROGRESS">In Progress</option>
                                <option value="ACTIVE">Active</option>
                                <option value="PAUSED">Paused</option>
                                <option value="FAILED">Failed</option>
                            </select>
                        </div>

                        <div style={{ gridColumn: '1 / -1' }}>
                            <label className="block text-sm font-semibold mb-2">Description</label>
                            <textarea className="form-textarea w-full" rows={3} value={description} onChange={e => setDescription(e.target.value)} placeholder="Brief description of the manufacturer..." />
                        </div>

                        <div style={{ gridColumn: '1 / -1' }}>
                            <label className="block text-sm font-semibold mb-2">Developer Notes</label>
                            <textarea className="form-textarea w-full" rows={2} value={devNotes} onChange={e => setDevNotes(e.target.value)} placeholder="Scraping instructions, API endpoints, contacts..." />
                        </div>
                    </div>
                </div>
            </form>

            {/* ── Brands section ────────────────────────────── */}
            <div className="card p-6">
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem', paddingBottom: '0.5rem', borderBottom: '1px solid var(--color-border)' }}>
                    <div>
                        <h3 className="font-semibold text-lg">Brands ({pendingBrands.length})</h3>
                        {pendingBrands.length === 0 && (
                            <p style={{ fontSize: 'var(--font-size-xs)', color: 'var(--color-text-muted)', marginTop: '2px' }}>
                                No brands added — a brand will be auto-created from the manufacturer info on save.
                            </p>
                        )}
                    </div>
                    <button type="button" className="btn btn-secondary btn-sm" onClick={openAddBrand}>+ Add Brand</button>
                </div>

                {/* Inline brand form */}
                {(isAddingBrand || editingKey) && (
                    <form onSubmit={savePendingBrand} style={{ background: 'var(--color-bg-elevated)', border: '1px solid var(--color-border)', borderRadius: 'var(--radius-md)', padding: '1.5rem', marginBottom: '1.5rem' }}>
                        <h4 className="font-semibold mb-4">{isAddingBrand ? 'Add Brand' : 'Edit Brand'}</h4>

                        <div style={{ display: 'flex', gap: '1.5rem', alignItems: 'flex-start' }}>
                            {/* Brand logo */}
                            <div style={{ width: '100px', flexShrink: 0 }}>
                                <div style={{ width: '100px', height: '100px', border: '1px dashed var(--color-border)', borderRadius: 'var(--radius-sm)', display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'var(--color-bg)', overflow: 'hidden' }}>
                                    {bLogoUrl ? (
                                        <img src={bLogoUrl} alt="Logo" style={{ width: '100%', height: '100%', objectFit: 'contain', padding: '0.25rem' }} />
                                    ) : (
                                        <span style={{ color: 'var(--color-text-muted)', fontSize: '11px' }}>No Logo</span>
                                    )}
                                </div>
                                <label className="btn btn-secondary btn-sm" style={{ marginTop: '0.5rem', width: '100%', textAlign: 'center', cursor: 'pointer', padding: '0.2rem', fontSize: '11px' }}>
                                    {isUploading ? '...' : 'Upload Logo'}
                                    <input type="file" accept="image/*" style={{ display: 'none' }} onChange={e => handleFileUpload(e, setBLogoUrl)} disabled={isUploading} />
                                </label>
                                {bLogoUrl && (
                                    <button type="button" className="btn btn-ghost btn-sm w-full text-[var(--color-danger)]" style={{ fontSize: '11px', padding: 0 }} onClick={() => setBLogoUrl('')}>Remove</button>
                                )}
                            </div>

                            <div style={{ flex: 1, display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
                                <div>
                                    <label className="block text-xs font-semibold mb-1">Brand Name *</label>
                                    <input type="text" className="form-input w-full" style={{ padding: '0.4rem' }} value={bName} onChange={e => setBName(e.target.value)} required />
                                </div>
                                <div>
                                    <label className="block text-xs font-semibold mb-1">SKU Prefix</label>
                                    <input type="text" className="form-input w-full" style={{ padding: '0.4rem' }} value={bBrandSku} onChange={e => setBBrandSku(e.target.value)} placeholder="e.g. HGL" />
                                </div>
                                <div>
                                    <label className="block text-xs font-semibold mb-1">Website</label>
                                    <input type="url" className="form-input w-full" style={{ padding: '0.4rem' }} value={bWebsite} onChange={e => setBWebsite(e.target.value)} placeholder="https://" />
                                </div>
                                <div>
                                    <label className="block text-xs font-semibold mb-1">Status</label>
                                    <select className="form-select w-full" style={{ padding: '0.4rem' }} value={bIsActive ? 'true' : 'false'} onChange={e => setBIsActive(e.target.value === 'true')}>
                                        <option value="true">Active</option>
                                        <option value="false">Inactive</option>
                                    </select>
                                </div>
                            </div>
                        </div>

                        <div style={{ display: 'flex', gap: '0.5rem', justifyContent: 'flex-end', marginTop: '1.5rem' }}>
                            <button type="button" className="btn btn-ghost" onClick={cancelBrandForm}>Cancel</button>
                            <button type="submit" className="btn btn-primary">
                                {isAddingBrand ? 'Add Brand' : 'Update Brand'}
                            </button>
                        </div>
                    </form>
                )}

                {/* Pending brands table */}
                {pendingBrands.length > 0 ? (
                    <table className="data-table">
                        <thead>
                            <tr>
                                <th>Logo</th>
                                <th>Brand Name</th>
                                <th>SKU</th>
                                <th>Website</th>
                                <th>Status</th>
                                <th style={{ textAlign: 'right' }}>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            {pendingBrands.map(brand => (
                                <tr key={brand.key}>
                                    <td style={{ width: '60px' }}>
                                        {brand.logoUrl ? (
                                            <img src={brand.logoUrl} alt="Logo" style={{ width: '40px', height: '40px', objectFit: 'contain', background: 'white', borderRadius: '4px' }} />
                                        ) : (
                                            <div style={{ width: '40px', height: '40px', background: 'var(--color-bg-elevated)', borderRadius: '4px', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '10px', color: 'var(--color-text-muted)' }}>None</div>
                                        )}
                                    </td>
                                    <td className="font-semibold">{brand.name}</td>
                                    <td>{brand.brandSku || '—'}</td>
                                    <td>{brand.website || '—'}</td>
                                    <td>
                                        <span className={`badge ${brand.isActive ? 'badge-active' : 'badge-inactive'}`}>
                                            {brand.isActive ? 'Active' : 'Inactive'}
                                        </span>
                                    </td>
                                    <td style={{ textAlign: 'right' }}>
                                        <div style={{ display: 'flex', gap: 'var(--space-2)', justifyContent: 'flex-end' }}>
                                            <button type="button" className="btn btn-sm btn-ghost" onClick={() => openEditBrand(brand)}>Edit</button>
                                            <button type="button" className="btn btn-sm btn-ghost" style={{ color: 'var(--color-danger)' }} onClick={() => removePendingBrand(brand.key)}>Remove</button>
                                        </div>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                ) : (
                    <div style={{ padding: '1.5rem', textAlign: 'center', color: 'var(--color-text-muted)', fontSize: 'var(--font-size-sm)', border: '1px dashed var(--color-border)', borderRadius: 'var(--radius-md)' }}>
                        No brands added yet — saving will auto-create one using the manufacturer info above.
                    </div>
                )}
            </div>

            {/* ── Save footer ───────────────────────────────── */}
            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 'var(--space-3)', paddingBottom: '2rem' }}>
                <Link href="/admin/manufacturers" className="btn btn-ghost">Cancel</Link>
                <button type="submit" form="new-manufacturer-form" className="btn btn-primary" disabled={isSaving}>
                    {isSaving ? 'Creating...' : 'Create Manufacturer & Brands'}
                </button>
            </div>
        </div>
    );
}
