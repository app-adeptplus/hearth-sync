import NewManufacturerClient from './NewManufacturerClient';

export default function NewManufacturerPage() {
    return <NewManufacturerClient />;
}
