import prisma from '@/lib/db';
import Link from 'next/link';
import ExportManufacturersModal from './ExportManufacturersModal';

async function getManufacturers(searchParams: Record<string, string | string[] | undefined>) {
    try {
        const where: Record<string, any> = {};
        const q = Array.isArray(searchParams.q) ? searchParams.q[0] : searchParams.q;
        const status = Array.isArray(searchParams.status) ? searchParams.status[0] : searchParams.status;

        if (q) {
            where.name = { contains: q, mode: 'insensitive' };
        }
        if (status) {
            where.integrations = { some: { status } };
        }

        return await prisma.manufacturer.findMany({
            where,
            orderBy: { name: 'asc' },
            include: {
                brands: {
                    select: {
                        id: true,
                        name: true,
                        isActive: true,
                        _count: { select: { products: true } },
                    },
                },
                integrations: true,
                _count: { select: { brands: true } },
            },
        });
    } catch {
        return [];
    }
}

export default async function ManufacturersPage({
    searchParams,
}: {
    searchParams: Record<string, string | string[] | undefined>;
}) {
    const manufacturers = await getManufacturers(searchParams);

    const statusBadge = (status: string) => {
        const map: Record<string, string> = {
            ACTIVE: 'active',
            IN_PROGRESS: 'warning',
            WISHLIST: 'info',
            PAUSED: 'inactive',
            FAILED: 'danger',
        };
        return map[status] || 'inactive';
    };

    return (
        <>
            <div className="page-header">
                <div>
                    <h2 className="page-title">Manufacturers</h2>
                    <p className="page-subtitle">
                        {manufacturers.length} manufacturers tracked · Integration status
                        and catalog management
                    </p>
                </div>
                <div style={{ display: 'flex', gap: 'var(--space-3)' }}>
                    <ExportManufacturersModal />
                    <Link href="/admin/manufacturers/new" className="btn btn-primary">
                        + Add Manufacturer
                    </Link>
                </div>
            </div>

            {/* Filters Row */}
            <div style={{ display: 'flex', gap: 'var(--space-4)', marginBottom: 'var(--space-6)', flexWrap: 'wrap' }}>
                <form style={{ display: 'flex', gap: 'var(--space-3)', flex: 1 }}>
                    <input
                        type="text"
                        name="q"
                        className="form-input"
                        placeholder="Search by manufacturer name..."
                        defaultValue={Array.isArray(searchParams.q) ? searchParams.q[0] : searchParams.q}
                        style={{ maxWidth: '350px' }}
                    />
                    <select
                        name="status"
                        className="form-select"
                        defaultValue={Array.isArray(searchParams.status) ? searchParams.status[0] : searchParams.status}
                        style={{ maxWidth: '160px' }}
                    >
                        <option value="">All Status</option>
                        <option value="ACTIVE">Active</option>
                        <option value="IN_PROGRESS">In Progress</option>
                        <option value="WISHLIST">Wishlist</option>
                        <option value="PAUSED">Paused</option>
                        <option value="FAILED">Failed</option>
                    </select>

                    <button type="submit" className="btn btn-secondary">
                        Filter
                    </button>
                    <Link href="/admin/manufacturers" className="btn btn-ghost" style={{ padding: 'var(--space-2) var(--space-3)' }}>
                        Clear
                    </Link>
                </form>
            </div>

            <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
                <table className="data-table">
                    <thead>
                        <tr>
                            <th style={{ width: '56px' }}></th>
                            <th>Manufacturer</th>
                            <th style={{ width: '60px' }}>Brands</th>
                            <th>Brand List</th>
                            <th style={{ width: '110px' }}>Status</th>
                            <th style={{ width: '100px' }}>Est. Products</th>
                            <th style={{ width: '70px' }}></th>
                        </tr>
                    </thead>
                    <tbody>
                        {manufacturers.length === 0 ? (
                            <tr>
                                <td colSpan={7}>
                                    <div className="empty-state">
                                        <h3>No manufacturers yet</h3>
                                        <p>
                                            Run the database seed to populate manufacturer data from
                                            the existing brand list.
                                        </p>
                                    </div>
                                </td>
                            </tr>
                        ) : (
                            manufacturers.map((mfr: any) => {
                                const totalProducts = mfr.brands.reduce((sum: number, b: any) => sum + (b._count?.products ?? 0), 0);
                                const integration = mfr.integrations[0];
                                return (
                                    <tr key={mfr.id}>
                                        <td style={{ width: '56px', paddingRight: '0.25rem' }}>
                                            {mfr.logoUrl ? (
                                                <img
                                                    src={mfr.logoUrl}
                                                    alt={mfr.name}
                                                    style={{
                                                        width: '40px',
                                                        height: '40px',
                                                        objectFit: 'contain',
                                                        background: '#fff',
                                                        borderRadius: 'var(--radius-sm)',
                                                        padding: '3px',
                                                        display: 'block',
                                                    }}
                                                />
                                            ) : (
                                                <div style={{
                                                    width: '40px',
                                                    height: '40px',
                                                    borderRadius: 'var(--radius-sm)',
                                                    background: 'var(--color-bg-elevated)',
                                                    border: '1px solid var(--color-border)',
                                                    display: 'flex',
                                                    alignItems: 'center',
                                                    justifyContent: 'center',
                                                    fontSize: '14px',
                                                    fontWeight: 700,
                                                    color: 'var(--color-text-muted)',
                                                }}>
                                                    {mfr.name.charAt(0).toUpperCase()}
                                                </div>
                                            )}
                                        </td>
                                        <td>
                                            <Link
                                                href={`/admin/manufacturers/${mfr.id}`}
                                                style={{
                                                    fontWeight: 600,
                                                    color: 'var(--color-text-primary)',
                                                }}
                                            >
                                                {mfr.name}
                                            </Link>
                                            {mfr.website && (
                                                <div
                                                    style={{
                                                        fontSize: 'var(--font-size-xs)',
                                                        color: 'var(--color-text-muted)',
                                                    }}
                                                >
                                                    {mfr.website}
                                                </div>
                                            )}
                                        </td>
                                        <td>
                                            <span
                                                style={{
                                                    fontWeight: 600,
                                                    color: 'var(--color-amber)',
                                                }}
                                            >
                                                {mfr._count.brands}
                                            </span>
                                        </td>
                                        <td>
                                            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.25rem' }}>
                                                {mfr.brands.length > 0 ? mfr.brands.map((b: any) => (
                                                    <span
                                                        key={b.id}
                                                        style={{
                                                            display: 'inline-block',
                                                            fontSize: 'var(--font-size-xs)',
                                                            padding: '0.15rem 0.5rem',
                                                            borderRadius: 'var(--radius-full)',
                                                            background: 'var(--color-bg-elevated)',
                                                            border: '1px solid var(--color-border)',
                                                            color: b.isActive ? 'var(--color-text-secondary)' : 'var(--color-text-muted)',
                                                            opacity: b.isActive ? 1 : 0.6,
                                                        }}
                                                    >
                                                        {b.name}
                                                    </span>
                                                )) : <span style={{ color: 'var(--color-text-muted)', fontSize: 'var(--font-size-xs)' }}>—</span>}
                                            </div>
                                        </td>
                                        <td>
                                            <span
                                                className={`badge badge-${statusBadge(integration?.status || 'WISHLIST')}`}
                                            >
                                                {integration?.status || 'WISHLIST'}
                                            </span>
                                        </td>
                                        <td style={{ fontWeight: 600, color: totalProducts > 0 ? 'var(--color-text-primary)' : 'var(--color-text-muted)' }}>
                                            {totalProducts > 0 ? totalProducts.toLocaleString() : '—'}
                                        </td>
                                        <td>
                                            <Link
                                                href={`/admin/manufacturers/${mfr.id}/edit`}
                                                className="btn btn-secondary btn-sm"
                                            >
                                                Edit
                                            </Link>
                                        </td>
                                    </tr>
                                );
                            })
                        )}
                    </tbody>
                </table>
            </div>
        </>
    );
}
