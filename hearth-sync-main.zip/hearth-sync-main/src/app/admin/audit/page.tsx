import prisma from '@/lib/db';
import Link from 'next/link';

export const dynamic = 'force-dynamic';

export default async function AuditLogPage() {
    const logs = await prisma.auditLog.findMany({
        orderBy: { createdAt: 'desc' },
        take: 100,
        include: {
            product: {
                select: { name: true, brand: { select: { name: true } } }
            }
        }
    });

    return (
        <div className="space-y-6">
            <div className="page-header pb-6 border-b border-[var(--border)] mb-6">
                <div>
                    <h2 className="text-2xl font-bold">System Audit Log</h2>
                    <p className="text-[var(--text-secondary)] mt-1">
                        Timeline of recent entity changes (top 100 entries)
                    </p>
                </div>
            </div>

            <div className="card p-0 overflow-hidden rounded-lg border border-[var(--color-border)]">
                <table className="data-table">
                    <thead>
                        <tr>
                            <th style={{ width: '150px' }}>Date</th>
                            <th style={{ width: '100px' }}>Action</th>
                            <th>Entity Type</th>
                            <th>Entity</th>
                            <th>Changed By</th>
                            <th>Details</th>
                        </tr>
                    </thead>
                    <tbody>
                        {logs.map((log: any) => {
                            const isCreation = log.action === 'CREATED';
                            const isDeletion = log.action === 'DELETED';
                            const isDiscontinued = log.action === 'DISCONTINUED';

                            let badgeClass = 'badge-info';
                            if (isCreation) badgeClass = 'badge-active';
                            else if (isDeletion || isDiscontinued) badgeClass = 'badge-danger';

                            return (
                                <tr key={log.id}>
                                    <td className="text-xs text-[var(--color-text-secondary)] whitespace-nowrap">
                                        {new Date(log.createdAt).toLocaleString()}
                                    </td>
                                    <td>
                                        <span className={`badge ${badgeClass} uppercase text-[10px] px-2 py-0.5 rounded-sm font-semibold tracking-wider`}>
                                            {log.action}
                                        </span>
                                    </td>
                                    <td className="text-sm font-medium text-[var(--color-text-primary)] capitalize">
                                        {log.entityType}
                                    </td>
                                    <td className="text-sm font-medium">
                                        {log.product?.brand?.name} {log.product?.name || log.entityId}
                                    </td>
                                    <td className="font-mono text-[10px] text-[var(--color-text-secondary)]">
                                        {log.changedBy || 'system'}
                                    </td>
                                    <td>
                                        {log.after && log.action === 'UPDATED' && (
                                            <div style={{ maxHeight: '100px', overflowY: 'auto', fontSize: 'var(--font-size-xs)', background: 'var(--color-bg)', padding: 'var(--space-2)', borderRadius: 'var(--radius-sm)', border: '1px solid var(--color-border)' }}>
                                                <pre style={{ whiteSpace: 'pre-wrap', color: 'var(--color-text-secondary)' }}>
                                                    {JSON.stringify(log.after, null, 2)}
                                                </pre>
                                            </div>
                                        )}
                                        {log.action === 'CREATED' && <span className="text-xs text-[var(--color-text-muted)]">Initial creation</span>}
                                        {log.action === 'DELETED' && <span className="text-xs text-[var(--color-text-muted)]">Record deleted</span>}
                                    </td>
                                </tr>
                            );
                        })}
                        {logs.length === 0 && (
                            <tr>
                                <td colSpan={6} className="p-12 text-center text-[var(--color-text-secondary)]">
                                    No audit logs found.
                                </td>
                            </tr>
                        )}
                    </tbody>
                </table>
            </div>
        </div>
    );
}
