import Link from 'next/link';

export default function HomePage() {
    return (
        <div
            style={{
                minHeight: '100vh',
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                justifyContent: 'center',
                textAlign: 'center',
                padding: '2rem',
                background:
                    'radial-gradient(ellipse at top, #1a1a2e 0%, #0d1117 70%)',
            }}
        >
            <div style={{ marginBottom: '2rem' }}>
                <span style={{ fontSize: '3.5rem' }}>🔥</span>
            </div>
            <h1
                style={{
                    fontSize: '3rem',
                    fontWeight: 800,
                    marginBottom: '0.5rem',
                    background: 'linear-gradient(135deg, #e94560, #f4a261)',
                    WebkitBackgroundClip: 'text',
                    WebkitTextFillColor: 'transparent',
                }}
            >
                HearthSync
            </h1>
            <p
                style={{
                    fontSize: '1.25rem',
                    color: '#8b949e',
                    maxWidth: '600px',
                    marginBottom: '3rem',
                    lineHeight: 1.7,
                }}
            >
                Master product catalog platform for the hearth industry. Aggregating
                10,000+ products from 80+ manufacturers.
            </p>
            <div style={{ display: 'flex', gap: '1rem' }}>
                <Link
                    href="/admin-access-h8x2k9m4"
                    className="btn btn-primary"
                    style={{ padding: '0.75rem 2rem', fontSize: '1rem' }}
                >
                    Admin Dashboard →
                </Link>
            </div>
        </div>
    );
}
