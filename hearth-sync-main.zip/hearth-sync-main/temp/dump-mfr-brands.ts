import { PrismaClient } from '@prisma/client';
import * as fs from 'fs';

const prisma = new PrismaClient();

async function main() {
    const manufacturers = await prisma.manufacturer.findMany({
        include: {
            brands: {
                select: {
                    id: true,
                    name: true,
                    slug: true,
                    website: true,
                    logoUrl: true,
                    brandSku: true,
                    isActive: true,
                }
            }
        },
        orderBy: { name: 'asc' }
    });

    fs.writeFileSync('temp/current-mfr-brands.json', JSON.stringify(manufacturers, null, 2));
    console.log(`Exported ${manufacturers.length} manufacturers`);
    const totalBrands = manufacturers.reduce((acc, m) => acc + m.brands.length, 0);
    console.log(`Total brands: ${totalBrands}`);

    // Print summary
    for (const m of manufacturers) {
        console.log(`\n[MANUFACTURER] ${m.name} | website: ${m.website || 'NONE'} | logo: ${m.logoUrl ? 'YES' : 'NONE'}`);
        for (const b of m.brands) {
            console.log(`  [BRAND] ${b.name} | sku: ${b.brandSku || '?'} | website: ${b.website || 'NONE'} | logo: ${b.logoUrl ? 'YES' : 'NONE'}`);
        }
    }
}

main().catch(console.error).finally(() => prisma.$disconnect());
