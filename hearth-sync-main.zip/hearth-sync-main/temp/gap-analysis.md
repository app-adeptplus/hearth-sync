# Attribute & Category Gap Analysis — Final
*Live DB cross-referenced: 2026-03-20 | 90 attributes · 39 sub-categories*

---

## Category Gaps — RESOLVED

All previously suggested new categories are now covered by **existing categories + Fuel Type attribute**, using the same logic as Patio Heater:

| Previously Suggested | Resolution |
|---|---|
| Patio Heater | → `heater` + Fuel Type = Gas/Electric + Heater Style attribute |
| Gas Log Set | → `vented-log-sets` / `vent-free-log-sets` + Fuel Type = Gas |
| Pellet Grill | → `smoker` / `portable-cart` / `built-in` + Fuel Type = Pellet |
| Charcoal Grill | → `kamado` / `portable-cart` / `portable` / `built-in` + Fuel Type = Charcoal |
| Spark Screen | → `fireplace-screen` (already in DB) |

**No new categories need to be added.** ✅

---

## Truly Missing Attributes

These 16 attributes are confirmed **absent** from the live DB (verified against all 90 slugs).

### Hearth

| Name | Slug | Type | Unit | Options | Priority |
|---|---|---|---|---|---|
| Wood Sub-Type | `wood-sub-type` | select | — | Cord Wood, Manufactured Log, Bio-Brick | Medium |
| Convertible (NG⇄LP) | `convertible-ng-lp` | boolean | — | Yes / No | Medium |
| Conversion Kit Included | `conversion-kit-included` | boolean | — | Yes / No | Low |
| Co-Linear Capable | `co-linear-capable` | boolean | — | Yes / No | Low |

### Grills

| Name | Slug | Type | Unit | Options | Priority |
|---|---|---|---|---|---|
| Stainless Steel Grade | `stainless-steel-grade` | select | — | 304 SS, 430 SS, 201 SS | High |
| Lid Material | `lid-material` | select | — | Stainless Steel, Cast Aluminum, Porcelain-Coated Steel | Medium |
| Pellet Sub-Type | `pellet-sub-type` | select | — | Wood Pellet, Multi-Fuel | Low |

### Outdoor Living / Outdoor Kitchen

| Name | Slug | Type | Unit | Options | Priority |
|---|---|---|---|---|---|
| Island Configuration | `island-configuration` | select | — | Straight, L-Shape, U-Shape, Custom | High |
| Frame Material | `frame-material` | select | — | Stainless Steel, Aluminum, Concrete Block, GFRC, Polymer | High |
| Counter Material | `counter-material` | select | — | Granite, Concrete, Quartz, Porcelain, Stainless Steel, GFRC | High |
| Table Top Material | `table-top-material` | select | — | Concrete, Granite, Porcelain, Aluminum, Steel, Wicker, GFRC | Medium |
| Burner Included | `burner-included` | select | — | Included, Sold Separately | Medium |
| Sink Included | `sink-included` | boolean | — | Yes / No | Medium |
| Refrigerator Included | `refrigerator-included` | boolean | — | Yes / No | Medium |
| Refrigerator Volume | `refrigerator-volume` | number | cu ft | 0.5–5.5 | Low |
| Fuel Supply | `fuel-supply` | select | — | Tank (Propane), Natural Gas Line, Electric | Medium |

---

> **Also confirmed present** (were incorrectly listed as missing previously):
> `gas-sub-type`, `fuel-tank-location`, `fire-feature-style` (used instead of fire-pit-style),
> `assembly-required`, `blower-cfm`, `battery-backup-included`, `cover-included`,
> `hopper-capacity`, `ip-rating`, `log-set-size`, `max-temperature`, `portable`,
> `side-burner-btu`, `storage-cabinet`, `efficiency-type`, `emissions-g-hr`,
> `flame-color`, `vent-pipe-diameter`, `viewing-area`, `weather-resistance-rating`,
> `wifi-enabled`, `safety-shutoff`, `btu-input-min`, `mantel-compatible`
