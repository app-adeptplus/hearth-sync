/**
 * Migration: Apply website URLs and brand logos to existing manufacturers/brands
 * Uploads logo files from temp/logo-library to Supabase Storage, then
 * patches manufacturer and brand records via Prisma.
 *
 * Run: npx tsx temp/apply-logo-website-updates.ts
 */

import { PrismaClient } from '@prisma/client';
import { createClient } from '@supabase/supabase-js';
import * as fs from 'fs';
import * as path from 'path';
import * as dotenv from 'dotenv';

dotenv.config({ path: '.env' });

const prisma = new PrismaClient();

const SUPABASE_URL = process.env.NEXT_PUBLIC_SUPABASE_URL!;
const SUPABASE_SERVICE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY!;
const BUCKET = 'products';
const LOGO_DIR = path.resolve('temp/logo-library');

const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_KEY, {
    auth: { autoRefreshToken: false, persistSession: false },
});

const uploadedUrls: Record<string, string> = {};

async function uploadLogo(filename: string): Promise<string | null> {
    if (!filename) return null;
    if (uploadedUrls[filename]) return uploadedUrls[filename];

    const filePath = path.join(LOGO_DIR, filename);
    if (!fs.existsSync(filePath)) {
        console.warn(`  ⚠ Logo file not found: ${filename}`);
        return null;
    }
    const fileBuffer = fs.readFileSync(filePath);
    const ext = path.extname(filename).toLowerCase();
    const contentType = ext === '.webp' ? 'image/webp'
        : ext === '.png' ? 'image/png'
        : ext === '.jpg' || ext === '.jpeg' ? 'image/jpeg'
        : 'image/png';
    const storagePath = `logos/${Date.now()}_${filename.replace(/[^a-z0-9._-]/gi, '_')}`;

    const { error } = await supabase.storage.from(BUCKET).upload(storagePath, fileBuffer, {
        contentType,
        upsert: false,
    });
    if (error) {
        console.error(`  ✗ Failed to upload ${filename}:`, error.message);
        return null;
    }
    const { data } = supabase.storage.from(BUCKET).getPublicUrl(storagePath);
    const url = data.publicUrl;
    uploadedUrls[filename] = url;
    console.log(`  ✓ Uploaded ${filename} → ${url}`);
    return url;
}

// ─────────────────────────────────────────────────────────
// DATA DEFINITIONS
// ─────────────────────────────────────────────────────────

interface MfrUpdate {
    name: string; // Exact DB name for lookup
    website?: string;
    logoFile?: string;
}

interface BrandUpdate {
    slug: string; // Exact DB slug for lookup
    website?: string;
    logoFile?: string;
}

// Manufacturer-level updates (website + logo on the manufacturer record)
const MFR_UPDATES: MfrUpdate[] = [
    { name: 'Alfa Forni', logoFile: 'alfa-forni-logo.webp' },
    { name: 'Alfresco Grills', website: 'https://www.alfrescograills.com', logoFile: 'Alfresco-300px.png' },
    { name: 'Amantii Electric Fireplaces', logoFile: 'Amantii_300px.png' },
    { name: 'Ambiance Fireplaces', logoFile: 'ambiance-300px.png' },
    { name: 'Astria Fireplaces', logoFile: 'Astria-300px.png' },
    { name: 'Athena Stoves & Fireplaces', logoFile: 'athena-logo-300x300-1.png' },
    { name: 'Bear Mountain BBQ', logoFile: 'bear-mountain-logo-resized.png' },
    { name: 'Berlin Gardens', logoFile: 'berlin-gardens-logo-300x300-1.png' },
    { name: 'Big Green Egg', logoFile: 'BigGreenEgg-300px.png' },
    { name: 'Blaze King', logoFile: 'blaze-king-300px.png' },
    { name: 'Breeo', logoFile: 'Breeo_Logo_reverse-white-black-bkgrnd_300x300.jpg' },
    { name: 'Breezesta', website: 'https://www.breezesta.com' },
    { name: 'Broilmaster', website: 'https://www.broilmaster.com', logoFile: 'Broil-Master-Grills-300px.png' },
    { name: 'Bull Grills', website: 'https://www.bullbbq.com', logoFile: 'bull-logo-resized-v2.png' },
    { name: 'Casbella Outdoor', website: 'https://www.casabellaoutdoor.com', logoFile: 'ember-logo-resized.png' },
    { name: 'Castelle', website: 'https://www.castellefurniture.com' },
    { name: 'Comfort Bilt', website: 'https://urbanafireplaces.com/' },
    { name: 'Copperfield', website: 'https://www.ventisfireplaces.com' }, // Ventis/Copperfield
    { name: 'Dimplex', logoFile: 'Dimplex-300px.png' },
    { name: 'Dracme Mantel', website: 'https://www.dracme.com', logoFile: 'Dracme-300px.png' },
    { name: 'Earthcore', website: 'https://earthcore.com', logoFile: 'earthcore-logo_300x300.jpg' },
    { name: 'Elmira Stove Works', website: 'https://www.elmirastoveworks.com', logoFile: 'elmira-logo-resized.png' },
    { name: 'Empire Comfort Systems', logoFile: 'empire-comfort-logo_NEW_300x300.jpg' },
    { name: 'Enviro', logoFile: 'Enviro-300px.png' },
    { name: 'European Home', logoFile: 'europeanhome-300px.png' },
    { name: 'Firegear', website: 'https://www.firegear.com', logoFile: 'Firegear.png' },
    { name: 'Galtech International', website: 'https://www.galtech.com', logoFile: 'Galtech-Logo_trsp_300x300.png' },
    { name: 'Golden Blount', website: 'https://www.goldenblount.com', logoFile: 'GoldenBlount-300px.png' },
    { name: 'Grand Canyon Gas Logs', website: 'https://www.grandcanyongaslogs.com', logoFile: 'GrandCanyon-300px.png' },
    { name: 'Green Mountain', website: 'https://www.greenmountaingrills.com', logoFile: 'green-mountain-grills-300px.png' },
    { name: 'Hanamint', website: 'https://www.hanamint.com' },
    { name: 'Hargrove Premium Products', website: 'https://www.hargrovegas.com', logoFile: 'hargrove-300px.png' },
    { name: 'Hearth & Home Technologies', logoFile: 'HHT-300px.png' },
    { name: 'HearthStone', logoFile: 'Hearthstone-300px.png' },
    { name: 'Houe', website: 'https://www.houe.com' },
    { name: 'HPC Fire Inspired', website: 'https://www.hpcfire.com', logoFile: 'HPC-300px.png' },
    { name: 'Innovative Hearth Products', website: 'https://superiorfireplaces.us.com', logoFile: 'Superior-Fireplaces-Logo_300x300.jpg' },
    { name: 'Invicta', website: 'https://urbanafireplaces.com/' },
    { name: 'Jotul Group', logoFile: 'Jotul-300.png' },
    { name: 'Kingsman', website: 'https://kingsmanind.com', logoFile: 'Kingsman-300px.png' },
    { name: 'Kingsman Fireplaces', website: 'https://kingsmanind.com', logoFile: 'Kingsman-300px.png' },
    { name: 'Kozy Heat (Elmira Stove Works)', logoFile: 'KozyHeat-300px.png' },
    { name: 'Kuma', website: 'https://www.kumastoves.com', logoFile: 'kuma-300px.png' },
    { name: 'Lafuma', website: 'https://www.lafumamobilier.com' },
    { name: 'Llyod Flanders', website: 'https://www.lloydflanders.com' },
    { name: 'Memphis', website: 'https://memphisgrills.com', logoFile: 'Memphis-Grills-300px.png' },
    { name: 'Mendota Hearth', logoFile: 'mendota-300px.png' },
    { name: 'Mesa Precast', website: 'https://www.mesaprecast.com' },
    { name: 'MF Fire', website: 'https://www.mffire.com', logoFile: 'mffire-logo-resized.png' },
    { name: 'Miles Industries', logoFile: 'Regency-300px.png' }, // Parent company logo
    { name: 'Modern Flames', logoFile: 'ModernFlames-300px.png' },
    { name: 'Napoleon', logoFile: 'Napoleon-300px.png' },
    { name: 'North Cape', website: 'https://www.northcape.com' },
    { name: 'Novo-Specialty', website: 'https://www.novogrills.com', logoFile: 'novo-grills.png' },
    { name: 'O.W. Lee', website: 'https://www.owlee.com' },
    { name: 'Ortal Heat', logoFile: 'ortal-300px.png' },
    { name: 'Patio Heat and Shade', website: 'https://www.bromic.com', logoFile: 'bromic-logo_300x300.jpg' },
    { name: 'Patio Renaissance', website: 'https://www.patiorenaissance.com', logoFile: 'Renaissance-Fireplaces-300px.png' },
    { name: 'Piazzetta', website: 'https://www.piazzetta.com', logoFile: 'piazzetta-300px.png' },
    { name: 'Pitboss', website: 'https://www.pitboss-grills.com', logoFile: 'Pitboss-300px.png' },
    { name: 'Ratana', website: 'https://www.ratana.com' },
    { name: 'Ravelli', logoFile: 'Ravelli-300px.png' },
    { name: 'RH Peterson', logoFile: 'rh-peterson-logo_300x300.jpg' },
    { name: 'Royal Teak', website: 'https://www.royalteakcollection.com' },
    { name: 'SBI International', logoFile: 'osburn-300px.png' }, // Best representative logo
    { name: 'Seaside Casual Furniture', website: 'https://www.seasidecasual.com' },
    { name: 'Smokin Brothers', logoFile: 'Smokin-Brothers-300px.png' },
    { name: 'Stoll', website: 'https://www.stollindustries.com', logoFile: 'StollIndustriesOutdoorKitchen.png' },
    { name: 'Summerset Grills', website: 'https://www.summersetgrills.com', logoFile: 'Summerset-300px.png' },
    { name: 'Sunesta Awnings', website: 'https://www.sunesta.com' },
    { name: 'Supreme Fireplaces', website: 'https://www.supremefireplaces.ca', logoFile: 'Supreme-300px.png' },
    { name: 'Telescope', website: 'https://www.telescopecasual.com' },
    { name: 'The Outdoor Greatroom Company', website: 'https://www.outdoorrooms.com', logoFile: 'TheOutdoorGreatRoom-300px.png' },
    { name: 'Thelin', website: 'https://www.thelinco.com' },
    { name: 'Town & Country Luxury Fireplaces', website: 'https://www.tcfireplaces.com', logoFile: 'towncountry-300px.png' },
    { name: 'Travis Industries', logoFile: 'travis-300px.png' },
    { name: 'Treasure Garden', website: 'https://www.treasuregarden.com' },
    { name: 'True Residential', website: 'https://www.true-residential.com' },
    { name: 'Tulikivi', website: 'https://www.tulikivi.com', logoFile: 'Tulikivi_logo_300x300.jpg' },
    { name: 'Warming Trends', logoFile: '' }, // Already has website; no logo match
];

// Brand-level updates (keyed by unique DB slug)
const BRAND_UPDATES: BrandUpdate[] = [
    // Alfa Forni
    { slug: 'alfa-forni', website: 'https://www.alfaforni.com', logoFile: 'alfa-forni-logo.webp' },
    // Alfresco
    { slug: 'alfresco', website: 'https://www.alfrescograills.com', logoFile: 'Alfresco-300px.png' },
    { slug: 'artisan', website: 'https://alfrescogrills.com/artisan/', logoFile: 'Artisan-House-300px.png' },
    // Amantii
    { slug: 'amantii', website: 'https://www.amantii.com', logoFile: 'Amantii_300px.png' },
    // Ambiance
    { slug: 'ambiance', website: 'https://www.ambiancefireplaces.com', logoFile: 'ambiance-300px.png' },
    // Astria
    { slug: 'astria', website: 'https://www.astria.com', logoFile: 'Astria-300px.png' },
    // Athena
    { slug: 'athena-fireplace-stirling', website: 'https://www.athenafireplacesstirling.co.uk', logoFile: 'athena-logo-300x300-1.png' },
    // Bear Mountain BBQ
    { slug: 'bear-mountain-bbq-woods', logoFile: 'bear-mountain-logo-resized.png' },
    // Berlin Gardens
    { slug: 'berlin-gardens', logoFile: 'berlin-gardens-logo-300x300-1.png' },
    // Big Green Egg
    { slug: 'big-green-egg', logoFile: 'BigGreenEgg-300px.png' },
    // Blaze King
    { slug: 'blaze-king', website: 'https://www.blazeking.com', logoFile: 'blaze-king-300px.png' },
    // Breeo
    { slug: 'breeo', logoFile: 'Breeo_Logo_reverse-white-black-bkgrnd_300x300.jpg' },
    // Breezesta
    { slug: 'breezesta', website: 'https://www.breezesta.com' },
    // Broilmaster
    { slug: 'broilmaster', website: 'https://www.broilmaster.com', logoFile: 'Broil-Master-Grills-300px.png' },
    // Bull Grills
    { slug: 'bull-grills', website: 'https://www.bullbbq.com', logoFile: 'bull-logo-resized-v2.png' },
    // Casbella
    { slug: 'casbella-outdoor', website: 'https://www.casabellaoutdoor.com', logoFile: 'ember-logo-resized.png' },
    // Castelle
    { slug: 'castelle', website: 'https://www.castellefurniture.com' },
    // Comfort Bilt
    { slug: 'comfort-bilt', website: 'https://urbanafireplaces.com/' },
    // Ventis (under Copperfield)
    { slug: 'ventis', website: 'https://www.ventisfireplaces.com', logoFile: 'Ventis-300px.png' },
    // Dimplex
    { slug: 'dimplex', website: 'https://www.dimplex.com', logoFile: 'Dimplex-300px.png' },
    // Dracme Mantel
    { slug: 'dracme-mantel', website: 'https://www.dracme.com', logoFile: 'Dracme-300px.png' },
    // Earthcore
    { slug: 'earthcore', website: 'https://earthcore.com', logoFile: 'earthcore-logo_300x300.jpg' },
    { slug: 'earthcore-isokern', logoFile: 'earthcore-logo_300x300.jpg' },
    // Elmira
    { slug: 'elmira', website: 'https://www.elmirastoveworks.com', logoFile: 'elmira-logo-resized.png' },
    // Empire brands
    { slug: 'white-mountain-hearth', logoFile: 'WhiteMountainHearth-300px.png' },
    { slug: 'empire-stove', logoFile: 'empire-comfort-logo_NEW_300x300.jpg' },
    { slug: 'plaza-luxury-fireplaces', website: 'https://www.plazafireplace.com/' },
    { slug: 'american-hearth', logoFile: 'AmericanHeath-300px.png' },
    { slug: 'montigo', website: 'https://www.montigo.com', logoFile: 'Montigo-300px.png' }, // Under Empire Comfort Systems in DB
    // Enviro brands
    { slug: 'enviro', website: 'https://www.enviro.com', logoFile: 'Enviro-300px.png' },
    { slug: 'uptown-electric-fireplaces', website: 'https://www.uptownfireplaces.com', logoFile: 'uptown-logo-resized.png' },
    { slug: 'urbana', website: 'https://www.urbanafireplaces.com', logoFile: 'Urbana-Luxry-Fireplaces-300px.png' },
    // European Home
    { slug: 'european-home', website: 'https://www.europeanhome.com', logoFile: 'EuropeanHomes.png' },
    // Firegear
    { slug: 'firegear', website: 'https://www.firegear.com', logoFile: 'Firegear.png' },
    // Galtech
    { slug: 'galtech', website: 'https://www.galtech.com', logoFile: 'Galtech-Logo_trsp_300x300.png' },
    // Golden Blount
    { slug: 'golden-blount', website: 'https://www.goldenblount.com', logoFile: 'GoldenBlount-300px.png' },
    // Grand Canyon
    { slug: 'grand-canyon-gas-logs', website: 'https://www.grandcanyongaslogs.com', logoFile: 'GrandCanyon-300px.png' },
    // Green Mountain
    { slug: 'green-mountain-grills', website: 'https://www.greenmountaingrills.com', logoFile: 'green-mountain-grills-300px.png' },
    // Hanamint
    { slug: 'hanamint', website: 'https://www.hanamint.com' },
    // Hargrove
    { slug: 'hargrove', website: 'https://www.hargrovegas.com', logoFile: 'hargrove-300px.png' },
    // HHT brands
    { slug: 'harman', website: 'https://www.harmanstoves.com', logoFile: 'Harman-300px-FNF-01.png' },
    { slug: 'heat-and-glo', website: 'https://www.heatnglo.com', logoFile: 'heatglo-300px.png' },
    { slug: 'heatilator', website: 'https://www.heatilator.com', logoFile: 'Heatilator-300px.png' },
    { slug: 'heatilator-eco-choice', website: 'https://www.heatilator.com', logoFile: 'Heatilator-300px.png' },
    { slug: 'majestic', website: 'https://www.majesticproducts.com', logoFile: 'Majestic-300px.png' },
    { slug: 'monessen', website: 'https://www.monessenco.com', logoFile: 'Monessen-logo_300x300.png' },
    { slug: 'outdoor-lifestyles', website: 'https://www.outdoorlifestylesfireplaces.com', logoFile: 'Outdoor-Lifestyles-HHT_logo-white_300x300.jpg' },
    { slug: 'quadra-fire', website: 'https://www.quadrafire.com', logoFile: 'Quadra-Fire-300px-FNF-01.png' },
    { slug: 'simplifire', website: 'https://www.simplifire.com', logoFile: 'SimpliFire_300px.png' },
    { slug: 'vermont-castings', website: 'https://www.vermontcastings.com', logoFile: 'Vermont-Castings-300px-FNF-01.png' },
    // HearthStone
    { slug: 'heartstone', website: 'https://www.hearthstonestoves.com', logoFile: 'Hearthstone-300px.png' },
    // Houe
    { slug: 'houe', website: 'https://www.houe.com' },
    // HPC Fire
    { slug: 'hpc-fire-inspired', website: 'https://www.hpcfire.com', logoFile: 'HPC-300px.png' },
    // IHP / Superior
    { slug: 'superior-fireplaces', website: 'https://superiorfireplaces.us.com', logoFile: 'Superior-Fireplaces-Logo_300x300.jpg' },
    { slug: 'superior', logoFile: 'Superior-Fireplaces-Logo_300x300.jpg' },
    // Jotul
    { slug: 'jotul', website: 'https://www.jotul.com', logoFile: 'Jotul-300.png' },
    // Kingsman
    { slug: 'kingsman-fireplaces', website: 'https://kingsmanind.com/collection/fireplaces/', logoFile: 'Kingsman-300px.png' },
    { slug: 'kingsman', website: 'https://kingsmanind.com', logoFile: 'Kingsman-300px.png' },
    // Kozy Heat
    { slug: 'kozy-heat', website: 'https://www.kozyheat.com', logoFile: 'KozyHeat-300px.png' },
    // Kuma
    { slug: 'kuma', website: 'https://www.kumastoves.com', logoFile: 'kuma-300px.png' },
    // Lafuma
    { slug: 'lafuma', website: 'https://www.lafumamobilier.com' },
    // Llyod Flanders
    { slug: 'llyod-flanders', website: 'https://www.lloydflanders.com' },
    // Memphis
    { slug: 'memphis-wood-fire-grills', logoFile: 'Memphis-Grills-300px.png' },
    // Mendota
    { slug: 'mendota', website: 'https://www.mendotahearth.com', logoFile: 'mendota-300px.png' },
    // MF Fire
    { slug: 'mf-fire', website: 'https://www.mffire.com', logoFile: 'mffire-logo-resized.png' },
    // Miles Industries brands
    { slug: 'valor', website: 'https://www.valorfireplaces.com', logoFile: 'Valor-Fire-300px.png' },
    { slug: 'regency', website: 'https://www.regency-fire.com', logoFile: 'Regency-300px.png' },
    { slug: 'pacific-energy', website: 'https://www.pacificenergy.net', logoFile: 'pacific_energy.png' },
    { slug: 'true-north', website: 'https://www.truenorthstoves.com', logoFile: 'TrueNorth.png' },
    // Modern Flames
    { slug: 'modern-flames', website: 'https://www.modernflames.com', logoFile: 'ModernFlames-300px.png' },
    // Napoleon brands
    { slug: 'napoleon', website: 'https://www.napoleon.com/en/us/fireplaces', logoFile: 'Napoleon-300px.png' },
    { slug: 'napoleon-grills', logoFile: 'napoleangrills-300x300-1.png' },
    // Novo-Specialty
    { slug: 'novo', website: 'https://www.novogrills.com', logoFile: 'novo-grills.png' },
    { slug: 'novo-specialty', website: 'https://www.novogrills.com', logoFile: 'novo-grills.png' },
    // Ortal
    { slug: 'ortal', website: 'https://www.ortalheat.com', logoFile: 'ortal-300px.png' },
    // Patio Heat / Bromic  
    { slug: 'bromic-heating', website: 'https://www.bromic.com', logoFile: 'bromic-logo_300x300.jpg' },
    // Patio Renaissance
    { slug: 'patio-renaissance', website: 'https://www.patiorenaissance.com', logoFile: 'Renaissance-Fireplaces-300px.png' },
    // Piazzetta
    { slug: 'piazzetta', website: 'https://www.piazzetta.com', logoFile: 'piazzetta-300px.png' },
    { slug: 'piazzetta-fireplaces-and-stoves', website: 'https://www.piazzetta.com', logoFile: 'piazzetta-300px.png' },
    // Pitboss
    { slug: 'pitboss', website: 'https://www.pitboss-grills.com', logoFile: 'Pitboss-300px.png' },
    // Planika
    { slug: 'planika', website: 'https://www.planikafires.com' },
    // Ratana
    { slug: 'ratana', website: 'https://www.ratana.com' },
    // Ravelli
    { slug: 'ravelli', logoFile: 'Ravelli-300px.png' },
    // RH Peterson brands (already have website, add logos)
    { slug: 'fire-magic-grills', logoFile: 'FireMagic-300px.png' },
    { slug: 'real-fyre', logoFile: 'Real-Fyre-300px.png' },
    { slug: 'american-fyre-designs', logoFile: 'AmericanFyre-300px.png' },
    { slug: 'american-outdoor-grill', logoFile: 'American-Outdoor-Grill-300px.png' },
    // Royal Teak
    { slug: 'royal-teak', website: 'https://www.royalteakcollection.com' },
    // SBI International brands
    { slug: 'osburn', website: 'https://www.osburn-mfg.com', logoFile: 'osburn-300px.png' },
    { slug: 'valcourt', logoFile: 'valcourt-300px.png' }, // Keep existing website - DB is source of truth
    { slug: 'enerzone', website: 'https://www.enerzone.net', logoFile: 'enerzon-300px.png' },
    { slug: 'british-fires', logoFile: 'British-Fires.png' },
    // Seaside Casual
    { slug: 'seaside-casual', website: 'https://www.seasidecasual.com' },
    // Smokin Brothers
    { slug: 'smokin-brothers', logoFile: 'Smokin-Brothers-300px.png' },
    // Stoll
    { slug: 'stoll', website: 'https://www.stollindustries.com', logoFile: 'StollIndustriesOutdoorKitchen.png' },
    // Summerset
    { slug: 'summerset', website: 'https://www.summersetgrills.com', logoFile: 'Summerset-300px.png' },
    // Sunesta
    { slug: 'sunesta', website: 'https://www.sunesta.com' },
    // Supreme
    { slug: 'supreme', website: 'https://www.supremefireplaces.ca', logoFile: 'Supreme-300px.png' },
    // Telescope
    { slug: 'telescope', website: 'https://www.telescopecasual.com' },
    // The OGC
    { slug: 'the-outdoor-greatroom-company', website: 'https://www.outdoorrooms.com', logoFile: 'TheOutdoorGreatRoom-300px.png' },
    // Thelin
    { slug: 'thelin', website: 'https://www.thelinco.com' },
    // Town & Country
    { slug: 'town-and-country', website: 'https://www.tcfireplaces.com', logoFile: 'towncountry-300px.png' },
    // Travis Industries brands
    { slug: 'lopi', website: 'https://www.lopistoves.com', logoFile: 'lopi-300px.png' },
    { slug: 'fireplacex', website: 'https://www.fireplacex.com', logoFile: 'Fireplace-X-300px.png' },
    { slug: 'davinci', website: 'https://www.davincifireplaces.com', logoFile: 'DaVinci-300px.png' },
    { slug: 'tempest-torch', website: 'https://www.tempesttorch.com', logoFile: 'Tempest-Torch-300px.png' },
    // Treasure Garden
    { slug: 'treasure-garden', website: 'https://www.treasuregarden.com' },
    // True Residential
    { slug: 'true-residential', website: 'https://www.true-residential.com' },
    // Tulikivi
    { slug: 'tulikivi', website: 'https://www.tulikivi.com', logoFile: 'Tulikivi_logo_300x300.jpg' },
    // Woodard brand
    { slug: 'woodard', website: 'https://www.woodard.com' },
    // Harman standalone mfr brand (DB has "Harman" manufacturer with "Harmon" brand)
    { slug: 'harmon', website: 'https://www.harmanstoves.com', logoFile: 'harman-300px.png' },
    // O.W. Lee
    { slug: 'ow-lee', website: 'https://www.owlee.com' },
    // North Cape
    { slug: 'north-cape', website: 'https://www.northcape.com' },
    // Llyod Flanders brand
    { slug: 'llyod-flanders', website: 'https://www.lloydflanders.com' },
    // Mesa Precast
    { slug: 'mesa-precast', website: 'https://www.mesaprecast.com' },
    // Warming Trends brand (already has website)
];

// ─────────────────────────────────────────────────────────
// MAIN
// ─────────────────────────────────────────────────────────

async function run() {
    let mfrUpdated = 0, mfrSkipped = 0, brandUpdated = 0, brandSkipped = 0;

    console.log('\n=== MANUFACTURER UPDATES ===');
    for (const u of MFR_UPDATES) {
        const mfr = await prisma.manufacturer.findFirst({ where: { name: u.name } });
        if (!mfr) {
            console.log(`  [NOT FOUND] Manufacturer: ${u.name}`);
            mfrSkipped++;
            continue;
        }

        const data: Record<string, string | null> = {};

        if (u.website && !mfr.website) data.website = u.website;
        
        if (u.logoFile && !mfr.logoUrl) {
            const url = await uploadLogo(u.logoFile);
            if (url) data.logoUrl = url;
        }

        if (Object.keys(data).length === 0) {
            console.log(`  [SKIP] ${u.name} — already has website/logo`);
            mfrSkipped++;
            continue;
        }

        await prisma.manufacturer.update({ where: { id: mfr.id }, data });
        console.log(`  [OK] ${u.name} → ${JSON.stringify(Object.keys(data))}`);
        mfrUpdated++;
    }

    console.log('\n=== BRAND UPDATES ===');
    for (const u of BRAND_UPDATES) {
        const brand = await prisma.brand.findUnique({ where: { slug: u.slug } });
        if (!brand) {
            console.log(`  [NOT FOUND] Brand slug: ${u.slug}`);
            brandSkipped++;
            continue;
        }

        const data: Record<string, string | null> = {};

        if (u.website && !brand.website) data.website = u.website;

        if (u.logoFile && !brand.logoUrl) {
            const url = await uploadLogo(u.logoFile);
            if (url) data.logoUrl = url;
        }

        if (Object.keys(data).length === 0) {
            console.log(`  [SKIP] ${u.slug} — already has website/logo`);
            brandSkipped++;
            continue;
        }

        await prisma.brand.update({ where: { id: brand.id }, data });
        console.log(`  [OK] ${u.slug} → ${JSON.stringify(Object.keys(data))}`);
        brandUpdated++;
    }

    console.log(`\n=== DONE ===`);
    console.log(`Manufacturers: ${mfrUpdated} updated, ${mfrSkipped} skipped/not found`);
    console.log(`Brands: ${brandUpdated} updated, ${brandSkipped} skipped/not found`);
}

run()
    .catch(console.error)
    .finally(() => prisma.$disconnect());
